import Flutter
import UIKit

@main
@objc class AppDelegate: FlutterAppDelegate, UIDocumentPickerDelegate {
  private let downloadChannelName = "in.bastionhome.manager/downloads"
  private var pendingDownloadResult: FlutterResult?

  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    GeneratedPluginRegistrant.register(with: self)
    guard let controller = window?.rootViewController as? FlutterViewController else {
      return super.application(application, didFinishLaunchingWithOptions: launchOptions)
    }
    let channel = FlutterMethodChannel(
      name: downloadChannelName,
      binaryMessenger: controller.binaryMessenger
    )
    channel.setMethodCallHandler { [weak self] call, result in
      guard call.method == "saveFile" else {
        result(FlutterMethodNotImplemented)
        return
      }
      self?.presentDownloadPicker(call: call, result: result)
    }
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }

  private func presentDownloadPicker(call: FlutterMethodCall, result: @escaping FlutterResult) {
    guard pendingDownloadResult == nil else {
      result(FlutterError(
        code: "download_busy",
        message: "Another download is still in progress",
        details: nil
      ))
      return
    }
    guard
      let arguments = call.arguments as? [String: Any],
      let sourcePath = arguments["sourcePath"] as? String,
      FileManager.default.fileExists(atPath: sourcePath)
    else {
      result(FlutterError(
        code: "missing_download",
        message: "The generated download file is missing",
        details: nil
      ))
      return
    }

    guard let presenter = topViewController() else {
      result(FlutterError(
        code: "download_unavailable",
        message: "The Files save sheet is unavailable",
        details: nil
      ))
      return
    }
    pendingDownloadResult = result
    let picker = UIDocumentPickerViewController(
      forExporting: [URL(fileURLWithPath: sourcePath)],
      asCopy: true
    )
    picker.delegate = self
    picker.modalPresentationStyle = .formSheet
    presenter.present(picker, animated: true)
  }

  func documentPicker(
    _ controller: UIDocumentPickerViewController,
    didPickDocumentsAt urls: [URL]
  ) {
    let result = pendingDownloadResult
    pendingDownloadResult = nil
    result?(urls.first?.lastPathComponent ?? "Saved in Files")
  }

  func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
    let result = pendingDownloadResult
    pendingDownloadResult = nil
    result?(FlutterError(
      code: "download_cancelled",
      message: "The download was cancelled",
      details: nil
    ))
  }

  private func topViewController() -> UIViewController? {
    var current = window?.rootViewController
    while let presented = current?.presentedViewController {
      current = presented
    }
    return current
  }
}
