# Bastion Home Website Booking Integration

This integration lets the public website check room availability and confirm a
booking against the same calendar used by every connected phone.

## Activate the channel

1. Deploy all Supabase migrations and the `website-bookings` Edge Function as
   described in `CLOUD-SYNC-SETUP.md`.
2. In the mobile app, open **Settings > Website Bookings**.
3. Enter the exact HTTPS origin of the booking website, without a trailing
   slash, for example `https://www.bastionhome.example`.
4. Create a website key. Copy it immediately; the app deliberately shows a new
   key only once.
5. Store the service address and website key in the website's deployment
   configuration. Never use a Supabase secret or service-role key in browser
   code.

The website key is revocable and restricted to the configured website origin.
Creating a new key disables the old one. Administrators can pause all online
bookings from the same app page.

## Check availability

Send a `POST` request to the service address. Put the website key in the
`x-bastion-booking-key` header.

```json
{
  "action": "availability",
  "checkin": "2026-12-20",
  "checkout": "2026-12-23"
}
```

The response separates available and occupied rooms:

```json
{
  "availability": {
    "availableRooms": ["Room 1", "Room 3"],
    "occupiedRooms": ["Room 2", "Room 4", "Room 5"]
  }
}
```

## Confirm a booking

Always check availability first, then submit the selected room. The server
checks the room again inside the same protected database transaction used to
create the booking, so simultaneous requests cannot both take the room.

```json
{
  "action": "book",
  "room": "Room 1",
  "checkin": "2026-12-20",
  "checkout": "2026-12-23",
  "guestName": "Example Guest",
  "phone": "+91 90000 00000",
  "guests": 2,
  "address": "Guest address",
  "otherOccupants": "Second Guest Name",
  "idType": "Passport",
  "idNumber": "P1234567",
  "notes": "Late arrival"
}
```

`guestName`, `phone`, `idNumber`, `room`, `checkin`, and `checkout` are
required. Optional other occupant names are separated by line breaks. The
server stores only a masked ID number and does not accept ID photos. Staff can
capture the primary guest's ID securely at check-in. Tariff and payment amounts
are set in the app by authorized staff.

A successful request returns HTTP `201` with the booking reference. HTTP `409`
means the room became unavailable and the website should refresh availability.
HTTP `429` means the request limit was reached.

## Browser client

`website-integration/bastion-booking-client.js` is a small framework-independent
client. Configure it once and call `availability()` or `book()` from the
website's existing form. Do not print the website key in logs or analytics.

Online bookings arrive with **Source: Online** and **Processed by: Website**.
Bookings entered on a phone default to **Offline / Walk-in**. Connected phones
receive website bookings in real time; offline phones receive them on their
next synchronization.

## Operational rule

Keep the front-desk phone connected to Cloud Sync whenever internet is
available. The cloud database is the final authority for website conflicts. A
walk-in entered while a phone is fully offline cannot be visible to the website
until that phone reconnects.
