# Bastion Home Owner Setup

## Your phone

1. Install Bastion Home Manager 2.0.2.
2. Sign in with your existing approved cloud email and password.
3. If this is the first setup for the business, choose **First-Time Owner
   Setup** once. Do not use this option on an employee phone.
4. Create your private device PIN. Your app username is `admin`.
5. Open **Settings > Cloud Sync** and confirm that your role says **Protected
   primary owner**.

## Backup administrator

1. On your phone, open **Settings > Cloud Sync**.
2. Choose **Create Backup Administrator Invite**.
3. Give the one-time code only to your trusted backup administrator.
4. On the backup phone, create or sign in to that person's cloud account, enter
   the invitation code, and create a private device PIN.
5. The backup administrator username is `backup-admin`.

The backup administrator can keep the business operating but cannot replace the
primary owner, create other administrators, or change the owner's access.

## Employees

1. On an administrator phone, open **Settings > Cloud Sync** and choose
   **Create Employee Invite**.
2. Give each employee a separate one-time invitation code.
3. The employee creates or signs in to their own cloud account on their phone,
   enters the code, chooses an app username, and creates a private device PIN.
4. Open **Settings > Accounts & Access** on your phone to select that employee's
   permissions.

Never share your owner cloud password or `admin` PIN with an employee.

## Removing access

Open **Settings > Accounts & Access**, open the account controls, and choose
**Disable access**. The account is blocked from cloud data and synchronization
as soon as the phone reconnects. Its historical booking, payment, and expense
attribution remains available for audit.


## Signing in on any phone (v2.0.9)

Accounts are not tied to a phone. On any phone with Bastion Home Manager,
sign in with the account's **username** and its **cloud password** (or the PIN
you set on that phone). The owner's username is `admin`; every other account
uses the username the owner created for it.

- The first time an account is used on a phone, or when a different account was
  last used there, the phone needs an internet connection to verify the cloud
  password. It then switches to that account's role and permissions.
- After that, the same password (or a PIN set under Settings) also works offline
  on that phone for that account, as long as it was the last account used there.
- A new employee or administrator is asked to replace the temporary password
  the first time they sign in.
