# Bastion Home Manager

Offline-first Flutter manager for Bastion Home, a five-room guesthouse in
Guwahati. The same codebase builds the iOS and Android apps.

## Main areas

- Dashboard with occupancy, arrivals, departures, revenue, expenses, and dues
- Bookings with room/date overlap warnings and BH-xxx ID suggestions
- Monthly occupancy calendar for Rooms 1-5
- Guest ID records with masked numbers and encrypted image capture
- Payments, including negative refund entries
- Daily, monthly recurring, and yearly recurring expenses
- Administrator-only seven-day Trash with restore and protected examples
- Optional authenticated Supabase Realtime synchronization across devices
- Manual JSON backup/restore and CSV export

The app works fully offline. Cloud synchronization is optional and must be
connected to a Bastion Home-controlled Supabase project from Settings. The app
contains no advertising or third-party analytics.

## Security and storage

- Business data is held in an on-device SQLCipher database.
- The 256-bit database key is generated on the device and stored in the
  platform secure store (Android Keystore / Apple Keychain).
- Guest ID images are encrypted with AES-256-GCM before being written to the
  app-support directory.
- The app locks with the device biometric or device credential when supported.
- Android cloud backup is disabled.
- Supabase sessions are stored in the platform secure store.
- Cloud access is protected by authenticated workspace membership and database
  Row Level Security. A publishable key is used by the app; a service-role key
  must never be entered into the app.
- Captured ID image files and local account PIN credentials are never uploaded.
- Exported JSON and CSV files are intentionally portable and are not encrypted.
  Treat them as sensitive records and move them to protected storage.

An older plaintext `bastion_home.db` is migrated into the encrypted database
on first launch. The legacy file is removed only after the encrypted copy is
created and populated successfully.

## Supported platforms

- Android 8.0 / API 26 and newer
- iOS 15 and newer

These are the confirmed final support targets. The current identifiers are
`in.bastionhome.manager` on both platforms; change them before signing if that
identifier is not owned by Bastion Home.

## Run locally

Install Flutter 3.38 or newer with Dart 3.10 or newer.

```sh
flutter pub get
flutter analyze
flutter test
flutter run
```

No cloud configuration is required for offline use. See
`CLOUD-SYNC-SETUP.md` to activate synchronization between devices.

## Release builds

Android:

```sh
flutter build appbundle --release
```

Create an upload keystore, add the normal `key.properties` signing
configuration, and replace the temporary debug signing configuration before
uploading the generated AAB to Play Console.

iOS on a local Mac:

```sh
flutter build ipa --release
```

Select the Bastion Home Apple team and signing profile in Xcode, archive the
Runner target, then upload through Xcode Organizer or Transporter.

No Mac is required when using the included `codemagic.yaml` cloud workflow.
Follow `IOS-CLOUD-BUILD.md` to create a signed IPA on Codemagic using the
owner's Apple Developer account and securely stored App Store Connect API key.

## Store publishing

1. Create the app records in App Store Connect and Google Play Console.
2. Confirm the final bundle/application identifier and signing owners.
3. Prepare the icon, screenshots, privacy policy, support URL, and store text.
4. Complete the privacy declarations. Operational records synchronize only
   when the property enables its private cloud workspace; encrypted ID image
   files and local PIN credentials stay on the device.
5. Upload a signed IPA and AAB to internal testing first.
6. Test backup/restore, notifications, biometrics, camera permissions, fresh
   install, upgrade migration, and month/year date boundaries on real devices.
7. Submit the reviewed builds for production release.

Apple currently lists Developer Program membership at USD 99 per year:
https://developer.apple.com/programs/

Google currently lists a USD 25 one-time Play Console registration fee:
https://support.google.com/googleplay/android-developer/answer/6112435

## Project layout

```text
lib/
  database/       SQLCipher schema and local repositories
  models/         booking and payment calculations
  presentation/   app screens and forms
  services/       notifications, secure keys, ID vault
  theme/          light and dark themes
  widgets/        adaptive navigation and shared UI
android/          Android API 26+ project
ios/              iOS 15+ project
```

The source archive did not include the separate
`Bastion_Home_Manager.html` reference mentioned in the original brief. The
included BH-001/BH-002 samples were retained as the available source-of-truth
sample data.
