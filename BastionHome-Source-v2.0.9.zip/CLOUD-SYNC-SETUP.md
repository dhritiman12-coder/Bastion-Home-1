# Bastion Home Cloud Sync Setup

The app remains fully usable offline. Complete these steps once to activate
live synchronization between authorized phones.

## 1. Create the private cloud project

Create a Supabase project owned by Bastion Home. In the Supabase Connect panel,
locate the Project URL and publishable key. Never put the secret or service-role
key into the mobile app.

## 2. Install the secured database schema

Apply every migration in `supabase/migrations`. The website-booking migration
adds the protected booking channel, atomic room/date conflict checks, request
rate limits, and a cloud-level overlap guard shared by phones and the website.

With the Supabase CLI, link the project and run:

```sh
supabase db push
```

The migration creates workspace membership, Row Level Security policies,
Realtime publication entries, one-time invitation codes, conflict protection,
and hourly cleanup of records that have spent seven days in Trash.

Deploy the public website-booking gateway:

```sh
supabase functions deploy website-bookings --no-verify-jwt
```

The gateway uses Supabase's server-side secret inside the Edge Function. Never
place a secret or service-role key in the app or website.

## 3. Enroll the primary owner's phone

Version 2.0.2 already contains the safe public project connection details.

1. Install the app and create or sign in to the owner's cloud account.
2. If no workspace exists yet, choose **First-Time Owner Setup** once.
3. Create the private PIN for this phone. The protected owner username is
   `admin`.
4. Open **Settings > Cloud Sync** and confirm that the role is **Protected
   primary owner**.

## 4. Connect other phones

On the owner's phone, create a Backup Administrator, Administrator, or Employee
invitation. Other administrators may invite employees only. The one-time code
expires after seven days. On the other phone, create or sign in to that person's
cloud account, enter the invitation code, and create a private PIN for that
phone.

The primary owner controls all accounts from **Settings > Accounts & Access**.
Disabling an account blocks its cloud access across phones while keeping its
historical activity for audit.

Operational changes synchronize automatically while online. Offline changes
remain on the phone and synchronize when connectivity returns. Captured guest
ID image files and app PIN credentials remain local to each phone.

## 5. Connect the booking website

On an administrator phone, open **Settings > Website Bookings**, enter the
website's HTTPS address, and create a website key. Copy the service address and
one-time key into the website configuration. The complete request format and a
ready JavaScript client are in `WEBSITE-BOOKING-INTEGRATION.md` and
`website-integration/bastion-booking-client.js`.
