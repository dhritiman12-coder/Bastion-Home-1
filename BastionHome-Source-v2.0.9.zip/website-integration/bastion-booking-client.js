export function createBastionBookingClient({ endpoint, websiteKey }) {
  if (!endpoint || !websiteKey) {
    throw new Error('Booking endpoint and website key are required.');
  }

  async function request(payload) {
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-bastion-booking-key': websiteKey,
      },
      body: JSON.stringify(payload),
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(result.error || 'Booking request failed.');
      error.status = response.status;
      throw error;
    }
    return result;
  }

  return Object.freeze({
    async availability({ checkin, checkout }) {
      const result = await request({ action: 'availability', checkin, checkout });
      return result.availability;
    },

    async book(booking) {
      const result = await request({ action: 'book', ...booking });
      return result.booking;
    },
  });
}
