import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:bastionhome/services/app_settings_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('corrupted stored choices fall back to safe UI values', () async {
    SharedPreferences.setMockInitialValues({
      'setting_theme_mode': 'unknown',
      'setting_text_scale': 999.0,
      'setting_font_family': 'Missing Font',
      'setting_heading_font_family': 'Missing Font',
      'setting_currency_code': 'INVALID',
      'setting_date_format': 'broken',
      'setting_measurement_system': 'unknown',
      'setting_temperature_unit': 'Kelvin',
      'setting_checkin_time': '99:99',
      'setting_checkout_time': 'not-time',
      'setting_stock_unit': 'truckloads',
    });

    final settings = AppSettingsService();
    await settings.initialize();

    expect(settings.themeMode, ThemeMode.system);
    expect(settings.textScale, 1.35);
    expect(settings.fontFamily, 'Modern');
    expect(settings.headingFontFamily, 'Classic');
    expect(settings.currencyCode, 'INR');
    expect(settings.dateFormat, 'dd-MMM-yyyy');
    expect(settings.measurementSystem, 'Metric');
    expect(settings.temperatureUnit, 'Celsius');
    expect(settings.defaultCheckinTime, '12:00');
    expect(settings.defaultCheckoutTime, '11:00');
    expect(settings.defaultStockUnit, 'pcs');
  });

  test('hostile backup settings are clamped and type checked', () async {
    SharedPreferences.setMockInitialValues({});
    final settings = AppSettingsService();
    await settings.initialize();

    await settings.restoreFromBackup({
      'textScale': double.negativeInfinity,
      'fontFamily': 'Injected',
      'currencyCode': 123,
      'dateFormat': <String>['not', 'a', 'string'],
      'defaultCheckinTime': '24:00',
      'biometricUnlock': 'yes',
    });

    expect(settings.textScale, 1.0);
    expect(settings.fontFamily, 'Modern');
    expect(settings.currencyCode, 'INR');
    expect(settings.dateFormat, 'dd-MMM-yyyy');
    expect(settings.defaultCheckinTime, '12:00');
    expect(settings.biometricUnlock, isFalse);
  });
}
