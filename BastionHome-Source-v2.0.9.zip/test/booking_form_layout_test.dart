import 'package:bastionhome/models/booking_model.dart';
import 'package:bastionhome/presentation/bookings_screen/enhanced_booking_form_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sizer/sizer.dart';

void main() {
  testWidgets('booking form fits a narrow phone with large app text', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(320, 568);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    final value = BookingModel(
      id: 'BH-LAYOUT',
      guest: 'Layout Test Guest',
      phone: '9999999999',
      guests: 2,
      room: RoomType.room1,
      checkin: DateTime(2026, 12, 20),
      checkout: DateTime(2026, 12, 22),
      tariff: 2500,
      extra: 0,
      discount: 0,
      status: BookingStatus.booked,
      idTaken: false,
      idNumber: 'XXXX1234',
      serialNumber: '1/10-2026',
      bookingSource: BookingSource.online,
      notes: '',
    );

    await tester.pumpWidget(
      MediaQuery(
        data: const MediaQueryData(textScaler: TextScaler.linear(1.35)),
        child: Sizer(
          builder: (context, orientation, screenType) =>
              MaterialApp(home: EnhancedBookingFormScreen(booking: value)),
        ),
      ),
    );
    await tester.pump();

    expect(find.text('Edit Booking'), findsOneWidget);
    await tester.scrollUntilVisible(
      find.text('Booking Source'),
      250,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.pump();
    expect(find.text('Online'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
