import 'package:bastionhome/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('primary text meets WCAG contrast in light and dark themes', () {
    for (final theme in [
      AppTheme.lightThemeFor(fontChoice: 'Modern', headingChoice: 'Classic'),
      AppTheme.darkThemeFor(fontChoice: 'Modern', headingChoice: 'Classic'),
    ]) {
      expect(
        _contrast(theme.colorScheme.onSurface, theme.colorScheme.surface),
        greaterThanOrEqualTo(4.5),
      );
      expect(theme.textTheme.bodyMedium?.color, theme.colorScheme.onSurface);
      expect(theme.textTheme.titleLarge?.color, theme.colorScheme.onSurface);
    }
  });

  test('payment summary text is readable on its primary background', () {
    for (final theme in [AppTheme.lightTheme, AppTheme.darkTheme]) {
      expect(
        _contrast(theme.colorScheme.onPrimary, theme.colorScheme.primary),
        greaterThanOrEqualTo(4.5),
      );
    }
  });
}

double _contrast(Color first, Color second) {
  final lighter = first.computeLuminance() > second.computeLuminance()
      ? first.computeLuminance()
      : second.computeLuminance();
  final darker = first.computeLuminance() > second.computeLuminance()
      ? second.computeLuminance()
      : first.computeLuminance();
  return (lighter + 0.05) / (darker + 0.05);
}
