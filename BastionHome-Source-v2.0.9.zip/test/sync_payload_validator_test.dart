import 'package:flutter_test/flutter_test.dart';
import 'package:bastionhome/services/sync_payload_validator.dart';

void main() {
  const booking = {
    'id': 'BH-900',
    'guest': 'Test Guest',
    'room': 'Room 1',
    'checkin': '2026-10-10',
    'checkout': '2026-10-12',
    'guests': 2,
    'tariff': 2500.0,
  };

  test('accepts a valid booking payload', () {
    expect(SyncPayloadValidator.validate('bookings', booking), isNotNull);
  });

  test('accepts known booking sources and rejects unknown sources', () {
    expect(
      SyncPayloadValidator.validate('bookings', {
        ...booking,
        'bookingSource': 'Online',
      }),
      isNotNull,
    );
    expect(
      SyncPayloadValidator.validate('bookings', {
        ...booking,
        'bookingSource': 'Untrusted',
      }),
      isNull,
    );
  });

  test(
    'accepts bounded occupant names and rejects oversized occupant data',
    () {
      expect(
        SyncPayloadValidator.validate('bookings', {
          ...booking,
          'otherOccupants': 'Guest Two\nGuest Three',
        }),
        isNotNull,
      );
      expect(
        SyncPayloadValidator.validate('bookings', {
          ...booking,
          'otherOccupants': 'x' * 4001,
        }),
        isNull,
      );
    },
  );

  test('rejects impossible and backward booking dates', () {
    expect(
      SyncPayloadValidator.validate('bookings', {
        ...booking,
        'checkout': '2026-10-09',
      }),
      isNull,
    );
    expect(
      SyncPayloadValidator.validate('bookings', {
        ...booking,
        'checkin': '2026-02-31',
      }),
      isNull,
    );
  });

  test('rejects nested and oversized hostile payload values', () {
    expect(
      SyncPayloadValidator.validate('bookings', {
        ...booking,
        'notes': {'nested': 'object'},
      }),
      isNull,
    );
    expect(
      SyncPayloadValidator.validate('bookings', {
        ...booking,
        'notes': 'x' * 20001,
      }),
      isNull,
    );
  });

  test('requires a valid parent sync id for child records', () {
    expect(
      SyncPayloadValidator.validate('payments', {
        'date': '2026-10-10',
        'amount': 500,
        'booking_sync_id': 'not-a-uuid',
      }),
      isNull,
    );
    expect(
      SyncPayloadValidator.validate('payments', {
        'date': '2026-10-10',
        'amount': 500,
        'booking_sync_id': '123e4567-e89b-42d3-a456-426614174000',
      }),
      isNotNull,
    );
  });

  test('rejects negative stock and non-finite money', () {
    expect(
      SyncPayloadValidator.validate('inventory', {
        'room': 'Room 1',
        'category': 'Linen',
        'itemName': 'Sheet',
        'currentStock': -1,
        'minStock': 1,
        'reorderQty': 2,
        'unit': 'pcs',
        'updatedAt': '2026-10-02T00:00:00Z',
      }),
      isNull,
    );
    expect(
      SyncPayloadValidator.validate('daily_expenses', {
        'date': '2026-10-02',
        'head': 'Test',
        'amount': double.infinity,
      }),
      isNull,
    );
  });

  test('accepts a bounded negative refund payment', () {
    expect(
      SyncPayloadValidator.validate('payments', {
        'date': '2026-10-02',
        'booking_sync_id': '123e4567-e89b-42d3-a456-426614174000',
        'amount': -250.0,
      }),
      isNotNull,
    );
    expect(
      SyncPayloadValidator.validate('payments', {
        'date': '2026-10-02',
        'booking_sync_id': '123e4567-e89b-42d3-a456-426614174000',
        'amount': 0,
      }),
      isNull,
    );
  });

  test('validates synchronization identifiers', () {
    expect(
      SyncPayloadValidator.isValidSyncId(
        '123e4567-e89b-42d3-a456-426614174000',
      ),
      isTrue,
    );
    expect(SyncPayloadValidator.isValidSyncId('../record'), isFalse);
  });
}
