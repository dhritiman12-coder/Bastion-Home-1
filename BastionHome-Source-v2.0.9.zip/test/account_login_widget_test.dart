import 'package:bastionhome/database/database_helper.dart';
import 'package:bastionhome/models/app_user.dart';
import 'package:bastionhome/services/account_service.dart';
import 'package:bastionhome/services/app_settings_service.dart';
import 'package:bastionhome/services/cloud_sync_service.dart';
import 'package:bastionhome/theme/app_theme.dart';
import 'package:bastionhome/widgets/app_lock_gate.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();

  final database = DatabaseHelper();
  final accounts = AccountService();

  setUp(() async {
    CloudSyncService().setAuthorityForTesting();
    SharedPreferences.setMockInitialValues({});
    final db = await databaseFactoryFfi.openDatabase(inMemoryDatabasePath);
    await database.initializeForTesting(db);
    accounts.resetForTesting();
    await accounts.initialize();
    await AppSettingsService().initialize();
    await accounts.createInitialAdmins(
      primaryName: 'Main Administrator',
      primaryPin: '123456',
      backupName: 'Backup Administrator',
      backupPin: '654321',
    );
    await accounts.authenticate('admin', '123456');
    await accounts.addUser(
      username: 'manager',
      displayName: 'Duty Manager',
      pin: '234567',
      role: UserRole.administrator,
    );
    await accounts.addEmployee(
      username: 'frontdesk',
      displayName: 'Front Desk',
      pin: '345678',
    );
    accounts.logout();
    CloudSyncService().setAuthorityForTesting(role: 'primary_admin');
  });

  tearDown(() async {
    CloudSyncService().setAuthorityForTesting();
    accounts.resetForTesting();
    await database.closeForTesting();
  });

  testWidgets('primary administrator signs in with username and PIN', (
    tester,
  ) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.lightTheme,
        home: const AppLockGate(child: SizedBox()),
      ),
    );
    for (var i = 0; i < 10; i++) {
      await tester.pump(const Duration(milliseconds: 100));
    }
    expect(find.byType(DropdownButton<String>), findsNothing);
    expect(find.text('Username'), findsOneWidget);
    expect(find.text('Password or PIN'), findsOneWidget);

    await tester.enterText(
      find.byKey(const ValueKey('sign_in_username')),
      'admin',
    );
    await tester.enterText(find.byKey(const ValueKey('sign_in_pin')), '123456');
    expect(
      tester
          .widget<TextFormField>(find.byKey(const ValueKey('sign_in_username')))
          .controller
          ?.text,
      'admin',
    );
    expect(
      tester
          .widget<TextFormField>(find.byKey(const ValueKey('sign_in_pin')))
          .controller
          ?.text,
      '123456',
    );
    final signIn = find.byKey(const ValueKey('sign_in_button'));
    await tester.ensureVisible(signIn);
    await tester.pump();
    final onPressed = tester.widget<FilledButton>(signIn).onPressed;
    expect(onPressed, isNotNull);
    await tester.runAsync(() async {
      onPressed!();
      for (var i = 0; i < 100 && accounts.currentUser == null; i++) {
        await Future<void>.delayed(const Duration(milliseconds: 100));
      }
    });
    await tester.pump();

    expect(accounts.currentUser?.username, 'admin');
    expect(accounts.currentUser?.role, UserRole.primaryAdmin);
    expect(find.text('Sign In'), findsNothing);
    expect(tester.takeException(), isNull);
  });

  testWidgets('mistyped sign-in details can be cleared and replaced', (
    tester,
  ) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.lightTheme,
        home: const AppLockGate(child: SizedBox()),
      ),
    );
    await tester.pumpAndSettle();

    final username = find.byKey(const ValueKey('sign_in_username'));
    final pin = find.byKey(const ValueKey('sign_in_pin'));
    await tester.enterText(username, 'wrong-user');
    await tester.enterText(pin, '999999');
    await tester.pump();

    await tester.tap(find.byKey(const ValueKey('sign_in_username_clear')));
    await tester.tap(find.byKey(const ValueKey('sign_in_pin_clear')));
    await tester.pump();

    expect(tester.widget<TextFormField>(username).controller?.text, isEmpty);
    expect(tester.widget<TextFormField>(pin).controller?.text, isEmpty);

    await tester.enterText(username, 'admin');
    await tester.enterText(pin, '123456');

    expect(tester.widget<TextFormField>(username).controller?.text, 'admin');
    expect(tester.widget<TextFormField>(pin).controller?.text, '123456');
    expect(tester.takeException(), isNull);
  });

  testWidgets('backspace permanently removes credential text', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.lightTheme,
        home: const AppLockGate(child: SizedBox()),
      ),
    );
    await tester.pumpAndSettle();

    final username = find.byKey(const ValueKey('sign_in_username'));
    await tester.tap(username);
    await tester.enterText(username, 'frontdeskx');
    await tester.pump();
    await tester.sendKeyEvent(LogicalKeyboardKey.backspace);
    await tester.pump();

    expect(
      tester.widget<TextFormField>(username).controller?.text,
      'frontdesk',
    );

    await tester.tap(find.byKey(const ValueKey('sign_in_pin')));
    await tester.pump();
    expect(
      tester.widget<TextFormField>(username).controller?.text,
      'frontdesk',
    );
    expect(tester.takeException(), isNull);
  });

  test('cloud session username follows the signed-in account', () {
    final cloud = CloudSyncService();
    cloud.setAuthorityForTesting(role: 'primary_admin');
    expect(cloud.sessionUsername, 'admin');
    expect(cloud.isSessionFor(' Admin '), isTrue);
    expect(cloud.isSessionFor('frontdesk'), isFalse);
    cloud.setAuthorityForTesting(role: 'backup_admin');
    expect(cloud.sessionUsername, 'backup-admin');
    cloud.setAuthorityForTesting(role: 'employee');
    expect(cloud.sessionUsername, isNull);
    cloud.setAuthorityForTesting();
    expect(cloud.sessionUsername, isNull);
  });

  test('sign-in fails fast without credentials and counts nothing', () async {
    final result = await accounts.signIn('  ', '');
    expect(result.ok, isFalse);
    expect(result.message, isNotNull);
  });

  test('signing in as the attached account works offline with its PIN', () async {
    final result = await accounts.signIn('Admin', '123456');
    expect(result.ok, isTrue);
    expect(result.user?.username, 'admin');
  });
}
