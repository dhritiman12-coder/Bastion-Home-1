import 'dart:convert';

import 'package:bastionhome/services/logo_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() => SharedPreferences.setMockInitialValues({}));

  test('property backup clamps text, tax, and rejects a device path', () async {
    await LogoService().restoreSettings({
      'logoPath': r'C:\private\other-device\logo.png',
      'guestHouseName': 'A' * 250,
      'gstPercent': 150,
    });

    expect(await LogoService().getLogoPath(), isNull);
    expect((await LogoService().getGuestHouseName()).length, 200);
    expect(await LogoService().getGstPercent(), 100);
  });

  test('valid embedded logo survives backup restore', () async {
    final logo = 'data:image/png;base64,${base64Encode([1, 2, 3, 4])}';
    await LogoService().restoreSettings({'logoPath': logo});
    expect(await LogoService().getLogoPath(), logo);
  });

  test('invalid embedded logo is rejected', () async {
    await expectLater(
      LogoService().setLogoPath('data:image/svg+xml;base64,not-valid'),
      throwsA(isA<FormatException>()),
    );
  });
}
