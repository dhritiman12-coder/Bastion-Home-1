import 'package:bastionhome/models/booking_model.dart';
import 'package:flutter_test/flutter_test.dart';

BookingModel booking({
  DateTime? checkin,
  DateTime? checkout,
  double tariff = 2500,
  double extra = 500,
  double discount = 250,
  double received = 0,
}) {
  return BookingModel(
    id: 'BH-TEST',
    guest: 'Test Guest',
    phone: '',
    guests: 2,
    room: RoomType.room1,
    checkin: checkin ?? DateTime(2026, 12, 30),
    checkout: checkout ?? DateTime(2027, 1, 2),
    tariff: tariff,
    extra: extra,
    discount: discount,
    status: BookingStatus.booked,
    idTaken: false,
    notes: '',
    received: received,
  );
}

void main() {
  test('calculates nights across month and year boundaries', () {
    expect(booking().nights, 3);
  });

  test('calculates room charges, total, received, and due', () {
    final value = booking(received: 3000);

    expect(value.roomCharges, 7500);
    expect(value.total, 7750);
    expect(value.received, 3000);
    expect(value.due, 4750);
    expect(value.payStatus, PayStatus.partial);
  });

  test('negative payments increase the outstanding balance', () {
    final value = booking(received: -500);

    expect(value.due, 8250);
    expect(value.payStatus, PayStatus.unpaid);
  });

  test('invalid negative stays never create negative room charges', () {
    final value = booking(
      checkin: DateTime(2026, 7, 10),
      checkout: DateTime(2026, 7, 9),
    );

    expect(value.nights, 0);
    expect(value.roomCharges, 0);
  });

  test('copyWith changes status while preserving payment data', () {
    final original = booking(received: 1000);
    final checkedIn = original.copyWith(status: BookingStatus.checkedIn);

    expect(checkedIn.status, BookingStatus.checkedIn);
    expect(checkedIn.received, 1000);
  });

  test('booking source survives storage and copy operations', () {
    final online = booking().copyWith(bookingSource: BookingSource.online);
    final restored = BookingModel.fromMap(online.toMap());

    expect(restored.bookingSource, BookingSource.online);
    expect(restored.bookingSourceLabel, 'Online');
    expect(restored.copyWith().bookingSource, BookingSource.online);
  });

  test('other occupant names are normalized and survive storage', () {
    final value = BookingModel.fromMap({
      ...booking().toMap(),
      'otherOccupants': '  Guest Two\r\n\r\nGuest Three  ',
    });

    expect(value.otherOccupantNames, ['Guest Two', 'Guest Three']);
    expect(value.toMap()['otherOccupants'], 'Guest Two\nGuest Three');
    expect(value.copyWith().otherOccupantNames, ['Guest Two', 'Guest Three']);
  });
}
