import 'package:bastionhome/utils/input_validators.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('required money rejects empty, zero, negative and non-finite input', () {
    String? validate(String? value) =>
        InputValidators.money(value, required: true, allowZero: false);

    expect(validate(''), 'Required');
    expect(validate('0'), 'Amount must be above 0');
    expect(validate('-1'), 'Amount must be above 0');
    expect(validate('NaN'), 'Enter a valid amount');
    expect(validate('Infinity'), 'Enter a valid amount');
    expect(validate('12.50'), isNull);
  });

  test('optional money allows blank and zero but enforces upper bound', () {
    expect(InputValidators.money(''), isNull);
    expect(InputValidators.money('0'), isNull);
    expect(InputValidators.money('1000000000'), isNull);
    expect(InputValidators.money('1000000000.01'), 'Amount is too large');
  });
}
