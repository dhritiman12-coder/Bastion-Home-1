import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:bastionhome/services/trash_service.dart';

void main() {
  test('trash item keeps its deletion metadata and booking label', () {
    final deleted = DateTime.now().toUtc().subtract(const Duration(hours: 1));
    final item = TrashItem.fromMap({
      'syncId': 'sync-1',
      'entityType': 'bookings',
      'payload': jsonEncode({'id': 'BH-100', 'guest': 'Test Guest'}),
      'deletedAt': deleted.toIso8601String(),
      'deletedBy': 'Administrator',
      'expiresAt': deleted.add(const Duration(days: 7)).toIso8601String(),
    });

    expect(item.title, 'BH-100 Test Guest');
    expect(item.typeLabel, 'Booking');
    expect(item.deletedBy, 'Administrator');
    expect(item.remaining.inDays, greaterThanOrEqualTo(6));
  });

  test('trash labels cover synchronized business record types', () {
    const labels = {
      'payments': 'Payment',
      'daily_expenses': 'Daily expense',
      'monthly_expenses': 'Monthly expense',
      'yearly_expenses': 'Yearly expense',
      'id_records': 'Guest ID record',
      'inventory': 'Stock item',
      'seasonal_rates': 'Seasonal rate',
    };
    for (final entry in labels.entries) {
      final now = DateTime.now().toUtc();
      final item = TrashItem.fromMap({
        'syncId': entry.key,
        'entityType': entry.key,
        'payload': '{}',
        'deletedAt': now.toIso8601String(),
        'deletedBy': 'Admin',
        'expiresAt': now.add(const Duration(days: 7)).toIso8601String(),
      });
      expect(item.typeLabel, entry.value);
    }
  });
}
