import 'package:bastionhome/utils/currency_formatter.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('formats full INR values with Indian digit grouping', () {
    expect(CurrencyFormatter.format(125000), '₹1,25,000');
    expect(CurrencyFormatter.format(12345678), '₹1,23,45,678');
    expect(CurrencyFormatter.format(-2500), '−₹2,500');
  });

  test('formats dates as dd-Mon-yyyy', () {
    expect(DateFormatter.format(DateTime(2027, 1, 2)), '02-Jan-2027');
  });
}
