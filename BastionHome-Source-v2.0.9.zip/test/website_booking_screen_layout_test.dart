import 'package:bastionhome/presentation/website_booking_screen/website_booking_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('website booking setup fits narrow large-text layout', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(320, 568);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(
      const MediaQuery(
        data: MediaQueryData(textScaler: TextScaler.linear(1.35)),
        child: MaterialApp(home: WebsiteBookingScreen()),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('Website Bookings'), findsOneWidget);
    expect(find.text('Cloud Sync is required'), findsOneWidget);
    expect(find.text('Open Cloud Sync'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
