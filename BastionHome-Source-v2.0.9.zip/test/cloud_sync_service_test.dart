import 'package:bastionhome/services/cloud_sync_service.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('uploads only records that are newer than the cloud copy', () {
    final remote = {
      'record_id': 'record-1',
      'updated_at': '2026-10-03T10:00:00.000Z',
    };

    expect(
      CloudSyncService.shouldUploadRecord({
        'record_id': 'record-1',
        'updated_at': '2026-10-03T10:00:00.000Z',
      }, remote),
      isFalse,
    );
    expect(
      CloudSyncService.shouldUploadRecord({
        'record_id': 'record-1',
        'updated_at': '2026-10-03T09:59:59.000Z',
      }, remote),
      isFalse,
    );
    expect(
      CloudSyncService.shouldUploadRecord({
        'record_id': 'record-1',
        'updated_at': '2026-10-03T10:00:01.000Z',
      }, remote),
      isTrue,
    );
    expect(
      CloudSyncService.shouldUploadRecord({
        'record_id': 'record-2',
        'updated_at': '2026-10-03T10:00:00.000Z',
      }, null),
      isTrue,
    );
  });
}
