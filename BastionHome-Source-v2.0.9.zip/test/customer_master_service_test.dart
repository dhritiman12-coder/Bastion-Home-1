import 'package:bastionhome/models/booking_model.dart';
import 'package:bastionhome/services/customer_master_service.dart';
import 'package:bastionhome/utils/phone_normalizer.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Indian phone formatting produces one stable customer key', () {
    expect(PhoneNormalizer.canonical('98765 43210'), '919876543210');
    expect(PhoneNormalizer.canonical('+91 98765-43210'), '919876543210');
    expect(PhoneNormalizer.canonical('09876543210'), '919876543210');
  });

  test('customer master groups visits and searches booking serials', () {
    final customers = CustomerMasterService.build([
      _booking(
        id: 'BH-101',
        phone: '+91 98765 43210',
        serial: '1/10-2026',
        status: BookingStatus.checkedOut,
        checkin: DateTime(2026, 10, 1),
      ),
      _booking(
        id: 'BH-205',
        phone: '9876543210',
        serial: '2/01-2027',
        status: BookingStatus.checkedOut,
        checkin: DateTime(2027, 1, 3),
      ),
    ]);

    expect(customers, hasLength(1));
    expect(customers.single.completedStays, 2);
    expect(customers.single.isFrequent, isTrue);
    expect(
      CustomerMasterService.matches(customers.single, '2/01-2027'),
      isTrue,
    );
    expect(
      CustomerMasterService.hasBookingInPeriod(
        customers.single,
        year: 2026,
        month: 10,
      ),
      isTrue,
    );
  });
}

BookingModel _booking({
  required String id,
  required String phone,
  required String serial,
  required BookingStatus status,
  required DateTime checkin,
}) => BookingModel(
  id: id,
  guest: 'Returning Guest',
  phone: phone,
  guests: 1,
  room: RoomType.room1,
  checkin: checkin,
  checkout: checkin.add(const Duration(days: 2)),
  tariff: 1000,
  extra: 0,
  discount: 0,
  status: status,
  idTaken: false,
  idNumber: 'ID-1234',
  serialNumber: serial,
  notes: '',
);
