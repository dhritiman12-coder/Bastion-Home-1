import 'package:bastionhome/services/cloud_sync_service.dart';
import 'package:bastionhome/theme/app_theme.dart';
import 'package:bastionhome/widgets/cloud_enrollment.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets(
    'fresh device requires cloud enrollment without local admin setup',
    (tester) async {
      CloudSyncService().setAuthorityForTesting();
      tester.view.physicalSize = const Size(320, 568);
      tester.view.devicePixelRatio = 1;
      addTearDown(() {
        tester.view.resetPhysicalSize();
        tester.view.resetDevicePixelRatio();
        CloudSyncService().setAuthorityForTesting();
      });

      await tester.pumpWidget(
        MaterialApp(
          theme: AppTheme.lightTheme,
          home: const MediaQuery(
            data: MediaQueryData(textScaler: TextScaler.linear(1.35)),
            child: CloudEnrollment(),
          ),
        ),
      );
      await tester.pump();

      expect(find.text('Secure Business Enrollment'), findsOneWidget);
      expect(find.text('Secure Your Manager'), findsNothing);
      expect(tester.takeException(), isNull);
    },
  );
}
