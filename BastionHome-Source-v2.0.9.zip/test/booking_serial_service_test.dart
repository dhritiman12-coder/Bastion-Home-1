import 'package:bastionhome/database/database_helper.dart';
import 'package:bastionhome/database/repositories/booking_repository.dart';
import 'package:bastionhome/models/booking_model.dart';
import 'package:bastionhome/services/booking_serial_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();

  final database = DatabaseHelper();
  final repository = BookingRepository();
  final serials = BookingSerialService();

  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    final db = await databaseFactoryFfi.openDatabase(inMemoryDatabasePath);
    await database.initializeForTesting(db);
  });

  tearDown(() => database.closeForTesting());

  test('preview does not consume a booking serial', () async {
    final first = await serials.previewNextSerial(DateTime(2026, 10, 3));
    final second = await serials.previewNextSerial(DateTime(2026, 10, 3));

    expect(first, '1/10-2026');
    expect(second, first);
    expect(await serials.getCurrentCount(DateTime(2026, 10, 3)), 0);
  });

  test('serial numbering restarts for every month and year', () async {
    await database.insertBookingWithNextSerial(
      _booking('BH-OCT').toMap(),
      DateTime(2026, 10, 31),
    );
    await database.insertBookingWithNextSerial(
      _booking('BH-NOV').toMap(),
      DateTime(2026, 11, 1),
    );
    await database.insertBookingWithNextSerial(
      _booking('BH-JAN').toMap(),
      DateTime(2027, 1, 1),
    );

    expect(
      (await repository.getBookingById('BH-OCT'))?.serialNumber,
      '1/10-2026',
    );
    expect(
      (await repository.getBookingById('BH-NOV'))?.serialNumber,
      '1/11-2026',
    );
    expect(
      (await repository.getBookingById('BH-JAN'))?.serialNumber,
      '1/01-2027',
    );
  });

  test('new booking cannot be saved without an ID number', () async {
    await expectLater(
      repository.insertBooking(_booking('BH-100', idNumber: '')),
      throwsArgumentError,
    );
    expect(await repository.getBookingById('BH-100'), isNull);
  });

  test('repository blocks an overlapping room booking', () async {
    await repository.insertBooking(_booking('BH-OVERLAP-1'));

    await expectLater(
      repository.insertBooking(_booking('BH-OVERLAP-2')),
      throwsA(isA<StateError>()),
    );
    expect(await repository.getBookingById('BH-OVERLAP-2'), isNull);
  });

  test('deleted serial is reused and restore avoids duplicates', () async {
    await database.insertBookingWithNextSerial(
      _booking('BH-101').toMap(),
      DateTime(2026, 10, 3),
    );
    await database.insertBookingWithNextSerial(
      _booking('BH-102').toMap(),
      DateTime(2026, 10, 3),
    );
    final firstRow = (await database.query(
      'bookings',
      where: 'id = ?',
      whereArgs: ['BH-101'],
    )).single;
    await database.moveToTrash(
      table: 'bookings',
      keyColumn: 'id',
      keyValue: 'BH-101',
      deletedBy: 'Administrator',
    );

    await database.insertBookingWithNextSerial(
      _booking('BH-103').toMap(),
      DateTime(2026, 10, 3),
    );
    expect(
      (await repository.getBookingById('BH-103'))?.serialNumber,
      '1/10-2026',
    );

    await database.restoreFromTrash(firstRow['syncId'] as String);
    final active = (await repository.getAllBookings())
        .where((booking) => booking.id.startsWith('BH-10'))
        .toList();
    expect(active.map((booking) => booking.serialNumber).toSet(), {
      '1/10-2026',
      '2/10-2026',
      '3/10-2026',
    });
    expect(await serials.getCurrentCount(DateTime(2026, 10, 3)), 3);
  });

  test('cloud booking collision is assigned the next free serial', () async {
    await database.insertBookingWithNextSerial(
      _booking('BH-201').toMap(),
      DateTime(2026, 10, 3),
    );
    final payload = _booking('BH-202').toMap()..['serialNumber'] = '1/10-2026';

    await database.applyRemoteSyncRecords([
      {
        'record_id': '11111111-1111-4111-8111-111111111111',
        'entity_type': 'bookings',
        'payload': payload,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
        'deleted_at': null,
      },
    ]);

    expect(
      (await repository.getBookingById('BH-202'))?.serialNumber,
      '2/10-2026',
    );
  });
}

BookingModel _booking(String id, {String idNumber = 'ID-1234'}) => BookingModel(
  id: id,
  guest: 'Guest $id',
  phone: '9999999999',
  guests: 1,
  room: RoomType.room1,
  checkin: DateTime(2026, 10, 3),
  checkout: DateTime(2026, 10, 4),
  tariff: 1000,
  extra: 0,
  discount: 0,
  status: BookingStatus.booked,
  idTaken: false,
  idNumber: idNumber,
  notes: '',
);
