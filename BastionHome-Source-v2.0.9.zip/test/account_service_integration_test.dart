import 'package:bastionhome/database/database_helper.dart';
import 'package:bastionhome/models/app_user.dart';
import 'package:bastionhome/services/account_service.dart';
import 'package:bastionhome/services/cloud_sync_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();

  final database = DatabaseHelper();
  final accounts = AccountService();

  setUp(() async {
    CloudSyncService().setAuthorityForTesting();
    SharedPreferences.setMockInitialValues({});
    final db = await databaseFactoryFfi.openDatabase(inMemoryDatabasePath);
    await database.initializeForTesting(db);
    accounts.resetForTesting();
    await accounts.initialize();
  });

  tearDown(() async {
    CloudSyncService().setAuthorityForTesting();
    accounts.resetForTesting();
    await database.closeForTesting();
  });

  test(
    'sign-in list includes primary, additional admin and employee',
    () async {
      await accounts.createInitialAdmins(
        primaryName: 'Main Administrator',
        primaryPin: '123456',
        backupName: 'Backup Administrator',
        backupPin: '654321',
      );
      expect(await accounts.authenticate('admin', '123456'), isNotNull);

      await accounts.addUser(
        username: 'manager',
        displayName: 'Duty Manager',
        pin: '234567',
        role: UserRole.administrator,
      );
      await accounts.addEmployee(
        username: 'frontdesk',
        displayName: 'Front Desk',
        pin: '345678',
      );
      accounts.logout();
      await accounts.refreshUsers();

      expect(accounts.loginUsers.map((user) => user.username), [
        'admin',
        'manager',
        'frontdesk',
        'backup-admin',
      ]);
      expect(await accounts.authenticate('manager', '234567'), isNotNull);
      accounts.logout();
      expect(await accounts.authenticate('frontdesk', '345678'), isNotNull);
    },
  );

  test(
    'protected administrator usernames repair incorrect stored roles',
    () async {
      await accounts.createInitialAdmins(
        primaryName: 'Main Administrator',
        primaryPin: '123456',
        backupName: 'Backup Administrator',
        backupPin: '654321',
      );
      await database.update(
        'app_users',
        {'role': UserRole.backupAdmin.name, 'active': 0},
        where: 'username = ?',
        whereArgs: ['admin'],
      );
      await database.update(
        'app_users',
        {'role': UserRole.primaryAdmin.name},
        where: 'username = ?',
        whereArgs: ['backup-admin'],
      );

      await accounts.refreshUsers();

      final primary = accounts.users.singleWhere(
        (user) => user.username == 'admin',
      );
      final backup = accounts.users.singleWhere(
        (user) => user.username == 'backup-admin',
      );
      expect(primary.role, UserRole.primaryAdmin);
      expect(primary.active, isTrue);
      expect(backup.role, UserRole.backupAdmin);
      expect(await accounts.authenticate('admin', '123456'), isNotNull);
    },
  );

  test('administrator can delete an employee account', () async {
    await accounts.createInitialAdmins(
      primaryName: 'Main Administrator',
      primaryPin: '123456',
      backupName: 'Backup Administrator',
      backupPin: '654321',
    );
    expect(await accounts.authenticate('admin', '123456'), isNotNull);
    await accounts.addUser(
      username: 'manager',
      displayName: 'Duty Manager',
      pin: '234567',
      role: UserRole.administrator,
    );
    await accounts.addEmployee(
      username: 'frontdesk',
      displayName: 'Front Desk',
      pin: '345678',
    );

    accounts.logout();
    expect(await accounts.authenticate('manager', '234567'), isNotNull);
    final employee = accounts.users.singleWhere(
      (user) => user.username == 'frontdesk',
    );
    await accounts.deleteEmployee(employee);

    expect(
      accounts.users.where((user) => user.username == 'frontdesk'),
      isEmpty,
    );
    await expectLater(
      accounts.deleteEmployee(
        accounts.users.singleWhere((user) => user.username == 'manager'),
      ),
      throwsArgumentError,
    );
    accounts.logout();
    expect(await accounts.authenticate('frontdesk', '345678'), isNull);
  });

  test('administrator can lock and recover an employee account', () async {
    await accounts.createInitialAdmins(
      primaryName: 'Main Administrator',
      primaryPin: '123456',
      backupName: 'Backup Administrator',
      backupPin: '654321',
    );
    expect(await accounts.authenticate('admin', '123456'), isNotNull);
    await accounts.addEmployee(
      username: 'frontdesk',
      displayName: 'Front Desk',
      pin: '345678',
    );

    var employee = accounts.users.singleWhere(
      (user) => user.username == 'frontdesk',
    );
    await accounts.updateEmployee(
      user: employee,
      displayName: employee.displayName,
      permissions: employee.permissions,
      active: false,
    );
    accounts.logout();
    expect(await accounts.authenticate('frontdesk', '345678'), isNull);

    expect(await accounts.authenticate('admin', '123456'), isNotNull);
    employee = accounts.users.singleWhere(
      (user) => user.username == 'frontdesk',
    );
    await accounts.updateEmployee(
      user: employee,
      displayName: employee.displayName,
      permissions: employee.permissions,
      active: true,
      newPin: '987654',
    );
    accounts.logout();
    expect(await accounts.authenticate('frontdesk', '345678'), isNull);
    expect(await accounts.authenticate('frontdesk', '987654'), isNotNull);
  });

  test('cloud authority prevents local role escalation', () async {
    await accounts.createInitialAdmins(
      primaryName: 'Main Administrator',
      primaryPin: '123456',
      backupName: 'Backup Administrator',
      backupPin: '654321',
    );
    expect(await accounts.authenticate('admin', '123456'), isNotNull);
    await accounts.addEmployee(
      username: 'frontdesk',
      displayName: 'Front Desk',
      pin: '345678',
    );
    accounts.logout();

    CloudSyncService().setAuthorityForTesting(
      role: 'employee',
      permissions: {AppPermission.viewOccupancy.name},
    );

    expect(await accounts.authenticate('admin', '123456'), isNull);
    expect(await accounts.authenticate('frontdesk', '345678'), isNotNull);
    expect(accounts.isAdmin, isFalse);
    expect(accounts.can(AppPermission.viewOccupancy), isTrue);
    expect(accounts.can(AppPermission.createBookings), isTrue);
    expect(accounts.can(AppPermission.recordExpenses), isTrue);
    expect(accounts.can(AppPermission.manageInventory), isFalse);
  });

  test(
    'employee actions use cloud permissions instead of stale local permissions',
    () async {
      await accounts.createInitialAdmins(
        primaryName: 'Main Administrator',
        primaryPin: '123456',
        backupName: 'Backup Administrator',
        backupPin: '654321',
      );
      expect(await accounts.authenticate('admin', '123456'), isNotNull);
      await accounts.addEmployee(
        username: 'frontdesk',
        displayName: 'Front Desk',
        pin: '345678',
        permissions: const {},
      );
      await database.update(
        'app_users',
        {'permissions': '[]'},
        where: 'username = ?',
        whereArgs: ['frontdesk'],
      );
      await accounts.refreshUsers();
      accounts.logout();

      CloudSyncService().setAuthorityForTesting(
        role: 'employee',
        permissions: {
          AppPermission.createBookings.name,
          AppPermission.recordExpenses.name,
        },
      );

      expect(await accounts.authenticate('frontdesk', '345678'), isNotNull);
      expect(accounts.currentUser!.permissions, isEmpty);
      expect(accounts.can(AppPermission.createBookings), isTrue);
      expect(accounts.can(AppPermission.recordExpenses), isTrue);
    },
  );

  test(
    'active employees retain core duties with empty cloud permissions',
    () async {
      await accounts.createInitialAdmins(
        primaryName: 'Main Administrator',
        primaryPin: '123456',
        backupName: 'Backup Administrator',
        backupPin: '654321',
      );
      expect(await accounts.authenticate('admin', '123456'), isNotNull);
      await accounts.addEmployee(
        username: 'frontdesk',
        displayName: 'Front Desk',
        pin: '345678',
        permissions: const {},
      );
      accounts.logout();

      CloudSyncService().setAuthorityForTesting(
        role: 'employee',
        permissions: const {},
      );

      expect(await accounts.authenticate('frontdesk', '345678'), isNotNull);
      expect(accounts.can(AppPermission.createBookings), isTrue);
      expect(accounts.can(AppPermission.viewOccupancy), isTrue);
      expect(accounts.can(AppPermission.recordExpenses), isTrue);
      expect(accounts.can(AppPermission.viewAnalytics), isFalse);
    },
  );

  test('employee access is locked without an active cloud session', () async {
    await accounts.createInitialAdmins(
      primaryName: 'Main Administrator',
      primaryPin: '123456',
      backupName: 'Backup Administrator',
      backupPin: '654321',
    );
    expect(await accounts.authenticate('admin', '123456'), isNotNull);
    await accounts.addEmployee(
      username: 'frontdesk',
      displayName: 'Front Desk',
      pin: '345678',
    );
    accounts.logout();

    CloudSyncService().setAuthorityForTesting(
      role: 'employee',
      permissions: {AppPermission.createBookings.name},
      connected: false,
    );

    expect(await accounts.authenticate('frontdesk', '345678'), isNull);
    expect(accounts.can(AppPermission.createBookings), isFalse);
  });

  test('cloud roles map to only the matching local role', () {
    expect(
      AccountService.roleForCloudAuthority('primary_admin'),
      UserRole.primaryAdmin,
    );
    expect(
      AccountService.roleForCloudAuthority('backup_admin'),
      UserRole.backupAdmin,
    );
    expect(
      AccountService.roleForCloudAuthority('admin'),
      UserRole.administrator,
    );
    expect(AccountService.roleForCloudAuthority('employee'), UserRole.employee);
    expect(AccountService.roleForCloudAuthority('unapproved'), isNull);
  });

  test(
    'cloud enrollment adds an employee to a device with admin accounts',
    () async {
      await accounts.createInitialAdmins(
        primaryName: 'Main Administrator',
        primaryPin: '123456',
        backupName: 'Backup Administrator',
        backupPin: '654321',
      );
      CloudSyncService().setAuthorityForTesting(
        role: 'employee',
        permissions: const {},
      );

      await accounts.createCloudEnrolledAccount(
        username: 'frontdesk',
        displayName: 'Front Desk',
        pin: '345678',
      );

      expect(accounts.users.map((user) => user.username), contains('admin'));
      expect(
        accounts.users.map((user) => user.username),
        contains('frontdesk'),
      );
      expect(await accounts.authenticate('frontdesk', '345678'), isNotNull);
      expect(accounts.currentUser?.role, UserRole.employee);
    },
  );
}
