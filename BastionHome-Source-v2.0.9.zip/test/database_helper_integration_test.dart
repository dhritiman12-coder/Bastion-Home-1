import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:bastionhome/database/database_helper.dart';
import 'package:bastionhome/database/repositories/booking_repository.dart';
import 'package:bastionhome/services/account_service.dart';
import 'package:bastionhome/services/data_change_service.dart';
import 'package:bastionhome/services/trash_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();

  final helper = DatabaseHelper();
  final accounts = AccountService();

  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    final db = await databaseFactoryFfi.openDatabase(inMemoryDatabasePath);
    await helper.initializeForTesting(db);
    accounts.resetForTesting();
    await accounts.initialize();
  });

  tearDown(() async {
    accounts.resetForTesting();
    await helper.closeForTesting();
  });

  test('seeded example data cannot be moved to trash', () async {
    await expectLater(
      helper.moveToTrash(
        table: 'bookings',
        keyColumn: 'id',
        keyValue: 'BH-001',
        deletedBy: 'Administrator',
      ),
      throwsA(isA<StateError>()),
    );
    expect(
      await helper.query('bookings', where: 'id = ?', whereArgs: ['BH-001']),
      hasLength(1),
    );
  });

  test('administrator can move a seeded example record to trash', () async {
    await accounts.createInitialAdmins(
      primaryName: 'Main Administrator',
      primaryPin: '123456',
      backupName: 'Backup Administrator',
      backupPin: '654321',
    );
    expect(await accounts.authenticate('admin', '123456'), isNotNull);

    await TrashService().deleteRecord(
      table: 'bookings',
      keyColumn: 'id',
      keyValue: 'BH-001',
    );

    expect(
      await helper.query('bookings', where: 'id = ?', whereArgs: ['BH-001']),
      isEmpty,
    );
    final trash = await helper.getTrashEntries();
    expect(
      trash,
      contains(
        predicate<Map<String, dynamic>>(
          (entry) => entry['entityType'] == 'bookings',
        ),
      ),
    );
  });

  test('booking deletion and restore includes linked children', () async {
    await helper.insert('bookings', _booking('BH-900'));
    await helper.insert('payments', {
      'date': '2026-10-10',
      'bookingId': 'BH-900',
      'amount': 500.0,
    });

    await helper.moveToTrash(
      table: 'bookings',
      keyColumn: 'id',
      keyValue: 'BH-900',
      deletedBy: 'Administrator',
    );
    final trash = await helper.getTrashEntries();
    expect(trash, hasLength(2));
    final bookingTrash = trash.firstWhere(
      (entry) => entry['entityType'] == 'bookings',
    );

    await helper.restoreFromTrash(bookingTrash['syncId'] as String);
    expect(
      await helper.query('bookings', where: 'id = ?', whereArgs: ['BH-900']),
      hasLength(1),
    );
    expect(
      await helper.query(
        'payments',
        where: 'bookingId = ?',
        whereArgs: ['BH-900'],
      ),
      hasLength(1),
    );
    expect(await helper.getTrashEntries(), isEmpty);
  });

  test('ID-bearing trash is retained until the one-year anniversary', () async {
    await helper.insert('bookings', {
      ..._booking('BH-ID-RETENTION'),
      'idFrontPath': 'retained-photo.bhid',
      'idFrontCapturedAt': '2026-09-15T08:30:00.000Z',
    });
    await helper.moveToTrash(
      table: 'bookings',
      keyColumn: 'id',
      keyValue: 'BH-ID-RETENTION',
      deletedBy: 'Administrator',
      deletedAt: DateTime.utc(2026, 10, 1),
    );

    final entry = (await helper.getTrashEntries()).singleWhere(
      (row) => row['entityType'] == 'bookings',
    );
    expect(
      DateTime.parse(entry['expiresAt'] as String),
      DateTime.utc(2027, 9, 15, 8, 30),
    );
  });

  test(
    'expired offline deletion cannot be resurrected by stale cloud data',
    () async {
      await helper.insert('bookings', _booking('BH-901'));
      final row = (await helper.query(
        'bookings',
        where: 'id = ?',
        whereArgs: ['BH-901'],
      )).single;
      final syncId = row['syncId'] as String;

      await helper.moveToTrash(
        table: 'bookings',
        keyColumn: 'id',
        keyValue: 'BH-901',
        deletedBy: 'Administrator',
        deletedAt: DateTime.now().toUtc().subtract(const Duration(days: 8)),
      );
      await helper.purgeExpiredTrash();

      expect(
        await helper.getLocalPurgedRecords(),
        contains(
          predicate<Map<String, dynamic>>(
            (record) => record['record_id'] == syncId,
          ),
        ),
      );

      await helper.applyRemoteSyncRecords([
        {
          'record_id': syncId,
          'entity_type': 'bookings',
          'payload': _booking('BH-901'),
          'updated_at': DateTime.now().toUtc().toIso8601String(),
          'deleted_at': null,
          'deleted_by': null,
        },
      ]);

      expect(
        await helper.query('bookings', where: 'id = ?', whereArgs: ['BH-901']),
        isEmpty,
      );
    },
  );

  test(
    'malformed remote rows are ignored without aborting the sync batch',
    () async {
      await helper.applyRemoteSyncRecords([
        {
          'record_id': '123e4567-e89b-42d3-a456-426614174000',
          'entity_type': 'bookings',
          'payload': {..._booking('BH-BAD'), 'checkout': 'not-a-date'},
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        },
        {
          'record_id': '123e4567-e89b-42d3-a456-426614174001',
          'entity_type': 'bookings',
          'payload': _booking('BH-VALID'),
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        },
      ]);

      expect(
        await helper.query('bookings', where: 'id = ?', whereArgs: ['BH-BAD']),
        isEmpty,
      );
      expect(
        await helper.query(
          'bookings',
          where: 'id = ?',
          whereArgs: ['BH-VALID'],
        ),
        hasLength(1),
      );
    },
  );

  test('equal cloud records do not trigger another local refresh', () async {
    await helper.insert('bookings', _booking('BH-STABLE'));
    final record = (await helper.getLocalSyncRecords()).firstWhere(
      (entry) =>
          entry['entity_type'] == 'bookings' &&
          (entry['payload'] as Map)['id'] == 'BH-STABLE',
    );
    final revision = DataChangeService().revision;

    final changed = await helper.applyRemoteSyncRecords([
      Map<String, dynamic>.from(record),
    ]);

    expect(changed, isFalse);
    expect(DataChangeService().revision, revision);
  });

  test('an already applied remote purge stays silent', () async {
    const syncId = '123e4567-e89b-42d3-a456-426614174099';
    expect(await helper.applyRemotePurges([syncId]), isTrue);
    final revision = DataChangeService().revision;

    expect(await helper.applyRemotePurges([syncId]), isFalse);
    expect(DataChangeService().revision, revision);
  });

  test(
    'unsupported backup is rejected before current data is replaced',
    () async {
      await helper.insert('bookings', _booking('BH-KEEP'));
      await expectLater(
        helper.importAll({'version': 999, 'bookings': <Object>[]}),
        throwsA(isA<FormatException>()),
      );
      expect(
        await helper.query('bookings', where: 'id = ?', whereArgs: ['BH-KEEP']),
        hasLength(1),
      );
    },
  );

  test(
    'nested backup rows are rejected before current data is replaced',
    () async {
      await helper.insert('bookings', _booking('BH-KEEP'));
      final backup = await helper.exportAll();
      final bookings = List<dynamic>.from(backup['bookings'] as List<dynamic>);
      backup['bookings'] = bookings;
      bookings.add({
        ..._booking('BH-BAD'),
        'notes': {'nested': 'not allowed'},
      });

      await expectLater(
        helper.importAll(backup),
        throwsA(isA<FormatException>()),
      );
      expect(
        await helper.query('bookings', where: 'id = ?', whereArgs: ['BH-KEEP']),
        hasLength(1),
      );
    },
  );

  test('booking queries aggregate payments including refunds', () async {
    await helper.insert('bookings', _booking('BH-902'));
    await helper.insert('payments', {
      'date': '2026-10-10',
      'bookingId': 'BH-902',
      'amount': 1000.0,
      'type': 'Advance',
    });
    await helper.insert('payments', {
      'date': '2026-10-11',
      'bookingId': 'BH-902',
      'amount': -200.0,
      'type': 'Refund',
    });

    final booking = await BookingRepository().getBookingById('BH-902');
    expect(booking, isNotNull);
    expect(booking!.received, 800.0);
    expect(
      (await BookingRepository().getBookingsForMonth(
        2026,
        10,
      )).firstWhere((value) => value.id == 'BH-902').received,
      800.0,
    );
  });
}

Map<String, dynamic> _booking(String id) => {
  'id': id,
  'guest': 'Test Guest',
  'phone': '9999999999',
  'guests': 2,
  'room': 'Room 1',
  'checkin': '2026-10-10',
  'checkout': '2026-10-12',
  'tariff': 2500.0,
  'extra': 0.0,
  'discount': 0.0,
  'status': 'Booked',
};
