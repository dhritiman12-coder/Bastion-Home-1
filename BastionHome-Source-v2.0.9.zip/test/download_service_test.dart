import 'package:bastionhome/services/download_service.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('DownloadService file names', () {
    test('removes path traversal and unsafe file-name characters', () {
      expect(
        DownloadService.sanitizeFileName('../guest:record?.pdf'),
        'guest_record_.pdf',
      );
      expect(
        DownloadService.sanitizeFileName(r'C:\temp\backup.json'),
        'backup.json',
      );
    });

    test('uses a safe fallback for an empty name', () {
      expect(DownloadService.sanitizeFileName('...'), 'bastion_download');
      expect(DownloadService.sanitizeFileName('   '), 'bastion_download');
    });
  });
}
