import 'package:bastionhome/models/booking_model.dart';
import 'package:bastionhome/services/guest_stay_pdf_service.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('builds a non-financial guest stay PDF with occupant details', () async {
    final booking = BookingModel(
      id: 'BH-PDF-1',
      guest: 'Primary Guest',
      phone: '9000000000',
      address: 'Test address',
      otherOccupants: 'Second Guest\nThird Guest',
      guests: 3,
      room: RoomType.room2,
      checkin: DateTime(2026, 12, 20),
      checkout: DateTime(2026, 12, 23),
      checkinTime: '14:30',
      checkoutTime: '10:00',
      tariff: 999999,
      extra: 12345,
      discount: 50,
      status: BookingStatus.booked,
      idTaken: false,
      idType: 'Passport',
      idNumber: 'XXXX4567',
      serialNumber: '1/12-2026',
      createdBy: 'Employee One (employee1)',
      bookingSource: BookingSource.online,
      notes: 'Late arrival expected',
    );

    final bytes = await GuestStayPdfService().buildPdf(
      booking: booking,
      propertyName: 'Bastion Home Guest House',
      propertyAddress: 'Test property address',
    );

    expect(bytes.length, greaterThan(5000));
    expect(String.fromCharCodes(bytes.take(5)), '%PDF-');
  });
}
