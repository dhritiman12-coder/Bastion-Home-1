import 'package:bastionhome/models/app_user.dart';
import 'package:bastionhome/services/account_service.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  const employee = AppUser(
    id: 3,
    username: 'frontdesk',
    displayName: 'Front Desk',
    role: UserRole.employee,
    pinHash: 'hash',
    pinSalt: 'salt',
    permissions: {
      AppPermission.createBookings,
      AppPermission.viewOccupancy,
      AppPermission.recordExpenses,
    },
    createdAt: '2026-10-01T00:00:00.000',
  );

  test('employee access is limited to assigned permissions', () {
    expect(employee.can(AppPermission.createBookings), isTrue);
    expect(employee.can(AppPermission.viewOccupancy), isTrue);
    expect(employee.can(AppPermission.manageInventory), isFalse);
    expect(employee.can(AppPermission.viewAnalytics), isFalse);
  });

  test('activity attribution keeps the employee username identifiable', () {
    expect(AccountService.auditLabelFor(employee), 'Front Desk (@frontdesk)');
    expect(
      AccountService.activityBelongsTo('Front Desk (@frontdesk)', employee),
      isTrue,
    );
    expect(AccountService.activityBelongsTo('Front Desk', employee), isTrue);
    expect(AccountService.activityBelongsTo('Night Staff', employee), isFalse);
  });

  test('permissions survive database serialization', () {
    final restored = AppUser.fromMap(employee.toMap());
    expect(restored.username, employee.username);
    expect(restored.role, UserRole.employee);
    expect(restored.permissions, employee.permissions);
  });

  test('administrators can access every module', () {
    for (final role in [
      UserRole.primaryAdmin,
      UserRole.backupAdmin,
      UserRole.administrator,
    ]) {
      final admin = employee.copyWith(role: role, permissions: const {});
      for (final permission in AppPermission.values) {
        expect(admin.can(permission), isTrue);
      }
    }
  });
}
