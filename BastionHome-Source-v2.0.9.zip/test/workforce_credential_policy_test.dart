import 'package:bastionhome/services/workforce_credential_policy.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('WorkforceCredentialPolicy', () {
    test('normalizes staff usernames into internal sign-in identifiers', () {
      expect(
        WorkforceCredentialPolicy.signInIdentifier('  Front.Desk-1  '),
        'front.desk-1@staff.bastionhome.app',
      );
    });

    test('preserves owner email sign-in identifiers', () {
      expect(
        WorkforceCredentialPolicy.signInIdentifier(' Owner@Example.com '),
        'owner@example.com',
      );
    });

    test('recognizes the protected primary owner username', () {
      expect(WorkforceCredentialPolicy.isPrimaryOwnerAlias(' Admin '), isTrue);
      expect(
        WorkforceCredentialPolicy.isPrimaryOwnerAlias('administrator'),
        isFalse,
      );
    });

    test('accepts only controlled username characters', () {
      expect(WorkforceCredentialPolicy.isValidUsername('desk_01'), isTrue);
      expect(WorkforceCredentialPolicy.isValidUsername('ab'), isFalse);
      expect(WorkforceCredentialPolicy.isValidUsername('desk staff'), isFalse);
    });

    test('requires a strong temporary or replacement password', () {
      expect(WorkforceCredentialPolicy.passwordError('StrongPass1'), isNull);
      expect(
        WorkforceCredentialPolicy.passwordError('alllowercase1'),
        isNotNull,
      );
      expect(WorkforceCredentialPolicy.passwordError('Short1A'), isNotNull);
    });
  });
}
