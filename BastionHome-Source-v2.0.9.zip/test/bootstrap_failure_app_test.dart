import 'package:bastionhome/main.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('startup failure remains usable on a narrow large-text screen', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(320, 568);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(
      const MediaQuery(
        data: MediaQueryData(textScaler: TextScaler.linear(1.35)),
        child: BootstrapFailureApp(),
      ),
    );

    expect(find.text('Bastion Home could not open its secure data'), findsOne);
    expect(find.text('Try again'), findsOne);
    expect(tester.takeException(), isNull);
  });
}
