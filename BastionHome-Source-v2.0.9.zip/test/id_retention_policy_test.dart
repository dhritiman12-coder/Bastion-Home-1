import 'package:bastionhome/services/id_retention_policy.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('retention uses the same calendar date in the next year', () {
    expect(
      IdRetentionPolicy.retainUntil(DateTime.utc(2026, 10, 4, 9, 15)),
      DateTime.utc(2027, 10, 4, 9, 15),
    );
  });

  test('booking trash keeps the newest ID image for a full year', () {
    final expiry = IdRetentionPolicy.trashExpiry(
      table: 'bookings',
      row: {
        'idFrontPath': 'front.bhid',
        'idFrontCapturedAt': '2026-04-01T00:00:00.000Z',
        'idBackPath': 'back.bhid',
        'idBackCapturedAt': '2026-05-20T00:00:00.000Z',
      },
      deletedAt: DateTime.utc(2026, 6, 1),
    );
    expect(expiry, DateTime.utc(2027, 5, 20));
  });

  test('ordinary records keep the normal seven-day trash window', () {
    final deletedAt = DateTime.utc(2026, 6, 1);
    expect(
      IdRetentionPolicy.trashExpiry(
        table: 'payments',
        row: const {},
        deletedAt: deletedAt,
      ),
      deletedAt.add(const Duration(days: 7)),
    );
  });
}
