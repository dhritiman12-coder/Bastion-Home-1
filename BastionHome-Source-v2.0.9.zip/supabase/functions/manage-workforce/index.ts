import "@supabase/functions-js/edge-runtime.d.ts";
import { withSupabase } from "@supabase/server";

const allowedRoles = new Set(["employee", "admin", "backup_admin"]);
const allowedPermissions = new Set([
  "createBookings",
  "viewOccupancy",
  "recordExpenses",
  "viewBookings",
  "manageBookings",
  "manageInventory",
  "viewPayments",
  "recordPayments",
  "manageGuestIds",
  "viewAnalytics",
]);
const defaultEmployeePermissions = [
  "createBookings",
  "viewOccupancy",
  "recordExpenses",
];

function employeePermissions(requested: string[]) {
  return [...new Set([...defaultEmployeePermissions, ...requested])];
}
const reportableSecurityEvents = new Set([
  "permission_denied",
  "settings_access_attempt",
  "failed_pin_lockout",
  "role_mismatch",
]);

function response(body: unknown, status = 200) {
  return Response.json(body, {
    status,
    headers: { "Cache-Control": "no-store" },
  });
}

function normalizeUsername(value: unknown) {
  const username = String(value ?? "").trim().toLowerCase();
  if (!/^[a-z0-9._-]{3,40}$/.test(username)) {
    throw new Error(
      "Username must be 3 to 40 letters, numbers, dots, dashes, or underscores",
    );
  }
  return username;
}

function validatePassword(value: unknown) {
  const password = String(value ?? "");
  if (
    password.length < 10 ||
    password.length > 72 ||
    !/[a-z]/.test(password) ||
    !/[A-Z]/.test(password) ||
    !/[0-9]/.test(password)
  ) {
    throw new Error(
      "Password must be 10 to 72 characters with uppercase, lowercase, and a number",
    );
  }
  return password;
}

function internalEmail(username: string) {
  return `${username}@staff.bastionhome.app`;
}

function safeSecurityMetadata(value: unknown) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  const allowedKeys = new Set([
    "resource",
    "attempted_action",
    "source",
    "device_id",
  ]);
  const output: Record<string, string> = {};
  for (const [key, item] of Object.entries(value)) {
    if (!allowedKeys.has(key)) continue;
    output[key] = String(item ?? "").slice(0, 160);
  }
  return output;
}

export default {
  fetch: withSupabase({ auth: "user" }, async (req, ctx) => {
    if (req.method !== "POST") return response({ error: "Method not allowed" }, 405);

    try {
      const callerId = ctx.userClaims?.id ?? ctx.jwtClaims?.sub;
      const body = await req.json();
      const action = String(body.action ?? "");
      const workspaceId = String(body.workspace_id ?? "");
      if (!callerId || !workspaceId) {
        return response({ error: "Authentication and workspace are required" }, 401);
      }

      const { data: caller, error: callerError } = await ctx.supabaseAdmin
        .from("bastion_workspace_members")
        .select("role, active, username")
        .eq("workspace_id", workspaceId)
        .eq("user_id", callerId)
        .maybeSingle();
      if (callerError) throw callerError;
      if (!caller?.active) {
        return response({ error: "Active business access is required" }, 403);
      }

      if (action === "report_security_event") {
        const eventType = String(body.event_type ?? "");
        if (!reportableSecurityEvents.has(eventType)) {
          return response({ error: "Unsupported security event" }, 400);
        }
        const oneMinuteAgo = new Date(Date.now() - 60_000).toISOString();
        const { count, error: countError } = await ctx.supabaseAdmin
          .from("bastion_security_events")
          .select("id", { count: "exact", head: true })
          .eq("workspace_id", workspaceId)
          .eq("actor_user_id", callerId)
          .gte("created_at", oneMinuteAgo);
        if (countError) throw countError;
        if ((count ?? 0) >= 20) {
          return response({ error: "Too many security events" }, 429);
        }
        const { error: insertError } = await ctx.supabaseAdmin
          .from("bastion_security_events")
          .insert({
            workspace_id: workspaceId,
            target_user_id: callerId,
            target_username: caller.username ?? "unknown",
            event_type: eventType,
            actor_user_id: callerId,
            metadata: safeSecurityMetadata(body.metadata),
          });
        if (insertError) throw insertError;
        return response({ ok: true }, 202);
      }

      if (caller.role !== "primary_admin") {
        return response({ error: "Only the primary owner can manage cloud accounts" }, 403);
      }

      if (action === "create") {
        const username = normalizeUsername(body.username);
        const password = validatePassword(body.temporary_password);
        const displayName = String(body.display_name ?? "").trim();
        const role = String(body.role ?? "employee");
        if (displayName.length < 2 || displayName.length > 100) {
          throw new Error("Display name must be 2 to 100 characters");
        }
        if (!allowedRoles.has(role)) throw new Error("Invalid account role");

        const requestedPermissions = Array.isArray(body.permissions)
          ? body.permissions.map(String)
          : defaultEmployeePermissions;
        if (requestedPermissions.some((item) => !allowedPermissions.has(item))) {
          throw new Error("Invalid employee permission");
        }
        const permissions = role === "employee"
          ? employeePermissions(requestedPermissions)
          : [];

        const { data: existing } = await ctx.supabaseAdmin
          .from("bastion_workspace_members")
          .select("user_id")
          .ilike("username", username)
          .maybeSingle();
        if (existing) return response({ error: "That username is already in use" }, 409);

        const { data: created, error: createError } =
          await ctx.supabaseAdmin.auth.admin.createUser({
            email: internalEmail(username),
            password,
            email_confirm: true,
            app_metadata: {
              bastion_managed: true,
              bastion_username: username,
              bastion_workspace_id: workspaceId,
              bastion_role: role,
            },
            user_metadata: { display_name: displayName },
          });
        if (createError || !created.user) throw createError ?? new Error("Account creation failed");

        const userId = created.user.id;
        const { error: membershipError } = await ctx.supabaseAdmin
          .from("bastion_workspace_members")
          .insert({
            workspace_id: workspaceId,
            user_id: userId,
            role,
            display_name: displayName,
            username,
            active: true,
            permissions,
            must_change_password: true,
            updated_at: new Date().toISOString(),
          });
        if (membershipError) {
          await ctx.supabaseAdmin.auth.admin.deleteUser(userId);
          throw membershipError;
        }

        await ctx.supabaseAdmin.from("bastion_security_events").insert({
          workspace_id: workspaceId,
          target_user_id: userId,
          target_username: username,
          event_type: "account_created",
          actor_user_id: callerId,
          metadata: { role },
        });
        return response({ user_id: userId, username, display_name: displayName, role }, 201);
      }

      const targetUserId = String(body.user_id ?? "");
      const { data: target, error: targetError } = await ctx.supabaseAdmin
        .from("bastion_workspace_members")
        .select("user_id, role, username, display_name, permissions")
        .eq("workspace_id", workspaceId)
        .eq("user_id", targetUserId)
        .maybeSingle();
      if (targetError) throw targetError;
      if (!target || target.role === "primary_admin" || !target.username) {
        return response({ error: "Managed staff account not found" }, 404);
      }

      if (action === "reset_password") {
        const password = validatePassword(body.temporary_password);
        const { error } = await ctx.supabaseAdmin.auth.admin.updateUserById(
          targetUserId,
          { password },
        );
        if (error) throw error;
        await ctx.supabaseAdmin
          .from("bastion_workspace_members")
          .update({ must_change_password: true, updated_at: new Date().toISOString() })
          .eq("workspace_id", workspaceId)
          .eq("user_id", targetUserId);
        await ctx.supabaseAdmin.from("bastion_security_events").insert({
          workspace_id: workspaceId,
          target_user_id: targetUserId,
          target_username: target.username,
          event_type: "password_reset_by_owner",
          actor_user_id: callerId,
        });
        return response({ ok: true });
      }

      if (action === "delete") {
        await ctx.supabaseAdmin
          .from("bastion_workspace_members")
          .update({ active: false, updated_at: new Date().toISOString() })
          .eq("workspace_id", workspaceId)
          .eq("user_id", targetUserId);
        await ctx.supabaseAdmin.from("bastion_security_events").insert({
          workspace_id: workspaceId,
          target_user_id: targetUserId,
          target_username: target.username,
          event_type: "account_deleted",
          actor_user_id: callerId,
          metadata: { display_name: target.display_name, role: target.role },
        });
        const { error } = await ctx.supabaseAdmin.auth.admin.deleteUser(targetUserId);
        if (error) throw error;
        return response({ ok: true });
      }

      return response({ error: "Unsupported workforce action" }, 400);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Workforce operation failed";
      return response({ error: message }, 400);
    }
  }),
};
