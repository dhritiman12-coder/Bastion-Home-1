import { createClient } from "jsr:@supabase/supabase-js@2";

const headers = {
  "Cache-Control": "no-store",
  "Content-Type": "application/json",
};

function response(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers });
}

Deno.serve(async (request) => {
  if (request.method !== "POST") {
    return response({ error: "Method not allowed" }, 405);
  }

  try {
    const body = await request.json();
    const username = String(body.username ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");
    if (username !== "admin" || password.length < 6 || password.length > 72) {
      return response({ error: "Invalid username or password" }, 400);
    }

    const url = Deno.env.get("SUPABASE_URL") ?? "";
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    const publishableKey =
      Deno.env.get("SUPABASE_ANON_KEY") ??
      Deno.env.get("SUPABASE_PUBLISHABLE_KEY") ??
      "";
    if (!url || !serviceRoleKey || !publishableKey) {
      throw new Error("Authentication service is not configured");
    }

    const admin = createClient(url, serviceRoleKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const { data: membership, error: membershipError } = await admin
      .from("bastion_workspace_members")
      .select("user_id")
      .eq("role", "primary_admin")
      .eq("active", true)
      .maybeSingle();
    if (membershipError || !membership?.user_id) {
      return response({ error: "Invalid username or password" }, 400);
    }

    const { data: owner, error: ownerError } =
      await admin.auth.admin.getUserById(membership.user_id);
    if (ownerError || !owner.user?.email) {
      return response({ error: "Invalid username or password" }, 400);
    }

    const auth = createClient(url, publishableKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const { data, error } = await auth.auth.signInWithPassword({
      email: owner.user.email,
      password,
    });
    if (error || !data.session) {
      return response({ error: "Invalid username or password" }, 400);
    }

    return response({
      access_token: data.session.access_token,
      refresh_token: data.session.refresh_token,
    });
  } catch {
    return response({ error: "Sign-in service is temporarily unavailable" }, 503);
  }
});
