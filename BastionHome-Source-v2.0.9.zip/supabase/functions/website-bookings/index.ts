import { createClient } from 'npm:@supabase/supabase-js@2'

type JsonRecord = Record<string, unknown>

const jsonHeaders = { 'Content-Type': 'application/json; charset=utf-8' }
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'content-type, x-bastion-booking-key',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Max-Age': '86400',
}

function response(body: JsonRecord, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...jsonHeaders, ...corsHeaders },
  })
}

function text(value: unknown, max = 2000) {
  return typeof value === 'string' ? value.trim().slice(0, max) : ''
}

function date(value: unknown) {
  const normalized = text(value, 10)
  return /^\d{4}-\d{2}-\d{2}$/.test(normalized) ? normalized : ''
}

async function fingerprint(request: Request) {
  const forwarded = request.headers.get('x-forwarded-for')?.split(',')[0] ?? ''
  const source = new TextEncoder().encode(forwarded.trim() || 'unknown')
  const digest = await crypto.subtle.digest('SHA-256', source)
  return Array.from(new Uint8Array(digest))
    .map((value) => value.toString(16).padStart(2, '0'))
    .join('')
}

function secretKey() {
  const modern = Deno.env.get('SUPABASE_SECRET_KEYS')
  if (modern) {
    const keys = JSON.parse(modern) as Record<string, string>
    if (keys.default) return keys.default
  }
  return Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
}

function errorMessage(error: unknown) {
  if (error instanceof Error) return error.message
  if (typeof error === 'object' && error !== null && 'message' in error) {
    return String((error as { message: unknown }).message)
  }
  return String(error)
}

Deno.serve(async (request) => {
  if (request.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }
  if (request.method !== 'POST') {
    return response({ error: 'Use POST for booking requests.' }, 405)
  }

  try {
    const body = (await request.json()) as JsonRecord
    const websiteKey =
      text(request.headers.get('x-bastion-booking-key'), 256) ||
      text(body.websiteKey, 256)
    const channelId = websiteKey.split('.')[0]
    if (!websiteKey || !/^[0-9a-f-]{36}$/i.test(channelId)) {
      return response({ error: 'Website booking key is missing or invalid.' }, 401)
    }

    const url = Deno.env.get('SUPABASE_URL') ?? ''
    const key = secretKey()
    if (!url || !key) {
      console.error('Supabase server credentials are unavailable')
      return response({ error: 'Booking service is not configured.' }, 503)
    }
    const admin = createClient(url, key, {
      auth: { persistSession: false, autoRefreshToken: false },
    })

    const { data: channel, error: channelError } = await admin
      .from('bastion_website_channels')
      .select('enabled, allowed_origin')
      .eq('id', channelId)
      .maybeSingle()
    if (channelError || !channel) {
      return response({ error: 'Website booking key is invalid.' }, 401)
    }
    if (!channel.enabled) {
      return response({ error: 'Online booking is currently paused.' }, 403)
    }
    const requestOrigin = (request.headers.get('origin') ?? '').replace(/\/$/, '')
    const allowedOrigin = String(channel.allowed_origin ?? '').replace(/\/$/, '')
    if (allowedOrigin && requestOrigin !== allowedOrigin) {
      return response({ error: 'This website is not authorized.' }, 403)
    }

    const action = text(body.action, 20).toLowerCase()
    const checkin = date(body.checkin)
    const checkout = date(body.checkout)
    const requestFingerprint = await fingerprint(request)

    if (action === 'availability') {
      const { data, error } = await admin.rpc('bastion_website_availability', {
        website_key: websiteKey,
        requested_checkin: checkin,
        requested_checkout: checkout,
        request_fingerprint: requestFingerprint,
      })
      if (error) throw error
      return response({ availability: data })
    }

    if (action === 'book') {
      const guests = Number(body.guests)
      const { data, error } = await admin.rpc('create_bastion_website_booking', {
        website_key: websiteKey,
        requested_room: text(body.room, 80),
        requested_checkin: checkin,
        requested_checkout: checkout,
        guest_name: text(body.guestName, 200),
        guest_phone: text(body.phone, 40),
        guest_count: Number.isInteger(guests) ? guests : 1,
        guest_address: text(body.address, 500),
        other_occupants: text(body.otherOccupants, 4000),
        guest_id_type: text(body.idType, 100),
        guest_id_number: text(body.idNumber, 100),
        booking_notes: text(body.notes, 2000),
        request_fingerprint: requestFingerprint,
      })
      if (error) throw error
      return response({ booking: data }, 201)
    }

    return response({ error: 'Choose availability or book.' }, 400)
  } catch (error) {
    const message = errorMessage(error)
    console.error('Website booking request failed', message)
    if (/already booked|just booked/i.test(message)) {
      return response({ error: message }, 409)
    }
    if (/too many/i.test(message)) {
      return response({ error: message }, 429)
    }
    if (/invalid website key/i.test(message)) {
      return response({ error: 'Website booking key is invalid.' }, 401)
    }
    if (/required|choose valid|valid room|future booking/i.test(message)) {
      return response({ error: message }, 400)
    }
    return response({ error: 'The booking could not be completed.' }, 500)
  }
})
