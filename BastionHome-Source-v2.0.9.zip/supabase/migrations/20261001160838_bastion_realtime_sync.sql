create extension if not exists pgcrypto with schema extensions;
create extension if not exists pg_cron with schema pg_catalog;

create table public.bastion_workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 100),
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.bastion_workspace_members (
  workspace_id uuid not null references public.bastion_workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('primary_admin', 'admin', 'employee')),
  display_name text not null default '',
  joined_at timestamptz not null default now(),
  primary key (workspace_id, user_id)
);

create table public.bastion_sync_records (
  workspace_id uuid not null references public.bastion_workspaces(id) on delete cascade,
  record_id text not null,
  entity_type text not null check (
    entity_type in (
      'bookings', 'payments', 'daily_expenses', 'monthly_expenses',
      'yearly_expenses', 'id_records', 'inventory', 'seasonal_rates'
    )
  ),
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  deleted_by text,
  source_device text not null default '',
  primary key (workspace_id, record_id)
);

create index bastion_sync_records_updated_idx
  on public.bastion_sync_records (workspace_id, updated_at);
create index bastion_sync_records_deleted_idx
  on public.bastion_sync_records (workspace_id, deleted_at)
  where deleted_at is not null;

create or replace function public.keep_newest_bastion_sync_record()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  if new.updated_at < old.updated_at then
    return old;
  end if;
  return new;
end;
$$;

create trigger keep_newest_bastion_sync_record
before update on public.bastion_sync_records
for each row execute function public.keep_newest_bastion_sync_record();

create table public.bastion_purged_records (
  workspace_id uuid not null references public.bastion_workspaces(id) on delete cascade,
  record_id text not null,
  purged_at timestamptz not null default now(),
  primary key (workspace_id, record_id)
);

create table public.bastion_workspace_invites (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.bastion_workspaces(id) on delete cascade,
  code_hash text not null unique,
  role text not null check (role in ('admin', 'employee')),
  created_by uuid not null references auth.users(id),
  expires_at timestamptz not null,
  used_by uuid references auth.users(id),
  used_at timestamptz
);

alter table public.bastion_workspaces enable row level security;
alter table public.bastion_workspace_members enable row level security;
alter table public.bastion_sync_records enable row level security;
alter table public.bastion_purged_records enable row level security;
alter table public.bastion_workspace_invites enable row level security;

revoke all on table public.bastion_workspaces from anon, authenticated;
revoke all on table public.bastion_workspace_members from anon, authenticated;
revoke all on table public.bastion_sync_records from anon, authenticated;
revoke all on table public.bastion_purged_records from anon, authenticated;
revoke all on table public.bastion_workspace_invites from anon, authenticated;

grant select on table public.bastion_workspaces to authenticated;
grant select on table public.bastion_workspace_members to authenticated;
grant select, insert, update on table public.bastion_sync_records to authenticated;
grant select on table public.bastion_purged_records to authenticated;

create schema if not exists private;
revoke all on schema private from public, anon, authenticated;

create or replace function private.bastion_member_role(target_workspace uuid)
returns text
language sql
stable
security definer
set search_path = public
as $$
  select member.role
  from public.bastion_workspace_members member
  where member.workspace_id = target_workspace
    and member.user_id = auth.uid()
  limit 1
$$;

revoke all on function private.bastion_member_role(uuid) from public;
grant usage on schema private to authenticated;
grant execute on function private.bastion_member_role(uuid) to authenticated;

create policy "Members can read their workspace"
on public.bastion_workspaces for select
to authenticated
using (private.bastion_member_role(id) is not null);

create policy "Members can read workspace membership"
on public.bastion_workspace_members for select
to authenticated
using (private.bastion_member_role(workspace_id) is not null);

create policy "Members can read synchronized records"
on public.bastion_sync_records for select
to authenticated
using (private.bastion_member_role(workspace_id) is not null);

create policy "Authorized members can insert synchronized records"
on public.bastion_sync_records for insert
to authenticated
with check (
  private.bastion_member_role(workspace_id) in ('primary_admin', 'admin')
  or (
    private.bastion_member_role(workspace_id) = 'employee'
    and entity_type in ('bookings', 'daily_expenses')
    and deleted_at is null
  )
);

create policy "Authorized members can update synchronized records"
on public.bastion_sync_records for update
to authenticated
using (private.bastion_member_role(workspace_id) is not null)
with check (
  private.bastion_member_role(workspace_id) in ('primary_admin', 'admin')
  or (
    private.bastion_member_role(workspace_id) = 'employee'
    and entity_type in ('bookings', 'daily_expenses')
    and deleted_at is null
  )
);

create policy "Members can read purge markers"
on public.bastion_purged_records for select
to authenticated
using (private.bastion_member_role(workspace_id) is not null);

create or replace function public.create_bastion_workspace(workspace_name text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  caller uuid := auth.uid();
  created_id uuid;
begin
  if caller is null then
    raise exception 'Authentication required';
  end if;
  if char_length(trim(workspace_name)) < 2 then
    raise exception 'Property name is required';
  end if;
  insert into public.bastion_workspaces (name, created_by)
  values (trim(workspace_name), caller)
  returning id into created_id;
  insert into public.bastion_workspace_members (
    workspace_id, user_id, role, display_name
  ) values (created_id, caller, 'primary_admin', 'Primary administrator');
  return created_id;
end;
$$;

create or replace function public.create_bastion_invite(
  target_workspace uuid,
  target_role text,
  valid_days integer default 7
)
returns text
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  caller uuid := auth.uid();
  invite_code text;
begin
  if caller is null then
    raise exception 'Authentication required';
  end if;
  if target_role not in ('admin', 'employee') then
    raise exception 'Invalid invited role';
  end if;
  if not exists (
    select 1 from public.bastion_workspace_members member
    where member.workspace_id = target_workspace
      and member.user_id = caller
      and member.role in ('primary_admin', 'admin')
  ) then
    raise exception 'Administrator access required';
  end if;
  invite_code := upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 10));
  insert into public.bastion_workspace_invites (
    workspace_id, code_hash, role, created_by, expires_at
  ) values (
    target_workspace,
    encode(digest(invite_code, 'sha256'), 'hex'),
    target_role,
    caller,
    now() + make_interval(days => greatest(1, least(valid_days, 30)))
  );
  return invite_code;
end;
$$;

create or replace function public.join_bastion_workspace(
  invite_code text,
  member_name text
)
returns uuid
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  caller uuid := auth.uid();
  matching_invite public.bastion_workspace_invites%rowtype;
begin
  if caller is null then
    raise exception 'Authentication required';
  end if;
  select * into matching_invite
  from public.bastion_workspace_invites invite
  where invite.code_hash = encode(digest(upper(trim(invite_code)), 'sha256'), 'hex')
    and invite.used_at is null
    and invite.expires_at > now()
  for update;
  if matching_invite.id is null then
    raise exception 'Invitation code is invalid or expired';
  end if;
  insert into public.bastion_workspace_members (
    workspace_id, user_id, role, display_name
  ) values (
    matching_invite.workspace_id,
    caller,
    matching_invite.role,
    left(trim(member_name), 100)
  ) on conflict (workspace_id, user_id) do update
    set role = excluded.role, display_name = excluded.display_name;
  update public.bastion_workspace_invites
  set used_by = caller, used_at = now()
  where id = matching_invite.id;
  return matching_invite.workspace_id;
end;
$$;

create or replace function public.purge_bastion_expired_trash()
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.bastion_purged_records (workspace_id, record_id, purged_at)
  select workspace_id, record_id, now()
  from public.bastion_sync_records
  where deleted_at <= now() - interval '7 days'
  on conflict (workspace_id, record_id) do nothing;

  delete from public.bastion_sync_records
  where deleted_at <= now() - interval '7 days';
end;
$$;

revoke all on function public.create_bastion_workspace(text) from public;
revoke all on function public.create_bastion_invite(uuid, text, integer) from public;
revoke all on function public.join_bastion_workspace(text, text) from public;
revoke all on function public.purge_bastion_expired_trash() from public;
revoke all on function public.keep_newest_bastion_sync_record() from public;
grant execute on function public.create_bastion_workspace(text) to authenticated;
grant execute on function public.create_bastion_invite(uuid, text, integer) to authenticated;
grant execute on function public.join_bastion_workspace(text, text) to authenticated;

alter table public.bastion_sync_records replica identity full;
alter table public.bastion_purged_records replica identity full;

do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'bastion_sync_records'
  ) then
    alter publication supabase_realtime add table public.bastion_sync_records;
  end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'bastion_purged_records'
  ) then
    alter publication supabase_realtime add table public.bastion_purged_records;
  end if;
end;
$$;

select cron.schedule(
  'bastion-trash-retention',
  '17 * * * *',
  'select public.purge_bastion_expired_trash()'
);
