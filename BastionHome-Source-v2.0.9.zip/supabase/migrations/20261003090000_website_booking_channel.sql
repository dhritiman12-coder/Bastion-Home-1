create table public.bastion_website_channels (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null unique
    references public.bastion_workspaces(id) on delete cascade,
  secret_hash text not null,
  enabled boolean not null default true,
  allowed_origin text not null default '',
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (char_length(allowed_origin) <= 2048)
);

alter table public.bastion_website_channels enable row level security;
revoke all on table public.bastion_website_channels from anon, authenticated;
grant select, update on table public.bastion_website_channels to authenticated;

create policy "Administrators can read website booking settings"
on public.bastion_website_channels for select
to authenticated
using (
  (select private.bastion_member_role(workspace_id)) in (
    'primary_admin', 'admin'
  )
);

create policy "Administrators can update website booking settings"
on public.bastion_website_channels for update
to authenticated
using (
  (select private.bastion_member_role(workspace_id)) in (
    'primary_admin', 'admin'
  )
)
with check (
  (select private.bastion_member_role(workspace_id)) in (
    'primary_admin', 'admin'
  )
);

create table private.bastion_website_request_log (
  channel_id uuid not null
    references public.bastion_website_channels(id) on delete cascade,
  request_fingerprint text not null,
  requested_at timestamptz not null default now()
);

create index bastion_website_request_log_lookup_idx
  on private.bastion_website_request_log (
    channel_id, request_fingerprint, requested_at
  );

create unique index bastion_active_booking_serial_unique_idx
  on public.bastion_sync_records (
    workspace_id, (payload ->> 'serialNumber')
  )
  where entity_type = 'bookings'
    and deleted_at is null
    and coalesce(payload ->> 'serialNumber', '') <> '';

create or replace function private.bastion_check_website_rate_limit(
  target_channel uuid,
  request_fingerprint text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  recent_requests integer;
begin
  delete from private.bastion_website_request_log
  where requested_at < now() - interval '1 day';

  select count(*) into recent_requests
  from private.bastion_website_request_log
  where channel_id = target_channel
    and request_fingerprint = left(coalesce(request_fingerprint, ''), 128)
    and requested_at >= now() - interval '10 minutes';

  if recent_requests >= 30 then
    raise exception 'Too many booking requests. Please try again shortly.'
      using errcode = 'P0001';
  end if;

  insert into private.bastion_website_request_log (
    channel_id, request_fingerprint
  ) values (
    target_channel, left(coalesce(request_fingerprint, ''), 128)
  );
end;
$$;

create or replace function public.create_bastion_website_channel(
  target_workspace uuid,
  website_origin text default ''
)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  caller uuid := auth.uid();
  channel_id uuid := extensions.gen_random_uuid();
  channel_secret text := encode(extensions.gen_random_bytes(32), 'hex');
  normalized_origin text := rtrim(trim(coalesce(website_origin, '')), '/');
begin
  if caller is null then
    raise exception 'Authentication required';
  end if;
  if not exists (
    select 1
    from public.bastion_workspace_members member
    where member.workspace_id = target_workspace
      and member.user_id = caller
      and member.role in ('primary_admin', 'admin')
  ) then
    raise exception 'Administrator access required';
  end if;
  if char_length(normalized_origin) > 2048
      or (
        normalized_origin <> ''
        and normalized_origin !~ '^https://[A-Za-z0-9]'
        and normalized_origin !~ '^http://(localhost|127[.]0[.]0[.]1)(:[0-9]+)?$'
      ) then
    raise exception 'Enter a valid HTTPS website address';
  end if;

  insert into public.bastion_website_channels (
    id, workspace_id, secret_hash, enabled, allowed_origin,
    created_by, created_at, updated_at
  ) values (
    channel_id,
    target_workspace,
    encode(extensions.digest(channel_secret, 'sha256'), 'hex'),
    true,
    normalized_origin,
    caller,
    now(),
    now()
  )
  on conflict (workspace_id) do update set
    secret_hash = excluded.secret_hash,
    enabled = true,
    allowed_origin = excluded.allowed_origin,
    created_by = excluded.created_by,
    created_at = now(),
    updated_at = now();

  select item.id into channel_id
  from public.bastion_website_channels item
  where item.workspace_id = target_workspace;

  return channel_id::text || '.' || channel_secret;
end;
$$;

create or replace function public.bastion_website_availability(
  website_key text,
  requested_checkin date,
  requested_checkout date,
  request_fingerprint text default ''
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  key_parts text[] := string_to_array(coalesce(website_key, ''), '.');
  channel public.bastion_website_channels%rowtype;
  available_rooms text[];
  occupied_rooms text[];
begin
  if array_length(key_parts, 1) <> 2
      or key_parts[1] !~* '^[0-9a-f-]{36}$' then
    raise exception 'Invalid website key';
  end if;
  select * into channel
  from public.bastion_website_channels item
  where item.id = key_parts[1]::uuid
    and item.secret_hash = encode(
      extensions.digest(key_parts[2], 'sha256'), 'hex'
    );
  if channel.id is null then
    raise exception 'Invalid website key';
  end if;
  if not channel.enabled then
    raise exception 'Online booking is paused';
  end if;
  if requested_checkin is null or requested_checkout is null
      or requested_checkout <= requested_checkin
      or requested_checkin < current_date then
    raise exception 'Choose valid future booking dates';
  end if;

  perform private.bastion_check_website_rate_limit(
    channel.id, request_fingerprint
  );

  select
    array_agg(room_name order by room_name)
      filter (where not occupied),
    array_agg(room_name order by room_name)
      filter (where occupied)
  into available_rooms, occupied_rooms
  from (
    select room_name, exists (
      select 1
      from public.bastion_sync_records record
      where record.workspace_id = channel.workspace_id
        and record.entity_type = 'bookings'
        and record.deleted_at is null
        and coalesce(record.payload ->> 'status', 'Booked')
          not in ('Cancelled', 'No-show')
        and record.payload ->> 'room' = room_name
        and record.payload ->> 'checkin' < requested_checkout::text
        and record.payload ->> 'checkout' > requested_checkin::text
    ) as occupied
    from unnest(array[
      'Room 1', 'Room 2', 'Room 3', 'Room 4', 'Room 5'
    ]) as room_name
  ) rooms;

  return jsonb_build_object(
    'availableRooms', to_jsonb(coalesce(available_rooms, array[]::text[])),
    'occupiedRooms', to_jsonb(coalesce(occupied_rooms, array[]::text[]))
  );
end;
$$;

create or replace function public.create_bastion_website_booking(
  website_key text,
  requested_room text,
  requested_checkin date,
  requested_checkout date,
  guest_name text,
  guest_phone text,
  guest_count integer,
  guest_address text,
  other_occupants text,
  guest_id_type text,
  guest_id_number text,
  booking_notes text,
  request_fingerprint text default ''
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  key_parts text[] := string_to_array(coalesce(website_key, ''), '.');
  channel public.bastion_website_channels%rowtype;
  sync_id uuid := extensions.gen_random_uuid();
  booking_id text;
  booking_serial text;
  serial_month text := to_char(current_date, 'MM-YYYY');
  masked_id text;
begin
  if array_length(key_parts, 1) <> 2
      or key_parts[1] !~* '^[0-9a-f-]{36}$' then
    raise exception 'Invalid website key';
  end if;
  select * into channel
  from public.bastion_website_channels item
  where item.id = key_parts[1]::uuid
    and item.secret_hash = encode(
      extensions.digest(key_parts[2], 'sha256'), 'hex'
    );
  if channel.id is null then
    raise exception 'Invalid website key';
  end if;
  if not channel.enabled then
    raise exception 'Online booking is paused';
  end if;
  if requested_room not in (
    'Room 1', 'Room 2', 'Room 3', 'Room 4', 'Room 5'
  ) then
    raise exception 'Choose a valid room';
  end if;
  if requested_checkin is null or requested_checkout is null
      or requested_checkout <= requested_checkin
      or requested_checkin < current_date then
    raise exception 'Choose valid future booking dates';
  end if;
  if char_length(trim(coalesce(guest_name, ''))) not between 2 and 200 then
    raise exception 'Guest name is required';
  end if;
  if char_length(trim(coalesce(guest_phone, ''))) not between 5 and 40 then
    raise exception 'Guest phone number is required';
  end if;
  if guest_count not between 1 and 20 then
    raise exception 'Choose a valid number of guests';
  end if;
  if char_length(trim(coalesce(guest_id_number, ''))) not between 4 and 100 then
    raise exception 'ID number is required';
  end if;

  perform private.bastion_check_website_rate_limit(
    channel.id, request_fingerprint
  );
  perform pg_catalog.pg_advisory_xact_lock(
    pg_catalog.hashtextextended(
      channel.workspace_id::text || ':' || requested_room, 0
    )
  );
  perform pg_catalog.pg_advisory_xact_lock(
    pg_catalog.hashtextextended(
      channel.workspace_id::text || ':serial:' || serial_month, 0
    )
  );

  if exists (
    select 1
    from public.bastion_sync_records record
    where record.workspace_id = channel.workspace_id
      and record.entity_type = 'bookings'
      and record.deleted_at is null
      and coalesce(record.payload ->> 'status', 'Booked')
        not in ('Cancelled', 'No-show')
      and record.payload ->> 'room' = requested_room
      and record.payload ->> 'checkin' < requested_checkout::text
      and record.payload ->> 'checkout' > requested_checkin::text
  ) then
    raise exception 'That room was just booked. Please choose another room.'
      using errcode = '23P01';
  end if;

  booking_id := 'WEB-' || upper(substr(replace(sync_id::text, '-', ''), 1, 8));
  select candidate::text || '/' || serial_month into booking_serial
  from generate_series(1, 1000000) candidate
  where not exists (
    select 1
    from public.bastion_sync_records record
    where record.workspace_id = channel.workspace_id
      and record.entity_type = 'bookings'
      and record.deleted_at is null
      and record.payload ->> 'serialNumber' =
        candidate::text || '/' || serial_month
  )
  order by candidate
  limit 1;
  masked_id := repeat(
    'X', greatest(char_length(trim(guest_id_number)) - 4, 0)
  ) || right(trim(guest_id_number), 4);

  insert into public.bastion_sync_records (
    workspace_id, record_id, entity_type, payload, updated_at, source_device
  ) values (
    channel.workspace_id,
    sync_id::text,
    'bookings',
    jsonb_build_object(
      'id', booking_id,
      'guest', left(trim(guest_name), 200),
      'phone', left(trim(guest_phone), 40),
      'address', left(trim(coalesce(guest_address, '')), 500),
      'otherOccupants', left(trim(coalesce(other_occupants, '')), 4000),
      'guests', guest_count,
      'room', requested_room,
      'checkin', requested_checkin::text,
      'checkout', requested_checkout::text,
      'checkinTime', '12:00',
      'checkoutTime', '11:00',
      'tariff', 0,
      'extra', 0,
      'discount', 0,
      'status', 'Booked',
      'idTaken', 'No',
      'idType', left(trim(coalesce(guest_id_type, 'Other')), 100),
      'idNumber', masked_id,
      'idFrontPath', '',
      'idBackPath', '',
      'paymentMode', 'Online',
      'serialNumber', booking_serial,
      'createdBy', 'Website',
      'bookingSource', 'Online',
      'notes', left(trim(coalesce(booking_notes, '')), 2000)
    ),
    now(),
    'website'
  );

  return jsonb_build_object(
    'bookingId', booking_id,
    'room', requested_room,
    'checkin', requested_checkin,
    'checkout', requested_checkout
  );
end;
$$;

create or replace function public.prevent_bastion_booking_overlap()
returns trigger
language plpgsql
set search_path = ''
as $$
declare
  room_name text := new.payload ->> 'room';
  checkin_date text := new.payload ->> 'checkin';
  checkout_date text := new.payload ->> 'checkout';
  booking_status text := coalesce(new.payload ->> 'status', 'Booked');
begin
  if new.entity_type <> 'bookings'
      or new.deleted_at is not null
      or booking_status in ('Cancelled', 'No-show') then
    return new;
  end if;
  if room_name not in ('Room 1', 'Room 2', 'Room 3', 'Room 4', 'Room 5')
      or checkin_date !~ '^\d{4}-\d{2}-\d{2}$'
      or checkout_date !~ '^\d{4}-\d{2}-\d{2}$'
      or checkout_date <= checkin_date then
    raise exception 'Invalid booking room or dates';
  end if;

  perform pg_catalog.pg_advisory_xact_lock(
    pg_catalog.hashtextextended(
      new.workspace_id::text || ':' || room_name, 0
    )
  );
  if exists (
    select 1
    from public.bastion_sync_records record
    where record.workspace_id = new.workspace_id
      and record.record_id <> new.record_id
      and record.entity_type = 'bookings'
      and record.deleted_at is null
      and coalesce(record.payload ->> 'status', 'Booked')
        not in ('Cancelled', 'No-show')
      and record.payload ->> 'room' = room_name
      and record.payload ->> 'checkin' < checkout_date
      and record.payload ->> 'checkout' > checkin_date
  ) then
    raise exception 'Room is already booked for these dates'
      using errcode = '23P01';
  end if;
  return new;
end;
$$;

create trigger prevent_bastion_booking_overlap
before insert or update on public.bastion_sync_records
for each row execute function public.prevent_bastion_booking_overlap();

revoke all on function public.create_bastion_website_channel(uuid, text)
  from public;
revoke all on function public.bastion_website_availability(
  text, date, date, text
) from public;
revoke all on function public.create_bastion_website_booking(
  text, text, date, date, text, text, integer, text, text, text, text, text,
  text
) from public;
revoke all on function private.bastion_check_website_rate_limit(uuid, text)
  from public;
revoke all on function public.prevent_bastion_booking_overlap() from public;

grant execute on function public.create_bastion_website_channel(uuid, text)
  to authenticated;
grant execute on function public.bastion_website_availability(
  text, date, date, text
) to service_role;
grant execute on function public.create_bastion_website_booking(
  text, text, date, date, text, text, integer, text, text, text, text, text,
  text
) to service_role;
