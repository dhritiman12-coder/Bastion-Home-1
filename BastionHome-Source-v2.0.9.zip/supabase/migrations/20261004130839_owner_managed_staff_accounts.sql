alter table public.bastion_workspace_members
  add column if not exists username text,
  add column if not exists must_change_password boolean not null default false,
  add column if not exists password_changed_at timestamptz;

alter table public.bastion_workspace_members
  drop constraint if exists bastion_workspace_members_username_check;
alter table public.bastion_workspace_members
  add constraint bastion_workspace_members_username_check check (
    username is null or username ~ '^[a-z0-9._-]{3,40}$'
  );

create unique index if not exists bastion_workspace_members_username_unique
  on public.bastion_workspace_members (lower(username))
  where username is not null;

create table if not exists public.bastion_security_events (
  id uuid primary key default extensions.gen_random_uuid(),
  workspace_id uuid not null references public.bastion_workspaces(id)
    on delete cascade,
  target_user_id uuid,
  target_username text not null,
  event_type text not null check (event_type in (
    'account_created', 'password_changed', 'password_reset_by_owner',
    'account_deleted'
  )),
  actor_user_id uuid,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists bastion_security_events_workspace_created_idx
  on public.bastion_security_events (workspace_id, created_at desc);
create index if not exists bastion_security_events_target_created_idx
  on public.bastion_security_events (workspace_id, target_user_id, created_at desc);

alter table public.bastion_security_events enable row level security;

drop policy if exists "Administrators can read workforce security events"
  on public.bastion_security_events;
create policy "Administrators can read workforce security events"
on public.bastion_security_events for select
to authenticated
using (
  (select private.bastion_member_role(workspace_id)) in (
    'primary_admin', 'backup_admin', 'admin'
  )
);

revoke all on public.bastion_security_events
  from public, anon, authenticated;
grant select on public.bastion_security_events to authenticated;

create or replace function public.record_my_bastion_password_change(
  target_workspace uuid
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  caller uuid := auth.uid();
  member_username text;
begin
  if caller is null then
    raise exception 'Authentication required';
  end if;

  select member.username into member_username
  from public.bastion_workspace_members member
  where member.workspace_id = target_workspace
    and member.user_id = caller
    and member.active
  for update;

  if member_username is null then
    raise exception 'Active managed workforce account not found';
  end if;

  update public.bastion_workspace_members
  set must_change_password = false,
      password_changed_at = now(),
      updated_at = now()
  where workspace_id = target_workspace
    and user_id = caller;

  insert into public.bastion_security_events (
    workspace_id, target_user_id, target_username, event_type,
    actor_user_id, metadata
  ) values (
    target_workspace, caller, member_username, 'password_changed',
    caller, jsonb_build_object('source', 'mobile_app')
  );
end;
$$;

revoke all on function public.record_my_bastion_password_change(uuid)
  from public, anon, authenticated, service_role;
grant execute on function public.record_my_bastion_password_change(uuid)
  to authenticated;

-- Owner-managed accounts replace invitation-based self-enrollment.
revoke all on function public.create_bastion_invite(uuid, text, integer)
  from public, anon, authenticated;
revoke all on function public.join_bastion_workspace(text, text)
  from public, anon, authenticated;
