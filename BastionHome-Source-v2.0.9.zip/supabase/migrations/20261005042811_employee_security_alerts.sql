alter table public.bastion_security_events
  drop constraint if exists bastion_security_events_event_type_check;

alter table public.bastion_security_events
  add constraint bastion_security_events_event_type_check check (event_type in (
    'account_created', 'password_changed', 'password_reset_by_owner',
    'account_deleted', 'permission_denied', 'settings_access_attempt',
    'failed_pin_lockout', 'role_mismatch'
  ));

do $$
begin
  if not exists (
    select 1
    from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'bastion_security_events'
  ) then
    alter publication supabase_realtime
      add table public.bastion_security_events;
  end if;
end;
$$;
