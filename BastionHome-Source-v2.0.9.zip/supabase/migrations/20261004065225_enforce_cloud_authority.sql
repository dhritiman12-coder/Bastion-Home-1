alter table public.bastion_workspace_members
  drop constraint if exists bastion_workspace_members_role_check;
alter table public.bastion_workspace_members
  add constraint bastion_workspace_members_role_check
  check (role in ('primary_admin', 'backup_admin', 'admin', 'employee'));
alter table public.bastion_workspace_members
  add column if not exists active boolean not null default true,
  add column if not exists permissions text[] not null default array[
    'createBookings', 'viewOccupancy', 'recordExpenses'
  ]::text[],
  add column if not exists updated_at timestamptz not null default now();
alter table public.bastion_workspace_members
  drop constraint if exists bastion_workspace_members_permissions_check;
alter table public.bastion_workspace_members
  add constraint bastion_workspace_members_permissions_check check (
    permissions <@ array[
      'createBookings', 'viewOccupancy', 'recordExpenses', 'viewBookings',
      'manageBookings', 'manageInventory', 'viewPayments', 'recordPayments',
      'manageGuestIds', 'viewAnalytics'
    ]::text[]
  );

alter table public.bastion_workspace_invites
  drop constraint if exists bastion_workspace_invites_role_check;
alter table public.bastion_workspace_invites
  add constraint bastion_workspace_invites_role_check
  check (role in ('backup_admin', 'admin', 'employee'));
alter table public.bastion_workspace_invites
  add column if not exists permissions text[] not null default array[
    'createBookings', 'viewOccupancy', 'recordExpenses'
  ]::text[];

create or replace function private.bastion_member_role(target_workspace uuid)
returns text
language sql
stable
security definer
set search_path = ''
as $$
  select member.role
  from public.bastion_workspace_members member
  where member.workspace_id = target_workspace
    and member.user_id = (select auth.uid())
    and member.active
  limit 1
$$;

create or replace function private.bastion_member_has_permission(
  target_workspace uuid,
  target_permission text
)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select coalesce(target_permission = any(member.permissions), false)
  from public.bastion_workspace_members member
  where member.workspace_id = target_workspace
    and member.user_id = (select auth.uid())
    and member.active
  limit 1
$$;

drop policy if exists "Members can read workspace membership"
  on public.bastion_workspace_members;
create policy "Members can read workspace membership"
on public.bastion_workspace_members for select
to authenticated
using (
  user_id = (select auth.uid())
  or (select private.bastion_member_role(workspace_id)) in (
    'primary_admin', 'backup_admin', 'admin'
  )
);

drop policy if exists "Members can read synchronized records"
  on public.bastion_sync_records;
create policy "Members can read synchronized records"
on public.bastion_sync_records for select
to authenticated
using (
  (select private.bastion_member_role(workspace_id)) in (
    'primary_admin', 'backup_admin', 'admin'
  )
  or (
    (select private.bastion_member_role(workspace_id)) = 'employee'
    and (
      (entity_type = 'bookings' and (
        (select private.bastion_member_has_permission(
          workspace_id, 'createBookings'
        ))
        or (select private.bastion_member_has_permission(
          workspace_id, 'viewOccupancy'
        ))
        or (select private.bastion_member_has_permission(
          workspace_id, 'viewBookings'
        ))
        or (select private.bastion_member_has_permission(
          workspace_id, 'manageBookings'
        ))
      ))
      or (entity_type = 'daily_expenses' and (
        select private.bastion_member_has_permission(
          workspace_id, 'recordExpenses'
        )
      ))
    )
  )
);

drop policy if exists "Authorized members can insert synchronized records"
  on public.bastion_sync_records;
create policy "Authorized members can insert synchronized records"
on public.bastion_sync_records for insert
to authenticated
with check (
  (select private.bastion_member_role(workspace_id)) in (
    'primary_admin', 'backup_admin', 'admin'
  )
  or (
    (select private.bastion_member_role(workspace_id)) = 'employee'
    and (
      (entity_type = 'bookings' and (
        select private.bastion_member_has_permission(
          workspace_id, 'createBookings'
        )
      ))
      or (entity_type = 'daily_expenses' and (
        select private.bastion_member_has_permission(
          workspace_id, 'recordExpenses'
        )
      ))
    )
    and deleted_at is null
  )
);

drop policy if exists "Authorized members can update synchronized records"
  on public.bastion_sync_records;
create policy "Authorized members can update synchronized records"
on public.bastion_sync_records for update
to authenticated
using (
  (select private.bastion_member_role(workspace_id)) in (
    'primary_admin', 'backup_admin', 'admin'
  )
  or (
    (select private.bastion_member_role(workspace_id)) = 'employee'
    and (
      (entity_type = 'bookings' and (
        select private.bastion_member_has_permission(
          workspace_id, 'createBookings'
        )
      ))
      or (entity_type = 'daily_expenses' and (
        select private.bastion_member_has_permission(
          workspace_id, 'recordExpenses'
        )
      ))
    )
    and deleted_at is null
  )
)
with check (
  (select private.bastion_member_role(workspace_id)) in (
    'primary_admin', 'backup_admin', 'admin'
  )
  or (
    (select private.bastion_member_role(workspace_id)) = 'employee'
    and (
      (entity_type = 'bookings' and (
        select private.bastion_member_has_permission(
          workspace_id, 'createBookings'
        )
      ))
      or (entity_type = 'daily_expenses' and (
        select private.bastion_member_has_permission(
          workspace_id, 'recordExpenses'
        )
      ))
    )
    and deleted_at is null
  )
);

drop policy if exists "Administrators can insert purge markers"
  on public.bastion_purged_records;
create policy "Administrators can insert purge markers"
on public.bastion_purged_records for insert
to authenticated
with check (
  (select private.bastion_member_role(workspace_id)) in (
    'primary_admin', 'backup_admin', 'admin'
  )
);

drop policy if exists "Administrators can read website booking settings"
  on public.bastion_website_channels;
create policy "Administrators can read website booking settings"
on public.bastion_website_channels for select
to authenticated
using (
  (select private.bastion_member_role(workspace_id)) in (
    'primary_admin', 'backup_admin', 'admin'
  )
);

drop policy if exists "Administrators can update website booking settings"
  on public.bastion_website_channels;
create policy "Administrators can update website booking settings"
on public.bastion_website_channels for update
to authenticated
using (
  (select private.bastion_member_role(workspace_id)) in (
    'primary_admin', 'backup_admin', 'admin'
  )
)
with check (
  (select private.bastion_member_role(workspace_id)) in (
    'primary_admin', 'backup_admin', 'admin'
  )
);

create or replace function public.create_bastion_invite(
  target_workspace uuid,
  target_role text,
  valid_days integer default 7
)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  caller uuid := auth.uid();
  caller_role text;
  invite_code text;
begin
  if caller is null then
    raise exception 'Authentication required';
  end if;
  if target_role not in ('backup_admin', 'admin', 'employee') then
    raise exception 'Invalid invited role';
  end if;
  select member.role into caller_role
  from public.bastion_workspace_members member
  where member.workspace_id = target_workspace
    and member.user_id = caller
    and member.active;
  if caller_role is null
      or (target_role <> 'employee' and caller_role <> 'primary_admin')
      or (target_role = 'employee' and caller_role not in (
        'primary_admin', 'backup_admin', 'admin'
      )) then
    raise exception 'The primary owner must authorize this invitation';
  end if;
  if target_role = 'backup_admin' and exists (
    select 1 from public.bastion_workspace_members member
    where member.workspace_id = target_workspace
      and member.role = 'backup_admin'
      and member.active
  ) then
    raise exception 'An active backup administrator already exists';
  end if;
  invite_code := upper(substr(replace(extensions.gen_random_uuid()::text, '-', ''), 1, 10));
  insert into public.bastion_workspace_invites (
    workspace_id, code_hash, role, permissions, created_by, expires_at
  ) values (
    target_workspace,
    encode(extensions.digest(invite_code, 'sha256'), 'hex'),
    target_role,
    case when target_role = 'employee' then array[
      'createBookings', 'viewOccupancy', 'recordExpenses'
    ]::text[] else array[]::text[] end,
    caller,
    now() + make_interval(days => greatest(1, least(valid_days, 30)))
  );
  return invite_code;
end;
$$;

create or replace function public.join_bastion_workspace(
  invite_code text,
  member_name text
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  caller uuid := auth.uid();
  matching_invite public.bastion_workspace_invites%rowtype;
begin
  if caller is null then
    raise exception 'Authentication required';
  end if;
  select * into matching_invite
  from public.bastion_workspace_invites invite
  where invite.code_hash = encode(
      extensions.digest(upper(trim(invite_code)), 'sha256'), 'hex'
    )
    and invite.used_at is null
    and invite.expires_at > now()
  for update;
  if matching_invite.id is null then
    raise exception 'Invitation code is invalid or expired';
  end if;
  insert into public.bastion_workspace_members (
    workspace_id, user_id, role, display_name, active, permissions, updated_at
  ) values (
    matching_invite.workspace_id,
    caller,
    matching_invite.role,
    left(trim(member_name), 100),
    true,
    matching_invite.permissions,
    now()
  ) on conflict (workspace_id, user_id) do update set
    role = excluded.role,
    display_name = excluded.display_name,
    active = true,
    permissions = excluded.permissions,
    updated_at = now();
  update public.bastion_workspace_invites
  set used_by = caller, used_at = now()
  where id = matching_invite.id;
  return matching_invite.workspace_id;
end;
$$;

create or replace function public.update_bastion_member_access(
  target_workspace uuid,
  target_user uuid,
  target_active boolean,
  target_permissions text[] default null
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  caller uuid := auth.uid();
  target_member public.bastion_workspace_members%rowtype;
  allowed_permissions constant text[] := array[
    'createBookings', 'viewOccupancy', 'recordExpenses', 'viewBookings',
    'manageBookings', 'manageInventory', 'viewPayments', 'recordPayments',
    'manageGuestIds', 'viewAnalytics'
  ]::text[];
begin
  if caller is null then
    raise exception 'Authentication required';
  end if;
  if not exists (
    select 1 from public.bastion_workspace_members member
    where member.workspace_id = target_workspace
      and member.user_id = caller
      and member.role = 'primary_admin'
      and member.active
  ) then
    raise exception 'Only the primary owner can change workspace access';
  end if;
  select * into target_member
  from public.bastion_workspace_members member
  where member.workspace_id = target_workspace
    and member.user_id = target_user
  for update;
  if target_member.user_id is null then
    raise exception 'Workspace member not found';
  end if;
  if target_member.role = 'primary_admin' then
    raise exception 'The primary owner cannot be disabled or changed';
  end if;
  if target_permissions is not null
      and not (target_permissions <@ allowed_permissions) then
    raise exception 'Invalid employee permission';
  end if;
  update public.bastion_workspace_members
  set active = target_active,
      permissions = case
        when target_member.role = 'employee'
          then coalesce(target_permissions, permissions)
        else array[]::text[]
      end,
      updated_at = now()
  where workspace_id = target_workspace
    and user_id = target_user;
end;
$$;

create or replace function public.update_my_bastion_display_name(
  target_workspace uuid,
  member_name text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if char_length(trim(member_name)) < 2 then
    raise exception 'Display name is required';
  end if;
  update public.bastion_workspace_members
  set display_name = left(trim(member_name), 100), updated_at = now()
  where workspace_id = target_workspace
    and user_id = (select auth.uid())
    and active;
  if not found then
    raise exception 'Active workspace membership not found';
  end if;
end;
$$;

create or replace function public.create_bastion_website_channel(
  target_workspace uuid,
  website_origin text default ''
)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  caller uuid := auth.uid();
  channel_id uuid := extensions.gen_random_uuid();
  channel_secret text := encode(extensions.gen_random_bytes(32), 'hex');
  normalized_origin text := rtrim(trim(coalesce(website_origin, '')), '/');
begin
  if caller is null then
    raise exception 'Authentication required';
  end if;
  if not exists (
    select 1
    from public.bastion_workspace_members member
    where member.workspace_id = target_workspace
      and member.user_id = caller
      and member.active
      and member.role in ('primary_admin', 'backup_admin', 'admin')
  ) then
    raise exception 'Administrator access required';
  end if;
  if char_length(normalized_origin) > 2048
      or (
        normalized_origin <> ''
        and normalized_origin !~ '^https://[A-Za-z0-9]'
        and normalized_origin !~ '^http://(localhost|127[.]0[.]0[.]1)(:[0-9]+)?$'
      ) then
    raise exception 'Enter a valid HTTPS website address';
  end if;
  insert into public.bastion_website_channels (
    id, workspace_id, secret_hash, enabled, allowed_origin,
    created_by, created_at, updated_at
  ) values (
    channel_id,
    target_workspace,
    encode(extensions.digest(channel_secret, 'sha256'), 'hex'),
    true,
    normalized_origin,
    caller,
    now(),
    now()
  )
  on conflict (workspace_id) do update set
    secret_hash = excluded.secret_hash,
    enabled = true,
    allowed_origin = excluded.allowed_origin,
    created_by = excluded.created_by,
    created_at = now(),
    updated_at = now();
  select item.id into channel_id
  from public.bastion_website_channels item
  where item.workspace_id = target_workspace;
  return channel_id::text || '.' || channel_secret;
end;
$$;

revoke all on function public.create_bastion_invite(uuid, text, integer)
  from public, anon, authenticated, service_role;
revoke all on function public.join_bastion_workspace(text, text)
  from public, anon, authenticated, service_role;
revoke all on function public.update_bastion_member_access(
  uuid, uuid, boolean, text[]
) from public, anon, authenticated, service_role;
revoke all on function public.update_my_bastion_display_name(uuid, text)
  from public, anon, authenticated, service_role;
revoke all on function public.create_bastion_website_channel(uuid, text)
  from public, anon, authenticated, service_role;

grant execute on function public.create_bastion_invite(uuid, text, integer)
  to authenticated;
grant execute on function public.join_bastion_workspace(text, text)
  to authenticated;
grant execute on function public.update_bastion_member_access(
  uuid, uuid, boolean, text[]
) to authenticated;
grant execute on function public.update_my_bastion_display_name(uuid, text)
  to authenticated;
grant execute on function public.create_bastion_website_channel(uuid, text)
  to authenticated;

revoke all on function private.bastion_member_role(uuid)
  from public, anon;
revoke all on function private.bastion_member_has_permission(uuid, text)
  from public, anon;
grant execute on function private.bastion_member_role(uuid)
  to authenticated;
grant execute on function private.bastion_member_has_permission(uuid, text)
  to authenticated;
