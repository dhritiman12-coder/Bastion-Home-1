-- Limit employees to the operational records exposed by the employee portal.
drop policy if exists "Members can read synchronized records"
  on public.bastion_sync_records;
create policy "Members can read synchronized records"
on public.bastion_sync_records for select
to authenticated
using (
  (select private.bastion_member_role(workspace_id)) in (
    'primary_admin', 'admin'
  )
  or (
    (select private.bastion_member_role(workspace_id)) = 'employee'
    and entity_type in ('bookings', 'daily_expenses')
  )
);

drop policy if exists "Authorized members can update synchronized records"
  on public.bastion_sync_records;
create policy "Authorized members can update synchronized records"
on public.bastion_sync_records for update
to authenticated
using (
  (select private.bastion_member_role(workspace_id)) in (
    'primary_admin', 'admin'
  )
  or (
    (select private.bastion_member_role(workspace_id)) = 'employee'
    and entity_type in ('bookings', 'daily_expenses')
    and deleted_at is null
  )
)
with check (
  (select private.bastion_member_role(workspace_id)) in (
    'primary_admin', 'admin'
  )
  or (
    (select private.bastion_member_role(workspace_id)) = 'employee'
    and entity_type in ('bookings', 'daily_expenses')
    and deleted_at is null
  )
);

-- Employees only need their own membership row. Administrators retain the
-- workspace roster needed to manage invitations and access.
drop policy if exists "Members can read workspace membership"
  on public.bastion_workspace_members;
create policy "Members can read workspace membership"
on public.bastion_workspace_members for select
to authenticated
using (
  user_id = (select auth.uid())
  or (select private.bastion_member_role(workspace_id)) in (
    'primary_admin', 'admin'
  )
);

-- A purge produced while a phone is offline must reach the server before old
-- devices can resurrect that record. Only cloud administrators may publish it.
grant insert on table public.bastion_purged_records to authenticated;
create policy "Administrators can insert purge markers"
on public.bastion_purged_records for insert
to authenticated
with check (
  (select private.bastion_member_role(workspace_id)) in (
    'primary_admin', 'admin'
  )
);

-- Bound untrusted client payloads before Realtime fans them out to every phone.
alter table public.bastion_sync_records
  add constraint bastion_sync_record_id_format
  check (
    record_id ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'
  ) not valid;
alter table public.bastion_sync_records
  add constraint bastion_sync_payload_size
  check (octet_length(payload::text) <= 262144) not valid;
alter table public.bastion_sync_records
  add constraint bastion_sync_source_device_size
  check (char_length(source_device) <= 128) not valid;

alter table public.bastion_purged_records
  add constraint bastion_purged_record_id_format
  check (
    record_id ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'
  ) not valid;

-- This security-definer helper references only schema-qualified objects.
alter function private.bastion_member_role(uuid) set search_path = '';
