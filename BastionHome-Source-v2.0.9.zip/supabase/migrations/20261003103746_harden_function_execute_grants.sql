-- Hosted Supabase projects grant function execution to API roles explicitly.
-- Remove those inherited grants before allowing only each intended caller.

revoke all on function public.create_bastion_workspace(text)
  from public, anon, authenticated, service_role;
revoke all on function public.create_bastion_invite(uuid, text, integer)
  from public, anon, authenticated, service_role;
revoke all on function public.join_bastion_workspace(text, text)
  from public, anon, authenticated, service_role;
revoke all on function public.purge_bastion_expired_trash()
  from public, anon, authenticated, service_role;
revoke all on function public.keep_newest_bastion_sync_record()
  from public, anon, authenticated, service_role;

revoke all on function public.create_bastion_website_channel(uuid, text)
  from public, anon, authenticated, service_role;
revoke all on function public.bastion_website_availability(
  text, date, date, text
) from public, anon, authenticated, service_role;
revoke all on function public.create_bastion_website_booking(
  text, text, date, date, text, text, integer, text, text, text, text, text,
  text
) from public, anon, authenticated, service_role;
revoke all on function private.bastion_check_website_rate_limit(uuid, text)
  from public, anon, authenticated, service_role;
revoke all on function public.prevent_bastion_booking_overlap()
  from public, anon, authenticated, service_role;

grant execute on function public.create_bastion_workspace(text)
  to authenticated;
grant execute on function public.create_bastion_invite(uuid, text, integer)
  to authenticated;
grant execute on function public.join_bastion_workspace(text, text)
  to authenticated;
grant execute on function public.create_bastion_website_channel(uuid, text)
  to authenticated;

grant execute on function public.bastion_website_availability(
  text, date, date, text
) to service_role;
grant execute on function public.create_bastion_website_booking(
  text, text, date, date, text, text, integer, text, text, text, text, text,
  text
) to service_role;
