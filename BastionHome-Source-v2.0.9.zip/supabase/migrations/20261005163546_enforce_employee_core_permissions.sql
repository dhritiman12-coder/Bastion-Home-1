-- Employee booking, occupancy, and expense duties are mandatory for every
-- active employee. Extra module permissions remain owner-controlled.

create or replace function private.ensure_bastion_employee_core_permissions()
returns trigger
language plpgsql
set search_path = ''
as $$
declare
  required_permissions constant text[] := array[
    'createBookings', 'viewOccupancy', 'recordExpenses'
  ]::text[];
begin
  if new.role = 'employee' then
    new.permissions := array(
      select distinct item.permission
      from unnest(
        coalesce(new.permissions, array[]::text[]) || required_permissions
      ) as item(permission)
      order by item.permission
    );
  end if;
  return new;
end;
$$;

drop trigger if exists ensure_bastion_employee_core_permissions
  on public.bastion_workspace_members;
create trigger ensure_bastion_employee_core_permissions
before insert or update of role, permissions
on public.bastion_workspace_members
for each row execute function private.ensure_bastion_employee_core_permissions();

drop trigger if exists ensure_bastion_employee_core_permissions
  on public.bastion_workspace_invites;
create trigger ensure_bastion_employee_core_permissions
before insert or update of role, permissions
on public.bastion_workspace_invites
for each row execute function private.ensure_bastion_employee_core_permissions();

update public.bastion_workspace_members member
set permissions = array(
      select distinct item.permission
      from unnest(
        coalesce(member.permissions, array[]::text[]) ||
        array['createBookings', 'viewOccupancy', 'recordExpenses']::text[]
      ) as item(permission)
      order by item.permission
    ),
    updated_at = now()
where member.role = 'employee'
  and not coalesce(member.permissions, array[]::text[]) @>
    array['createBookings', 'viewOccupancy', 'recordExpenses']::text[];

update public.bastion_workspace_invites invite
set permissions = array(
      select distinct item.permission
      from unnest(
        coalesce(invite.permissions, array[]::text[]) ||
        array['createBookings', 'viewOccupancy', 'recordExpenses']::text[]
      ) as item(permission)
      order by item.permission
    )
where invite.role = 'employee'
  and not coalesce(invite.permissions, array[]::text[]) @>
    array['createBookings', 'viewOccupancy', 'recordExpenses']::text[];

alter table public.bastion_workspace_members
  drop constraint if exists
    bastion_workspace_members_employee_core_permissions_check;
alter table public.bastion_workspace_members
  add constraint bastion_workspace_members_employee_core_permissions_check
  check (
    role <> 'employee' or
    permissions @>
      array['createBookings', 'viewOccupancy', 'recordExpenses']::text[]
  );

alter table public.bastion_workspace_invites
  drop constraint if exists
    bastion_workspace_invites_employee_core_permissions_check;
alter table public.bastion_workspace_invites
  add constraint bastion_workspace_invites_employee_core_permissions_check
  check (
    role <> 'employee' or
    permissions @>
      array['createBookings', 'viewOccupancy', 'recordExpenses']::text[]
  );

create or replace function public.update_bastion_member_access(
  target_workspace uuid,
  target_user uuid,
  target_active boolean,
  target_permissions text[] default null
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  caller uuid := auth.uid();
  target_member public.bastion_workspace_members%rowtype;
  allowed_permissions constant text[] := array[
    'createBookings', 'viewOccupancy', 'recordExpenses', 'viewBookings',
    'manageBookings', 'manageInventory', 'viewPayments', 'recordPayments',
    'manageGuestIds', 'viewAnalytics'
  ]::text[];
  required_permissions constant text[] := array[
    'createBookings', 'viewOccupancy', 'recordExpenses'
  ]::text[];
begin
  if caller is null then
    raise exception 'Authentication required';
  end if;
  if not exists (
    select 1 from public.bastion_workspace_members member
    where member.workspace_id = target_workspace
      and member.user_id = caller
      and member.role = 'primary_admin'
      and member.active
  ) then
    raise exception 'Only the primary owner can change workspace access';
  end if;

  select * into target_member
  from public.bastion_workspace_members member
  where member.workspace_id = target_workspace
    and member.user_id = target_user
  for update;

  if target_member.user_id is null then
    raise exception 'Workspace member not found';
  end if;
  if target_member.role = 'primary_admin' then
    raise exception 'The primary owner cannot be disabled or changed';
  end if;
  if target_permissions is not null
      and not (target_permissions <@ allowed_permissions) then
    raise exception 'Invalid employee permission';
  end if;

  update public.bastion_workspace_members
  set active = target_active,
      permissions = case
        when target_member.role = 'employee' then array(
          select distinct item.permission
          from unnest(
            coalesce(
              target_permissions,
              target_member.permissions,
              array[]::text[]
            ) || required_permissions
          ) as item(permission)
          order by item.permission
        )
        else array[]::text[]
      end,
      updated_at = now()
  where workspace_id = target_workspace
    and user_id = target_user;
end;
$$;

revoke all on function public.update_bastion_member_access(
  uuid, uuid, boolean, text[]
) from public, anon, authenticated, service_role;
grant execute on function public.update_bastion_member_access(
  uuid, uuid, boolean, text[]
) to authenticated;
