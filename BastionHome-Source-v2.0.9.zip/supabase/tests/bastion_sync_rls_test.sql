BEGIN;
SELECT plan(24);

SELECT has_table('public', 'bastion_workspaces');
SELECT has_table('public', 'bastion_workspace_members');
SELECT has_table('public', 'bastion_sync_records');
SELECT has_table('public', 'bastion_purged_records');
SELECT has_table('public', 'bastion_workspace_invites');

SELECT ok(
  (SELECT relrowsecurity FROM pg_class WHERE oid = 'public.bastion_workspaces'::regclass),
  'workspaces has RLS enabled'
);
SELECT ok(
  (SELECT relrowsecurity FROM pg_class WHERE oid = 'public.bastion_workspace_members'::regclass),
  'members has RLS enabled'
);
SELECT ok(
  (SELECT relrowsecurity FROM pg_class WHERE oid = 'public.bastion_sync_records'::regclass),
  'sync records has RLS enabled'
);
SELECT ok(
  (SELECT relrowsecurity FROM pg_class WHERE oid = 'public.bastion_purged_records'::regclass),
  'purge markers has RLS enabled'
);
SELECT ok(
  (SELECT relrowsecurity FROM pg_class WHERE oid = 'public.bastion_workspace_invites'::regclass),
  'invites has RLS enabled'
);

SELECT ok(
  NOT has_table_privilege('anon', 'public.bastion_sync_records', 'SELECT'),
  'anonymous users cannot read business records'
);
SELECT ok(
  NOT has_table_privilege('anon', 'public.bastion_sync_records', 'INSERT'),
  'anonymous users cannot insert business records'
);
SELECT ok(
  NOT has_table_privilege('authenticated', 'public.bastion_sync_records', 'DELETE'),
  'clients cannot permanently delete synchronized records'
);
SELECT ok(
  NOT has_table_privilege('authenticated', 'public.bastion_workspace_invites', 'SELECT'),
  'invite hashes are not readable by clients'
);
SELECT ok(
  has_table_privilege('authenticated', 'public.bastion_purged_records', 'INSERT'),
  'authenticated administrators have an insert path for offline purge markers'
);
SELECT ok(
  NOT has_table_privilege('anon', 'public.bastion_purged_records', 'INSERT'),
  'anonymous users cannot insert purge markers'
);

SELECT ok(
  EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'bastion_sync_records'
      AND policyname = 'Members can read synchronized records'
  ),
  'sync record reads have an explicit membership policy'
);
SELECT ok(
  EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'bastion_sync_records'
      AND policyname = 'Authorized members can update synchronized records'
  ),
  'sync record updates check both old and resulting rows'
);
SELECT ok(
  EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'bastion_workspace_members'
      AND policyname = 'Members can read workspace membership'
  ),
  'workspace roster reads have an explicit role policy'
);
SELECT ok(
  EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'bastion_purged_records'
      AND policyname = 'Administrators can insert purge markers'
  ),
  'purge marker inserts require administrator membership'
);

SELECT has_function('public', 'create_bastion_workspace', ARRAY['text']);
SELECT has_function(
  'public',
  'create_bastion_invite',
  ARRAY['uuid', 'text', 'integer']
);
SELECT has_function(
  'public',
  'join_bastion_workspace',
  ARRAY['text', 'text']
);
SELECT has_function('public', 'purge_bastion_expired_trash', ARRAY[]::text[]);

SELECT * FROM finish();
ROLLBACK;
