import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../models/app_user.dart';
import '../../services/account_service.dart';
import '../../services/app_settings_service.dart';
import '../../services/cloud_sync_service.dart';
import '../../services/notification_service.dart';
import '../../services/workforce_credential_policy.dart';
import '../backup_screen/backup_screen.dart';
import '../branding_screen/branding_settings_screen.dart';
import '../staff_screen/staff_management_screen.dart';
import '../trash_screen/trash_screen.dart';
import '../cloud_sync_screen/cloud_sync_screen.dart';
import '../website_booking_screen/website_booking_screen.dart';
import '../customers_screen/customer_master_screen.dart';
import '../../widgets/app_back_button.dart';
import '../../widgets/admin_access_denied.dart';
import '../../widgets/credential_text_form_field.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  void _open(BuildContext context, Widget screen) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => screen));
  }

  Future<void> _pickTime(BuildContext context, {required bool checkin}) async {
    final settings = AppSettingsService();
    final raw = checkin
        ? settings.defaultCheckinTime
        : settings.defaultCheckoutTime;
    final parts = raw.split(':');
    final picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(
        hour: int.tryParse(parts.first) ?? 12,
        minute: int.tryParse(parts.length > 1 ? parts[1] : '') ?? 0,
      ),
    );
    if (picked == null) return;
    final value =
        '${picked.hour.toString().padLeft(2, '0')}:${picked.minute.toString().padLeft(2, '0')}';
    await settings.update(
      defaultCheckinTime: checkin ? value : null,
      defaultCheckoutTime: checkin ? null : value,
    );
  }

  Future<void> _changePin(BuildContext context) async {
    final current = TextEditingController();
    final next = TextEditingController();
    final confirm = TextEditingController();
    final formKey = GlobalKey<FormState>();
    final accepted = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Change PIN'),
        content: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              for (final field in [
                (controller: current, label: 'Current PIN'),
                (controller: next, label: 'New PIN'),
                (controller: confirm, label: 'Confirm new PIN'),
              ]) ...[
                CredentialTextFormField(
                  controller: field.controller,
                  labelText: field.label,
                  secret: true,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  validator: (value) =>
                      RegExp(r'^\d{6,12}$').hasMatch(value ?? '')
                      ? null
                      : 'Enter 6 to 12 digits',
                ),
                const SizedBox(height: 12),
              ],
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (!formKey.currentState!.validate()) return;
              if (next.text != confirm.text) {
                ScaffoldMessenger.of(dialogContext).showSnackBar(
                  const SnackBar(content: Text('New PINs do not match')),
                );
                return;
              }
              Navigator.pop(dialogContext, true);
            },
            child: const Text('Change'),
          ),
        ],
      ),
    );
    if (accepted != true || !context.mounted) return;
    try {
      await AccountService().changeOwnPin(current.text, next.text);
      if (context.mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('PIN changed')));
      }
    } catch (error) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              error.toString().replaceFirst('Invalid argument(s): ', ''),
            ),
          ),
        );
      }
    } finally {
      current.dispose();
      next.dispose();
      confirm.dispose();
    }
  }

  Future<void> _changeCloudPassword(BuildContext context) async {
    final current = TextEditingController();
    final next = TextEditingController();
    final confirm = TextEditingController();
    final formKey = GlobalKey<FormState>();
    final accepted = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Change Cloud Password'),
        content: Form(
          key: formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'The security event is recorded for the administrator. Password values are never recorded.',
                ),
                const SizedBox(height: 14),
                CredentialTextFormField(
                  controller: current,
                  labelText: 'Current password',
                  secret: true,
                  validator: (value) => (value?.isNotEmpty ?? false)
                      ? null
                      : 'Enter the current password',
                ),
                const SizedBox(height: 12),
                CredentialTextFormField(
                  controller: next,
                  labelText: 'New password',
                  helperText:
                      '10+ characters with uppercase, lowercase, and a number',
                  secret: true,
                  validator: (value) =>
                      WorkforceCredentialPolicy.passwordError(value ?? ''),
                ),
                const SizedBox(height: 12),
                CredentialTextFormField(
                  controller: confirm,
                  labelText: 'Confirm password',
                  secret: true,
                  validator: (value) =>
                      value == next.text ? null : 'Passwords do not match',
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (formKey.currentState!.validate()) {
                Navigator.pop(dialogContext, true);
              }
            },
            child: const Text('Change Password'),
          ),
        ],
      ),
    );
    if (accepted != true || !context.mounted) return;
    try {
      await CloudSyncService().changeCloudPassword(
        currentPassword: current.text,
        newPassword: next.text,
      );
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Cloud password changed securely')),
        );
      }
    } catch (error) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              error
                  .toString()
                  .replaceFirst('Invalid argument(s): ', '')
                  .replaceFirst('Bad state: ', ''),
            ),
          ),
        );
      }
    } finally {
      current.dispose();
      next.dispose();
      confirm.dispose();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!AccountService().isAdmin) {
      return const AdminAccessDenied(resource: 'application_settings');
    }
    final settings = AppSettingsService();
    final account = AccountService().currentUser!;
    return AnimatedBuilder(
      animation: settings,
      builder: (context, _) => Scaffold(
        appBar: AppBar(
          leading: const AppBackButton(),
          title: const Text('Settings'),
        ),
        body: ListView(
          padding: const EdgeInsets.only(bottom: 32),
          children: [
            _SettingsHeader(icon: Icons.business_outlined, title: 'Property'),
            ListTile(
              leading: const Icon(Icons.image_outlined),
              title: const Text('Branding & Property Details'),
              subtitle: const Text(
                'Logo, name, address, tax and invoice details',
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _open(context, const BrandingSettingsScreen()),
            ),
            ListTile(
              leading: const Icon(Icons.login_outlined),
              title: const Text('Default Check-in Time'),
              trailing: Text(settings.defaultCheckinTime),
              onTap: () => _pickTime(context, checkin: true),
            ),
            ListTile(
              leading: const Icon(Icons.logout_outlined),
              title: const Text('Default Check-out Time'),
              trailing: Text(settings.defaultCheckoutTime),
              onTap: () => _pickTime(context, checkin: false),
            ),
            _SettingsHeader(icon: Icons.palette_outlined, title: 'Appearance'),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: SegmentedButton<ThemeMode>(
                segments: const [
                  ButtonSegment(
                    value: ThemeMode.system,
                    icon: Icon(Icons.brightness_auto_outlined),
                    label: Text('System'),
                  ),
                  ButtonSegment(
                    value: ThemeMode.light,
                    icon: Icon(Icons.light_mode_outlined),
                    label: Text('Light'),
                  ),
                  ButtonSegment(
                    value: ThemeMode.dark,
                    icon: Icon(Icons.dark_mode_outlined),
                    label: Text('Dark'),
                  ),
                ],
                selected: {settings.themeMode},
                onSelectionChanged: (value) =>
                    settings.update(themeMode: value.first),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.text_fields),
              title: const Text('Text Size'),
              subtitle: Slider(
                min: 0.9,
                max: 1.35,
                divisions: 9,
                label: settings.textScale == 0.9
                    ? 'Compact'
                    : settings.textScale >= 1.3
                    ? 'Extra large'
                    : settings.textScale > 1.1
                    ? 'Large'
                    : 'Standard',
                value: settings.textScale.clamp(0.9, 1.35),
                onChanged: (value) => settings.update(textScale: value),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.font_download_outlined),
              title: const Text('App Font'),
              subtitle: const Text('Used for forms, lists and reports'),
              trailing: DropdownButton<String>(
                value: settings.fontFamily,
                underline: const SizedBox.shrink(),
                items: const [
                  DropdownMenuItem(value: 'Modern', child: Text('Modern')),
                  DropdownMenuItem(value: 'Classic', child: Text('Classic')),
                  DropdownMenuItem(value: 'System', child: Text('System')),
                ],
                onChanged: (value) => settings.update(fontFamily: value),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.title_outlined),
              title: const Text('Heading Font'),
              subtitle: const Text('Used for page and section headings'),
              trailing: DropdownButton<String>(
                value: settings.headingFontFamily,
                underline: const SizedBox.shrink(),
                items: const [
                  DropdownMenuItem(value: 'Classic', child: Text('Classic')),
                  DropdownMenuItem(value: 'Modern', child: Text('Modern')),
                  DropdownMenuItem(
                    value: 'Match app',
                    child: Text('Match app'),
                  ),
                  DropdownMenuItem(value: 'System', child: Text('System')),
                ],
                onChanged: (value) => settings.update(headingFontFamily: value),
              ),
            ),
            _SettingsHeader(
              icon: Icons.language_outlined,
              title: 'Currency, Date & Units',
            ),
            ListTile(
              leading: const Icon(Icons.currency_exchange),
              title: const Text('Currency'),
              trailing: DropdownButton<String>(
                value: settings.currencyCode,
                underline: const SizedBox.shrink(),
                items: const [
                  DropdownMenuItem(value: 'INR', child: Text('₹ INR')),
                  DropdownMenuItem(value: 'USD', child: Text('\$ USD')),
                  DropdownMenuItem(value: 'EUR', child: Text('€ EUR')),
                  DropdownMenuItem(value: 'GBP', child: Text('£ GBP')),
                ],
                onChanged: (value) {
                  const symbols = {
                    'INR': '₹',
                    'USD': '\$',
                    'EUR': '€',
                    'GBP': '£',
                  };
                  if (value != null) {
                    settings.update(
                      currencyCode: value,
                      currencySymbol: symbols[value],
                      indianNumberGrouping: value == 'INR',
                    );
                  }
                },
              ),
            ),
            ListTile(
              leading: const Icon(Icons.calendar_month_outlined),
              title: const Text('Date Format'),
              trailing: DropdownButton<String>(
                value: settings.dateFormat,
                underline: const SizedBox.shrink(),
                items: const [
                  DropdownMenuItem(
                    value: 'dd-MMM-yyyy',
                    child: Text('31-Dec-2026'),
                  ),
                  DropdownMenuItem(
                    value: 'dd/MM/yyyy',
                    child: Text('31/12/2026'),
                  ),
                  DropdownMenuItem(
                    value: 'MM/dd/yyyy',
                    child: Text('12/31/2026'),
                  ),
                  DropdownMenuItem(
                    value: 'yyyy-MM-dd',
                    child: Text('2026-12-31'),
                  ),
                ],
                onChanged: (value) => settings.update(dateFormat: value),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.straighten_outlined),
              title: const Text('Measurement Units'),
              trailing: DropdownButton<String>(
                value: settings.measurementSystem,
                underline: const SizedBox.shrink(),
                items: const [
                  DropdownMenuItem(value: 'Metric', child: Text('Metric')),
                  DropdownMenuItem(value: 'Imperial', child: Text('Imperial')),
                ],
                onChanged: (value) => settings.update(measurementSystem: value),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.thermostat_outlined),
              title: const Text('Temperature'),
              trailing: DropdownButton<String>(
                value: settings.temperatureUnit,
                underline: const SizedBox.shrink(),
                items: const [
                  DropdownMenuItem(value: 'Celsius', child: Text('°C')),
                  DropdownMenuItem(value: 'Fahrenheit', child: Text('°F')),
                ],
                onChanged: (value) => settings.update(temperatureUnit: value),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.inventory_2_outlined),
              title: const Text('Default Stock Unit'),
              trailing: DropdownButton<String>(
                value: settings.defaultStockUnit,
                underline: const SizedBox.shrink(),
                items: const ['pcs', 'sets', 'kg', 'litres', 'bottles', 'packs']
                    .map(
                      (unit) =>
                          DropdownMenuItem(value: unit, child: Text(unit)),
                    )
                    .toList(),
                onChanged: (value) => settings.update(defaultStockUnit: value),
              ),
            ),
            _SettingsHeader(
              icon: Icons.notifications_outlined,
              title: 'Alerts',
            ),
            SwitchListTile(
              secondary: const Icon(Icons.event_available_outlined),
              title: const Text('Booking Reminders'),
              value: settings.bookingReminders,
              onChanged: (value) async {
                await settings.update(bookingReminders: value);
                await NotificationService().scheduleAllNotifications();
              },
            ),
            SwitchListTile(
              secondary: const Icon(Icons.receipt_long_outlined),
              title: const Text('Expense Due Reminders'),
              value: settings.expenseReminders,
              onChanged: (value) async {
                await settings.update(expenseReminders: value);
                await NotificationService().scheduleAllNotifications();
              },
            ),
            SwitchListTile(
              secondary: const Icon(Icons.inventory_outlined),
              title: const Text('Low Stock Alerts'),
              value: settings.lowStockAlerts,
              onChanged: (value) async {
                await settings.update(lowStockAlerts: value);
                await NotificationService().scheduleAllNotifications();
              },
            ),
            SwitchListTile(
              secondary: const Icon(Icons.backup_outlined),
              title: const Text('Weekly Backup Reminder'),
              value: settings.weeklyBackupReminder,
              onChanged: (value) async {
                await settings.update(weeklyBackupReminder: value);
                await NotificationService().scheduleAllNotifications();
              },
            ),
            _SettingsHeader(
              icon: Icons.security_outlined,
              title: 'Security & Access',
            ),
            ListTile(
              leading: const Icon(Icons.people_outline),
              title: const Text('Accounts & Permissions'),
              subtitle: const Text('Create employees and administrators'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _open(context, const StaffManagementScreen()),
            ),
            SwitchListTile(
              secondary: const Icon(Icons.fingerprint),
              title: const Text('Device Unlock'),
              subtitle: const Text(
                'Use biometrics or device credentials after first PIN sign-in',
              ),
              value: settings.biometricUnlock,
              onChanged: (value) => settings.update(biometricUnlock: value),
            ),
            SwitchListTile(
              secondary: const Icon(Icons.phonelink_lock_outlined),
              title: const Text('Lock When App Is Backgrounded'),
              value: settings.lockOnBackground,
              onChanged: (value) => settings.update(lockOnBackground: value),
            ),
            ListTile(
              leading: const Icon(Icons.password_outlined),
              title: const Text('Change My PIN'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _changePin(context),
            ),
            if (CloudSyncService().isConnected)
              ListTile(
                leading: const Icon(Icons.lock_outline),
                title: const Text('Change Cloud Password'),
                subtitle: const Text('Update the password used on a new phone'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _changeCloudPassword(context),
              ),
            _SettingsHeader(icon: Icons.storage_outlined, title: 'Data'),
            if (account.role.isAdmin)
              ListTile(
                leading: const Icon(Icons.manage_search_outlined),
                title: const Text('Customer Master'),
                subtitle: const Text(
                  'Search customer history by phone, booking or serial',
                ),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _open(context, const CustomerMasterScreen()),
              ),
            ListTile(
              leading: const Icon(Icons.cloud_sync_outlined),
              title: const Text('Cloud Sync'),
              subtitle: const Text('Keep authorized devices up to date'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _open(context, const CloudSyncScreen()),
            ),
            if (account.role.isAdmin)
              ListTile(
                leading: const Icon(Icons.language_outlined),
                title: const Text('Website Bookings'),
                subtitle: const Text(
                  'Connect online reservations and prevent date conflicts',
                ),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _open(context, const WebsiteBookingScreen()),
              ),
            ListTile(
              leading: const Icon(Icons.backup_outlined),
              title: const Text('Backup & Restore'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _open(context, const BackupScreen()),
            ),
            if (account.role.isAdmin)
              ListTile(
                leading: const Icon(Icons.delete_sweep_outlined),
                title: const Text('Trash'),
                subtitle: const Text(
                  'Restore records deleted in the last 7 days',
                ),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _open(context, const TrashScreen()),
              ),
            _SettingsHeader(icon: Icons.info_outline, title: 'Account'),
            ListTile(
              leading: const Icon(Icons.account_circle_outlined),
              title: Text(account.displayName),
              subtitle: Text('${account.role.label} · ${account.username}'),
            ),
            ListTile(
              leading: const Icon(Icons.apps_outlined),
              title: const Text('Bastion Home Manager'),
              subtitle: const Text('Version 2.0.9'),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: OutlinedButton.icon(
                onPressed: AccountService().logout,
                icon: const Icon(Icons.logout),
                label: const Text('Sign Out'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SettingsHeader extends StatelessWidget {
  final IconData icon;
  final String title;
  const _SettingsHeader({required this.icon, required this.title});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(top: 14),
    padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
    color: Theme.of(context).colorScheme.surfaceContainerHighest,
    child: Row(
      children: [
        Icon(icon, size: 18, color: Theme.of(context).colorScheme.secondary),
        const SizedBox(width: 8),
        Text(
          title,
          style: Theme.of(context).textTheme.titleSmall?.copyWith(
            color: Theme.of(context).colorScheme.secondary,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    ),
  );
}
