import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:image_picker/image_picker.dart';

import '../../core/app_constants.dart';
import '../../database/repositories/booking_repository.dart';
import '../../models/booking_model.dart';
import '../../services/booking_serial_service.dart';
import '../../services/id_vault_service.dart';
import '../../services/app_settings_service.dart';
import '../../services/account_service.dart';
import '../../services/id_retention_policy.dart';
import '../../utils/currency_formatter.dart';
import '../../utils/input_validators.dart';
import '../../widgets/app_back_button.dart';

class EnhancedBookingFormScreen extends StatefulWidget {
  final BookingModel? booking;
  final String? createdBy;
  final String? initialRoom;
  final DateTime? initialCheckin;
  const EnhancedBookingFormScreen({
    super.key,
    this.booking,
    this.createdBy,
    this.initialRoom,
    this.initialCheckin,
  });

  @override
  State<EnhancedBookingFormScreen> createState() =>
      _EnhancedBookingFormScreenState();
}

class _EnhancedBookingFormScreenState extends State<EnhancedBookingFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final BookingRepository _repo = BookingRepository();
  final BookingSerialService _serialService = BookingSerialService();
  final IdVaultService _vault = IdVaultService();

  late TextEditingController _bookingIdCtrl;
  late TextEditingController _guestCtrl;
  late TextEditingController _phoneCtrl;
  late TextEditingController _addressCtrl;
  late TextEditingController _otherOccupantsCtrl;
  late TextEditingController _guestsCtrl;
  late TextEditingController _tariffCtrl;
  late TextEditingController _extraCtrl;
  late TextEditingController _discountCtrl;
  late TextEditingController _notesCtrl;
  late TextEditingController _idNumberCtrl;
  late TextEditingController _checkinTimeCtrl;
  late TextEditingController _checkoutTimeCtrl;

  DateTime _checkin = DateTime.now();
  DateTime _checkout = DateTime.now().add(const Duration(days: 1));
  String _room = AppConstants.rooms.first;
  String _status = AppConstants.bookingStatuses.first;
  String _idType = AppConstants.idTypes.first;
  String _paymentMode = AppConstants.paymentModes.first;
  BookingSource _bookingSource = BookingSource.offline;
  bool _isSaving = false;
  bool _isCapturingImage = false;
  bool _isNew = true;
  String _serialNumber = '';

  // ID image paths (file path on mobile, base64 data URL on web)
  String? _idFrontPath;
  String? _idBackPath;
  DateTime? _idFrontCapturedAt;
  DateTime? _idBackCapturedAt;
  final Map<String, Future<Uint8List>> _imagePreviews = {};
  final Set<String> _temporaryImages = {};
  final Set<String> _imagesToDeleteAfterSave = {};
  bool _didSave = false;

  @override
  void initState() {
    super.initState();
    _isNew = widget.booking == null;
    final b = widget.booking;
    _bookingIdCtrl = TextEditingController(text: b?.id ?? '');
    _guestCtrl = TextEditingController(text: b?.guest ?? '');
    _phoneCtrl = TextEditingController(text: b?.phone ?? '');
    _addressCtrl = TextEditingController(text: b?.address ?? '');
    _otherOccupantsCtrl = TextEditingController(text: b?.otherOccupants ?? '');
    _guestsCtrl = TextEditingController(text: b?.guests.toString() ?? '1');
    _tariffCtrl = TextEditingController(
      text: b != null && b.tariff > 0 ? b.tariff.toString() : '',
    );
    _extraCtrl = TextEditingController(
      text: b != null && b.extra > 0 ? b.extra.toString() : '',
    );
    _discountCtrl = TextEditingController(
      text: b != null && b.discount > 0 ? b.discount.toString() : '',
    );
    _notesCtrl = TextEditingController(text: b?.notes ?? '');
    _idNumberCtrl = TextEditingController(text: b?.idNumber ?? '');
    final settings = AppSettingsService();
    _checkinTimeCtrl = TextEditingController(
      text: b?.checkinTime ?? settings.defaultCheckinTime,
    );
    _checkoutTimeCtrl = TextEditingController(
      text: b?.checkoutTime ?? settings.defaultCheckoutTime,
    );

    if (b != null) {
      _checkin = b.checkin;
      _checkout = b.checkout;
      _room = b.roomLabel;
      _status = b.statusLabel;
      _idType = b.idType.isNotEmpty ? b.idType : AppConstants.idTypes.first;
      _paymentMode = b.paymentMode.isNotEmpty
          ? b.paymentMode
          : AppConstants.paymentModes.first;
      _bookingSource = b.bookingSource;
      _serialNumber = b.serialNumber;
      _idFrontPath = b.idFrontPath.isNotEmpty ? b.idFrontPath : null;
      _idBackPath = b.idBackPath.isNotEmpty ? b.idBackPath : null;
      _idFrontCapturedAt = b.idFrontCapturedAt;
      _idBackCapturedAt = b.idBackCapturedAt;
    } else {
      if (widget.initialRoom != null &&
          AppConstants.rooms.contains(widget.initialRoom)) {
        _room = widget.initialRoom!;
      }
      if (widget.initialCheckin != null) {
        _checkin = DateTime(
          widget.initialCheckin!.year,
          widget.initialCheckin!.month,
          widget.initialCheckin!.day,
        );
        _checkout = _checkin.add(const Duration(days: 1));
      }
      _prepareNewBooking();
    }
    _restoreRecoveredImage();
  }

  Future<void> _prepareNewBooking() async {
    final values = await Future.wait([
      _repo.suggestNextId(),
      _serialService.previewNextSerial(DateTime.now()),
    ]);
    if (mounted) {
      setState(() {
        if (_bookingIdCtrl.text.isEmpty) _bookingIdCtrl.text = values[0];
        _serialNumber = values[1];
      });
    }
  }

  @override
  void dispose() {
    if (!_didSave) {
      for (final fileName in _temporaryImages) {
        unawaited(_deleteImageBestEffort(fileName));
      }
    }
    _bookingIdCtrl.dispose();
    _guestCtrl.dispose();
    _phoneCtrl.dispose();
    _addressCtrl.dispose();
    _otherOccupantsCtrl.dispose();
    _guestsCtrl.dispose();
    _tariffCtrl.dispose();
    _extraCtrl.dispose();
    _discountCtrl.dispose();
    _notesCtrl.dispose();
    _idNumberCtrl.dispose();
    _checkinTimeCtrl.dispose();
    _checkoutTimeCtrl.dispose();
    super.dispose();
  }

  int get _nights => _checkout.difference(_checkin).inDays.clamp(0, 9999);
  double get _tariff => double.tryParse(_tariffCtrl.text) ?? 0;
  double get _extra => double.tryParse(_extraCtrl.text) ?? 0;
  double get _discount => double.tryParse(_discountCtrl.text) ?? 0;
  double get _roomCharges => _nights * _tariff;
  double get _total => _roomCharges + _extra - _discount;

  Future<void> _restoreRecoveredImage() async {
    try {
      final recovered = await _vault.claimRecoveredCapture('booking-');
      if (recovered == null || !mounted) return;

      _imagePreviews[recovered.fileName] = _vault.readDecrypted(
        recovered.fileName,
      );
      _temporaryImages.add(recovered.fileName);
      setState(() {
        if (recovered.slot == 'booking-back') {
          _idBackPath = recovered.fileName;
          _idBackCapturedAt = DateTime.now().toUtc();
        } else {
          _idFrontPath = recovered.fileName;
          _idFrontCapturedAt = DateTime.now().toUtc();
        }
      });
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Recovered the ID photo from camera')),
        );
      });
    } catch (e) {
      debugPrint('Could not restore the interrupted ID capture: $e');
    }
  }

  Future<void> _pickImage(bool isFront, ImageSource source) async {
    if (_isCapturingImage) return;
    if (_storedImageIsProtected(isFront)) {
      _showRetentionMessage(isFront);
      return;
    }
    setState(() => _isCapturingImage = true);
    try {
      final previous = isFront ? _idFrontPath : _idBackPath;
      final fileName = await _vault.capture(
        source,
        recoverySlot: isFront ? 'booking-front' : 'booking-back',
      );
      if (fileName == null) return;
      if (!mounted) {
        await _vault.delete(fileName);
        return;
      }

      _imagePreviews[fileName] = _vault.readDecrypted(fileName);
      _temporaryImages.add(fileName);
      final capturedAt = DateTime.now().toUtc();
      setState(() {
        if (isFront) {
          _idFrontPath = fileName;
          _idFrontCapturedAt = capturedAt;
        } else {
          _idBackPath = fileName;
          _idBackCapturedAt = capturedAt;
        }
      });
      if (previous != null && previous.endsWith('.bhid')) {
        _imagePreviews.remove(previous);
        await _retireImage(previous);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Could not load image: $e')));
      }
    } finally {
      if (mounted) setState(() => _isCapturingImage = false);
    }
  }

  Future<void> _removeImage(bool isFront) async {
    if (_storedImageIsProtected(isFront)) {
      _showRetentionMessage(isFront);
      return;
    }
    final previous = isFront ? _idFrontPath : _idBackPath;
    setState(() {
      if (isFront) {
        _idFrontPath = null;
        _idFrontCapturedAt = null;
      } else {
        _idBackPath = null;
        _idBackCapturedAt = null;
      }
    });
    if (previous != null && previous.endsWith('.bhid')) {
      _imagePreviews.remove(previous);
      await _retireImage(previous);
    }
  }

  bool _storedImageIsProtected(bool isFront) {
    final path = isFront ? _idFrontPath : _idBackPath;
    if (path == null || _temporaryImages.contains(path)) return false;
    final capturedAt = isFront ? _idFrontCapturedAt : _idBackCapturedAt;
    return IdRetentionPolicy.isProtected(capturedAt);
  }

  void _showRetentionMessage(bool isFront) {
    final capturedAt = isFront ? _idFrontCapturedAt : _idBackCapturedAt;
    final until = capturedAt == null
        ? null
        : IdRetentionPolicy.retainUntil(capturedAt).toLocal();
    final date = until == null
        ? 'the retention date'
        : DateFormatter.format(until);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('This ID photo must be retained until $date.')),
    );
  }

  Future<void> _retireImage(String fileName) async {
    if (_temporaryImages.remove(fileName)) {
      await _deleteImageBestEffort(fileName);
    } else {
      _imagesToDeleteAfterSave.add(fileName);
    }
  }

  Future<void> _deleteImageBestEffort(String fileName) async {
    try {
      await _vault.delete(fileName);
    } catch (error) {
      debugPrint('Could not remove unused ID image: $error');
    }
  }

  void _showImageSourceDialog(bool isFront) {
    final protected = _storedImageIsProtected(isFront);
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: EdgeInsets.all(4.w),
              child: Text(
                isFront ? 'ID Front Side' : 'ID Back Side',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
              ),
            ),
            if (protected)
              ListTile(
                leading: const Icon(Icons.lock_clock_outlined),
                title: const Text('One-year retention active'),
                subtitle: const Text(
                  'This saved photo cannot be replaced or removed yet.',
                ),
              ),
            ListTile(
              leading: const Icon(Icons.camera_alt_outlined),
              title: Text('Take Photo', style: TextStyle()),
              onTap: protected
                  ? null
                  : () {
                      Navigator.pop(context);
                      _pickImage(isFront, ImageSource.camera);
                    },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: Text('Choose from Gallery', style: TextStyle()),
              onTap: protected
                  ? null
                  : () {
                      Navigator.pop(context);
                      _pickImage(isFront, ImageSource.gallery);
                    },
            ),
            if ((isFront ? _idFrontPath : _idBackPath) != null && !protected)
              ListTile(
                leading: const Icon(Icons.delete_outline, color: Colors.red),
                title: Text(
                  'Remove Photo',
                  style: TextStyle(color: Colors.red),
                ),
                onTap: () {
                  Navigator.pop(context);
                  _removeImage(isFront);
                },
              ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  Future<void> _pickDate(bool isCheckin) async {
    final initial = isCheckin ? _checkin : _checkout;
    final first = isCheckin
        ? DateTime(2020)
        : _checkin.add(const Duration(days: 1));
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: first,
      lastDate: DateTime(DateTime.now().year + 10),
    );
    if (picked != null) {
      setState(() {
        if (isCheckin) {
          _checkin = picked;
          if (!_checkout.isAfter(_checkin)) {
            _checkout = _checkin.add(const Duration(days: 1));
          }
        } else {
          _checkout = picked;
        }
      });
    }
  }

  Future<void> _pickTime(bool isCheckin) async {
    final ctrl = isCheckin ? _checkinTimeCtrl : _checkoutTimeCtrl;
    final parts = ctrl.text.split(':');
    final initial = TimeOfDay(
      hour: int.tryParse(parts[0]) ?? (isCheckin ? 12 : 11),
      minute: int.tryParse(parts.length > 1 ? parts[1] : '0') ?? 0,
    );
    final picked = await showTimePicker(context: context, initialTime: initial);
    if (picked != null) {
      final h = picked.hour.toString().padLeft(2, '0');
      final m = picked.minute.toString().padLeft(2, '0');
      setState(() => ctrl.text = '$h:$m');
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (!_checkout.isAfter(_checkin)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Checkout must be after check-in')),
      );
      return;
    }

    final hasOverlap = await _repo.hasOverlap(
      _room,
      _checkin,
      _checkout,
      excludeId: widget.booking?.id,
    );
    if (hasOverlap && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$_room is already booked for those dates')),
      );
      return;
    }

    setState(() => _isSaving = true);
    try {
      final bookingId = _bookingIdCtrl.text.trim().toUpperCase();
      if (_isNew && !await _repo.isIdUnique(bookingId)) {
        throw StateError('Booking ID $bookingId already exists');
      }

      final booking = BookingModel(
        id: bookingId,
        guest: _guestCtrl.text.trim(),
        phone: _phoneCtrl.text.trim(),
        address: _addressCtrl.text.trim(),
        otherOccupants: _normalizedOtherOccupants,
        guests: int.tryParse(_guestsCtrl.text) ?? 1,
        room: BookingModel.roomFromString(_room),
        checkin: _checkin,
        checkout: _checkout,
        checkinTime: _checkinTimeCtrl.text,
        checkoutTime: _checkoutTimeCtrl.text,
        tariff: _tariff,
        extra: _extra,
        discount: _discount,
        status: BookingModel.statusFromString(_status),
        idTaken: _idFrontPath != null || _idBackPath != null,
        idType: _idType,
        idNumber: _maskIdNumber(_idNumberCtrl.text),
        idFrontPath: _idFrontPath ?? '',
        idBackPath: _idBackPath ?? '',
        idFrontCapturedAt: _idFrontCapturedAt,
        idBackCapturedAt: _idBackCapturedAt,
        paymentMode: _paymentMode,
        serialNumber: _isNew ? '' : _serialNumber,
        createdBy: widget.booking?.createdBy.isNotEmpty == true
            ? widget.booking!.createdBy
            : AccountService().currentAuditLabel.isNotEmpty
            ? AccountService().currentAuditLabel
            : widget.createdBy ?? '',
        bookingSource: _bookingSource,
        notes: _notesCtrl.text.trim(),
      );
      if (_isNew) {
        await _repo.insertBooking(booking);
      } else {
        await _repo.updateBooking(booking);
      }
      _didSave = true;
      _temporaryImages.clear();
      for (final fileName in _imagesToDeleteAfterSave) {
        await _deleteImageBestEffort(fileName);
      }
      _imagesToDeleteAfterSave.clear();
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        setState(() => _isSaving = false);
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error saving: $e')));
      }
    }
  }

  String _maskIdNumber(String input) {
    final value = input.trim();
    final visibleStart =
        value.replaceAll(RegExp(r'[^A-Za-z0-9]'), '').length - 4;
    var seen = 0;
    return value.split('').map((character) {
      if (!RegExp(r'[A-Za-z0-9]').hasMatch(character)) return character;
      final masked = seen < visibleStart ? 'X' : character;
      seen++;
      return masked;
    }).join();
  }

  String get _normalizedOtherOccupants => _otherOccupantsCtrl.text
      .split(RegExp(r'[\r\n]+'))
      .map((name) => name.trim())
      .where((name) => name.isNotEmpty)
      .join('\n');

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF0D1F25) : const Color(0xFFF7F4EE);
    final inkColor = isDark ? Colors.white : const Color(0xFF0E332B);
    final fieldFill = isDark ? const Color(0xFF123F34) : Colors.white;
    final accentColor = const Color(0xFF8E2A18);

    InputDecoration fieldDec(String label, {String? hint}) => InputDecoration(
      labelText: label,
      hintText: hint,
      filled: true,
      fillColor: fieldFill,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.grey.withAlpha(60)),
      ),
      contentPadding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
    );

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        leading: const AppBackButton(color: Colors.white),
        backgroundColor: isDark
            ? const Color(0xFF0E332B)
            : const Color(0xFF123F34),
        title: Text(
          _isNew ? 'New Booking' : 'Edit Booking',
          style: TextStyle(color: Colors.white, fontSize: 18.0),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          TextButton(
            onPressed: _isSaving ? null : _save,
            child: Text(
              _isSaving ? 'Saving…' : 'Save',
              style: TextStyle(
                color: accentColor,
                fontWeight: FontWeight.w700,
                fontSize: 16.0,
              ),
            ),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: EdgeInsets.all(4.w),
          children: [
            TextFormField(
              controller: _bookingIdCtrl,
              readOnly: !_isNew,
              textCapitalization: TextCapitalization.characters,
              decoration: fieldDec('Booking ID *').copyWith(
                helperText: _isNew ? 'Suggested ID can be changed' : null,
              ),
              validator: (value) => value == null || value.trim().isEmpty
                  ? 'Booking ID is required'
                  : null,
            ),
            SizedBox(height: 2.h),

            // Serial Number (auto-generated, read-only)
            if (_serialNumber.isNotEmpty) ...[
              Container(
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.2.h),
                decoration: BoxDecoration(
                  color: accentColor.withAlpha(30),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: accentColor.withAlpha(80)),
                ),
                child: Wrap(
                  crossAxisAlignment: WrapCrossAlignment.center,
                  spacing: 8,
                  runSpacing: 4,
                  children: [
                    Icon(Icons.tag_rounded, color: accentColor, size: 18),
                    Text(
                      'Serial No: ',
                      style: TextStyle(
                        color: inkColor.withAlpha(160),
                        fontSize: 13.0,
                      ),
                    ),
                    Text(
                      _serialNumber,
                      style: TextStyle(
                        color: accentColor,
                        fontWeight: FontWeight.w700,
                        fontSize: 16.0,
                      ),
                    ),
                    Text(
                      'Auto-generated',
                      style: TextStyle(
                        color: inkColor.withAlpha(100),
                        fontSize: 11.0,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 2.h),
            ],

            // Section: Guest Details
            _sectionHeader('Guest Details', Icons.person_outline, inkColor),
            SizedBox(height: 1.h),

            TextFormField(
              controller: _guestCtrl,
              decoration: fieldDec('Full Name *'),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Required' : null,
            ),
            SizedBox(height: 2.h),

            TextFormField(
              controller: _phoneCtrl,
              decoration: fieldDec('Phone Number'),
              keyboardType: TextInputType.phone,
            ),
            SizedBox(height: 2.h),

            TextFormField(
              controller: _addressCtrl,
              decoration: fieldDec('Address'),
              maxLines: 2,
            ),
            SizedBox(height: 2.h),

            TextFormField(
              controller: _otherOccupantsCtrl,
              decoration: fieldDec(
                'Other Occupants',
                hint: 'Enter one full name per line',
              ),
              minLines: 2,
              maxLines: 5,
              validator: (value) {
                final names = (value ?? '')
                    .split(RegExp(r'[\r\n]+'))
                    .map((name) => name.trim())
                    .where((name) => name.isNotEmpty)
                    .toList();
                if (names.any((name) => name.length > 200)) {
                  return 'Each occupant name must be 200 characters or less';
                }
                final guestCount = int.tryParse(_guestsCtrl.text) ?? 0;
                if (names.length > guestCount - 1) {
                  return 'Increase the number of guests to include all occupants';
                }
                return null;
              },
            ),
            SizedBox(height: 3.h),

            // Section: ID Details
            _sectionHeader('ID Verification', Icons.badge_outlined, inkColor),
            SizedBox(height: 1.h),

            DropdownButtonFormField<String>(
              isExpanded: true,
              initialValue: _idType,
              decoration: fieldDec('ID Type'),
              items: AppConstants.idTypes
                  .map(
                    (t) => DropdownMenuItem(
                      value: t,
                      child: Text(t, style: TextStyle(fontSize: 14.0)),
                    ),
                  )
                  .toList(),
              onChanged: (v) => setState(() => _idType = v!),
            ),
            SizedBox(height: 2.h),

            TextFormField(
              controller: _idNumberCtrl,
              decoration: fieldDec(_isNew ? 'ID Number *' : 'ID Number'),
              validator: (value) =>
                  _isNew && (value == null || value.trim().isEmpty)
                  ? 'ID Number is required for a new booking'
                  : null,
            ),
            SizedBox(height: 2.h),

            // ID Photo Capture
            Row(
              children: [
                Expanded(
                  child: _idPhotoCard(
                    label: 'Front Side',
                    path: _idFrontPath,
                    onTap: _isCapturingImage
                        ? () {}
                        : () => _showImageSourceDialog(true),
                    fieldFill: fieldFill,
                    inkColor: inkColor,
                    accentColor: accentColor,
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: _idPhotoCard(
                    label: 'Back Side',
                    path: _idBackPath,
                    onTap: _isCapturingImage
                        ? () {}
                        : () => _showImageSourceDialog(false),
                    fieldFill: fieldFill,
                    inkColor: inkColor,
                    accentColor: accentColor,
                  ),
                ),
              ],
            ),
            SizedBox(height: 3.h),

            // Section: Booking Details
            _sectionHeader('Booking Details', Icons.bed_outlined, inkColor),
            SizedBox(height: 1.h),

            DropdownButtonFormField<BookingSource>(
              isExpanded: true,
              initialValue: _bookingSource,
              decoration: fieldDec('Booking Source'),
              items: const [
                DropdownMenuItem(
                  value: BookingSource.offline,
                  child: Text('Offline / Walk-in'),
                ),
                DropdownMenuItem(
                  value: BookingSource.online,
                  child: Text('Online'),
                ),
              ],
              onChanged: (value) {
                if (value != null) setState(() => _bookingSource = value);
              },
            ),
            SizedBox(height: 2.h),

            DropdownButtonFormField<String>(
              isExpanded: true,
              initialValue: _room,
              decoration: fieldDec('Room Number'),
              items: AppConstants.rooms
                  .map(
                    (r) => DropdownMenuItem(
                      value: r,
                      child: Text(r, style: TextStyle(fontSize: 14.0)),
                    ),
                  )
                  .toList(),
              onChanged: (v) => setState(() => _room = v!),
            ),
            SizedBox(height: 2.h),

            TextFormField(
              controller: _guestsCtrl,
              decoration: fieldDec('Number of Guests'),
              keyboardType: TextInputType.number,
              validator: (value) {
                final count = int.tryParse(value?.trim() ?? '');
                if (count == null || count < 1 || count > 20) {
                  return 'Enter a guest count from 1 to 20';
                }
                final occupantCount = _normalizedOtherOccupants.isEmpty
                    ? 0
                    : _normalizedOtherOccupants.split('\n').length;
                if (occupantCount > count - 1) {
                  return 'Guest count must include all occupants';
                }
                return null;
              },
            ),
            SizedBox(height: 2.h),

            _responsivePair(
              _dateField(
                'Check-in Date',
                _checkin,
                () => _pickDate(true),
                fieldFill,
                inkColor,
              ),
              _timeField(
                'Check-in Time',
                _checkinTimeCtrl,
                () => _pickTime(true),
                fieldFill,
                inkColor,
              ),
            ),
            SizedBox(height: 2.h),

            _responsivePair(
              _dateField(
                'Check-out Date',
                _checkout,
                () => _pickDate(false),
                fieldFill,
                inkColor,
              ),
              _timeField(
                'Check-out Time',
                _checkoutTimeCtrl,
                () => _pickTime(false),
                fieldFill,
                inkColor,
              ),
            ),
            SizedBox(height: 3.h),

            // Section: Billing
            _sectionHeader('Billing', Icons.receipt_outlined, inkColor),
            SizedBox(height: 1.h),

            TextFormField(
              controller: _tariffCtrl,
              decoration: fieldDec('Tariff / Night (₹)'),
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              onChanged: (_) => setState(() {}),
              validator: InputValidators.money,
            ),
            SizedBox(height: 2.h),

            _responsivePair(
              TextFormField(
                controller: _extraCtrl,
                decoration: fieldDec('Additional Charges (₹)'),
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                onChanged: (_) => setState(() {}),
                validator: InputValidators.money,
              ),
              TextFormField(
                controller: _discountCtrl,
                decoration: fieldDec('Discount (₹)'),
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                onChanged: (_) => setState(() {}),
                validator: (value) {
                  final error = InputValidators.money(value);
                  if (error != null) return error;
                  if (_discount > _roomCharges + _extra) {
                    return 'Exceeds charges';
                  }
                  return null;
                },
              ),
            ),
            SizedBox(height: 2.h),

            DropdownButtonFormField<String>(
              isExpanded: true,
              initialValue: _paymentMode,
              decoration: fieldDec('Payment Mode'),
              items: AppConstants.paymentModes
                  .map(
                    (m) => DropdownMenuItem(
                      value: m,
                      child: Text(m, style: TextStyle(fontSize: 14.0)),
                    ),
                  )
                  .toList(),
              onChanged: (v) => setState(() => _paymentMode = v!),
            ),
            SizedBox(height: 2.h),

            // Financial summary
            _buildFinancialSummary(inkColor, fieldFill, accentColor),
            SizedBox(height: 2.h),

            // Status
            DropdownButtonFormField<String>(
              isExpanded: true,
              initialValue: _status,
              decoration: fieldDec('Booking Status'),
              items: AppConstants.bookingStatuses
                  .map(
                    (s) => DropdownMenuItem(
                      value: s,
                      child: Text(s, style: TextStyle(fontSize: 14.0)),
                    ),
                  )
                  .toList(),
              onChanged: (v) => setState(() => _status = v!),
            ),
            SizedBox(height: 2.h),

            TextFormField(
              controller: _notesCtrl,
              decoration: fieldDec('Notes'),
              maxLines: 3,
            ),
            SizedBox(height: 4.h),
          ],
        ),
      ),
    );
  }

  Widget _sectionHeader(String title, IconData icon, Color inkColor) {
    return Row(
      children: [
        Icon(icon, size: 16, color: const Color(0xFF8E2A18)),
        SizedBox(width: 2.w),
        Flexible(
          child: Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 14.0,
              color: const Color(0xFF8E2A18),
            ),
          ),
        ),
        SizedBox(width: 2.w),
        Expanded(child: Divider(color: const Color(0xFF8E2A18).withAlpha(60))),
      ],
    );
  }

  Widget _responsivePair(Widget first, Widget second) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 420) {
          return Column(children: [first, const SizedBox(height: 12), second]);
        }
        return Row(
          children: [
            Expanded(child: first),
            const SizedBox(width: 12),
            Expanded(child: second),
          ],
        );
      },
    );
  }

  Widget _idPhotoCard({
    required String label,
    required String? path,
    required VoidCallback onTap,
    required Color fieldFill,
    required Color inkColor,
    required Color accentColor,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 14.h,
        decoration: BoxDecoration(
          color: fieldFill,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: path != null
                ? const Color(0xFF3D6B4A)
                : Colors.grey.withAlpha(80),
          ),
        ),
        child: path != null
            ? ClipRRect(
                borderRadius: BorderRadius.circular(9),
                child: _buildImageWidget(path),
              )
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.add_a_photo_outlined,
                    color: accentColor,
                    size: 24,
                  ),
                  SizedBox(height: 0.5.h),
                  Text(
                    label,
                    style: TextStyle(
                      fontSize: 12.0,
                      color: inkColor.withAlpha(140),
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
      ),
    );
  }

  Widget _buildImageWidget(String path) {
    if (path.endsWith('.bhid')) {
      final preview = _imagePreviews.putIfAbsent(
        path,
        () => _vault.readDecrypted(path),
      );
      return FutureBuilder<Uint8List>(
        future: preview,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return Image.memory(
              snapshot.data!,
              fit: BoxFit.cover,
              cacheWidth: 640,
              gaplessPlayback: true,
            );
          }
          if (snapshot.hasError) {
            return const Center(
              child: Icon(Icons.broken_image_outlined, color: Colors.red),
            );
          }
          return const Center(child: Icon(Icons.lock_outline));
        },
      );
    }

    return Image.file(
      File(path),
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => const Center(
        child: Icon(Icons.badge_outlined, color: Color(0xFF3D6B4A)),
      ),
    );
  }

  Widget _dateField(
    String label,
    DateTime date,
    VoidCallback onTap,
    Color fill,
    Color inkColor,
  ) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.5.h),
        decoration: BoxDecoration(
          color: fill,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.grey.withAlpha(60)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(fontSize: 11.0, color: inkColor.withAlpha(140)),
            ),
            SizedBox(height: 0.3.h),
            Text(
              '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}',
              style: TextStyle(
                fontSize: 14.0,
                fontWeight: FontWeight.w600,
                color: inkColor,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _timeField(
    String label,
    TextEditingController ctrl,
    VoidCallback onTap,
    Color fill,
    Color inkColor,
  ) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.5.h),
        decoration: BoxDecoration(
          color: fill,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.grey.withAlpha(60)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(fontSize: 11.0, color: inkColor.withAlpha(140)),
            ),
            SizedBox(height: 0.3.h),
            Row(
              children: [
                Text(
                  ctrl.text,
                  style: TextStyle(
                    fontSize: 14.0,
                    fontWeight: FontWeight.w600,
                    color: inkColor,
                  ),
                ),
                const Spacer(),
                Icon(
                  Icons.access_time_outlined,
                  size: 14,
                  color: inkColor.withAlpha(120),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFinancialSummary(
    Color inkColor,
    Color fieldFill,
    Color accentColor,
  ) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: fieldFill,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey.withAlpha(60)),
      ),
      child: Column(
        children: [
          _summaryRow('Nights', '$_nights', inkColor),
          _summaryRow(
            'Room Charges',
            CurrencyFormatter.format(_roomCharges),
            inkColor,
          ),
          if (_extra > 0)
            _summaryRow(
              'Additional Charges',
              CurrencyFormatter.format(_extra),
              inkColor,
            ),
          if (_discount > 0)
            _summaryRow(
              'Discount',
              '- ${CurrencyFormatter.format(_discount)}',
              inkColor,
            ),
          Divider(color: Colors.grey.withAlpha(60)),
          _summaryRow(
            'Total',
            CurrencyFormatter.format(_total),
            accentColor,
            bold: true,
          ),
        ],
      ),
    );
  }

  Widget _summaryRow(
    String label,
    String value,
    Color color, {
    bool bold = false,
  }) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 0.4.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 13.0,
              color: color.withAlpha(bold ? 255 : 180),
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 13.0,
              fontWeight: bold ? FontWeight.w700 : FontWeight.w500,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
