import 'package:flutter/material.dart';
import '../../../models/booking_model.dart';
import '../../../theme/app_theme.dart';

// TODO: Replace with [Riverpod/Bloc] for production — connect to SQLite data layer
class AddBookingFormWidget extends StatefulWidget {
  final String nextBookingId;
  final void Function(BookingModel) onSaved;

  const AddBookingFormWidget({
    required this.nextBookingId,
    required this.onSaved,
    super.key,
  });

  @override
  State<AddBookingFormWidget> createState() => _AddBookingFormWidgetState();
}

class _AddBookingFormWidgetState extends State<AddBookingFormWidget> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _idCtrl;
  final _guestCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _guestsCtrl = TextEditingController(text: '1');
  final _tariffCtrl = TextEditingController();
  final _extraCtrl = TextEditingController(text: '0');
  final _discountCtrl = TextEditingController(text: '0');
  final _notesCtrl = TextEditingController();

  String _selectedRoom = 'Room 1';
  String _selectedStatus = 'Booked';
  DateTime _checkin = DateTime.now();
  DateTime _checkout = DateTime.now().add(const Duration(days: 1));
  bool _idTaken = false;
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    _idCtrl = TextEditingController(text: widget.nextBookingId);
  }

  @override
  void dispose() {
    for (final c in [
      _idCtrl,
      _guestCtrl,
      _phoneCtrl,
      _guestsCtrl,
      _tariffCtrl,
      _extraCtrl,
      _discountCtrl,
      _notesCtrl,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _pickDate({required bool isCheckin}) async {
    final initial = isCheckin ? _checkin : _checkout;
    final first = isCheckin
        ? DateTime(2020)
        : _checkin.add(const Duration(days: 1));
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: first,
      lastDate: DateTime(2030),
      builder: (context, child) => Theme(
        data: Theme.of(context).copyWith(
          colorScheme: Theme.of(
            context,
          ).colorScheme.copyWith(primary: AppTheme.deepTeal),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() {
        if (isCheckin) {
          _checkin = picked;
          if (!_checkout.isAfter(_checkin)) {
            _checkout = _checkin.add(const Duration(days: 1));
          }
        } else {
          _checkout = picked;
        }
      });
    }
  }

  String _formatDate(DateTime d) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return '${d.day.toString().padLeft(2, '0')}-${months[d.month - 1]}-${d.year}';
  }

  void _submit() {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    setState(() => _isSubmitting = true);

    // TODO: Replace with [Riverpod/Bloc] — save to SQLite via data layer
    Future.microtask(() {
      if (!mounted) return;
      setState(() => _isSubmitting = false);
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Booking ${_idCtrl.text} created',
            style: TextStyle(color: Colors.white),
          ),
          backgroundColor: AppTheme.successGreen,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.92,
      minChildSize: 0.6,
      maxChildSize: 0.95,
      builder: (_, scrollController) => Container(
        decoration: const BoxDecoration(
          color: AppTheme.backgroundLightAlt,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // Handle + header
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
                child: Column(
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: const Color(0xFFDDD8CF),
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Text(
                          'New Booking',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                            color: AppTheme.deepTealDark,
                          ),
                        ),
                        const Spacer(),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          decoration: BoxDecoration(
                            color: AppTheme.brassAccent.withAlpha(31),
                            borderRadius: BorderRadius.circular(50),
                            border: Border.all(
                              color: AppTheme.brassAccent.withAlpha(77),
                            ),
                          ),
                          child: Text(
                            widget.nextBookingId,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: AppTheme.brassAccent,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              const Divider(height: 1, color: Color(0xFFEAE4DC)),
              Expanded(
                child: ListView(
                  controller: scrollController,
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 100),
                  children: [
                    _SectionCard(
                      title: 'Guest Info',
                      children: [
                        _buildField(
                          _idCtrl,
                          'Booking ID',
                          'BH-003',
                          validator: (v) => v!.isEmpty ? 'Required' : null,
                        ),
                        const SizedBox(height: 10),
                        _buildField(
                          _guestCtrl,
                          'Guest Name',
                          'Full name',
                          validator: (v) => v!.isEmpty ? 'Required' : null,
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(
                              child: _buildField(
                                _phoneCtrl,
                                'Phone',
                                '98640-XXXXX',
                                keyboardType: TextInputType.phone,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: _buildField(
                                _guestsCtrl,
                                'Guests',
                                '1',
                                keyboardType: TextInputType.number,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _SectionCard(
                      title: 'Stay Details',
                      children: [
                        _buildDropdown(
                          label: 'Room',
                          value: _selectedRoom,
                          items: [
                            'Room 1',
                            'Room 2',
                            'Room 3',
                            'Room 4',
                            'Room 5',
                          ],
                          onChanged: (v) => setState(() => _selectedRoom = v!),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(
                              child: _DatePickerField(
                                label: 'Check-in',
                                date: _checkin,
                                onTap: () => _pickDate(isCheckin: true),
                                formatDate: _formatDate,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: _DatePickerField(
                                label: 'Check-out',
                                date: _checkout,
                                onTap: () => _pickDate(isCheckin: false),
                                formatDate: _formatDate,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        _buildDropdown(
                          label: 'Status',
                          value: _selectedStatus,
                          items: [
                            'Booked',
                            'Checked-in',
                            'Checked-out',
                            'Cancelled',
                            'No-show',
                          ],
                          onChanged: (v) =>
                              setState(() => _selectedStatus = v!),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _SectionCard(
                      title: 'Financials',
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: _buildField(
                                _tariffCtrl,
                                'Tariff / Night (₹)',
                                '0',
                                keyboardType: TextInputType.number,
                                validator: (v) =>
                                    v!.isEmpty ? 'Required' : null,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: _buildField(
                                _extraCtrl,
                                'Extra Charges (₹)',
                                '0',
                                keyboardType: TextInputType.number,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        _buildField(
                          _discountCtrl,
                          'Discount (₹)',
                          '0',
                          keyboardType: TextInputType.number,
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _SectionCard(
                      title: 'ID & Notes',
                      children: [
                        Row(
                          children: [
                            Text(
                              'ID Taken',
                              style: TextStyle(
                                fontSize: 14,
                                color: AppTheme.textSecondaryLight,
                              ),
                            ),
                            const Spacer(),
                            Switch(
                              value: _idTaken,
                              onChanged: (v) => setState(() => _idTaken = v),
                              activeThumbColor: AppTheme.deepTeal,
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        _buildField(
                          _notesCtrl,
                          'Notes',
                          'Optional notes…',
                          maxLines: 3,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              // Submit bar
              Container(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  border: Border(top: BorderSide(color: Color(0xFFEAE4DC))),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.of(context).pop(),
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          side: const BorderSide(color: Color(0xFFDDD8CF)),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        child: Text(
                          'Cancel',
                          style: TextStyle(
                            color: AppTheme.textSecondaryLight,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      flex: 2,
                      child: FilledButton(
                        onPressed: _isSubmitting ? null : _submit,
                        style: FilledButton.styleFrom(
                          backgroundColor: AppTheme.deepTeal,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        child: _isSubmitting
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : Text(
                                'Create Booking',
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white,
                                ),
                              ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildField(
    TextEditingController ctrl,
    String label,
    String hint, {
    TextInputType keyboardType = TextInputType.text,
    String? Function(String?)? validator,
    int maxLines = 1,
  }) {
    return TextFormField(
      controller: ctrl,
      keyboardType: keyboardType,
      validator: validator,
      maxLines: maxLines,
      style: TextStyle(fontSize: 14, color: AppTheme.deepTealDark),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFFDDD8CF)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFFDDD8CF)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: AppTheme.deepTeal, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: AppTheme.alertRed, width: 1),
        ),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 12,
        ),
        labelStyle: TextStyle(fontSize: 12, color: AppTheme.textSecondaryLight),
      ),
    );
  }

  Widget _buildDropdown({
    required String label,
    required String value,
    required List<String> items,
    required void Function(String?) onChanged,
  }) {
    return DropdownButtonFormField<String>(
      initialValue: value,
      onChanged: onChanged,
      decoration: InputDecoration(
        labelText: label,
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFFDDD8CF)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFFDDD8CF)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: AppTheme.deepTeal, width: 1.5),
        ),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 12,
        ),
        labelStyle: TextStyle(fontSize: 12, color: AppTheme.textSecondaryLight),
      ),
      style: TextStyle(fontSize: 14, color: AppTheme.deepTealDark),
      items: items
          .map((i) => DropdownMenuItem(value: i, child: Text(i)))
          .toList(),
    );
  }
}

class _SectionCard extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const _SectionCard({required this.title, required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFEAE4DC)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(8),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: AppTheme.deepTeal,
              letterSpacing: 0,
            ),
          ),
          const SizedBox(height: 12),
          ...children,
        ],
      ),
    );
  }
}

class _DatePickerField extends StatelessWidget {
  final String label;
  final DateTime date;
  final VoidCallback onTap;
  final String Function(DateTime) formatDate;

  const _DatePickerField({
    required this.label,
    required this.date,
    required this.onTap,
    required this.formatDate,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFDDD8CF)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                color: AppTheme.textSecondaryLight,
              ),
            ),
            const SizedBox(height: 3),
            Row(
              children: [
                Expanded(
                  child: Text(
                    formatDate(date),
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: AppTheme.deepTealDark,
                      fontFeatures: const [FontFeature.tabularFigures()],
                    ),
                  ),
                ),
                const Icon(
                  Icons.calendar_today_outlined,
                  size: 14,
                  color: AppTheme.deepTeal,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
