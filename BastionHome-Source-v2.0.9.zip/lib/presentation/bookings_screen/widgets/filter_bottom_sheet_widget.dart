import 'package:flutter/material.dart';
import '../../../theme/app_theme.dart';

// Filter bottom sheet — anatomy from reference image extraction:
// Section labels (bold) + chip selectors (pill, Any + numeric, outlined-selected) + action row

class FilterBottomSheetWidget extends StatefulWidget {
  final String currentStatus;
  final String currentRoom;
  final List<String> statusOptions;
  final List<String> roomOptions;
  final void Function(String status, String room) onApply;

  const FilterBottomSheetWidget({
    required this.currentStatus,
    required this.currentRoom,
    required this.statusOptions,
    required this.roomOptions,
    required this.onApply,
    super.key,
  });

  @override
  State<FilterBottomSheetWidget> createState() =>
      _FilterBottomSheetWidgetState();
}

class _FilterBottomSheetWidgetState extends State<FilterBottomSheetWidget> {
  late String _selectedStatus;
  late String _selectedRoom;

  @override
  void initState() {
    super.initState();
    _selectedStatus = widget.currentStatus;
    _selectedRoom = widget.currentRoom;
  }

  void _clearAll() {
    setState(() {
      _selectedStatus = 'All';
      _selectedRoom = 'All Rooms';
    });
  }

  void _apply() {
    widget.onApply(_selectedStatus, _selectedRoom);
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: const Color(0xFFDDD8CF),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
          ),
          // Header row — X icon left + "Filter" title centered
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Row(
              children: [
                GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF0EEE9),
                      borderRadius: BorderRadius.circular(50),
                    ),
                    child: const Icon(
                      Icons.close_rounded,
                      size: 16,
                      color: AppTheme.deepTealDark,
                    ),
                  ),
                ),
                const Expanded(
                  child: Center(
                    child: Text(
                      'Filter',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.deepTealDark,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 32),
              ],
            ),
          ),
          const Divider(height: 1, color: Color(0xFFF0EEE9)),
          // Scrollable content
          ConstrainedBox(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.of(context).size.height * 0.55,
            ),
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Section: Booking Status
                  _SectionLabel(label: 'Booking Status'),
                  const SizedBox(height: 12),
                  _ChipSelectorRow(
                    options: widget.statusOptions,
                    selected: _selectedStatus,
                    onSelect: (v) => setState(() => _selectedStatus = v),
                  ),
                  const SizedBox(height: 20),
                  // Section: Room
                  _SectionLabel(label: 'Room'),
                  const SizedBox(height: 12),
                  _ChipSelectorRow(
                    options: widget.roomOptions,
                    selected: _selectedRoom,
                    onSelect: (v) => setState(() => _selectedRoom = v),
                  ),
                ],
              ),
            ),
          ),
          const Divider(height: 1, color: Color(0xFFF0EEE9)),
          // Action row — Clear All (text button) + Apply (filled pill CTA)
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
            child: Row(
              children: [
                TextButton(
                  onPressed: _clearAll,
                  child: Text(
                    'Clear All',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: AppTheme.textSecondaryLight,
                      decoration: TextDecoration.underline,
                    ),
                  ),
                ),
                const Spacer(),
                FilledButton(
                  onPressed: _apply,
                  style: FilledButton.styleFrom(
                    backgroundColor: AppTheme.deepTeal,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 32,
                      vertical: 14,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                  child: Text(
                    'Apply Filters',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String label;

  const _SectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Text(
      label,
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
        color: AppTheme.deepTealDark,
      ),
    );
  }
}

// Chip selector row — pill chips, "Any"/"All" first, outlined-selected style
// Anatomy locked from reference: pill shape, outlined border on selected, filled on active
class _ChipSelectorRow extends StatelessWidget {
  final List<String> options;
  final String selected;
  final void Function(String) onSelect;

  const _ChipSelectorRow({
    required this.options,
    required this.selected,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: options.map((option) {
        final isSelected = option == selected;
        return GestureDetector(
          onTap: () => onSelect(option),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            curve: Curves.easeOutCubic,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: isSelected ? AppTheme.deepTeal : Colors.white,
              borderRadius: BorderRadius.circular(50),
              border: Border.all(
                color: isSelected ? AppTheme.deepTeal : const Color(0xFFDDD8CF),
                width: isSelected ? 1.5 : 1,
              ),
            ),
            child: Text(
              option,
              style: TextStyle(
                fontSize: 13,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                color: isSelected ? Colors.white : AppTheme.textSecondaryLight,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}
