import 'package:flutter/material.dart';
import '../../../models/booking_model.dart';
import '../../../theme/app_theme.dart';
import '../../../utils/currency_formatter.dart';

class BookingListItemWidget extends StatelessWidget {
  final BookingModel booking;
  final VoidCallback onTap;
  final VoidCallback? onInvoiceTap;
  final VoidCallback? onGuestStayPdfTap;
  final bool isGeneratingGuestStayPdf;
  final VoidCallback? onCheckInTap;
  final VoidCallback? onCollectPaymentTap;
  final VoidCallback? onViewGuestProfileTap;
  final VoidCallback? onDeleteTap;

  const BookingListItemWidget({
    required this.booking,
    required this.onTap,
    this.onInvoiceTap,
    this.onGuestStayPdfTap,
    this.isGeneratingGuestStayPdf = false,
    this.onCheckInTap,
    this.onCollectPaymentTap,
    this.onViewGuestProfileTap,
    this.onDeleteTap,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final payStatus = booking.payStatus;

    Color statusBarColor;
    switch (booking.status) {
      case BookingStatus.checkedIn:
        statusBarColor = AppTheme.successGreen;
        break;
      case BookingStatus.booked:
        statusBarColor = AppTheme.deepTeal;
        break;
      case BookingStatus.cancelled:
        statusBarColor = AppTheme.alertRed;
        break;
      case BookingStatus.noShow:
        statusBarColor = AppTheme.brassAccent;
        break;
      default:
        statusBarColor = const Color(0xFFCDD5D8);
    }

    // Determine check-in button label & icon based on current status
    final bool isCheckedIn = booking.status == BookingStatus.checkedIn;
    final bool isBooked = booking.status == BookingStatus.booked;
    final bool canCheckInOut = isBooked || isCheckedIn;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        splashColor: AppTheme.deepTeal.withAlpha(13),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFEAE4DC)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withAlpha(10),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Status bar — left edge colour strip
              Container(
                width: 4,
                decoration: BoxDecoration(
                  color: statusBarColor,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(12),
                    bottomLeft: Radius.circular(12),
                  ),
                ),
              ),
              // Main content
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Row 1: Booking ID + Room + Status badge
                      Row(
                        children: [
                          Text(
                            booking.id,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: AppTheme.brassAccent,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: AppTheme.deepTeal.withAlpha(20),
                              borderRadius: BorderRadius.circular(50),
                            ),
                            child: Text(
                              booking.roomLabel,
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w500,
                                color: AppTheme.deepTeal,
                              ),
                            ),
                          ),
                          const Spacer(),
                          _PayStatusBadge(payStatus: payStatus),
                          if (onGuestStayPdfTap != null) ...[
                            const SizedBox(width: 2),
                            IconButton(
                              tooltip: 'Download guest stay PDF',
                              visualDensity: VisualDensity.compact,
                              constraints: const BoxConstraints.tightFor(
                                width: 32,
                                height: 32,
                              ),
                              padding: EdgeInsets.zero,
                              onPressed: isGeneratingGuestStayPdf
                                  ? null
                                  : onGuestStayPdfTap,
                              icon: isGeneratingGuestStayPdf
                                  ? const SizedBox.square(
                                      dimension: 16,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                      ),
                                    )
                                  : const Icon(
                                      Icons.picture_as_pdf_outlined,
                                      size: 19,
                                      color: Color(0xFF8E2A18),
                                    ),
                            ),
                          ],
                          if (onDeleteTap != null) ...[
                            const SizedBox(width: 2),
                            IconButton(
                              tooltip: 'Move booking to Trash',
                              visualDensity: VisualDensity.compact,
                              constraints: const BoxConstraints.tightFor(
                                width: 32,
                                height: 32,
                              ),
                              padding: EdgeInsets.zero,
                              onPressed: onDeleteTap,
                              icon: Icon(
                                Icons.delete_outline,
                                size: 19,
                                color: Theme.of(context).colorScheme.error,
                              ),
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 5),
                      // Row 2: Guest name
                      Text(
                        booking.guest,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.deepTealDark,
                        ),
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                      ),
                      const SizedBox(height: 3),
                      Row(
                        children: [
                          Icon(
                            booking.bookingSource == BookingSource.online
                                ? Icons.language_outlined
                                : Icons.meeting_room_outlined,
                            size: 12,
                            color: Theme.of(context).colorScheme.primary,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            booking.bookingSourceLabel,
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: Theme.of(
                                context,
                              ).colorScheme.onSurfaceVariant,
                            ),
                          ),
                          if (booking.createdBy.isNotEmpty) ...[
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'Processed by ${booking.createdBy}',
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w500,
                                  color: Theme.of(
                                    context,
                                  ).colorScheme.onSurfaceVariant,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 4),
                      // Row 3: Dates + Due
                      Row(
                        children: [
                          Icon(
                            Icons.calendar_today_outlined,
                            size: 11,
                            color: AppTheme.textMutedLight,
                          ),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Text(
                              '${DateFormatter.format(booking.checkin)} → ${DateFormatter.format(booking.checkout)}',
                              style: TextStyle(
                                fontSize: 11,
                                color: AppTheme.textSecondaryLight,
                                fontFeatures: const [
                                  FontFeature.tabularFigures(),
                                ],
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          if (booking.due > 0)
                            Text(
                              'Due: ${CurrencyFormatter.format(booking.due)}',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: AppTheme.alertRed,
                                fontFeatures: const [
                                  FontFeature.tabularFigures(),
                                ],
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      // Quick-action buttons row
                      Row(
                        children: [
                          if (canCheckInOut)
                            _QuickActionButton(
                              icon: isCheckedIn
                                  ? Icons.logout_rounded
                                  : Icons.how_to_reg_rounded,
                              label: isCheckedIn ? 'Check-Out' : 'Check-In',
                              color: isCheckedIn
                                  ? AppTheme.brassAccent
                                  : AppTheme.successGreen,
                              onTap: onCheckInTap,
                            ),
                          if (canCheckInOut) const SizedBox(width: 6),
                          _QuickActionButton(
                            icon: Icons.receipt_long_outlined,
                            label: 'Invoice',
                            color: const Color(0xFF8E2A18),
                            onTap: onInvoiceTap,
                          ),
                          const SizedBox(width: 6),
                          if (booking.due > 0)
                            _QuickActionButton(
                              icon: Icons.payments_outlined,
                              label: 'Collect',
                              color: AppTheme.deepTeal,
                              onTap: onCollectPaymentTap,
                            ),
                          if (booking.due > 0) const SizedBox(width: 6),
                          _QuickActionButton(
                            icon: Icons.person_outline_rounded,
                            label: 'Profile',
                            color: const Color(0xFF5C6BC0),
                            onTap: onViewGuestProfileTap,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _QuickActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback? onTap;

  const _QuickActionButton({
    required this.icon,
    required this.label,
    required this.color,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
        decoration: BoxDecoration(
          color: color.withAlpha(20),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withAlpha(51), width: 1),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 13, color: color),
            const SizedBox(width: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PayStatusBadge extends StatelessWidget {
  final PayStatus payStatus;

  const _PayStatusBadge({required this.payStatus});

  @override
  Widget build(BuildContext context) {
    Color bg, border, text;
    String label;

    switch (payStatus) {
      case PayStatus.paid:
        bg = AppTheme.successGreen.withAlpha(31);
        border = AppTheme.successGreen.withAlpha(77);
        text = AppTheme.successGreen;
        label = 'Paid';
        break;
      case PayStatus.partial:
        bg = AppTheme.brassAccent.withAlpha(31);
        border = AppTheme.brassAccent.withAlpha(77);
        text = AppTheme.brassAccent;
        label = 'Partial';
        break;
      case PayStatus.unpaid:
        bg = AppTheme.alertRed.withAlpha(31);
        border = AppTheme.alertRed.withAlpha(77);
        text = AppTheme.alertRed;
        label = 'Unpaid';
        break;
      case PayStatus.none:
        bg = const Color(0xFFF0EEE9);
        border = const Color(0xFFDDD8CF);
        text = AppTheme.textMutedLight;
        label = '—';
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(50),
        border: Border.all(color: border, width: 1),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w600,
          color: text,
          letterSpacing: 0,
        ),
      ),
    );
  }
}
