import 'package:flutter/material.dart';

import '../../database/repositories/booking_repository.dart';
import '../../models/booking_model.dart';
import '../../theme/app_theme.dart';
import '../../utils/currency_formatter.dart';
import '../../services/data_change_service.dart';
import '../../services/account_service.dart';
import '../../services/guest_stay_pdf_service.dart';
import '../../widgets/confirm_trash_dialog.dart';
import '../../utils/phone_normalizer.dart';
import './enhanced_booking_form_screen.dart';
import '../invoice_screen/invoice_screen.dart';
import '../payments_screen/payments_screen.dart';
import '../customer_details_screen/customer_details_screen.dart';
import './widgets/booking_list_item_widget.dart';
import './widgets/filter_bottom_sheet_widget.dart';

class BookingsScreen extends StatefulWidget {
  const BookingsScreen({super.key});

  @override
  State<BookingsScreen> createState() => _BookingsScreenState();
}

class _BookingsScreenState extends State<BookingsScreen> {
  final BookingRepository _repo = BookingRepository();
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  String _statusFilter = 'All';
  String _roomFilter = 'All Rooms';
  bool _isLoading = true;
  final Set<String> _generatingGuestPdf = {};

  List<BookingModel> _allBookings = [];
  List<BookingModel> _filteredBookings = [];

  final List<String> _statusFilters = [
    'All',
    'Booked',
    'Checked-in',
    'Checked-out',
    'Cancelled',
    'No-show',
  ];
  final List<String> _roomFilters = [
    'All Rooms',
    'Room 1',
    'Room 2',
    'Room 3',
    'Room 4',
    'Room 5',
  ];

  @override
  void initState() {
    super.initState();
    _loadData();
    DataChangeService().addListener(_handleDataChange);
    _searchController.addListener(() {
      setState(() {
        _searchQuery = _searchController.text.toLowerCase();
        _applyFilters();
      });
    });
  }

  @override
  void dispose() {
    DataChangeService().removeListener(_handleDataChange);
    _searchController.dispose();
    super.dispose();
  }

  void _handleDataChange() {
    if (mounted) _loadData();
  }

  Future<void> _loadData() async {
    if (mounted) setState(() => _isLoading = true);
    try {
      final bookings = await _repo.getAllBookings();
      if (!mounted) return;
      setState(() {
        _allBookings = bookings;
        _isLoading = false;
        _applyFilters();
      });
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _applyFilters() {
    final searchDigits = PhoneNormalizer.digitsOnly(_searchQuery);
    _filteredBookings = _allBookings.where((b) {
      final matchesSearch =
          _searchQuery.isEmpty ||
          b.guest.toLowerCase().contains(_searchQuery) ||
          b.id.toLowerCase().contains(_searchQuery) ||
          b.serialNumber.toLowerCase().contains(_searchQuery) ||
          b.phone.toLowerCase().contains(_searchQuery) ||
          (searchDigits.isNotEmpty &&
              PhoneNormalizer.canonical(b.phone).contains(searchDigits));
      final matchesStatus =
          _statusFilter == 'All' || b.statusLabel == _statusFilter;
      final matchesRoom =
          _roomFilter == 'All Rooms' || b.roomLabel == _roomFilter;
      return matchesSearch && matchesStatus && matchesRoom;
    }).toList();

    _filteredBookings.sort((a, b) {
      const order = [
        BookingStatus.checkedIn,
        BookingStatus.booked,
        BookingStatus.checkedOut,
        BookingStatus.noShow,
        BookingStatus.cancelled,
      ];
      final aOrder = order.indexOf(a.status);
      final bOrder = order.indexOf(b.status);
      if (aOrder != bOrder) return aOrder.compareTo(bOrder);
      return b.checkin.compareTo(a.checkin);
    });
  }

  void _showFilterSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => FilterBottomSheetWidget(
        currentStatus: _statusFilter,
        currentRoom: _roomFilter,
        statusOptions: _statusFilters,
        roomOptions: _roomFilters,
        onApply: (status, room) {
          setState(() {
            _statusFilter = status;
            _roomFilter = room;
            _applyFilters();
          });
        },
      ),
    );
  }

  void _openBookingForm({BookingModel? booking}) async {
    final result = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => EnhancedBookingFormScreen(booking: booking),
      ),
    );
    if (result == true) _loadData();
  }

  void _openInvoice(BookingModel booking) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => InvoiceScreen(booking: booking)),
    );
  }

  Future<void> _downloadGuestStayPdf(BookingModel booking) async {
    if (_generatingGuestPdf.contains(booking.id)) return;
    setState(() => _generatingGuestPdf.add(booking.id));
    try {
      final fileName = await GuestStayPdfService().downloadOrShare(booking);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Guest stay PDF downloaded to $fileName')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not create guest stay PDF: $error')),
      );
    } finally {
      if (mounted) setState(() => _generatingGuestPdf.remove(booking.id));
    }
  }

  Future<void> _handleCheckInOut(BookingModel booking) async {
    final isCheckedIn = booking.status == BookingStatus.checkedIn;
    final actionLabel = isCheckedIn ? 'Check-Out' : 'Check-In';
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          '$actionLabel — ${booking.guest}',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: AppTheme.deepTealDark,
          ),
        ),
        content: Text(
          isCheckedIn
              ? 'Mark ${booking.guest} as checked out from ${booking.roomLabel}?'
              : 'Mark ${booking.guest} as checked in to ${booking.roomLabel}?',
          style: TextStyle(fontSize: 14, color: AppTheme.textSecondaryLight),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(
              'Cancel',
              style: TextStyle(color: AppTheme.textMutedLight),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: isCheckedIn
                  ? AppTheme.brassAccent
                  : AppTheme.successGreen,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            onPressed: () => Navigator.pop(context, true),
            child: Text(
              actionLabel,
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    try {
      await _repo.updateBooking(
        booking.copyWith(
          status: isCheckedIn
              ? BookingStatus.checkedOut
              : BookingStatus.checkedIn,
        ),
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              booking.due > 0 && isCheckedIn
                  ? '$actionLabel complete. ${CurrencyFormatter.format(booking.due)} is still due.'
                  : '$actionLabel successful for ${booking.guest}',
              style: TextStyle(),
            ),
            backgroundColor: isCheckedIn
                ? AppTheme.brassAccent
                : AppTheme.successGreen,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        );
        _loadData();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Action failed: $e', style: TextStyle()),
            backgroundColor: AppTheme.alertRed,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    }
  }

  void _handleCollectPayment(BookingModel booking) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const PaymentsScreen()),
    ).then((_) => _loadData());
  }

  void _handleViewGuestProfile(BookingModel booking) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CustomerDetailsScreen(initialBooking: booking),
      ),
    );
  }

  Future<void> _deleteBooking(BookingModel booking) async {
    final confirmed = await confirmMoveToTrash(
      context,
      itemName: 'Booking ${booking.id} for ${booking.guest}',
    );
    if (!confirmed) return;
    try {
      await _repo.deleteBooking(booking.id);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Booking moved to Trash for 7 days')),
      );
      await _loadData();
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(error.toString().replaceFirst('Bad state: ', '')),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(theme),
            _buildSearchBar(theme),
            _buildFilterChips(theme),
            _buildListHeader(theme),
            Expanded(child: _buildBookingList(theme)),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openBookingForm(),
        icon: const Icon(Icons.add_rounded, size: 20),
        label: Text(
          'Add Booking',
          style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
        ),
        backgroundColor: AppTheme.deepTeal,
        foregroundColor: Colors.white,
        elevation: 3,
      ),
    );
  }

  Widget _buildHeader(ThemeData theme) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      color: theme.scaffoldBackgroundColor,
      child: Row(
        children: [
          Text(
            'Bookings',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w700,
              color: theme.colorScheme.onSurface,
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: theme.colorScheme.primary.withAlpha(26),
              borderRadius: BorderRadius.circular(50),
            ),
            child: Text(
              '${_filteredBookings.length} records',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w500,
                color: theme.colorScheme.primary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar(ThemeData theme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
      child: Row(
        children: [
          Expanded(
            child: Container(
              height: 44,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFDDD8CF)),
              ),
              child: Row(
                children: [
                  const SizedBox(width: 12),
                  Icon(
                    Icons.search_rounded,
                    size: 18,
                    color: AppTheme.textMutedLight,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _searchController,
                      style: TextStyle(
                        fontSize: 14,
                        color: AppTheme.deepTealDark,
                      ),
                      decoration: InputDecoration(
                        hintText: 'Search guest or booking ID…',
                        hintStyle: TextStyle(
                          fontSize: 14,
                          color: AppTheme.textMutedLight,
                        ),
                        border: InputBorder.none,
                        isDense: true,
                        contentPadding: EdgeInsets.zero,
                      ),
                    ),
                  ),
                  if (_searchQuery.isNotEmpty)
                    GestureDetector(
                      onTap: () {
                        _searchController.clear();
                        setState(() {
                          _searchQuery = '';
                          _applyFilters();
                        });
                      },
                      child: Padding(
                        padding: const EdgeInsets.only(right: 10),
                        child: Icon(
                          Icons.close_rounded,
                          size: 16,
                          color: AppTheme.textSecondaryLight,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: _showFilterSheet,
            child: Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: (_statusFilter != 'All' || _roomFilter != 'All Rooms')
                    ? AppTheme.deepTeal
                    : Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFDDD8CF)),
              ),
              child: Icon(
                Icons.tune_rounded,
                size: 20,
                color: (_statusFilter != 'All' || _roomFilter != 'All Rooms')
                    ? Colors.white
                    : AppTheme.textSecondaryLight,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChips(ThemeData theme) {
    return SizedBox(
      height: 36,
      child: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        scrollDirection: Axis.horizontal,
        itemCount: _statusFilters.length,
        itemBuilder: (context, index) {
          final filter = _statusFilters[index];
          final isSelected = _statusFilter == filter;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: GestureDetector(
              onTap: () {
                setState(() {
                  _statusFilter = filter;
                  _applyFilters();
                });
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                curve: Curves.easeOutCubic,
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 7,
                ),
                decoration: BoxDecoration(
                  color: isSelected ? AppTheme.deepTeal : Colors.white,
                  borderRadius: BorderRadius.circular(50),
                  border: Border.all(
                    color: isSelected
                        ? AppTheme.deepTeal
                        : const Color(0xFFDDD8CF),
                  ),
                ),
                child: Text(
                  filter,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: isSelected
                        ? Colors.white
                        : AppTheme.textSecondaryLight,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildListHeader(ThemeData theme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 6),
      child: Row(
        children: [
          Text(
            'BOOKING',
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w600,
              color: AppTheme.textMutedLight,
              letterSpacing: 0,
            ),
          ),
          const Spacer(),
          Text(
            'ROOM   DATES   STATUS',
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w600,
              color: AppTheme.textMutedLight,
              letterSpacing: 0,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBookingList(ThemeData theme) {
    if (_isLoading) return const Center(child: CircularProgressIndicator());

    if (_filteredBookings.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.bed_outlined, size: 56, color: AppTheme.textMutedLight),
            const SizedBox(height: 16),
            Text(
              'No bookings found',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: AppTheme.textSecondaryLight,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Try adjusting your search or filters',
              style: TextStyle(fontSize: 13, color: AppTheme.textMutedLight),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 120),
      itemCount: _filteredBookings.length,
      itemBuilder: (context, index) {
        final booking = _filteredBookings[index];
        return Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: BookingListItemWidget(
            booking: booking,
            onTap: () => _openBookingForm(booking: booking),
            onInvoiceTap: () => _openInvoice(booking),
            onGuestStayPdfTap: () => _downloadGuestStayPdf(booking),
            isGeneratingGuestStayPdf: _generatingGuestPdf.contains(booking.id),
            onCheckInTap: () => _handleCheckInOut(booking),
            onCollectPaymentTap: () => _handleCollectPayment(booking),
            onViewGuestProfileTap: () => _handleViewGuestProfile(booking),
            onDeleteTap: AccountService().isAdmin
                ? () => _deleteBooking(booking)
                : null,
          ),
        );
      },
    );
  }
}
