import 'package:flutter/material.dart';
import '../../widgets/app_back_button.dart';
import 'package:sizer/sizer.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/app_constants.dart';
import '../../database/repositories/booking_repository.dart';
import '../../database/repositories/payment_repository.dart';
import '../../models/booking_model.dart';
import '../../models/payment_model.dart';
import '../../utils/currency_formatter.dart';

class BookingFormScreen extends StatefulWidget {
  final BookingModel? booking;
  const BookingFormScreen({super.key, this.booking});

  @override
  State<BookingFormScreen> createState() => _BookingFormScreenState();
}

class _BookingFormScreenState extends State<BookingFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final BookingRepository _repo = BookingRepository();
  final PaymentRepository _payRepo = PaymentRepository();

  late TextEditingController _idCtrl;
  late TextEditingController _guestCtrl;
  late TextEditingController _phoneCtrl;
  late TextEditingController _guestsCtrl;
  late TextEditingController _tariffCtrl;
  late TextEditingController _extraCtrl;
  late TextEditingController _discountCtrl;
  late TextEditingController _notesCtrl;

  DateTime _checkin = DateTime.now();
  DateTime _checkout = DateTime.now().add(const Duration(days: 1));
  String _room = AppConstants.rooms.first;
  String _status = AppConstants.bookingStatuses.first;
  String _idTaken = 'No';
  bool _isSaving = false;
  bool _isNew = true;

  List<PaymentModel> _payments = [];

  @override
  void initState() {
    super.initState();
    _isNew = widget.booking == null;
    final b = widget.booking;
    _idCtrl = TextEditingController(text: b?.id ?? '');
    _guestCtrl = TextEditingController(text: b?.guest ?? '');
    _phoneCtrl = TextEditingController(text: b?.phone ?? '');
    _guestsCtrl = TextEditingController(text: b?.guests.toString() ?? '1');
    _tariffCtrl = TextEditingController(
      text: b != null && b.tariff > 0 ? b.tariff.toString() : '',
    );
    _extraCtrl = TextEditingController(
      text: b != null && b.extra > 0 ? b.extra.toString() : '',
    );
    _discountCtrl = TextEditingController(
      text: b != null && b.discount > 0 ? b.discount.toString() : '',
    );
    _notesCtrl = TextEditingController(text: b?.notes ?? '');
    if (b != null) {
      _checkin = b.checkin;
      _checkout = b.checkout;
      _room = b.roomLabel;
      _status = b.statusLabel;
      _idTaken = b.idTaken ? 'Yes' : 'No';
      _loadLinkedData(b.id);
    } else {
      _suggestNextId();
    }
  }

  Future<void> _suggestNextId() async {
    final nextId = await _repo.suggestNextId();
    setState(() => _idCtrl.text = nextId);
  }

  Future<void> _loadLinkedData(String bookingId) async {
    final payments = await _payRepo.getPaymentsForBooking(bookingId);
    if (!mounted) return;
    setState(() {
      _payments = payments;
    });
  }

  @override
  void dispose() {
    _idCtrl.dispose();
    _guestCtrl.dispose();
    _phoneCtrl.dispose();
    _guestsCtrl.dispose();
    _tariffCtrl.dispose();
    _extraCtrl.dispose();
    _discountCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  // Derived calculations from form inputs
  int get _nights => _checkout.difference(_checkin).inDays.clamp(0, 9999);
  double get _tariff => double.tryParse(_tariffCtrl.text) ?? 0;
  double get _extra => double.tryParse(_extraCtrl.text) ?? 0;
  double get _discount => double.tryParse(_discountCtrl.text) ?? 0;
  double get _roomCharges => _nights * _tariff;
  double get _total => _roomCharges + _extra - _discount;
  double get _received => _payments.fold(0.0, (s, p) => s + p.amount);
  double get _due => _total - _received;

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    // Validate checkout after checkin
    if (!_checkout.isAfter(_checkin)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Checkout must be after check-in')),
      );
      return;
    }

    // Check ID uniqueness for new bookings
    if (_isNew) {
      final isUnique = await _repo.isIdUnique(_idCtrl.text.trim());
      if (!isUnique) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Booking ID "${_idCtrl.text}" already exists'),
            ),
          );
        }
        return;
      }
    }

    // Warn on double-booking
    final hasOverlap = await _repo.hasOverlap(
      _room,
      _checkin,
      _checkout,
      excludeId: widget.booking?.id,
    );
    if (hasOverlap && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$_room is already booked for those dates')),
      );
      return;
    }

    setState(() => _isSaving = true);
    try {
      final booking = BookingModel(
        id: _idCtrl.text.trim(),
        guest: _guestCtrl.text.trim(),
        phone: _phoneCtrl.text.trim(),
        guests: int.tryParse(_guestsCtrl.text) ?? 1,
        room: BookingModel.roomFromString(_room),
        checkin: _checkin,
        checkout: _checkout,
        tariff: _tariff,
        extra: _extra,
        discount: _discount,
        status: BookingModel.statusFromString(_status),
        idTaken: _idTaken == 'Yes',
        notes: _notesCtrl.text.trim(),
      );
      if (_isNew) {
        await _repo.insertBooking(booking);
      } else {
        await _repo.updateBooking(booking);
      }
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      setState(() => _isSaving = false);
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error saving: $e')));
      }
    }
  }

  Future<void> _pickDate(bool isCheckin) async {
    final initial = isCheckin ? _checkin : _checkout;
    final first = isCheckin
        ? DateTime(2020)
        : _checkin.add(const Duration(days: 1));
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: first,
      lastDate: DateTime(2030),
    );
    if (picked != null) {
      setState(() {
        if (isCheckin) {
          _checkin = picked;
          if (!_checkout.isAfter(_checkin)) {
            _checkout = _checkin.add(const Duration(days: 1));
          }
        } else {
          _checkout = picked;
        }
      });
    }
  }

  Future<void> _callGuest() async {
    final phone = _phoneCtrl.text.trim();
    if (phone.isEmpty) return;
    final uri = Uri.parse('tel:$phone');
    if (await canLaunchUrl(uri)) await launchUrl(uri);
  }

  Future<void> _whatsappGuest() async {
    final phone = _phoneCtrl.text.trim();
    if (phone.isEmpty) return;
    final uri = Uri.parse('https://wa.me/91$phone');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF0D1F25) : const Color(0xFFF7F4EE);
    final inkColor = isDark ? Colors.white : const Color(0xFF0E332B);
    final fieldFill = isDark ? const Color(0xFF123F34) : Colors.white;
    final accentColor = const Color(0xFF8E2A18);

    InputDecoration fieldDec(String label, {String? hint}) => InputDecoration(
      labelText: label,
      hintText: hint,
      filled: true,
      fillColor: fieldFill,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.grey.withAlpha(60)),
      ),
      contentPadding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
    );

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        leading: const AppBackButton(color: Colors.white),
        backgroundColor: isDark
            ? const Color(0xFF0E332B)
            : const Color(0xFF123F34),
        title: Text(
          _isNew ? 'New Booking' : 'Edit Booking',
          style: TextStyle(color: Colors.white, fontSize: 18.0),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          TextButton(
            onPressed: _isSaving ? null : _save,
            child: Text(
              'Save',
              style: TextStyle(
                color: accentColor,
                fontWeight: FontWeight.w700,
                fontSize: 16.0,
              ),
            ),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: EdgeInsets.all(4.w),
          children: [
            // Booking ID
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _idCtrl,
                    decoration: fieldDec('Booking ID *', hint: 'e.g. BH-001'),
                    validator: (v) =>
                        (v == null || v.trim().isEmpty) ? 'Required' : null,
                    enabled: _isNew,
                  ),
                ),
              ],
            ),
            SizedBox(height: 2.h),

            // Guest name
            TextFormField(
              controller: _guestCtrl,
              decoration: fieldDec('Guest Name *'),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Required' : null,
            ),
            SizedBox(height: 2.h),

            // Phone with call/WA buttons
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _phoneCtrl,
                    decoration: fieldDec('Phone'),
                    keyboardType: TextInputType.phone,
                  ),
                ),
                SizedBox(width: 2.w),
                IconButton(
                  onPressed: _callGuest,
                  icon: const Icon(Icons.call_outlined),
                  color: const Color(0xFF3D6B4A),
                  tooltip: 'Call',
                ),
                IconButton(
                  onPressed: _whatsappGuest,
                  icon: const Icon(Icons.chat_outlined),
                  color: const Color(0xFF3D6B4A),
                  tooltip: 'WhatsApp',
                ),
              ],
            ),
            SizedBox(height: 2.h),

            // Guests count
            TextFormField(
              controller: _guestsCtrl,
              decoration: fieldDec('Number of Guests'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 2.h),

            // Room
            DropdownButtonFormField<String>(
              initialValue: _room,
              decoration: fieldDec('Room'),
              items: AppConstants.rooms
                  .map(
                    (r) => DropdownMenuItem(
                      value: r,
                      child: Text(r, style: TextStyle(fontSize: 14.0)),
                    ),
                  )
                  .toList(),
              onChanged: (v) => setState(() => _room = v!),
            ),
            SizedBox(height: 2.h),

            // Check-in / Check-out
            Row(
              children: [
                Expanded(
                  child: _dateField(
                    'Check-in',
                    _checkin,
                    () => _pickDate(true),
                    fieldFill,
                    inkColor,
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: _dateField(
                    'Check-out',
                    _checkout,
                    () => _pickDate(false),
                    fieldFill,
                    inkColor,
                  ),
                ),
              ],
            ),
            SizedBox(height: 2.h),

            // Tariff
            TextFormField(
              controller: _tariffCtrl,
              decoration: fieldDec('Tariff / Night (₹)'),
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              onChanged: (_) => setState(() {}),
            ),
            SizedBox(height: 2.h),

            // Extra & Discount
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _extraCtrl,
                    decoration: fieldDec('Extra (₹)'),
                    keyboardType: const TextInputType.numberWithOptions(
                      decimal: true,
                    ),
                    onChanged: (_) => setState(() {}),
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: TextFormField(
                    controller: _discountCtrl,
                    decoration: fieldDec('Discount (₹)'),
                    keyboardType: const TextInputType.numberWithOptions(
                      decimal: true,
                    ),
                    onChanged: (_) => setState(() {}),
                  ),
                ),
              ],
            ),
            SizedBox(height: 2.h),

            // Status
            DropdownButtonFormField<String>(
              initialValue: _status,
              decoration: fieldDec('Status'),
              items: AppConstants.bookingStatuses
                  .map(
                    (s) => DropdownMenuItem(
                      value: s,
                      child: Text(s, style: TextStyle(fontSize: 14.0)),
                    ),
                  )
                  .toList(),
              onChanged: (v) => setState(() => _status = v!),
            ),
            SizedBox(height: 2.h),

            // ID Taken
            DropdownButtonFormField<String>(
              initialValue: _idTaken,
              decoration: fieldDec('ID Taken'),
              items: ['Yes', 'No']
                  .map(
                    (v) => DropdownMenuItem(
                      value: v,
                      child: Text(v, style: TextStyle(fontSize: 14.0)),
                    ),
                  )
                  .toList(),
              onChanged: (v) => setState(() => _idTaken = v!),
            ),
            SizedBox(height: 2.h),

            // Notes
            TextFormField(
              controller: _notesCtrl,
              decoration: fieldDec('Notes'),
              maxLines: 3,
            ),
            SizedBox(height: 3.h),

            // Financial summary
            _buildFinancialSummary(inkColor, fieldFill),
            SizedBox(height: 3.h),

            // Linked payments
            if (!_isNew) ...[
              _buildLinkedPayments(inkColor, fieldFill),
              SizedBox(height: 3.h),
            ],

            SizedBox(height: 4.h),
          ],
        ),
      ),
    );
  }

  Widget _dateField(
    String label,
    DateTime date,
    VoidCallback onTap,
    Color fill,
    Color inkColor,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.5.h),
        decoration: BoxDecoration(
          color: fill,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.grey.withAlpha(60)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(fontSize: 12.0, color: inkColor.withAlpha(120)),
            ),
            SizedBox(height: 0.3.h),
            Text(
              DateFormatter.format(date),
              style: TextStyle(
                fontSize: 14.0,
                fontWeight: FontWeight.w600,
                color: inkColor,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFinancialSummary(Color inkColor, Color cardColor) {
    Color payStatusColor;
    String payStatusLabel;
    if (_total <= 0) {
      payStatusColor = Colors.grey;
      payStatusLabel = '—';
    } else if (_due <= 0) {
      payStatusColor = const Color(0xFF3D6B4A);
      payStatusLabel = 'PAID';
    } else if (_received > 0) {
      payStatusColor = const Color(0xFF8E2A18);
      payStatusLabel = 'PARTIAL';
    } else {
      payStatusColor = const Color(0xFFA2432F);
      payStatusLabel = 'UNPAID';
    }

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: const Color(0xFF123F34),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Financial Summary',
                style: TextStyle(color: Colors.white70, fontSize: 13.0),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: payStatusColor.withAlpha(40),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: payStatusColor.withAlpha(100)),
                ),
                child: Text(
                  payStatusLabel,
                  style: TextStyle(
                    fontSize: 12.0,
                    fontWeight: FontWeight.w700,
                    color: payStatusColor,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          _summaryRow('Nights', '$_nights', Colors.white),
          _summaryRow(
            'Room Charges',
            CurrencyFormatter.format(_roomCharges),
            Colors.white,
          ),
          _summaryRow('Extra', CurrencyFormatter.format(_extra), Colors.white),
          _summaryRow(
            'Discount',
            '−${CurrencyFormatter.format(_discount)}',
            Colors.white,
          ),
          Divider(color: Colors.white24, height: 2.h),
          _summaryRow(
            'Total',
            CurrencyFormatter.format(_total),
            Colors.white,
            bold: true,
          ),
          _summaryRow(
            'Received',
            CurrencyFormatter.format(_received),
            const Color(0xFF3D6B4A),
          ),
          _summaryRow(
            'Due',
            CurrencyFormatter.format(_due),
            _due > 0 ? const Color(0xFFA2432F) : const Color(0xFF3D6B4A),
            bold: true,
          ),
        ],
      ),
    );
  }

  Widget _summaryRow(
    String label,
    String value,
    Color valueColor, {
    bool bold = false,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(fontSize: 13.0, color: Colors.white60)),
          Text(
            value,
            style: TextStyle(
              fontSize: 14.0,
              fontWeight: bold ? FontWeight.w700 : FontWeight.w500,
              color: valueColor,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLinkedPayments(Color inkColor, Color cardColor) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Payments',
          style: TextStyle(
            fontSize: 16.0,
            fontWeight: FontWeight.w700,
            color: inkColor,
          ),
        ),
        SizedBox(height: 1.h),
        if (_payments.isEmpty)
          Text(
            'No payments recorded',
            style: TextStyle(fontSize: 13.0, color: inkColor.withAlpha(120)),
          )
        else
          ..._payments.map(
            (p) => Container(
              margin: const EdgeInsets.only(bottom: 6),
              padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
              decoration: BoxDecoration(
                color: cardColor,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.grey.withAlpha(40)),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${DateFormatter.format(p.date)} · ${p.typeLabel}',
                          style: TextStyle(fontSize: 13.0, color: inkColor),
                        ),
                        Text(
                          '${p.modeLabel}${p.by.isNotEmpty ? ' · ${p.by}' : ''}',
                          style: TextStyle(
                            fontSize: 12.0,
                            color: inkColor.withAlpha(140),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Text(
                    CurrencyFormatter.format(p.amount),
                    style: TextStyle(
                      fontSize: 16.0,
                      fontWeight: FontWeight.w700,
                      color: p.amount < 0
                          ? const Color(0xFFA2432F)
                          : const Color(0xFF3D6B4A),
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}
