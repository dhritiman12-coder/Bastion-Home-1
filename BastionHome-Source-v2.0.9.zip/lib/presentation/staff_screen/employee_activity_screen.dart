import 'package:flutter/material.dart';

import '../../database/repositories/booking_repository.dart';
import '../../database/repositories/expense_repository.dart';
import '../../database/repositories/payment_repository.dart';
import '../../models/app_user.dart';
import '../../models/booking_model.dart';
import '../../models/payment_model.dart';
import '../../services/account_service.dart';
import '../../utils/currency_formatter.dart';
import '../../widgets/app_back_button.dart';

class EmployeeActivityScreen extends StatefulWidget {
  final AppUser employee;

  const EmployeeActivityScreen({required this.employee, super.key});

  @override
  State<EmployeeActivityScreen> createState() => _EmployeeActivityScreenState();
}

class _EmployeeActivityScreenState extends State<EmployeeActivityScreen> {
  final _bookings = BookingRepository();
  final _payments = PaymentRepository();
  final _expenses = ExpenseRepository();

  List<BookingModel> _processedBookings = const [];
  List<PaymentModel> _recordedPayments = const [];
  List<DailyExpense> _recordedExpenses = const [];
  bool _loading = true;
  bool _locking = false;
  late bool _active;

  @override
  void initState() {
    super.initState();
    _active = widget.employee.active;
    _load();
  }

  Future<void> _load() async {
    try {
      final results = await Future.wait<dynamic>([
        _bookings.getAllBookings(),
        _payments.getAllPayments(),
        _expenses.getAllDailyExpenses(),
      ]);
      if (!mounted) return;
      setState(() {
        _processedBookings = (results[0] as List<BookingModel>)
            .where(
              (booking) => AccountService.activityBelongsTo(
                booking.createdBy,
                widget.employee,
              ),
            )
            .toList();
        _recordedPayments = (results[1] as List<PaymentModel>)
            .where(
              (payment) =>
                  AccountService.activityBelongsTo(payment.by, widget.employee),
            )
            .toList();
        _recordedExpenses = (results[2] as List<DailyExpense>)
            .where(
              (expense) =>
                  AccountService.activityBelongsTo(expense.by, widget.employee),
            )
            .toList();
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not load employee activity: $error')),
      );
    }
  }

  Future<void> _lockAccount() async {
    if (!_active || _locking) return;
    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        icon: Icon(
          Icons.lock_person_outlined,
          color: Theme.of(dialogContext).colorScheme.error,
        ),
        title: const Text('Lock employee account?'),
        content: Text(
          '${widget.employee.displayName} will be blocked from signing in. '
          'Their activity history and business records will remain available.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(dialogContext).colorScheme.error,
              foregroundColor: Theme.of(dialogContext).colorScheme.onError,
            ),
            onPressed: () => Navigator.pop(dialogContext, true),
            icon: const Icon(Icons.lock_outline),
            label: const Text('Lock Account'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;

    setState(() => _locking = true);
    try {
      await AccountService().updateEmployee(
        user: widget.employee,
        displayName: widget.employee.displayName,
        permissions: widget.employee.permissions,
        active: false,
      );
      if (!mounted) return;
      setState(() {
        _active = false;
        _locking = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Employee account locked immediately')),
      );
    } catch (error) {
      if (!mounted) return;
      setState(() => _locking = false);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Could not lock account: $error')));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!AccountService().isAdmin) {
      return Scaffold(
        appBar: AppBar(leading: const AppBackButton()),
        body: const Center(child: Text('Administrator access is required')),
      );
    }
    return Scaffold(
      appBar: AppBar(
        leading: const AppBackButton(),
        title: const Text('Employee Activity'),
        actions: [
          IconButton(
            tooltip: _active ? 'Lock employee account' : 'Account locked',
            onPressed: _active && !_locking ? _lockAccount : null,
            icon: Icon(
              _active ? Icons.lock_person_outlined : Icons.lock_outline,
            ),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
                children: [
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: CircleAvatar(
                      child: Icon(
                        _active
                            ? Icons.badge_outlined
                            : Icons.person_off_outlined,
                      ),
                    ),
                    title: Text(widget.employee.displayName),
                    subtitle: Text(
                      '@${widget.employee.username} · ${_active ? 'Active' : 'Locked'}',
                    ),
                  ),
                  const SizedBox(height: 8),
                  _ActivitySummary(
                    bookings: _processedBookings.length,
                    payments: _recordedPayments.length,
                    expenses: _recordedExpenses.length,
                  ),
                  const SizedBox(height: 24),
                  _SectionTitle(
                    title: 'Guests Processed',
                    count: _processedBookings.length,
                  ),
                  if (_processedBookings.isEmpty)
                    const _EmptyActivity(label: 'No attributed bookings')
                  else
                    for (final booking in _processedBookings)
                      Card(
                        child: ListTile(
                          leading: const Icon(Icons.hotel_outlined),
                          title: Text(booking.guest),
                          subtitle: Text(
                            '${booking.id} · ${booking.roomLabel}\n'
                            '${DateFormatter.format(booking.checkin)} to '
                            '${DateFormatter.format(booking.checkout)}',
                          ),
                          isThreeLine: true,
                        ),
                      ),
                  const SizedBox(height: 20),
                  _SectionTitle(
                    title: 'Payments Recorded',
                    count: _recordedPayments.length,
                  ),
                  if (_recordedPayments.isEmpty)
                    const _EmptyActivity(label: 'No attributed payments')
                  else
                    for (final payment in _recordedPayments)
                      Card(
                        child: ListTile(
                          leading: const Icon(Icons.payments_outlined),
                          title: Text(
                            payment.guestName.isEmpty
                                ? payment.bookingId
                                : payment.guestName,
                          ),
                          subtitle: Text(
                            '${payment.bookingId} · ${DateFormatter.format(payment.date)}',
                          ),
                          trailing: Text(
                            CurrencyFormatter.format(payment.amount),
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                        ),
                      ),
                  const SizedBox(height: 20),
                  _SectionTitle(
                    title: 'Expenses Recorded',
                    count: _recordedExpenses.length,
                  ),
                  if (_recordedExpenses.isEmpty)
                    const _EmptyActivity(label: 'No attributed expenses')
                  else
                    for (final expense in _recordedExpenses)
                      Card(
                        child: ListTile(
                          leading: const Icon(Icons.receipt_long_outlined),
                          title: Text(expense.head),
                          subtitle: Text(DateFormatter.format(expense.date)),
                          trailing: Text(
                            CurrencyFormatter.format(expense.amount),
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                        ),
                      ),
                ],
              ),
            ),
    );
  }
}

class _ActivitySummary extends StatelessWidget {
  final int bookings;
  final int payments;
  final int expenses;

  const _ActivitySummary({
    required this.bookings,
    required this.payments,
    required this.expenses,
  });

  @override
  Widget build(BuildContext context) => Row(
    children: [
      Expanded(
        child: _SummaryValue(label: 'Guests', value: bookings),
      ),
      Expanded(
        child: _SummaryValue(label: 'Payments', value: payments),
      ),
      Expanded(
        child: _SummaryValue(label: 'Expenses', value: expenses),
      ),
    ],
  );
}

class _SummaryValue extends StatelessWidget {
  final String label;
  final int value;

  const _SummaryValue({required this.label, required this.value});

  @override
  Widget build(BuildContext context) => Column(
    children: [
      Text('$value', style: Theme.of(context).textTheme.headlineSmall),
      Text(label, style: Theme.of(context).textTheme.bodySmall),
    ],
  );
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final int count;

  const _SectionTitle({required this.title, required this.count});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Row(
      children: [
        Expanded(
          child: Text(title, style: Theme.of(context).textTheme.titleMedium),
        ),
        Badge(label: Text('$count')),
      ],
    ),
  );
}

class _EmptyActivity extends StatelessWidget {
  final String label;

  const _EmptyActivity({required this.label});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 12),
    child: Text(label, style: Theme.of(context).textTheme.bodyMedium),
  );
}
