import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../models/app_user.dart';
import '../../services/account_service.dart';
import '../../services/cloud_sync_service.dart';
import '../../widgets/app_back_button.dart';
import '../../widgets/credential_text_form_field.dart';
import '../cloud_sync_screen/workspace_access_screen.dart';
import 'employee_activity_screen.dart';

enum _EmployeeAction { activity, edit, toggleActive, delete }

class StaffManagementScreen extends StatelessWidget {
  const StaffManagementScreen({super.key});

  Future<void> _openEditor(BuildContext context, [AppUser? user]) async {
    final changed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => _AccountEditorDialog(user: user),
    );
    if (changed == true && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(user == null ? 'Account added' : 'Account updated'),
        ),
      );
    }
  }

  Future<void> _deleteEmployee(BuildContext context, AppUser user) async {
    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        icon: Icon(
          Icons.person_remove_outlined,
          color: Theme.of(dialogContext).colorScheme.error,
        ),
        title: const Text('Delete employee account?'),
        content: Text(
          '${user.displayName} (${user.username}) will no longer be able to '
          'sign in on this device. Bookings, expenses, and other business '
          'records created by this employee will be kept.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(dialogContext).colorScheme.error,
              foregroundColor: Theme.of(dialogContext).colorScheme.onError,
            ),
            onPressed: () => Navigator.pop(dialogContext, true),
            icon: const Icon(Icons.delete_outline),
            label: const Text('Delete Account'),
          ),
        ],
      ),
    );
    if (confirmed != true || !context.mounted) return;

    try {
      await AccountService().deleteEmployee(user);
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${user.displayName} account deleted')),
      );
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            error
                .toString()
                .replaceFirst('Invalid argument(s): ', '')
                .replaceFirst('Bad state: ', ''),
          ),
        ),
      );
    }
  }

  Future<void> _openActivity(BuildContext context, AppUser user) async {
    await Navigator.push<void>(
      context,
      MaterialPageRoute(builder: (_) => EmployeeActivityScreen(employee: user)),
    );
  }

  Future<void> _setEmployeeActive(
    BuildContext context,
    AppUser user,
    bool active,
  ) async {
    if (!active) {
      final confirmed = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => AlertDialog(
          icon: Icon(
            Icons.lock_person_outlined,
            color: Theme.of(dialogContext).colorScheme.error,
          ),
          title: const Text('Lock employee account?'),
          content: Text(
            '${user.displayName} will be blocked from signing in. Their '
            'activity history and business records will remain available.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancel'),
            ),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: Theme.of(dialogContext).colorScheme.error,
                foregroundColor: Theme.of(dialogContext).colorScheme.onError,
              ),
              onPressed: () => Navigator.pop(dialogContext, true),
              icon: const Icon(Icons.lock_outline),
              label: const Text('Lock Account'),
            ),
          ],
        ),
      );
      if (confirmed != true || !context.mounted) return;
    }

    try {
      await AccountService().updateEmployee(
        user: user,
        displayName: user.displayName,
        permissions: user.permissions,
        active: active,
      );
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            active ? 'Employee account unlocked' : 'Employee account locked',
          ),
        ),
      );
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not update account: $error')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (CloudSyncService().isConnected) {
      return const WorkspaceAccessScreen();
    }
    final accounts = AccountService();
    return Scaffold(
      appBar: AppBar(
        leading: const AppBackButton(),
        title: const Text('Accounts & Access'),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openEditor(context),
        icon: const Icon(Icons.person_add_alt_1),
        label: const Text('Add Account'),
      ),
      body: AnimatedBuilder(
        animation: accounts,
        builder: (context, _) {
          final admins = accounts.users.where((u) => u.role.isAdmin).toList();
          final employees = accounts.users
              .where((u) => u.role == UserRole.employee)
              .toList();
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
            children: [
              _SectionTitle(title: 'Administrators', count: admins.length),
              for (final user in admins)
                Card(
                  child: ListTile(
                    onTap:
                        accounts.currentUser?.role == UserRole.primaryAdmin &&
                            user.role != UserRole.primaryAdmin
                        ? () => _openEditor(context, user)
                        : null,
                    leading: CircleAvatar(
                      child: Icon(
                        user.role == UserRole.primaryAdmin
                            ? Icons.admin_panel_settings_outlined
                            : Icons.health_and_safety_outlined,
                      ),
                    ),
                    title: Text(user.displayName),
                    subtitle: Text(
                      '${user.role.label}\nUsername: ${user.username}',
                    ),
                    isThreeLine: true,
                    trailing: Icon(
                      user.active ? Icons.verified_user : Icons.block,
                      color: user.active
                          ? Theme.of(context).colorScheme.primary
                          : Theme.of(context).colorScheme.error,
                    ),
                  ),
                ),
              const SizedBox(height: 22),
              _SectionTitle(title: 'Employees', count: employees.length),
              if (employees.isEmpty)
                const Card(
                  child: Padding(
                    padding: EdgeInsets.all(20),
                    child: Text(
                      'No employee accounts yet. Add an employee and choose exactly what they can access.',
                    ),
                  ),
                ),
              for (final user in employees)
                Card(
                  child: ListTile(
                    onTap: () => _openEditor(context, user),
                    leading: CircleAvatar(
                      backgroundColor: user.active
                          ? Theme.of(context).colorScheme.primaryContainer
                          : Theme.of(
                              context,
                            ).colorScheme.surfaceContainerHighest,
                      child: Icon(
                        user.active
                            ? Icons.person_outline
                            : Icons.person_off_outlined,
                      ),
                    ),
                    title: Text(user.displayName),
                    subtitle: Text(
                      '${user.username} · ${user.permissions.length} permissions'
                      '${user.active ? '' : ' · Locked'}\n'
                      'Tap to edit access or reset PIN',
                    ),
                    isThreeLine: true,
                    trailing: PopupMenuButton<_EmployeeAction>(
                      tooltip: 'Employee account actions',
                      onSelected: (action) {
                        switch (action) {
                          case _EmployeeAction.activity:
                            _openActivity(context, user);
                          case _EmployeeAction.edit:
                            _openEditor(context, user);
                          case _EmployeeAction.toggleActive:
                            _setEmployeeActive(context, user, !user.active);
                          case _EmployeeAction.delete:
                            _deleteEmployee(context, user);
                        }
                      },
                      itemBuilder: (context) => [
                        const PopupMenuItem(
                          value: _EmployeeAction.activity,
                          child: ListTile(
                            contentPadding: EdgeInsets.zero,
                            leading: Icon(Icons.history_outlined),
                            title: Text('View Activity'),
                          ),
                        ),
                        const PopupMenuItem(
                          value: _EmployeeAction.edit,
                          child: ListTile(
                            contentPadding: EdgeInsets.zero,
                            leading: Icon(Icons.manage_accounts_outlined),
                            title: Text('Edit Access / Reset PIN'),
                          ),
                        ),
                        PopupMenuItem(
                          value: _EmployeeAction.toggleActive,
                          child: ListTile(
                            contentPadding: EdgeInsets.zero,
                            leading: Icon(
                              user.active
                                  ? Icons.lock_person_outlined
                                  : Icons.lock_open_outlined,
                            ),
                            title: Text(
                              user.active
                                  ? 'Lock Immediately'
                                  : 'Unlock Account',
                            ),
                          ),
                        ),
                        PopupMenuItem(
                          value: _EmployeeAction.delete,
                          child: ListTile(
                            contentPadding: EdgeInsets.zero,
                            leading: Icon(
                              Icons.delete_outline,
                              color: Theme.of(context).colorScheme.error,
                            ),
                            title: Text(
                              'Delete Account',
                              style: TextStyle(
                                color: Theme.of(context).colorScheme.error,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final int count;
  const _SectionTitle({required this.title, required this.count});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Row(
      children: [
        Text(title, style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(width: 8),
        Badge(label: Text('$count')),
      ],
    ),
  );
}

class _AccountEditorDialog extends StatefulWidget {
  final AppUser? user;
  const _AccountEditorDialog({this.user});

  @override
  State<_AccountEditorDialog> createState() => _AccountEditorDialogState();
}

class _AccountEditorDialogState extends State<_AccountEditorDialog> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _username;
  final _pin = TextEditingController();
  late Set<AppPermission> _permissions;
  late UserRole _role;
  late bool _active;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _name = TextEditingController(text: widget.user?.displayName ?? '');
    _username = TextEditingController(text: widget.user?.username ?? '');
    _permissions = Set.of(
      widget.user?.permissions ?? AccountService.defaultEmployeePermissions,
    );
    _role = widget.user?.role ?? UserRole.employee;
    _active = widget.user?.active ?? true;
  }

  @override
  void dispose() {
    _name.dispose();
    _username.dispose();
    _pin.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      if (widget.user == null) {
        await AccountService().addUser(
          username: _username.text,
          displayName: _name.text,
          pin: _pin.text,
          role: _role,
          permissions: _permissions,
        );
      } else {
        await AccountService().updateManagedUser(
          user: widget.user!,
          displayName: _name.text,
          role: _role,
          permissions: _permissions,
          active: _active,
          newPin: _pin.text.isEmpty ? null : _pin.text,
        );
      }
      if (mounted) Navigator.pop(context, true);
    } catch (error) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              error.toString().replaceFirst('Invalid argument(s): ', ''),
            ),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isNew = widget.user == null;
    return AlertDialog(
      title: Text(isNew ? 'Add Account' : 'Edit Account'),
      content: SizedBox(
        width: 520,
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _name,
                  decoration: const InputDecoration(labelText: 'Account name'),
                  validator: (value) => value == null || value.trim().isEmpty
                      ? 'Name is required'
                      : null,
                ),
                const SizedBox(height: 12),
                if (isNew ||
                    (widget.user?.role != UserRole.primaryAdmin &&
                        widget.user?.role != UserRole.backupAdmin)) ...[
                  DropdownButtonFormField<UserRole>(
                    initialValue: _role,
                    decoration: const InputDecoration(
                      labelText: 'Account type',
                    ),
                    items: [
                      const DropdownMenuItem(
                        value: UserRole.employee,
                        child: Text('Employee'),
                      ),
                      if (AccountService().currentUser?.role ==
                          UserRole.primaryAdmin)
                        const DropdownMenuItem(
                          value: UserRole.administrator,
                          child: Text('Administrator'),
                        ),
                    ],
                    onChanged: (value) => setState(() {
                      _role = value ?? UserRole.employee;
                      if (_role.isAdmin) {
                        _permissions = AppPermission.values.toSet();
                      }
                    }),
                  ),
                  const SizedBox(height: 12),
                ],
                CredentialTextFormField(
                  controller: _username,
                  labelText: 'Username',
                  enabled: isNew,
                  validator: (value) => value == null || value.trim().isEmpty
                      ? 'Username is required'
                      : null,
                ),
                const SizedBox(height: 12),
                CredentialTextFormField(
                  controller: _pin,
                  labelText: isNew ? 'PIN' : 'New PIN (optional)',
                  helperText: '6 to 12 digits',
                  secret: true,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  validator: (value) {
                    if (!isNew && (value == null || value.isEmpty)) return null;
                    return RegExp(r'^\d{6,12}$').hasMatch(value ?? '')
                        ? null
                        : 'Enter a 6 to 12 digit PIN';
                  },
                ),
                if (!isNew)
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Account active'),
                    value: _active,
                    onChanged: (value) => setState(() => _active = value),
                  ),
                if (!_role.isAdmin) ...[
                  const Divider(height: 28),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Access permissions',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                  ),
                  const SizedBox(height: 4),
                  for (final permission in AppPermission.values)
                    CheckboxListTile(
                      contentPadding: EdgeInsets.zero,
                      dense: true,
                      title: Text(permission.label),
                      value: _permissions.contains(permission),
                      onChanged: (value) => setState(() {
                        if (value == true) {
                          _permissions.add(permission);
                        } else {
                          _permissions.remove(permission);
                        }
                      }),
                    ),
                ] else
                  const Padding(
                    padding: EdgeInsets.only(top: 18),
                    child: ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: Icon(Icons.admin_panel_settings_outlined),
                      title: Text('Full administrator access'),
                      subtitle: Text(
                        'Administrators can use every management section.',
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: _saving ? null : () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        FilledButton(
          onPressed: _saving ? null : _save,
          child: Text(_saving ? 'Saving...' : 'Save'),
        ),
      ],
    );
  }
}
