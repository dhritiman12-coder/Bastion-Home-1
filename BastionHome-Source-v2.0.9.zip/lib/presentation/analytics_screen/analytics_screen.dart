import 'package:flutter/material.dart';
import '../../widgets/app_back_button.dart';
import 'package:sizer/sizer.dart';

import '../../database/repositories/booking_repository.dart';
import '../../database/repositories/expense_repository.dart';
import '../../database/repositories/payment_repository.dart';
import '../../models/booking_model.dart';
import '../../models/payment_model.dart';
import '../../theme/app_theme.dart';
import '../../services/download_service.dart';
import '../../utils/currency_formatter.dart';

class AnalyticsScreen extends StatefulWidget {
  const AnalyticsScreen({super.key});

  @override
  State<AnalyticsScreen> createState() => _AnalyticsScreenState();
}

class _AnalyticsScreenState extends State<AnalyticsScreen>
    with SingleTickerProviderStateMixin {
  final BookingRepository _bookingRepo = BookingRepository();
  final PaymentRepository _paymentRepo = PaymentRepository();
  final ExpenseRepository _expenseRepo = ExpenseRepository();

  late TabController _tabController;

  bool _isLoading = true;

  // All raw data
  List<BookingModel> _allBookings = [];
  List<PaymentModel> _allPayments = [];
  List<DailyExpense> _allDailyExpenses = [];
  List<MonthlyExpense> _monthlyExpenses = [];
  List<YearlyExpense> _yearlyExpenses = [];

  // Computed analytics — last 6 months
  final List<DateTime> _months = [];
  final Map<String, double> _monthlyRevenue = {};
  final Map<String, double> _monthlyPaymentsReceived = {};
  final Map<String, double> _monthlyDailyExpenses = {};
  final Map<String, int> _monthlyBookingCount = {};
  final Map<String, double> _monthlyOccupancyRate = {};
  final Map<String, Map<String, double>> _roomRevenue = {};

  // Guest patterns
  final Map<String, int> _guestsByMonth = {};
  final Map<String, int> _bookingsByStatus = {};
  final Map<String, int> _paymentModeCount = {};
  final Map<String, double> _paymentModeAmount = {};

  // Expense breakdown
  final Map<String, double> _expenseByHead = {};

  // Staff
  final Map<String, double> _expenseByStaff = {};
  final Map<String, double> _paymentsCollectedBy = {};

  // ROI
  double _totalRevenue6m = 0;
  double _totalExpenses6m = 0;
  double _monthlyRecurringTotal = 0;
  double _yearlyRecurringMonthly = 0;

  static const int _totalRooms = 5;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
    _buildMonthList();
    _loadData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _buildMonthList() {
    final now = DateTime.now();
    for (int i = 5; i >= 0; i--) {
      _months.add(DateTime(now.year, now.month - i, 1));
    }
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      _allBookings = await _bookingRepo.getAllBookings();
      _allPayments = await _paymentRepo.getAllPayments();
      _monthlyExpenses = await _expenseRepo.getAllMonthlyExpenses();
      _yearlyExpenses = await _expenseRepo.getAllYearlyExpenses();

      // Load daily expenses for last 6 months
      final List<DailyExpense> allDaily = [];
      for (final m in _months) {
        final expenses = await _expenseRepo.getDailyExpensesForMonth(
          m.year,
          m.month,
        );
        allDaily.addAll(expenses);
      }
      _allDailyExpenses = allDaily;

      _computeAnalytics();
    } catch (_) {
      setState(() => _isLoading = false);
    }
  }

  void _computeAnalytics() {
    _monthlyRevenue.clear();
    _monthlyPaymentsReceived.clear();
    _monthlyDailyExpenses.clear();
    _monthlyBookingCount.clear();
    _monthlyOccupancyRate.clear();
    _roomRevenue.clear();
    _guestsByMonth.clear();
    _bookingsByStatus.clear();
    _paymentModeCount.clear();
    _paymentModeAmount.clear();
    _expenseByHead.clear();
    _expenseByStaff.clear();
    _paymentsCollectedBy.clear();

    for (final m in _months) {
      final key = _monthKey(m);
      final monthStart = DateTime(m.year, m.month, 1);
      final monthEnd = DateTime(m.year, m.month + 1, 1);
      final daysInMonth = monthEnd.difference(monthStart).inDays;

      // Bookings for this month
      final bookingsInMonth = _allBookings.where((b) {
        return b.status != BookingStatus.cancelled &&
            b.checkin.isBefore(monthEnd) &&
            b.checkout.isAfter(monthStart);
      }).toList();

      // Room-nights sold
      double roomNights = 0;
      double revenue = 0;
      final Map<String, double> roomRev = {};

      for (final b in bookingsInMonth) {
        final effectiveStart = b.checkin.isBefore(monthStart)
            ? monthStart
            : b.checkin;
        final effectiveEnd = b.checkout.isAfter(monthEnd)
            ? monthEnd
            : b.checkout;
        final nights = effectiveEnd.difference(effectiveStart).inDays;
        if (nights > 0) {
          roomNights += nights;
          final rev = nights * b.tariff;
          revenue += rev;
          roomRev[b.roomLabel] = (roomRev[b.roomLabel] ?? 0) + rev;
        }
      }

      _monthlyRevenue[key] = revenue;
      _monthlyOccupancyRate[key] = daysInMonth > 0
          ? (roomNights / (_totalRooms * daysInMonth)).clamp(0.0, 1.0)
          : 0;
      _roomRevenue[key] = roomRev;

      // Bookings count (check-in in this month)
      final newBookings = _allBookings
          .where(
            (b) =>
                b.checkin.isAfter(
                  monthStart.subtract(const Duration(days: 1)),
                ) &&
                b.checkin.isBefore(monthEnd) &&
                b.status != BookingStatus.cancelled,
          )
          .toList();
      _monthlyBookingCount[key] = newBookings.length;
      _guestsByMonth[key] = newBookings.fold(0, (s, b) => s + b.guests);

      // Payments received
      final paymentsInMonth = _allPayments
          .where(
            (p) => !p.date.isBefore(monthStart) && p.date.isBefore(monthEnd),
          )
          .toList();
      _monthlyPaymentsReceived[key] = paymentsInMonth.fold(
        0.0,
        (s, p) => s + p.amount,
      );

      // Daily expenses
      final dailyInMonth = _allDailyExpenses
          .where(
            (e) => !e.date.isBefore(monthStart) && e.date.isBefore(monthEnd),
          )
          .toList();
      _monthlyDailyExpenses[key] = dailyInMonth.fold(
        0.0,
        (s, e) => s + e.amount,
      );
    }

    // Booking status breakdown
    for (final b in _allBookings) {
      _bookingsByStatus[b.statusLabel] =
          (_bookingsByStatus[b.statusLabel] ?? 0) + 1;
    }

    // Payment mode breakdown
    for (final p in _allPayments) {
      _paymentModeCount[p.modeLabel] =
          (_paymentModeCount[p.modeLabel] ?? 0) + 1;
      _paymentModeAmount[p.modeLabel] =
          (_paymentModeAmount[p.modeLabel] ?? 0) + p.amount;
    }

    // Expense by head (last 6 months daily)
    for (final e in _allDailyExpenses) {
      _expenseByHead[e.head] = (_expenseByHead[e.head] ?? 0) + e.amount;
    }

    // Staff expense attribution
    for (final e in _allDailyExpenses) {
      if (e.by.isNotEmpty) {
        _expenseByStaff[e.by] = (_expenseByStaff[e.by] ?? 0) + e.amount;
      }
    }

    // Payments collected by staff
    for (final p in _allPayments) {
      if (p.by.isNotEmpty) {
        _paymentsCollectedBy[p.by] =
            (_paymentsCollectedBy[p.by] ?? 0) + p.amount;
      }
    }

    // ROI totals
    _totalRevenue6m = _monthlyRevenue.values.fold(0.0, (s, v) => s + v);
    _totalExpenses6m = _monthlyDailyExpenses.values.fold(0.0, (s, v) => s + v);
    _monthlyRecurringTotal = _monthlyExpenses.fold(0.0, (s, e) => s + e.amount);
    _yearlyRecurringMonthly =
        _yearlyExpenses.fold(0.0, (s, e) => s + e.amount) / 12;

    setState(() => _isLoading = false);
  }

  String _monthKey(DateTime m) =>
      '${m.year}-${m.month.toString().padLeft(2, '0')}';

  String _shortMonth(DateTime m) {
    const names = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return names[m.month - 1];
  }

  // ── Export ─────────────────────────────────────────────────────────────────

  Future<void> _exportReport() async {
    final buffer = StringBuffer();
    buffer.writeln('Bastion Home — Analytics Report');
    buffer.writeln('Generated: ${DateTime.now().toIso8601String()}');
    buffer.writeln('');
    buffer.writeln('=== MONTHLY SUMMARY (Last 6 Months) ===');
    buffer.writeln(
      'Month,Room Revenue,Payments Received,Daily Expenses,Bookings,Occupancy %',
    );
    for (final m in _months) {
      final k = _monthKey(m);
      buffer.writeln(
        '${_shortMonth(m)} ${m.year},'
        '${_monthlyRevenue[k]?.toStringAsFixed(2) ?? '0'},'
        '${_monthlyPaymentsReceived[k]?.toStringAsFixed(2) ?? '0'},'
        '${_monthlyDailyExpenses[k]?.toStringAsFixed(2) ?? '0'},'
        '${_monthlyBookingCount[k] ?? 0},'
        '${((_monthlyOccupancyRate[k] ?? 0) * 100).toStringAsFixed(1)}%',
      );
    }
    buffer.writeln('');
    buffer.writeln('=== EXPENSE BREAKDOWN BY HEAD ===');
    buffer.writeln('Expense Head,Total Amount');
    final sortedHeads = _expenseByHead.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    for (final e in sortedHeads) {
      buffer.writeln('${e.key},${e.value.toStringAsFixed(2)}');
    }
    buffer.writeln('');
    buffer.writeln('=== ROI SUMMARY ===');
    final totalCost6m =
        _totalExpenses6m +
        (_monthlyRecurringTotal * 6) +
        (_yearlyRecurringMonthly * 6);
    final netProfit = _totalRevenue6m - totalCost6m;
    final roi = totalCost6m > 0 ? (netProfit / totalCost6m * 100) : 0;
    buffer.writeln('Total Revenue (6m),${_totalRevenue6m.toStringAsFixed(2)}');
    buffer.writeln('Total Expenses (6m),${totalCost6m.toStringAsFixed(2)}');
    buffer.writeln('Net Profit (6m),${netProfit.toStringAsFixed(2)}');
    buffer.writeln('ROI,${roi.toStringAsFixed(1)}%');
    buffer.writeln('');
    buffer.writeln('=== STAFF PERFORMANCE ===');
    buffer.writeln('Staff,Expenses Managed,Payments Collected');
    final allStaff = {..._expenseByStaff.keys, ..._paymentsCollectedBy.keys};
    for (final s in allStaff) {
      buffer.writeln(
        '$s,'
        '${(_expenseByStaff[s] ?? 0).toStringAsFixed(2)},'
        '${(_paymentsCollectedBy[s] ?? 0).toStringAsFixed(2)}',
      );
    }

    final csvContent = buffer.toString();
    final fileName =
        'bastion_analytics_${DateTime.now().millisecondsSinceEpoch}.csv';

    try {
      final location = await DownloadService().saveText(
        fileName: fileName,
        contents: csvContent,
        mimeType: 'text/csv',
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Report downloaded to $location'),
          backgroundColor: AppTheme.successGreen,
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not download report: $error')),
      );
    }
  }

  // ── Build ──────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundLight,
      appBar: AppBar(
        leading: const AppBackButton(),
        backgroundColor: AppTheme.backgroundLight,
        title: Text(
          'Analytics',
          style: TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: 18,
            color: AppTheme.textPrimaryLight,
          ),
        ),
        actions: [
          TextButton.icon(
            onPressed: _isLoading ? null : _exportReport,
            icon: const Icon(
              Icons.download_rounded,
              size: 18,
              color: AppTheme.deepTeal,
            ),
            label: Text(
              'Download CSV',
              style: TextStyle(
                color: AppTheme.deepTeal,
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            ),
          ),
          const SizedBox(width: 8),
        ],
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          tabAlignment: TabAlignment.start,
          labelColor: AppTheme.deepTeal,
          unselectedLabelColor: AppTheme.textSecondaryLight,
          indicatorColor: AppTheme.deepTeal,
          indicatorWeight: 2.5,
          labelStyle: TextStyle(fontWeight: FontWeight.w600, fontSize: 12),
          unselectedLabelStyle: TextStyle(
            fontWeight: FontWeight.w400,
            fontSize: 12,
          ),
          tabs: const [
            Tab(text: 'Occupancy'),
            Tab(text: 'Revenue'),
            Tab(text: 'Guests'),
            Tab(text: 'Expenses'),
            Tab(text: 'ROI & Staff'),
          ],
        ),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: AppTheme.deepTeal),
            )
          : TabBarView(
              controller: _tabController,
              children: [
                _OccupancyTab(
                  months: _months,
                  monthlyOccupancy: _monthlyOccupancyRate,
                  monthlyBookings: _monthlyBookingCount,
                  bookingsByStatus: _bookingsByStatus,
                  shortMonth: _shortMonth,
                  monthKey: _monthKey,
                ),
                _RevenueTab(
                  months: _months,
                  monthlyRevenue: _monthlyRevenue,
                  monthlyPayments: _monthlyPaymentsReceived,
                  roomRevenue: _roomRevenue,
                  shortMonth: _shortMonth,
                  monthKey: _monthKey,
                ),
                _GuestTab(
                  months: _months,
                  guestsByMonth: _guestsByMonth,
                  paymentModeCount: _paymentModeCount,
                  paymentModeAmount: _paymentModeAmount,
                  shortMonth: _shortMonth,
                  monthKey: _monthKey,
                ),
                _ExpenseTab(
                  months: _months,
                  monthlyDailyExpenses: _monthlyDailyExpenses,
                  expenseByHead: _expenseByHead,
                  monthlyRecurring: _monthlyExpenses,
                  yearlyRecurring: _yearlyExpenses,
                  shortMonth: _shortMonth,
                  monthKey: _monthKey,
                ),
                _RoiStaffTab(
                  months: _months,
                  monthlyRevenue: _monthlyRevenue,
                  monthlyDailyExpenses: _monthlyDailyExpenses,
                  monthlyRecurringTotal: _monthlyRecurringTotal,
                  yearlyRecurringMonthly: _yearlyRecurringMonthly,
                  totalRevenue6m: _totalRevenue6m,
                  totalExpenses6m: _totalExpenses6m,
                  expenseByStaff: _expenseByStaff,
                  paymentsCollectedBy: _paymentsCollectedBy,
                  shortMonth: _shortMonth,
                  monthKey: _monthKey,
                ),
              ],
            ),
    );
  }
}

// ── Shared Widgets ─────────────────────────────────────────────────────────

class _SectionHeader extends StatelessWidget {
  final String title;
  final IconData icon;
  const _SectionHeader({required this.title, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(4.w, 2.h, 4.w, 1.h),
      child: Row(
        children: [
          Icon(icon, size: 16, color: AppTheme.deepTeal),
          const SizedBox(width: 8),
          Text(
            title,
            style: TextStyle(
              fontSize: 18.0,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimaryLight,
            ),
          ),
        ],
      ),
    );
  }
}

class _KpiCard extends StatelessWidget {
  final String label;
  final String value;
  final String? subtitle;
  final Color? valueColor;
  final IconData? icon;

  const _KpiCard({
    required this.label,
    required this.value,
    this.subtitle,
    this.valueColor,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.5.h),
      decoration: BoxDecoration(
        color: AppTheme.surfaceLight,
        borderRadius: BorderRadius.circular(10.0),
        border: Border.all(color: const Color(0xFFEAE4DC)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              if (icon != null) ...[
                Icon(icon, size: 14, color: AppTheme.textMutedLight),
                const SizedBox(width: 4),
              ],
              Expanded(
                child: Text(
                  label,
                  style: TextStyle(
                    fontSize: 12.0,
                    color: AppTheme.textSecondaryLight,
                    fontWeight: FontWeight.w500,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              fontSize: 20.0,
              fontWeight: FontWeight.w700,
              color: valueColor ?? AppTheme.textPrimaryLight,
            ),
            overflow: TextOverflow.ellipsis,
          ),
          if (subtitle != null)
            Text(
              subtitle!,
              style: TextStyle(fontSize: 11.0, color: AppTheme.textMutedLight),
              overflow: TextOverflow.ellipsis,
            ),
        ],
      ),
    );
  }
}

class _BarChart extends StatelessWidget {
  final List<_BarData> bars;
  final bool isPercent;

  const _BarChart({required this.bars, this.isPercent = false});

  @override
  Widget build(BuildContext context) {
    if (bars.isEmpty) return const SizedBox.shrink();
    final maxVal = bars.map((b) => b.value).reduce((a, b) => a > b ? a : b);
    if (maxVal <= 0) {
      return Center(
        child: Padding(
          padding: EdgeInsets.all(4.w),
          child: Text(
            'No data available',
            style: TextStyle(color: AppTheme.textMutedLight, fontSize: 14.0),
          ),
        ),
      );
    }

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: AppTheme.surfaceLight,
        borderRadius: BorderRadius.circular(10.0),
        border: Border.all(color: const Color(0xFFEAE4DC)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 18.h,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: bars.map((bar) {
                final ratio = maxVal > 0 ? bar.value / maxVal : 0.0;
                return Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 3),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          isPercent
                              ? '${(bar.value * 100).toStringAsFixed(0)}%'
                              : CurrencyFormatter.formatCompact(bar.value),
                          style: TextStyle(
                            fontSize: 10.0,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.deepTeal,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 2),
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 600),
                          curve: Curves.easeOutCubic,
                          height: (ratio * 14.h).clamp(2.0, 14.h),
                          decoration: BoxDecoration(
                            color: bar.color ?? AppTheme.deepTeal,
                            borderRadius: const BorderRadius.vertical(
                              top: Radius.circular(4),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 6),
          Row(
            children: bars.map((bar) {
              return Expanded(
                child: Text(
                  bar.label,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 10.0,
                    color: AppTheme.textSecondaryLight,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

class _BarData {
  final String label;
  final double value;
  final Color? color;
  const _BarData(this.label, this.value, {this.color});
}

class _HorizontalBar extends StatelessWidget {
  final String label;
  final double value;
  final double maxValue;
  final String displayValue;
  final Color color;

  const _HorizontalBar({
    required this.label,
    required this.value,
    required this.maxValue,
    required this.displayValue,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final ratio = maxValue > 0 ? (value / maxValue).clamp(0.0, 1.0) : 0.0;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(
            width: 22.w,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 12.0,
                color: AppTheme.textSecondaryLight,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(4.0),
              child: LinearProgressIndicator(
                value: ratio,
                backgroundColor: const Color(0xFFEAE4DC),
                valueColor: AlwaysStoppedAnimation<Color>(color),
                minHeight: 8,
              ),
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 18.w,
            child: Text(
              displayValue,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontSize: 12.0,
                fontWeight: FontWeight.w600,
                color: AppTheme.textPrimaryLight,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}

// ── Tab: Occupancy ─────────────────────────────────────────────────────────

class _OccupancyTab extends StatelessWidget {
  final List<DateTime> months;
  final Map<String, double> monthlyOccupancy;
  final Map<String, int> monthlyBookings;
  final Map<String, int> bookingsByStatus;
  final String Function(DateTime) shortMonth;
  final String Function(DateTime) monthKey;

  const _OccupancyTab({
    required this.months,
    required this.monthlyOccupancy,
    required this.monthlyBookings,
    required this.bookingsByStatus,
    required this.shortMonth,
    required this.monthKey,
  });

  @override
  Widget build(BuildContext context) {
    final currentKey = monthKey(months.last);
    final currentOcc = monthlyOccupancy[currentKey] ?? 0;
    final avgOcc = months.isEmpty
        ? 0.0
        : months
                  .map((m) => monthlyOccupancy[monthKey(m)] ?? 0.0)
                  .reduce((a, b) => a + b) /
              months.length;
    final totalBookings = monthlyBookings.values.fold(0, (s, v) => s + v);

    return ListView(
      padding: EdgeInsets.only(bottom: 3.h),
      children: [
        _SectionHeader(
          title: 'Occupancy Overview',
          icon: Icons.grid_view_rounded,
        ),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w),
          child: Row(
            children: [
              Expanded(
                child: _KpiCard(
                  label: 'This Month',
                  value: '${(currentOcc * 100).toStringAsFixed(1)}%',
                  subtitle: 'Occupancy rate',
                  valueColor: AppTheme.deepTeal,
                  icon: Icons.hotel_rounded,
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: _KpiCard(
                  label: '6-Month Avg',
                  value: '${(avgOcc * 100).toStringAsFixed(1)}%',
                  subtitle: 'Avg occupancy',
                  icon: Icons.trending_up_rounded,
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: _KpiCard(
                  label: 'Total Bookings',
                  value: '$totalBookings',
                  subtitle: 'Last 6 months',
                  icon: Icons.bed_rounded,
                ),
              ),
            ],
          ),
        ),
        _SectionHeader(
          title: 'Occupancy Rate Trend',
          icon: Icons.show_chart_rounded,
        ),
        _BarChart(
          isPercent: true,
          bars: months
              .map(
                (m) => _BarData(
                  shortMonth(m),
                  monthlyOccupancy[monthKey(m)] ?? 0,
                  color: AppTheme.deepTeal,
                ),
              )
              .toList(),
        ),
        _SectionHeader(
          title: 'Bookings per Month',
          icon: Icons.calendar_month_rounded,
        ),
        _BarChart(
          bars: months
              .map(
                (m) => _BarData(
                  shortMonth(m),
                  (monthlyBookings[monthKey(m)] ?? 0).toDouble(),
                  color: AppTheme.brassAccent,
                ),
              )
              .toList(),
        ),
        _SectionHeader(
          title: 'Booking Status Breakdown',
          icon: Icons.donut_small_rounded,
        ),
        if (bookingsByStatus.isEmpty)
          Padding(
            padding: EdgeInsets.all(4.w),
            child: Text(
              'No booking data',
              style: TextStyle(color: AppTheme.textMutedLight),
            ),
          )
        else
          Container(
            margin: EdgeInsets.symmetric(horizontal: 4.w),
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: AppTheme.surfaceLight,
              borderRadius: BorderRadius.circular(10.0),
              border: Border.all(color: const Color(0xFFEAE4DC)),
            ),
            child: Column(
              children: bookingsByStatus.entries.map((e) {
                final total = bookingsByStatus.values.fold(0, (s, v) => s + v);
                final pct = total > 0 ? e.value / total * 100 : 0;
                final colors = {
                  'Checked-in': AppTheme.successGreen,
                  'Checked-out': AppTheme.deepTeal,
                  'Booked': AppTheme.brassAccent,
                  'Cancelled': AppTheme.alertRed,
                  'No-show': AppTheme.textMutedLight,
                };
                return _HorizontalBar(
                  label: e.key,
                  value: e.value.toDouble(),
                  maxValue: bookingsByStatus.values
                      .reduce((a, b) => a > b ? a : b)
                      .toDouble(),
                  displayValue: '${e.value} (${pct.toStringAsFixed(0)}%)',
                  color: colors[e.key] ?? AppTheme.deepTeal,
                );
              }).toList(),
            ),
          ),
      ],
    );
  }
}

// ── Tab: Revenue ───────────────────────────────────────────────────────────

class _RevenueTab extends StatelessWidget {
  final List<DateTime> months;
  final Map<String, double> monthlyRevenue;
  final Map<String, double> monthlyPayments;
  final Map<String, Map<String, double>> roomRevenue;
  final String Function(DateTime) shortMonth;
  final String Function(DateTime) monthKey;

  const _RevenueTab({
    required this.months,
    required this.monthlyRevenue,
    required this.monthlyPayments,
    required this.roomRevenue,
    required this.shortMonth,
    required this.monthKey,
  });

  @override
  Widget build(BuildContext context) {
    final totalRevenue = monthlyRevenue.values.fold(0.0, (s, v) => s + v);
    final totalReceived = monthlyPayments.values.fold(0.0, (s, v) => s + v);
    final currentKey = monthKey(months.last);

    // Aggregate room revenue across all months
    final Map<String, double> totalRoomRevenue = {};
    for (final m in months) {
      final rr = roomRevenue[monthKey(m)] ?? {};
      for (final entry in rr.entries) {
        totalRoomRevenue[entry.key] =
            (totalRoomRevenue[entry.key] ?? 0) + entry.value;
      }
    }
    final maxRoomRev = totalRoomRevenue.isEmpty
        ? 1.0
        : totalRoomRevenue.values.reduce((a, b) => a > b ? a : b);

    return ListView(
      padding: EdgeInsets.only(bottom: 3.h),
      children: [
        _SectionHeader(
          title: 'Revenue Overview',
          icon: Icons.currency_rupee_rounded,
        ),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w),
          child: Row(
            children: [
              Expanded(
                child: _KpiCard(
                  label: 'Total Revenue',
                  value: CurrencyFormatter.formatCompact(totalRevenue),
                  subtitle: 'Last 6 months',
                  valueColor: AppTheme.deepTeal,
                  icon: Icons.trending_up_rounded,
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: _KpiCard(
                  label: 'Cash Received',
                  value: CurrencyFormatter.formatCompact(totalReceived),
                  subtitle: 'Actual payments',
                  icon: Icons.payments_rounded,
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: _KpiCard(
                  label: 'This Month',
                  value: CurrencyFormatter.formatCompact(
                    monthlyRevenue[currentKey] ?? 0,
                  ),
                  subtitle: 'Room revenue',
                  icon: Icons.hotel_rounded,
                ),
              ),
            ],
          ),
        ),
        _SectionHeader(
          title: 'Monthly Revenue vs Received',
          icon: Icons.bar_chart_rounded,
        ),
        Container(
          margin: EdgeInsets.symmetric(horizontal: 4.w),
          padding: EdgeInsets.all(3.w),
          decoration: BoxDecoration(
            color: AppTheme.surfaceLight,
            borderRadius: BorderRadius.circular(10.0),
            border: Border.all(color: const Color(0xFFEAE4DC)),
          ),
          child: Column(
            children: [
              Row(
                children: [
                  _LegendDot(color: AppTheme.deepTeal, label: 'Room Revenue'),
                  SizedBox(width: 3.w),
                  _LegendDot(
                    color: AppTheme.brassAccent,
                    label: 'Cash Received',
                  ),
                ],
              ),
              SizedBox(height: 1.h),
              SizedBox(
                height: 18.h,
                child: _DualBarChart(
                  months: months,
                  series1: monthlyRevenue,
                  series2: monthlyPayments,
                  color1: AppTheme.deepTeal,
                  color2: AppTheme.brassAccent,
                  shortMonth: shortMonth,
                  monthKey: monthKey,
                ),
              ),
            ],
          ),
        ),
        _SectionHeader(
          title: 'Revenue by Room (6 Months)',
          icon: Icons.meeting_room_rounded,
        ),
        if (totalRoomRevenue.isEmpty)
          Padding(
            padding: EdgeInsets.all(4.w),
            child: Text(
              'No room revenue data',
              style: TextStyle(color: AppTheme.textMutedLight),
            ),
          )
        else
          Container(
            margin: EdgeInsets.symmetric(horizontal: 4.w),
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: AppTheme.surfaceLight,
              borderRadius: BorderRadius.circular(10.0),
              border: Border.all(color: const Color(0xFFEAE4DC)),
            ),
            child: Column(
              children:
                  (totalRoomRevenue.entries.toList()
                        ..sort((a, b) => b.value.compareTo(a.value)))
                      .map(
                        (e) => _HorizontalBar(
                          label: e.key,
                          value: e.value,
                          maxValue: maxRoomRev,
                          displayValue: CurrencyFormatter.formatCompact(
                            e.value,
                          ),
                          color: AppTheme.deepTeal,
                        ),
                      )
                      .toList(),
            ),
          ),
        _SectionHeader(
          title: 'Monthly Revenue Breakdown',
          icon: Icons.table_chart_rounded,
        ),
        Container(
          margin: EdgeInsets.symmetric(horizontal: 4.w),
          decoration: BoxDecoration(
            color: AppTheme.surfaceLight,
            borderRadius: BorderRadius.circular(10.0),
            border: Border.all(color: const Color(0xFFEAE4DC)),
          ),
          child: Column(
            children: [
              _TableHeader(),
              ...months.map((m) {
                final k = monthKey(m);
                final rev = monthlyRevenue[k] ?? 0;
                final rcv = monthlyPayments[k] ?? 0;
                final outstanding = rev - rcv;
                return _TableRow(
                  month: '${shortMonth(m)} ${m.year}',
                  revenue: CurrencyFormatter.format(rev),
                  received: CurrencyFormatter.format(rcv),
                  outstanding: CurrencyFormatter.format(
                    outstanding,
                    showSign: false,
                  ),
                  outstandingColor: outstanding > 0
                      ? AppTheme.alertRed
                      : AppTheme.successGreen,
                );
              }),
            ],
          ),
        ),
        SizedBox(height: 2.h),
      ],
    );
  }
}

class _LegendDot extends StatelessWidget {
  final Color color;
  final String label;
  const _LegendDot({required this.color, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 4),
        Text(
          label,
          style: TextStyle(fontSize: 12.0, color: AppTheme.textSecondaryLight),
        ),
      ],
    );
  }
}

class _DualBarChart extends StatelessWidget {
  final List<DateTime> months;
  final Map<String, double> series1;
  final Map<String, double> series2;
  final Color color1;
  final Color color2;
  final String Function(DateTime) shortMonth;
  final String Function(DateTime) monthKey;

  const _DualBarChart({
    required this.months,
    required this.series1,
    required this.series2,
    required this.color1,
    required this.color2,
    required this.shortMonth,
    required this.monthKey,
  });

  @override
  Widget build(BuildContext context) {
    double maxVal = 1;
    for (final m in months) {
      final k = monthKey(m);
      final v1 = series1[k] ?? 0;
      final v2 = series2[k] ?? 0;
      if (v1 > maxVal) maxVal = v1;
      if (v2 > maxVal) maxVal = v2;
    }

    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: months.map((m) {
        final k = monthKey(m);
        final v1 = series1[k] ?? 0;
        final v2 = series2[k] ?? 0;
        return Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _SingleBar(
                    value: v1,
                    maxValue: maxVal,
                    color: color1,
                    maxHeight: 14.h,
                  ),
                  const SizedBox(width: 2),
                  _SingleBar(
                    value: v2,
                    maxValue: maxVal,
                    color: color2,
                    maxHeight: 14.h,
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                shortMonth(m),
                style: TextStyle(
                  fontSize: 10.0,
                  color: AppTheme.textSecondaryLight,
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }
}

class _SingleBar extends StatelessWidget {
  final double value;
  final double maxValue;
  final Color color;
  final double maxHeight;

  const _SingleBar({
    required this.value,
    required this.maxValue,
    required this.color,
    required this.maxHeight,
  });

  @override
  Widget build(BuildContext context) {
    final ratio = maxValue > 0 ? (value / maxValue).clamp(0.0, 1.0) : 0.0;
    return Container(
      width: 6,
      height: (ratio * maxHeight).clamp(2.0, maxHeight),
      decoration: BoxDecoration(
        color: color,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(3)),
      ),
    );
  }
}

class _TableHeader extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
      decoration: const BoxDecoration(
        color: Color(0xFFF0EEE9),
        borderRadius: BorderRadius.vertical(top: Radius.circular(10)),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Text(
              'Month',
              style: TextStyle(
                fontSize: 12.0,
                fontWeight: FontWeight.w600,
                color: AppTheme.textSecondaryLight,
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: Text(
              'Revenue',
              textAlign: TextAlign.right,
              style: TextStyle(
                fontSize: 12.0,
                fontWeight: FontWeight.w600,
                color: AppTheme.textSecondaryLight,
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: Text(
              'Received',
              textAlign: TextAlign.right,
              style: TextStyle(
                fontSize: 12.0,
                fontWeight: FontWeight.w600,
                color: AppTheme.textSecondaryLight,
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: Text(
              'Outstanding',
              textAlign: TextAlign.right,
              style: TextStyle(
                fontSize: 12.0,
                fontWeight: FontWeight.w600,
                color: AppTheme.textSecondaryLight,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TableRow extends StatelessWidget {
  final String month;
  final String revenue;
  final String received;
  final String outstanding;
  final Color outstandingColor;

  const _TableRow({
    required this.month,
    required this.revenue,
    required this.received,
    required this.outstanding,
    required this.outstandingColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.8.h),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Color(0xFFEAE4DC))),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Text(
              month,
              style: TextStyle(
                fontSize: 12.0,
                color: AppTheme.textPrimaryLight,
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: Text(
              revenue,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontSize: 12.0,
                fontWeight: FontWeight.w600,
                color: AppTheme.deepTeal,
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: Text(
              received,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontSize: 12.0,
                color: AppTheme.textPrimaryLight,
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: Text(
              outstanding,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontSize: 12.0,
                fontWeight: FontWeight.w600,
                color: outstandingColor,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Tab: Guests ────────────────────────────────────────────────────────────

class _GuestTab extends StatelessWidget {
  final List<DateTime> months;
  final Map<String, int> guestsByMonth;
  final Map<String, int> paymentModeCount;
  final Map<String, double> paymentModeAmount;
  final String Function(DateTime) shortMonth;
  final String Function(DateTime) monthKey;

  const _GuestTab({
    required this.months,
    required this.guestsByMonth,
    required this.paymentModeCount,
    required this.paymentModeAmount,
    required this.shortMonth,
    required this.monthKey,
  });

  @override
  Widget build(BuildContext context) {
    final totalGuests = guestsByMonth.values.fold(0, (s, v) => s + v);
    final avgGuests = months.isEmpty ? 0.0 : totalGuests / months.length;
    final maxModeAmount = paymentModeAmount.isEmpty
        ? 1.0
        : paymentModeAmount.values.reduce((a, b) => a > b ? a : b);

    return ListView(
      padding: EdgeInsets.only(bottom: 3.h),
      children: [
        _SectionHeader(title: 'Guest Overview', icon: Icons.people_rounded),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w),
          child: Row(
            children: [
              Expanded(
                child: _KpiCard(
                  label: 'Total Guests',
                  value: '$totalGuests',
                  subtitle: 'Last 6 months',
                  valueColor: AppTheme.deepTeal,
                  icon: Icons.person_rounded,
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: _KpiCard(
                  label: 'Avg / Month',
                  value: avgGuests.toStringAsFixed(1),
                  subtitle: 'Guest arrivals',
                  icon: Icons.trending_up_rounded,
                ),
              ),
            ],
          ),
        ),
        _SectionHeader(
          title: 'Guest Arrivals by Month',
          icon: Icons.person_add_rounded,
        ),
        _BarChart(
          bars: months
              .map(
                (m) => _BarData(
                  shortMonth(m),
                  (guestsByMonth[monthKey(m)] ?? 0).toDouble(),
                  color: AppTheme.brassAccent,
                ),
              )
              .toList(),
        ),
        _SectionHeader(
          title: 'Payment Mode Preference',
          icon: Icons.payment_rounded,
        ),
        if (paymentModeAmount.isEmpty)
          Padding(
            padding: EdgeInsets.all(4.w),
            child: Text(
              'No payment data',
              style: TextStyle(color: AppTheme.textMutedLight),
            ),
          )
        else
          Container(
            margin: EdgeInsets.symmetric(horizontal: 4.w),
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: AppTheme.surfaceLight,
              borderRadius: BorderRadius.circular(10.0),
              border: Border.all(color: const Color(0xFFEAE4DC)),
            ),
            child: Column(
              children:
                  (paymentModeAmount.entries.toList()
                        ..sort((a, b) => b.value.compareTo(a.value)))
                      .map(
                        (e) => _HorizontalBar(
                          label: e.key,
                          value: e.value,
                          maxValue: maxModeAmount,
                          displayValue: CurrencyFormatter.formatCompact(
                            e.value,
                          ),
                          color: AppTheme.deepTeal,
                        ),
                      )
                      .toList(),
            ),
          ),
        _SectionHeader(
          title: 'Payment Mode Count',
          icon: Icons.bar_chart_rounded,
        ),
        _BarChart(
          bars:
              (paymentModeCount.entries.toList()
                    ..sort((a, b) => b.value.compareTo(a.value)))
                  .map(
                    (e) => _BarData(
                      e.key,
                      e.value.toDouble(),
                      color: AppTheme.deepTeal,
                    ),
                  )
                  .toList(),
        ),
      ],
    );
  }
}

// ── Tab: Expenses ──────────────────────────────────────────────────────────

class _ExpenseTab extends StatelessWidget {
  final List<DateTime> months;
  final Map<String, double> monthlyDailyExpenses;
  final Map<String, double> expenseByHead;
  final List<MonthlyExpense> monthlyRecurring;
  final List<YearlyExpense> yearlyRecurring;
  final String Function(DateTime) shortMonth;
  final String Function(DateTime) monthKey;

  const _ExpenseTab({
    required this.months,
    required this.monthlyDailyExpenses,
    required this.expenseByHead,
    required this.monthlyRecurring,
    required this.yearlyRecurring,
    required this.shortMonth,
    required this.monthKey,
  });

  @override
  Widget build(BuildContext context) {
    final totalVariable = monthlyDailyExpenses.values.fold(
      0.0,
      (s, v) => s + v,
    );
    final totalMonthlyFixed = monthlyRecurring.fold(
      0.0,
      (s, e) => s + e.amount,
    );
    final totalYearly = yearlyRecurring.fold(0.0, (s, e) => s + e.amount);
    final estMonthlyRunning =
        (totalVariable / (months.isEmpty ? 1 : months.length)) +
        totalMonthlyFixed +
        (totalYearly / 12);

    final sortedHeads = expenseByHead.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final topHeads = sortedHeads.take(10).toList();
    final maxHead = topHeads.isEmpty ? 1.0 : topHeads.first.value;

    return ListView(
      padding: EdgeInsets.only(bottom: 3.h),
      children: [
        _SectionHeader(
          title: 'Expense Overview',
          icon: Icons.receipt_long_rounded,
        ),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w),
          child: Row(
            children: [
              Expanded(
                child: _KpiCard(
                  label: 'Variable (6m)',
                  value: CurrencyFormatter.formatCompact(totalVariable),
                  subtitle: 'Daily expenses',
                  valueColor: AppTheme.alertRed,
                  icon: Icons.receipt_rounded,
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: _KpiCard(
                  label: 'Monthly Fixed',
                  value: CurrencyFormatter.formatCompact(totalMonthlyFixed),
                  subtitle: 'Per month',
                  icon: Icons.repeat_rounded,
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: _KpiCard(
                  label: 'Est. Monthly',
                  value: CurrencyFormatter.formatCompact(estMonthlyRunning),
                  subtitle: 'Running cost',
                  icon: Icons.calculate_rounded,
                ),
              ),
            ],
          ),
        ),
        _SectionHeader(
          title: 'Variable Expenses by Month',
          icon: Icons.show_chart_rounded,
        ),
        _BarChart(
          bars: months
              .map(
                (m) => _BarData(
                  shortMonth(m),
                  monthlyDailyExpenses[monthKey(m)] ?? 0,
                  color: AppTheme.alertRed,
                ),
              )
              .toList(),
        ),
        _SectionHeader(
          title: 'Top Expense Heads (6 Months)',
          icon: Icons.category_rounded,
        ),
        if (topHeads.isEmpty)
          Padding(
            padding: EdgeInsets.all(4.w),
            child: Text(
              'No expense data',
              style: TextStyle(color: AppTheme.textMutedLight),
            ),
          )
        else
          Container(
            margin: EdgeInsets.symmetric(horizontal: 4.w),
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: AppTheme.surfaceLight,
              borderRadius: BorderRadius.circular(10.0),
              border: Border.all(color: const Color(0xFFEAE4DC)),
            ),
            child: Column(
              children: topHeads
                  .map(
                    (e) => _HorizontalBar(
                      label: e.key,
                      value: e.value,
                      maxValue: maxHead,
                      displayValue: CurrencyFormatter.formatCompact(e.value),
                      color: AppTheme.alertRed,
                    ),
                  )
                  .toList(),
            ),
          ),
        _SectionHeader(
          title: 'Monthly Recurring Expenses',
          icon: Icons.autorenew_rounded,
        ),
        if (monthlyRecurring.isEmpty)
          Padding(
            padding: EdgeInsets.all(4.w),
            child: Text(
              'No monthly recurring expenses',
              style: TextStyle(color: AppTheme.textMutedLight),
            ),
          )
        else
          Container(
            margin: EdgeInsets.symmetric(horizontal: 4.w),
            decoration: BoxDecoration(
              color: AppTheme.surfaceLight,
              borderRadius: BorderRadius.circular(10.0),
              border: Border.all(color: const Color(0xFFEAE4DC)),
            ),
            child: Column(
              children: monthlyRecurring
                  .map(
                    (e) => ListTile(
                      dense: true,
                      title: Text(
                        e.head,
                        style: TextStyle(
                          fontSize: 14.0,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      subtitle: e.payee.isNotEmpty
                          ? Text(
                              e.payee,
                              style: TextStyle(
                                fontSize: 12.0,
                                color: AppTheme.textMutedLight,
                              ),
                            )
                          : null,
                      trailing: Text(
                        CurrencyFormatter.format(e.amount),
                        style: TextStyle(
                          fontSize: 14.0,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.deepTeal,
                        ),
                      ),
                    ),
                  )
                  .toList(),
            ),
          ),
        _SectionHeader(
          title: 'Yearly Recurring Expenses',
          icon: Icons.event_repeat_rounded,
        ),
        if (yearlyRecurring.isEmpty)
          Padding(
            padding: EdgeInsets.all(4.w),
            child: Text(
              'No yearly recurring expenses',
              style: TextStyle(color: AppTheme.textMutedLight),
            ),
          )
        else
          Container(
            margin: EdgeInsets.symmetric(horizontal: 4.w),
            decoration: BoxDecoration(
              color: AppTheme.surfaceLight,
              borderRadius: BorderRadius.circular(10.0),
              border: Border.all(color: const Color(0xFFEAE4DC)),
            ),
            child: Column(
              children: yearlyRecurring
                  .map(
                    (e) => ListTile(
                      dense: true,
                      title: Text(
                        e.head,
                        style: TextStyle(
                          fontSize: 14.0,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      subtitle: Text(
                        'Due: ${e.dueMonth}  •  Monthly equiv: ${CurrencyFormatter.formatCompact(e.amount / 12)}',
                        style: TextStyle(
                          fontSize: 12.0,
                          color: AppTheme.textMutedLight,
                        ),
                      ),
                      trailing: Text(
                        CurrencyFormatter.format(e.amount),
                        style: TextStyle(
                          fontSize: 14.0,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.brassAccent,
                        ),
                      ),
                    ),
                  )
                  .toList(),
            ),
          ),
        SizedBox(height: 2.h),
      ],
    );
  }
}

// ── Tab: ROI & Staff ───────────────────────────────────────────────────────

class _RoiStaffTab extends StatelessWidget {
  final List<DateTime> months;
  final Map<String, double> monthlyRevenue;
  final Map<String, double> monthlyDailyExpenses;
  final double monthlyRecurringTotal;
  final double yearlyRecurringMonthly;
  final double totalRevenue6m;
  final double totalExpenses6m;
  final Map<String, double> expenseByStaff;
  final Map<String, double> paymentsCollectedBy;
  final String Function(DateTime) shortMonth;
  final String Function(DateTime) monthKey;

  const _RoiStaffTab({
    required this.months,
    required this.monthlyRevenue,
    required this.monthlyDailyExpenses,
    required this.monthlyRecurringTotal,
    required this.yearlyRecurringMonthly,
    required this.totalRevenue6m,
    required this.totalExpenses6m,
    required this.expenseByStaff,
    required this.paymentsCollectedBy,
    required this.shortMonth,
    required this.monthKey,
  });

  @override
  Widget build(BuildContext context) {
    final totalFixed6m = (monthlyRecurringTotal + yearlyRecurringMonthly) * 6;
    final totalCost6m = totalExpenses6m + totalFixed6m;
    final netProfit6m = totalRevenue6m - totalCost6m;
    final roi = totalCost6m > 0 ? (netProfit6m / totalCost6m * 100) : 0.0;
    final margin = totalRevenue6m > 0
        ? (netProfit6m / totalRevenue6m * 100)
        : 0.0;

    final maxPayments = paymentsCollectedBy.isEmpty
        ? 1.0
        : paymentsCollectedBy.values.reduce((a, b) => a > b ? a : b);
    final maxExpStaff = expenseByStaff.isEmpty
        ? 1.0
        : expenseByStaff.values.reduce((a, b) => a > b ? a : b);

    return ListView(
      padding: EdgeInsets.only(bottom: 3.h),
      children: [
        _SectionHeader(
          title: 'ROI Calculation (6 Months)',
          icon: Icons.analytics_rounded,
        ),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: _KpiCard(
                      label: 'Total Revenue',
                      value: CurrencyFormatter.formatCompact(totalRevenue6m),
                      subtitle: '6-month accrual',
                      valueColor: AppTheme.successGreen,
                      icon: Icons.trending_up_rounded,
                    ),
                  ),
                  SizedBox(width: 2.w),
                  Expanded(
                    child: _KpiCard(
                      label: 'Total Cost',
                      value: CurrencyFormatter.formatCompact(totalCost6m),
                      subtitle: 'Variable + fixed',
                      valueColor: AppTheme.alertRed,
                      icon: Icons.money_off_rounded,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 1.5.h),
              Row(
                children: [
                  Expanded(
                    child: _KpiCard(
                      label: 'Net Profit',
                      value: CurrencyFormatter.formatCompact(netProfit6m),
                      subtitle: 'Revenue − Cost',
                      valueColor: netProfit6m >= 0
                          ? AppTheme.successGreen
                          : AppTheme.alertRed,
                      icon: Icons.account_balance_rounded,
                    ),
                  ),
                  SizedBox(width: 2.w),
                  Expanded(
                    child: _KpiCard(
                      label: 'ROI',
                      value: '${roi.toStringAsFixed(1)}%',
                      subtitle: 'Return on investment',
                      valueColor: roi >= 0
                          ? AppTheme.successGreen
                          : AppTheme.alertRed,
                      icon: Icons.percent_rounded,
                    ),
                  ),
                  SizedBox(width: 2.w),
                  Expanded(
                    child: _KpiCard(
                      label: 'Margin',
                      value: '${margin.toStringAsFixed(1)}%',
                      subtitle: 'Profit margin',
                      valueColor: margin >= 0
                          ? AppTheme.successGreen
                          : AppTheme.alertRed,
                      icon: Icons.pie_chart_rounded,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        _SectionHeader(
          title: 'Monthly Net Profit Trend',
          icon: Icons.show_chart_rounded,
        ),
        _BarChart(
          bars: months.map((m) {
            final k = monthKey(m);
            final rev = monthlyRevenue[k] ?? 0;
            final varExp = monthlyDailyExpenses[k] ?? 0;
            final fixedExp = monthlyRecurringTotal + yearlyRecurringMonthly;
            final net = rev - varExp - fixedExp;
            return _BarData(
              shortMonth(m),
              net.abs(),
              color: net >= 0 ? AppTheme.successGreen : AppTheme.alertRed,
            );
          }).toList(),
        ),
        Container(
          margin: EdgeInsets.symmetric(horizontal: 4.w),
          padding: EdgeInsets.all(3.w),
          decoration: BoxDecoration(
            color: const Color(0xFFF0EEE9),
            borderRadius: BorderRadius.circular(10.0),
            border: Border.all(color: const Color(0xFFEAE4DC)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Cost Breakdown',
                style: TextStyle(
                  fontSize: 14.0,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textPrimaryLight,
                ),
              ),
              SizedBox(height: 1.h),
              _CostRow(
                label: 'Variable Expenses',
                value: CurrencyFormatter.format(totalExpenses6m),
                color: AppTheme.alertRed,
              ),
              _CostRow(
                label: 'Monthly Recurring × 6',
                value: CurrencyFormatter.format(monthlyRecurringTotal * 6),
                color: AppTheme.brassAccent,
              ),
              _CostRow(
                label: 'Yearly Amortised × 6',
                value: CurrencyFormatter.format(yearlyRecurringMonthly * 6),
                color: AppTheme.warningAmber,
              ),
              const Divider(color: Color(0xFFDCE4E0)),
              _CostRow(
                label: 'Total Cost',
                value: CurrencyFormatter.format(totalCost6m),
                color: AppTheme.textPrimaryLight,
                bold: true,
              ),
            ],
          ),
        ),
        _SectionHeader(
          title: 'Staff — Payments Collected',
          icon: Icons.person_rounded,
        ),
        if (paymentsCollectedBy.isEmpty)
          Padding(
            padding: EdgeInsets.all(4.w),
            child: Text(
              'No staff payment data (fill "Received By" in payments)',
              style: TextStyle(color: AppTheme.textMutedLight),
            ),
          )
        else
          Container(
            margin: EdgeInsets.symmetric(horizontal: 4.w),
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: AppTheme.surfaceLight,
              borderRadius: BorderRadius.circular(10.0),
              border: Border.all(color: const Color(0xFFEAE4DC)),
            ),
            child: Column(
              children:
                  (paymentsCollectedBy.entries.toList()
                        ..sort((a, b) => b.value.compareTo(a.value)))
                      .map(
                        (e) => _HorizontalBar(
                          label: e.key,
                          value: e.value,
                          maxValue: maxPayments,
                          displayValue: CurrencyFormatter.formatCompact(
                            e.value,
                          ),
                          color: AppTheme.successGreen,
                        ),
                      )
                      .toList(),
            ),
          ),
        _SectionHeader(
          title: 'Staff — Expenses Managed',
          icon: Icons.manage_accounts_rounded,
        ),
        if (expenseByStaff.isEmpty)
          Padding(
            padding: EdgeInsets.all(4.w),
            child: Text(
              'No staff expense data (fill "Paid By" in daily expenses)',
              style: TextStyle(color: AppTheme.textMutedLight),
            ),
          )
        else
          Container(
            margin: EdgeInsets.symmetric(horizontal: 4.w),
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: AppTheme.surfaceLight,
              borderRadius: BorderRadius.circular(10.0),
              border: Border.all(color: const Color(0xFFEAE4DC)),
            ),
            child: Column(
              children:
                  (expenseByStaff.entries.toList()
                        ..sort((a, b) => b.value.compareTo(a.value)))
                      .map(
                        (e) => _HorizontalBar(
                          label: e.key,
                          value: e.value,
                          maxValue: maxExpStaff,
                          displayValue: CurrencyFormatter.formatCompact(
                            e.value,
                          ),
                          color: AppTheme.brassAccent,
                        ),
                      )
                      .toList(),
            ),
          ),
        SizedBox(height: 2.h),
      ],
    );
  }
}

class _CostRow extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  final bool bold;

  const _CostRow({
    required this.label,
    required this.value,
    required this.color,
    this.bold = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 13.0,
                color: AppTheme.textSecondaryLight,
                fontWeight: bold ? FontWeight.w700 : FontWeight.w400,
              ),
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 13.0,
              fontWeight: bold ? FontWeight.w700 : FontWeight.w600,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
