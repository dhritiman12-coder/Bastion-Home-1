import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../services/cloud_sync_service.dart';
import '../../widgets/app_back_button.dart';
import '../cloud_sync_screen/cloud_sync_screen.dart';

class WebsiteBookingScreen extends StatefulWidget {
  const WebsiteBookingScreen({super.key});

  @override
  State<WebsiteBookingScreen> createState() => _WebsiteBookingScreenState();
}

class _WebsiteBookingScreenState extends State<WebsiteBookingScreen> {
  final CloudSyncService _sync = CloudSyncService();
  final TextEditingController _origin = TextEditingController();
  bool _loading = true;
  bool _busy = false;
  bool _enabled = true;
  bool _hasChannel = false;
  String? _newKey;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _origin.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    if (!_sync.isConnected || !_sync.isCloudAdmin) {
      if (mounted) setState(() => _loading = false);
      return;
    }
    try {
      final channel = await _sync.getWebsiteBookingChannel();
      if (!mounted) return;
      setState(() {
        _hasChannel = channel != null;
        _enabled = channel?['enabled'] as bool? ?? true;
        _origin.text = channel?['allowed_origin'] as String? ?? '';
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = _cleanError(error);
        _loading = false;
      });
    }
  }

  String _cleanError(Object error) => error
      .toString()
      .replaceFirst('PostgrestException(message: ', '')
      .replaceFirst('Bad state: ', '');

  Future<void> _createKey() async {
    final origin = _origin.text.trim();
    if (origin.isNotEmpty) {
      final uri = Uri.tryParse(origin);
      final local = uri?.host == 'localhost' || uri?.host == '127.0.0.1';
      if (uri == null ||
          (!uri.hasScheme || (uri.scheme != 'https' && !local))) {
        setState(
          () =>
              _error = 'Enter a secure website address beginning with https://',
        );
        return;
      }
    }
    if (_hasChannel) {
      final accepted = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Replace website key?'),
          content: const Text(
            'The current website connection will stop until the new key is added to your website.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Replace Key'),
            ),
          ],
        ),
      );
      if (accepted != true) return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final key = await _sync.createWebsiteBookingChannel(
        allowedOrigin: origin,
      );
      if (!mounted) return;
      setState(() {
        _newKey = key;
        _hasChannel = true;
        _enabled = true;
      });
    } catch (error) {
      if (mounted) setState(() => _error = _cleanError(error));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _updateChannel({bool? enabled}) async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await _sync.updateWebsiteBookingChannel(
        enabled: enabled ?? _enabled,
        allowedOrigin: _origin.text,
      );
      if (!mounted) return;
      setState(() => _enabled = enabled ?? _enabled);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Website booking settings saved')),
      );
    } catch (error) {
      if (mounted) setState(() => _error = _cleanError(error));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _copy(String value, String label) async {
    await Clipboard.setData(ClipboardData(text: value));
    if (!mounted) return;
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text('$label copied')));
  }

  @override
  Widget build(BuildContext context) {
    final endpoint = _sync.websiteBookingEndpoint;
    return Scaffold(
      appBar: AppBar(
        leading: const AppBackButton(),
        title: const Text('Website Bookings'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
              children: [
                if (!_sync.isConnected || !_sync.isCloudAdmin) ...[
                  const _InfoPanel(
                    icon: Icons.cloud_off_outlined,
                    title: 'Cloud Sync is required',
                    message:
                        'Connect an administrator cloud account before linking your website.',
                  ),
                  const SizedBox(height: 16),
                  FilledButton.icon(
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const CloudSyncScreen(),
                      ),
                    ),
                    icon: const Icon(Icons.cloud_sync_outlined),
                    label: const Text('Open Cloud Sync'),
                  ),
                ] else ...[
                  const _InfoPanel(
                    icon: Icons.event_available_outlined,
                    title: 'One shared room calendar',
                    message:
                        'Online reservations appear in the app automatically. Room availability is checked again when the website confirms a booking.',
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: _origin,
                    enabled: !_busy,
                    keyboardType: TextInputType.url,
                    decoration: const InputDecoration(
                      labelText: 'Website address',
                      hintText: 'https://www.example.com',
                      helperText: 'Only this website may send booking requests',
                    ),
                  ),
                  const SizedBox(height: 16),
                  if (_hasChannel)
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      value: _enabled,
                      onChanged: _busy
                          ? null
                          : (value) => _updateChannel(enabled: value),
                      title: const Text('Accept online bookings'),
                      subtitle: Text(
                        _enabled
                            ? 'Website booking is active'
                            : 'New website bookings are paused',
                      ),
                    ),
                  if (endpoint != null) ...[
                    const SizedBox(height: 8),
                    _CopyField(
                      label: 'Booking service address',
                      value: endpoint,
                      onCopy: () => _copy(endpoint, 'Service address'),
                    ),
                  ],
                  if (_newKey != null) ...[
                    const SizedBox(height: 12),
                    _CopyField(
                      label: 'Website key',
                      value: _newKey!,
                      onCopy: () => _copy(_newKey!, 'Website key'),
                    ),
                    const Padding(
                      padding: EdgeInsets.only(top: 8),
                      child: Text(
                        'This key is shown once. Add it to the website before leaving this page.',
                      ),
                    ),
                  ],
                  const SizedBox(height: 20),
                  FilledButton.icon(
                    onPressed: _busy ? null : _createKey,
                    icon: const Icon(Icons.key_outlined),
                    label: Text(
                      _hasChannel
                          ? 'Create New Website Key'
                          : 'Create Website Key',
                    ),
                  ),
                  if (_hasChannel) ...[
                    const SizedBox(height: 8),
                    OutlinedButton.icon(
                      onPressed: _busy ? null : () => _updateChannel(),
                      icon: const Icon(Icons.save_outlined),
                      label: const Text('Save Website Address'),
                    ),
                  ],
                ],
                if (_error != null) ...[
                  const SizedBox(height: 16),
                  Text(
                    _error!,
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.error,
                    ),
                  ),
                ],
              ],
            ),
    );
  }
}

class _InfoPanel extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;

  const _InfoPanel({
    required this.icon,
    required this.title,
    required this.message,
  });

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Theme.of(context).colorScheme.surfaceContainerHighest,
      borderRadius: BorderRadius.circular(8),
    ),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: Theme.of(context).colorScheme.secondary),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 4),
              Text(message),
            ],
          ),
        ),
      ],
    ),
  );
}

class _CopyField extends StatelessWidget {
  final String label;
  final String value;
  final VoidCallback onCopy;

  const _CopyField({
    required this.label,
    required this.value,
    required this.onCopy,
  });

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.fromLTRB(12, 10, 4, 10),
    decoration: BoxDecoration(
      border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
      borderRadius: BorderRadius.circular(8),
    ),
    child: Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: Theme.of(context).textTheme.labelMedium),
              const SizedBox(height: 4),
              SelectableText(value),
            ],
          ),
        ),
        IconButton(
          onPressed: onCopy,
          tooltip: 'Copy $label',
          icon: const Icon(Icons.copy_outlined),
        ),
      ],
    ),
  );
}
