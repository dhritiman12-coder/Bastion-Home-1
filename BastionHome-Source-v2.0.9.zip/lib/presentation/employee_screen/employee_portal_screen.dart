import 'package:flutter/material.dart';
import '../../widgets/app_back_button.dart';

import '../../database/repositories/expense_repository.dart';
import '../../models/app_user.dart';
import '../../presentation/analytics_screen/analytics_screen.dart';
import '../../presentation/bookings_screen/bookings_screen.dart';
import '../../presentation/bookings_screen/enhanced_booking_form_screen.dart';
import '../../presentation/expenses_screen/expenses_screen.dart';
import '../../presentation/guest_ids_screen/guest_ids_screen.dart';
import '../../presentation/inventory_screen/inventory_screen.dart';
import '../../presentation/occupancy_screen/occupancy_screen.dart';
import '../../presentation/payments_screen/payments_screen.dart';
import '../../presentation/cloud_sync_screen/cloud_sync_screen.dart';
import '../../services/account_service.dart';
import '../../services/cloud_sync_service.dart';
import '../../utils/currency_formatter.dart';
import '../../widgets/brand_logo.dart';

class EmployeePortalScreen extends StatefulWidget {
  const EmployeePortalScreen({super.key});

  @override
  State<EmployeePortalScreen> createState() => _EmployeePortalScreenState();
}

class _EmployeePortalScreenState extends State<EmployeePortalScreen> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final account = AccountService();
    final user = account.currentUser!;
    const hasMore = true;
    final pages = <Widget>[
      _NewBookingPage(user: user),
      const OccupancyScreen(employeeMode: true),
      _EmployeeExpensesPage(user: user),
      if (hasMore) _EmployeeMorePage(user: user),
    ];
    final destinations = <NavigationDestination>[
      const NavigationDestination(
        icon: Icon(Icons.add_box_outlined),
        selectedIcon: Icon(Icons.add_box),
        label: 'Booking',
      ),
      const NavigationDestination(
        icon: Icon(Icons.grid_view_outlined),
        selectedIcon: Icon(Icons.grid_view),
        label: 'Occupancy',
      ),
      const NavigationDestination(
        icon: Icon(Icons.receipt_long_outlined),
        selectedIcon: Icon(Icons.receipt_long),
        label: 'Expense',
      ),
      if (hasMore)
        const NavigationDestination(
          icon: Icon(Icons.more_horiz),
          selectedIcon: Icon(Icons.more),
          label: 'More',
        ),
    ];
    if (_index >= pages.length) _index = 0;

    return Scaffold(
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: destinations,
      ),
    );
  }
}

class _NewBookingPage extends StatelessWidget {
  final AppUser user;
  const _NewBookingPage({required this.user});

  Future<void> _recordBooking(BuildContext context) async {
    final account = AccountService();
    final cloud = CloudSyncService();
    if (!await cloud.verifyActiveMembership()) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Cloud access could not be verified. Check the connection and sign in again.',
            ),
          ),
        );
      }
      return;
    }
    if (!account.can(AppPermission.createBookings)) {
      await cloud.reportSecurityEvent(
        'permission_denied',
        resource: 'bookings',
        attemptedAction: 'create_booking',
      );
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Booking access is not enabled for this employee account.',
            ),
          ),
        );
      }
      return;
    }
    if (!context.mounted) return;
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) =>
            EnhancedBookingFormScreen(createdBy: account.currentAuditLabel),
      ),
    );
    if (saved == true) {
      await cloud.syncNow();
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              cloud.status == CloudSyncStatus.error
                  ? 'Booking saved. Cloud sync will retry automatically.'
                  : 'Booking saved and synchronized.',
            ),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Employee Workspace'),
        actions: [
          IconButton(
            tooltip: 'Sign out',
            onPressed: AccountService().logout,
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Center(child: BrandLogo(height: 72)),
            const SizedBox(height: 24),
            Text(
              'Hello, ${user.displayName}',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 6),
            Text(
              'Record a booking, check room availability, or add a business expense.',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 28),
            FilledButton.icon(
              onPressed: () => _recordBooking(context),
              icon: const Icon(Icons.add),
              label: const Text('Record New Booking'),
              style: FilledButton.styleFrom(
                minimumSize: const Size.fromHeight(54),
              ),
            ),
            const SizedBox(height: 14),
            Card(
              child: ListTile(
                leading: const Icon(Icons.grid_view_outlined),
                title: const Text('Occupancy chart'),
                subtitle: const Text(
                  'Use the Occupancy tab to check dates before accepting a booking.',
                ),
                isThreeLine: true,
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.verified_user_outlined),
                title: Text(user.role.label),
                subtitle: Text('Signed in as ${user.username}'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmployeeExpensesPage extends StatefulWidget {
  final AppUser user;
  const _EmployeeExpensesPage({required this.user});

  @override
  State<_EmployeeExpensesPage> createState() => _EmployeeExpensesPageState();
}

class _EmployeeExpensesPageState extends State<_EmployeeExpensesPage> {
  final ExpenseRepository _repo = ExpenseRepository();
  List<DailyExpense> _recent = const [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final now = DateTime.now();
    final all = await _repo.getDailyExpensesForMonth(now.year, now.month);
    if (!mounted) return;
    setState(() {
      _recent = all
          .where(
            (expense) =>
                AccountService.activityBelongsTo(expense.by, widget.user),
          )
          .take(20)
          .toList();
      _loading = false;
    });
  }

  Future<void> _record() async {
    final account = AccountService();
    final cloud = CloudSyncService();
    if (!await cloud.verifyActiveMembership()) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Cloud access could not be verified. Check the connection and sign in again.',
            ),
          ),
        );
      }
      return;
    }
    if (!account.can(AppPermission.recordExpenses)) {
      await cloud.reportSecurityEvent(
        'permission_denied',
        resource: 'expenses',
        attemptedAction: 'create_expense',
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Expense access is not enabled for this employee account.',
            ),
          ),
        );
      }
      return;
    }
    if (!mounted) return;
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => DailyExpenseFormScreen(
          recordedBy: account.currentAuditLabel,
          employeeMode: true,
        ),
      ),
    );
    if (saved == true) {
      await cloud.syncNow();
      await _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const AppBackButton(),
        title: const Text('Record Expenses'),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _record,
        icon: const Icon(Icons.add),
        label: const Text('New Expense'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
              children: [
                Text(
                  'Your recent entries',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 10),
                if (_recent.isEmpty)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(20),
                      child: Text('No expenses recorded by you this month.'),
                    ),
                  ),
                for (final expense in _recent)
                  Card(
                    child: ListTile(
                      leading: const Icon(Icons.receipt_outlined),
                      title: Text(expense.head),
                      subtitle: Text(DateFormatter.format(expense.date)),
                      trailing: Text(
                        CurrencyFormatter.format(expense.amount),
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
              ],
            ),
    );
  }
}

class _EmployeeMorePage extends StatelessWidget {
  final AppUser user;
  const _EmployeeMorePage({required this.user});

  @override
  Widget build(BuildContext context) {
    final modules =
        <
              ({
                AppPermission permission,
                String title,
                IconData icon,
                Widget screen,
              })
            >[
              (
                permission: AppPermission.manageBookings,
                title: 'Booking Records',
                icon: Icons.bed_outlined,
                screen: const BookingsScreen(),
              ),
              (
                permission: AppPermission.manageInventory,
                title: 'Stock & Inventory',
                icon: Icons.inventory_2_outlined,
                screen: const InventoryScreen(),
              ),
              (
                permission: AppPermission.recordPayments,
                title: 'Payments',
                icon: Icons.payments_outlined,
                screen: const PaymentsScreen(),
              ),
              (
                permission: AppPermission.manageGuestIds,
                title: 'Guest IDs',
                icon: Icons.badge_outlined,
                screen: const GuestIdsScreen(),
              ),
              (
                permission: AppPermission.viewAnalytics,
                title: 'Reports',
                icon: Icons.analytics_outlined,
                screen: const AnalyticsScreen(),
              ),
            ]
            .where((module) => AccountService().can(module.permission));

    return Scaffold(
      appBar: AppBar(
        leading: const AppBackButton(),
        title: const Text('Additional Access'),
        actions: [
          IconButton(
            tooltip: 'Sign out',
            onPressed: AccountService().logout,
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.cloud_sync_outlined),
              title: const Text('Cloud Sync'),
              subtitle: const Text('Connect this employee device'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const CloudSyncScreen()),
              ),
            ),
          ),
          for (final module in modules)
            Card(
              child: ListTile(
                leading: Icon(module.icon),
                title: Text(module.title),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => module.screen),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
