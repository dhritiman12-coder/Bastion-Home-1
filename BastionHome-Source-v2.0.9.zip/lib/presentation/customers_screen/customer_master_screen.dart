import 'package:flutter/material.dart';

import '../../database/repositories/booking_repository.dart';
import '../../services/account_service.dart';
import '../../services/customer_master_service.dart';
import '../../services/data_change_service.dart';
import '../../theme/app_theme.dart';
import '../../utils/currency_formatter.dart';
import '../../widgets/app_back_button.dart';
import '../customer_details_screen/customer_details_screen.dart';

class CustomerMasterScreen extends StatefulWidget {
  const CustomerMasterScreen({super.key});

  @override
  State<CustomerMasterScreen> createState() => _CustomerMasterScreenState();
}

class _CustomerMasterScreenState extends State<CustomerMasterScreen> {
  static const _months = [
    'All months',
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];

  final _repository = BookingRepository();
  final _searchController = TextEditingController();
  List<CustomerSummary> _customers = const [];
  List<int> _years = const [];
  bool _loading = true;
  bool _frequentOnly = false;
  int _year = 0;
  int _month = 0;

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_refresh);
    DataChangeService().addListener(_reload);
    _reload();
  }

  @override
  void dispose() {
    DataChangeService().removeListener(_reload);
    _searchController
      ..removeListener(_refresh)
      ..dispose();
    super.dispose();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  Future<void> _reload() async {
    if (mounted) setState(() => _loading = true);
    try {
      final bookings = await _repository.getAllBookings();
      final years = bookings.map((booking) => booking.checkin.year).toSet()
        ..add(DateTime.now().year);
      if (!mounted) return;
      setState(() {
        _customers = CustomerMasterService.build(bookings);
        _years = years.toList()..sort((a, b) => b.compareTo(a));
        if (_year != 0 && !_years.contains(_year)) _year = 0;
        _loading = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  List<CustomerSummary> get _visible => _customers.where((customer) {
    if (_frequentOnly && !customer.isFrequent) return false;
    if (!CustomerMasterService.matches(customer, _searchController.text)) {
      return false;
    }
    return CustomerMasterService.hasBookingInPeriod(
      customer,
      year: _year == 0 ? null : _year,
      month: _month == 0 ? null : _month,
    );
  }).toList();

  @override
  Widget build(BuildContext context) {
    if (!AccountService().isAdmin) {
      return Scaffold(
        appBar: AppBar(
          leading: const AppBackButton(),
          title: const Text('Customer Master'),
        ),
        body: const Center(child: Text('Administrator access required')),
      );
    }
    final visible = _visible;
    final repeatCount = _customers.where((item) => item.isFrequent).length;
    return Scaffold(
      appBar: AppBar(
        leading: const AppBackButton(),
        title: const Text('Customer Master'),
      ),
      body: RefreshIndicator(
        onRefresh: _reload,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
          children: [
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                _SummaryTile(
                  label: 'Customers',
                  value: '${_customers.length}',
                  icon: Icons.people_outline,
                ),
                _SummaryTile(
                  label: 'Frequent',
                  value: '$repeatCount',
                  icon: Icons.workspace_premium_outlined,
                ),
                _SummaryTile(
                  label: 'Results',
                  value: '${visible.length}',
                  icon: Icons.manage_search,
                ),
              ],
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _searchController,
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.search),
                hintText: 'Name, phone, booking ID or serial number',
                suffixIcon: _searchController.text.isEmpty
                    ? null
                    : IconButton(
                        tooltip: 'Clear search',
                        onPressed: _searchController.clear,
                        icon: const Icon(Icons.close),
                      ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<int>(
                    initialValue: _year,
                    decoration: const InputDecoration(
                      labelText: 'Year',
                      isDense: true,
                    ),
                    items: [
                      const DropdownMenuItem(
                        value: 0,
                        child: Text('All years'),
                      ),
                      ..._years.map(
                        (year) =>
                            DropdownMenuItem(value: year, child: Text('$year')),
                      ),
                    ],
                    onChanged: (value) => setState(() => _year = value ?? 0),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: DropdownButtonFormField<int>(
                    initialValue: _month,
                    decoration: const InputDecoration(
                      labelText: 'Month',
                      isDense: true,
                    ),
                    items: List.generate(
                      _months.length,
                      (index) => DropdownMenuItem(
                        value: index,
                        child: Text(
                          _months[index],
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ),
                    onChanged: (value) => setState(() => _month = value ?? 0),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerLeft,
              child: FilterChip(
                selected: _frequentOnly,
                avatar: const Icon(Icons.repeat, size: 18),
                label: const Text('Frequent customers only'),
                onSelected: (value) => setState(() => _frequentOnly = value),
              ),
            ),
            const SizedBox(height: 8),
            if (_loading)
              const Padding(
                padding: EdgeInsets.all(40),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (visible.isEmpty)
              const Padding(
                padding: EdgeInsets.all(40),
                child: Center(child: Text('No matching customer records')),
              )
            else
              for (final customer in visible)
                _CustomerTile(
                  customer: customer,
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => CustomerDetailsScreen(
                        initialBooking: customer.latestBooking,
                      ),
                    ),
                  ),
                ),
          ],
        ),
      ),
    );
  }
}

class _SummaryTile extends StatelessWidget {
  const _SummaryTile({
    required this.label,
    required this.value,
    required this.icon,
  });

  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) => Container(
    width: 104,
    padding: const EdgeInsets.all(10),
    decoration: BoxDecoration(
      color: Theme.of(context).colorScheme.surfaceContainerHighest,
      borderRadius: BorderRadius.circular(8),
    ),
    child: Row(
      children: [
        Icon(icon, size: 20, color: AppTheme.deepTeal),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(value, style: const TextStyle(fontWeight: FontWeight.w700)),
              Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.labelSmall,
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

class _CustomerTile extends StatelessWidget {
  const _CustomerTile({required this.customer, required this.onTap});

  final CustomerSummary customer;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final serials = customer.bookings
        .map((booking) => booking.serialNumber)
        .where((serial) => serial.isNotEmpty)
        .take(3)
        .join(', ');
    return Card(
      margin: const EdgeInsets.only(top: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        leading: CircleAvatar(
          backgroundColor: AppTheme.deepTeal.withAlpha(24),
          foregroundColor: AppTheme.deepTeal,
          child: Text(
            customer.displayName.trim().isEmpty
                ? '?'
                : customer.displayName.trim()[0].toUpperCase(),
          ),
        ),
        title: Row(
          children: [
            Expanded(
              child: Text(
                customer.displayName,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
            if (customer.isFrequent)
              const Tooltip(
                message: 'Two or more completed stays',
                child: Icon(
                  Icons.workspace_premium,
                  size: 19,
                  color: AppTheme.brassAccent,
                ),
              ),
          ],
        ),
        subtitle: Text(
          '${customer.displayPhone.isEmpty ? 'Phone missing' : customer.displayPhone}\n'
          '${customer.validBookings} booking${customer.validBookings == 1 ? '' : 's'} · '
          '${customer.totalNights} night${customer.totalNights == 1 ? '' : 's'} · '
          'Last ${DateFormatter.format(customer.lastVisit)}'
          '${serials.isEmpty ? '' : '\nSerials: $serials'}',
        ),
        isThreeLine: true,
        trailing: const Icon(Icons.chevron_right),
      ),
    );
  }
}
