import 'package:flutter/material.dart';
import '../../widgets/app_back_button.dart';
import 'package:sizer/sizer.dart';

import '../../database/repositories/booking_repository.dart';
import '../../database/repositories/payment_repository.dart';
import '../../models/booking_model.dart';
import '../../models/payment_model.dart';
import '../../utils/currency_formatter.dart';

// ─── Helpers ─────────────────────────────────────────────────────────────────

class _DateFormatter {
  static const _months = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];
  static const _days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  static String monthYear(DateTime d) => '${_months[d.month - 1]} ${d.year}';
  static String shortDate(DateTime d) =>
      '${d.day} ${_months[d.month - 1].substring(0, 3)} ${d.year}';
  static String dayLabel(int weekday) => _days[weekday - 1];
}

// ─── Status colour map ────────────────────────────────────────────────────────

Color _statusColor(BookingStatus s) {
  switch (s) {
    case BookingStatus.booked:
      return const Color(0xFF123F34); // deep teal
    case BookingStatus.checkedIn:
      return const Color(0xFF3D6B4A); // success green
    case BookingStatus.checkedOut:
      return const Color(0xFF52645F); // muted slate
    case BookingStatus.cancelled:
      return const Color(0xFFA2432F); // alert red
    case BookingStatus.noShow:
      return const Color(0xFF8E2A18); // brass amber
  }
}

String _statusLabel(BookingStatus s) {
  switch (s) {
    case BookingStatus.booked:
      return 'Booked';
    case BookingStatus.checkedIn:
      return 'Checked-in';
    case BookingStatus.checkedOut:
      return 'Checked-out';
    case BookingStatus.cancelled:
      return 'Cancelled';
    case BookingStatus.noShow:
      return 'No-show';
  }
}

// ─── Screen ───────────────────────────────────────────────────────────────────

class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key});

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen>
    with SingleTickerProviderStateMixin {
  final BookingRepository _repo = BookingRepository();
  final PaymentRepository _payRepo = PaymentRepository();

  late TabController _tabController;
  DateTime _focusDate = DateTime(DateTime.now().year, DateTime.now().month);
  List<BookingModel> _bookings = [];
  bool _isLoading = true;

  // For week view: start of week
  DateTime _weekStart = _startOfWeek(DateTime.now());
  int _loadRevision = 0;

  static DateTime _startOfWeek(DateTime d) {
    return d.subtract(Duration(days: d.weekday - 1));
  }

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(() => setState(() {}));
    _focusDate = DateTime(DateTime.now().year, DateTime.now().month);
    _weekStart = _startOfWeek(DateTime.now());
    _loadData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    final revision = ++_loadRevision;
    final focusDate = _focusDate;
    setState(() => _isLoading = true);
    try {
      // Load bookings that overlap the current month
      final bookings = await _repo.getBookingsForOccupancy(
        focusDate.year,
        focusDate.month,
      );
      if (!mounted || revision != _loadRevision) return;
      setState(() {
        _bookings = bookings;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted || revision != _loadRevision) return;
      setState(() => _isLoading = false);
    }
  }

  Future<void> _loadWeekData() async {
    final revision = ++_loadRevision;
    final weekStart = _weekStart;
    setState(() => _isLoading = true);
    try {
      final weekEnd = weekStart.add(const Duration(days: 7));
      final rows = await _repo.getBookingsForOccupancy(
        weekStart.year,
        weekStart.month,
      );
      // Also load next month if week spans two months
      List<BookingModel> extra = [];
      if (weekEnd.month != _weekStart.month) {
        extra = await _repo.getBookingsForOccupancy(
          weekEnd.year,
          weekEnd.month,
        );
      }
      final all = {...rows, ...extra}.toList();
      if (!mounted || revision != _loadRevision) return;
      setState(() {
        _bookings = all;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted || revision != _loadRevision) return;
      setState(() => _isLoading = false);
    }
  }

  void _prevMonth() {
    setState(() {
      _focusDate = DateTime(_focusDate.year, _focusDate.month - 1);
    });
    _loadData();
  }

  void _nextMonth() {
    setState(() {
      _focusDate = DateTime(_focusDate.year, _focusDate.month + 1);
    });
    _loadData();
  }

  void _prevWeek() {
    setState(() {
      _weekStart = _weekStart.subtract(const Duration(days: 7));
    });
    _loadWeekData();
  }

  void _nextWeek() {
    setState(() {
      _weekStart = _weekStart.add(const Duration(days: 7));
    });
    _loadWeekData();
  }

  void _showBookingDetail(BookingModel booking) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _BookingDetailSheet(
        booking: booking,
        payRepo: _payRepo,
        onReschedule: () {
          Navigator.pop(context);
          _showRescheduleDialog(booking);
        },
        onRefresh: _loadData,
      ),
    );
  }

  void _showRescheduleDialog(BookingModel booking) {
    DateTime newCheckin = booking.checkin;
    DateTime newCheckout = booking.checkout;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: Text(
            'Reschedule Booking',
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 16,
              color: const Color(0xFF0E332B),
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                booking.guest,
                style: TextStyle(fontSize: 13, color: const Color(0xFF52645F)),
              ),
              const SizedBox(height: 16),
              _DatePickerRow(
                label: 'Check-in',
                date: newCheckin,
                onPick: (d) => setS(() => newCheckin = d),
              ),
              const SizedBox(height: 10),
              _DatePickerRow(
                label: 'Check-out',
                date: newCheckout,
                onPick: (d) => setS(() => newCheckout = d),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text(
                'Cancel',
                style: TextStyle(color: const Color(0xFF52645F)),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF123F34),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              onPressed: () async {
                if (newCheckout.isBefore(newCheckin) ||
                    newCheckout.isAtSameMomentAs(newCheckin)) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Check-out must be after check-in'),
                    ),
                  );
                  return;
                }
                final hasOverlap = await _repo.hasOverlap(
                  booking.roomLabel,
                  newCheckin,
                  newCheckout,
                  excludeId: booking.id,
                );
                if (hasOverlap) {
                  if (ctx.mounted) {
                    ScaffoldMessenger.of(ctx).showSnackBar(
                      const SnackBar(
                        content: Text('Room is already booked for those dates'),
                        backgroundColor: Color(0xFFA2432F),
                      ),
                    );
                  }
                  return;
                }
                final updated = BookingModel(
                  id: booking.id,
                  guest: booking.guest,
                  phone: booking.phone,
                  address: booking.address,
                  otherOccupants: booking.otherOccupants,
                  guests: booking.guests,
                  room: booking.room,
                  checkin: newCheckin,
                  checkout: newCheckout,
                  checkinTime: booking.checkinTime,
                  checkoutTime: booking.checkoutTime,
                  tariff: booking.tariff,
                  extra: booking.extra,
                  discount: booking.discount,
                  status: booking.status,
                  idTaken: booking.idTaken,
                  idType: booking.idType,
                  idNumber: booking.idNumber,
                  idFrontPath: booking.idFrontPath,
                  idBackPath: booking.idBackPath,
                  idFrontCapturedAt: booking.idFrontCapturedAt,
                  idBackCapturedAt: booking.idBackCapturedAt,
                  paymentMode: booking.paymentMode,
                  serialNumber: booking.serialNumber,
                  createdBy: booking.createdBy,
                  bookingSource: booking.bookingSource,
                  notes: booking.notes,
                  received: booking.received,
                );
                await _repo.updateBooking(updated);
                if (ctx.mounted) Navigator.pop(ctx);
                _loadData();
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Booking rescheduled successfully'),
                      backgroundColor: Color(0xFF3D6B4A),
                    ),
                  );
                }
              },
              child: Text(
                'Save',
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF0D1F25) : const Color(0xFFF7F4EE);

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        leading: const AppBackButton(),
        backgroundColor: isDark
            ? const Color(0xFF0E332B)
            : const Color(0xFF123F34),
        elevation: 0,
        title: Text(
          'ROOM CALENDAR',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.0,
            fontWeight: FontWeight.w700,
            letterSpacing: 0,
          ),
        ),
        centerTitle: true,
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: const Color(0xFF8E2A18),
          indicatorWeight: 3,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white54,
          labelStyle: TextStyle(fontSize: 14.0, fontWeight: FontWeight.w600),
          unselectedLabelStyle: TextStyle(
            fontSize: 14.0,
            fontWeight: FontWeight.w400,
          ),
          tabs: const [
            Tab(text: 'MONTH'),
            Tab(text: 'WEEK'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _MonthView(
            focusDate: _focusDate,
            bookings: _bookings,
            isLoading: _isLoading,
            onPrev: _prevMonth,
            onNext: _nextMonth,
            onTap: _showBookingDetail,
            isDark: isDark,
          ),
          _WeekView(
            weekStart: _weekStart,
            bookings: _bookings,
            isLoading: _isLoading,
            onPrev: _prevWeek,
            onNext: _nextWeek,
            onTap: _showBookingDetail,
            isDark: isDark,
          ),
        ],
      ),
    );
  }
}

// ─── Month View ───────────────────────────────────────────────────────────────

class _MonthView extends StatelessWidget {
  final DateTime focusDate;
  final List<BookingModel> bookings;
  final bool isLoading;
  final VoidCallback onPrev;
  final VoidCallback onNext;
  final void Function(BookingModel) onTap;
  final bool isDark;

  const _MonthView({
    required this.focusDate,
    required this.bookings,
    required this.isLoading,
    required this.onPrev,
    required this.onNext,
    required this.onTap,
    required this.isDark,
  });

  int get _daysInMonth => DateTime(focusDate.year, focusDate.month + 1, 0).day;

  BookingModel? _bookingForRoomDay(String room, int day) {
    final date = DateTime(focusDate.year, focusDate.month, day);
    for (final b in bookings) {
      if (b.roomLabel == room &&
          !b.checkin.isAfter(date) &&
          b.checkout.isAfter(date) &&
          b.status != BookingStatus.cancelled) {
        return b;
      }
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final inkColor = isDark ? Colors.white : const Color(0xFF0E332B);

    return Column(
      children: [
        // Navigator
        _PeriodNavigator(
          label: _DateFormatter.monthYear(focusDate),
          onPrev: onPrev,
          onNext: onNext,
          isDark: isDark,
        ),
        // Legend
        _Legend(isDark: isDark),
        // Grid
        Expanded(
          child: isLoading
              ? const Center(
                  child: CircularProgressIndicator(color: Color(0xFF123F34)),
                )
              : SingleChildScrollView(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    padding: EdgeInsets.symmetric(
                      horizontal: 2.w,
                      vertical: 1.h,
                    ),
                    child: _buildGrid(inkColor),
                  ),
                ),
        ),
      ],
    );
  }

  Widget _buildGrid(Color inkColor) {
    const rooms = ['Room 1', 'Room 2', 'Room 3', 'Room 4', 'Room 5'];
    const cellW = 48.0;
    const cellH = 42.0;
    const labelW = 68.0;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Day header row
        Row(
          children: [
            SizedBox(width: labelW),
            ...List.generate(_daysInMonth, (i) {
              final day = i + 1;
              final date = DateTime(focusDate.year, focusDate.month, day);
              final isWeekend = date.weekday == 6 || date.weekday == 7;
              final isToday =
                  date.year == DateTime.now().year &&
                  date.month == DateTime.now().month &&
                  date.day == DateTime.now().day;
              return Container(
                width: cellW,
                height: 28,
                alignment: Alignment.center,
                decoration: isToday
                    ? BoxDecoration(
                        color: const Color(0xFF8E2A18).withAlpha(40),
                        borderRadius: BorderRadius.circular(4),
                      )
                    : null,
                child: Text(
                  day.toString(),
                  style: TextStyle(
                    fontSize: 12.0,
                    fontWeight: FontWeight.w600,
                    color: isToday
                        ? const Color(0xFF8E2A18)
                        : isWeekend
                        ? const Color(0xFF8E2A18).withAlpha(180)
                        : inkColor.withAlpha(160),
                  ),
                ),
              );
            }),
          ],
        ),
        const SizedBox(height: 4),
        // Room rows
        ...rooms.map((room) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 3),
            child: Row(
              children: [
                Container(
                  width: labelW,
                  height: cellH,
                  alignment: Alignment.centerLeft,
                  padding: const EdgeInsets.only(left: 4),
                  child: Text(
                    room,
                    style: TextStyle(
                      fontSize: 12.0,
                      fontWeight: FontWeight.w600,
                      color: inkColor,
                    ),
                  ),
                ),
                ...List.generate(_daysInMonth, (i) {
                  final day = i + 1;
                  final booking = _bookingForRoomDay(room, day);
                  final date = DateTime(focusDate.year, focusDate.month, day);
                  final isCheckout =
                      booking != null &&
                      booking.checkout.year == date.year &&
                      booking.checkout.month == date.month &&
                      booking.checkout.day == date.day;
                  final active = booking != null && !isCheckout;
                  final color = active ? _statusColor(booking.status) : null;

                  return GestureDetector(
                    onTap: active ? () => onTap(booking) : null,
                    child: Container(
                      width: cellW,
                      height: cellH,
                      margin: const EdgeInsets.symmetric(horizontal: 1),
                      decoration: BoxDecoration(
                        color: active
                            ? color!.withAlpha(220)
                            : (isDark ? Colors.white10 : Colors.grey.shade100),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                          color: active ? color! : Colors.grey.withAlpha(40),
                          width: 0.5,
                        ),
                      ),
                      alignment: Alignment.center,
                      child: active
                          ? Text(
                              _initials(booking.guest),
                              style: TextStyle(
                                fontSize: 11.0,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                              ),
                              overflow: TextOverflow.ellipsis,
                            )
                          : null,
                    ),
                  );
                }),
              ],
            ),
          );
        }),
      ],
    );
  }

  String _initials(String name) {
    final parts = name.trim().split(' ');
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    }
    return name.substring(0, name.length.clamp(0, 2)).toUpperCase();
  }
}

// ─── Week View ────────────────────────────────────────────────────────────────

class _WeekView extends StatelessWidget {
  final DateTime weekStart;
  final List<BookingModel> bookings;
  final bool isLoading;
  final VoidCallback onPrev;
  final VoidCallback onNext;
  final void Function(BookingModel) onTap;
  final bool isDark;

  const _WeekView({
    required this.weekStart,
    required this.bookings,
    required this.isLoading,
    required this.onPrev,
    required this.onNext,
    required this.onTap,
    required this.isDark,
  });

  DateTime get _weekEnd => weekStart.add(const Duration(days: 6));

  String get _weekLabel {
    final s = weekStart;
    final e = _weekEnd;
    if (s.month == e.month) {
      return '${s.day}–${e.day} ${_DateFormatter.monthYear(s)}';
    }
    return '${s.day} ${_DateFormatter.monthYear(s).split(' ')[0]} – ${e.day} ${_DateFormatter.monthYear(e).split(' ')[0]} ${e.year}';
  }

  BookingModel? _bookingForRoomDay(String room, DateTime date) {
    for (final b in bookings) {
      if (b.roomLabel == room &&
          !b.checkin.isAfter(date) &&
          b.checkout.isAfter(date) &&
          b.status != BookingStatus.cancelled) {
        return b;
      }
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final inkColor = isDark ? Colors.white : const Color(0xFF0E332B);

    return Column(
      children: [
        _PeriodNavigator(
          label: _weekLabel,
          onPrev: onPrev,
          onNext: onNext,
          isDark: isDark,
        ),
        _Legend(isDark: isDark),
        Expanded(
          child: isLoading
              ? const Center(
                  child: CircularProgressIndicator(color: Color(0xFF123F34)),
                )
              : SingleChildScrollView(
                  padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                  child: _buildWeekGrid(context, inkColor),
                ),
        ),
      ],
    );
  }

  Widget _buildWeekGrid(BuildContext context, Color inkColor) {
    const rooms = ['Room 1', 'Room 2', 'Room 3', 'Room 4', 'Room 5'];
    final days = List.generate(7, (i) => weekStart.add(Duration(days: i)));

    return Column(
      children: [
        // Header
        Row(
          children: [
            SizedBox(width: 70),
            ...days.map((d) {
              final isToday =
                  d.year == DateTime.now().year &&
                  d.month == DateTime.now().month &&
                  d.day == DateTime.now().day;
              final isWeekend = d.weekday == 6 || d.weekday == 7;
              return Expanded(
                child: Container(
                  height: 44,
                  margin: const EdgeInsets.symmetric(horizontal: 2),
                  decoration: BoxDecoration(
                    color: isToday
                        ? const Color(0xFF8E2A18).withAlpha(40)
                        : (isDark ? Colors.white10 : Colors.grey.shade100),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  alignment: Alignment.center,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        _DateFormatter.dayLabel(d.weekday),
                        style: TextStyle(
                          fontSize: 11.0,
                          fontWeight: FontWeight.w500,
                          color: isToday
                              ? const Color(0xFF8E2A18)
                              : isWeekend
                              ? const Color(0xFF8E2A18).withAlpha(180)
                              : inkColor.withAlpha(140),
                        ),
                      ),
                      Text(
                        '${d.day}',
                        style: TextStyle(
                          fontSize: 14.0,
                          fontWeight: FontWeight.w700,
                          color: isToday
                              ? const Color(0xFF8E2A18)
                              : isWeekend
                              ? const Color(0xFF8E2A18).withAlpha(180)
                              : inkColor,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          ],
        ),
        const SizedBox(height: 6),
        // Room rows
        ...rooms.map((room) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Row(
              children: [
                SizedBox(
                  width: 70,
                  child: Text(
                    room,
                    style: TextStyle(
                      fontSize: 12.0,
                      fontWeight: FontWeight.w600,
                      color: inkColor,
                    ),
                  ),
                ),
                ...days.map((d) {
                  final booking = _bookingForRoomDay(room, d);
                  final isCheckout =
                      booking != null &&
                      booking.checkout.year == d.year &&
                      booking.checkout.month == d.month &&
                      booking.checkout.day == d.day;
                  final active = booking != null && !isCheckout;
                  final color = active ? _statusColor(booking.status) : null;

                  return Expanded(
                    child: GestureDetector(
                      onTap: active ? () => onTap(booking) : null,
                      child: Container(
                        height: 56,
                        margin: const EdgeInsets.symmetric(horizontal: 2),
                        decoration: BoxDecoration(
                          color: active
                              ? color!.withAlpha(220)
                              : (isDark
                                    ? Colors.white10
                                    : Colors.grey.shade100),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: active ? color! : Colors.grey.withAlpha(40),
                            width: 0.5,
                          ),
                        ),
                        alignment: Alignment.center,
                        child: active
                            ? Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    _initials(booking.guest),
                                    style: TextStyle(
                                      fontSize: 12.0,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 4,
                                      vertical: 1,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Colors.white.withAlpha(40),
                                      borderRadius: BorderRadius.circular(4),
                                    ),
                                    child: Text(
                                      _statusLabel(
                                        booking.status,
                                      ).split('-').first,
                                      style: TextStyle(
                                        fontSize: 10.0,
                                        color: Colors.white,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ),
                                ],
                              )
                            : null,
                      ),
                    ),
                  );
                }),
              ],
            ),
          );
        }),
      ],
    );
  }

  String _initials(String name) {
    final parts = name.trim().split(' ');
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    }
    return name.substring(0, name.length.clamp(0, 2)).toUpperCase();
  }
}

// ─── Shared Widgets ───────────────────────────────────────────────────────────

class _PeriodNavigator extends StatelessWidget {
  final String label;
  final VoidCallback onPrev;
  final VoidCallback onNext;
  final bool isDark;

  const _PeriodNavigator({
    required this.label,
    required this.onPrev,
    required this.onNext,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: isDark ? const Color(0xFF0E332B) : const Color(0xFF123F34),
      padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 1.2.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(
            icon: const Icon(Icons.chevron_left, color: Colors.white),
            onPressed: onPrev,
          ),
          Text(
            label,
            style: TextStyle(
              color: Colors.white,
              fontSize: 16.0,
              fontWeight: FontWeight.w600,
            ),
          ),
          IconButton(
            icon: const Icon(Icons.chevron_right, color: Colors.white),
            onPressed: onNext,
          ),
        ],
      ),
    );
  }
}

class _Legend extends StatelessWidget {
  final bool isDark;
  const _Legend({required this.isDark});

  @override
  Widget build(BuildContext context) {
    final inkColor = isDark ? Colors.white : const Color(0xFF0E332B);
    final statuses = [
      (BookingStatus.booked, 'Booked'),
      (BookingStatus.checkedIn, 'Checked-in'),
      (BookingStatus.checkedOut, 'Checked-out'),
      (BookingStatus.noShow, 'No-show'),
    ];

    return Container(
      color: isDark ? const Color(0xFF0D1F25) : const Color(0xFFF7F4EE),
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: statuses.map((s) {
            return Padding(
              padding: const EdgeInsets.only(right: 12),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      color: _statusColor(s.$1),
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    s.$2,
                    style: TextStyle(
                      fontSize: 12.0,
                      color: inkColor.withAlpha(180),
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

class _DatePickerRow extends StatelessWidget {
  final String label;
  final DateTime date;
  final void Function(DateTime) onPick;

  const _DatePickerRow({
    required this.label,
    required this.date,
    required this.onPick,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 80,
          child: Text(
            label,
            style: TextStyle(fontSize: 13, color: const Color(0xFF52645F)),
          ),
        ),
        Expanded(
          child: GestureDetector(
            onTap: () async {
              final picked = await showDatePicker(
                context: context,
                initialDate: date,
                firstDate: DateTime(2020),
                lastDate: DateTime(2030),
                builder: (ctx, child) => Theme(
                  data: Theme.of(ctx).copyWith(
                    colorScheme: const ColorScheme.light(
                      primary: Color(0xFF123F34),
                    ),
                  ),
                  child: child!,
                ),
              );
              if (picked != null) onPick(picked);
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xFFF0EEE9),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: const Color(0xFFDCE4E0)),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      _DateFormatter.shortDate(date),
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: const Color(0xFF0E332B),
                      ),
                    ),
                  ),
                  const Icon(
                    Icons.calendar_today_outlined,
                    size: 16,
                    color: Color(0xFF123F34),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// ─── Booking Detail Sheet ─────────────────────────────────────────────────────

class _BookingDetailSheet extends StatefulWidget {
  final BookingModel booking;
  final PaymentRepository payRepo;
  final VoidCallback onReschedule;
  final VoidCallback onRefresh;

  const _BookingDetailSheet({
    required this.booking,
    required this.payRepo,
    required this.onReschedule,
    required this.onRefresh,
  });

  @override
  State<_BookingDetailSheet> createState() => _BookingDetailSheetState();
}

class _BookingDetailSheetState extends State<_BookingDetailSheet>
    with SingleTickerProviderStateMixin {
  late TabController _tabs;
  List<PaymentModel> _payments = [];
  bool _loadingPayments = true;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this);
    _loadPayments();
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  Future<void> _loadPayments() async {
    try {
      final all = await widget.payRepo.getPaymentsForBooking(widget.booking.id);
      if (!mounted) return;
      setState(() {
        _payments = all;
        _loadingPayments = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _loadingPayments = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF123F34) : Colors.white;
    final inkColor = isDark ? Colors.white : const Color(0xFF0E332B);
    final b = widget.booking;
    final statusColor = _statusColor(b.status);

    return DraggableScrollableSheet(
      initialChildSize: 0.7,
      minChildSize: 0.4,
      maxChildSize: 0.92,
      builder: (_, controller) => Container(
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          children: [
            // Handle
            Padding(
              padding: const EdgeInsets.only(top: 12, bottom: 4),
              child: Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.withAlpha(80),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
            ),
            // Header
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          b.guest,
                          style: TextStyle(
                            fontSize: 20.0,
                            fontWeight: FontWeight.w700,
                            color: inkColor,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          '${b.id} · ${b.roomLabel}',
                          style: TextStyle(
                            fontSize: 13.0,
                            color: inkColor.withAlpha(160),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 5,
                    ),
                    decoration: BoxDecoration(
                      color: statusColor.withAlpha(30),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: statusColor.withAlpha(100)),
                    ),
                    child: Text(
                      _statusLabel(b.status).toUpperCase(),
                      style: TextStyle(
                        fontSize: 12.0,
                        fontWeight: FontWeight.w700,
                        color: statusColor,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // Reschedule button
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              child: SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: widget.onReschedule,
                  icon: const Icon(
                    Icons.edit_calendar_outlined,
                    size: 16,
                    color: Color(0xFF123F34),
                  ),
                  label: Text(
                    'Reschedule Booking',
                    style: TextStyle(
                      fontSize: 14.0,
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFF123F34),
                    ),
                  ),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Color(0xFF123F34)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            // Tabs
            TabBar(
              controller: _tabs,
              indicatorColor: const Color(0xFF123F34),
              labelColor: const Color(0xFF123F34),
              unselectedLabelColor: const Color(0xFF7B8A86),
              labelStyle: TextStyle(
                fontSize: 13.0,
                fontWeight: FontWeight.w600,
              ),
              tabs: const [
                Tab(text: 'DETAILS'),
                Tab(text: 'FINANCIALS'),
              ],
            ),
            Expanded(
              child: TabBarView(
                controller: _tabs,
                children: [
                  _DetailsTab(booking: b, inkColor: inkColor),
                  _FinancialsTab(
                    booking: b,
                    payments: _payments,
                    isLoading: _loadingPayments,
                    inkColor: inkColor,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DetailsTab extends StatelessWidget {
  final BookingModel booking;
  final Color inkColor;
  const _DetailsTab({required this.booking, required this.inkColor});

  @override
  Widget build(BuildContext context) {
    final b = booking;
    return ListView(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      children: [
        _row('Phone', b.phone.isNotEmpty ? b.phone : '—', inkColor),
        _row('Address', b.address.isNotEmpty ? b.address : '—', inkColor),
        _row('Guests', '${b.guests}', inkColor),
        if (b.otherOccupantNames.isNotEmpty)
          _row('Other occupants', b.otherOccupantNames.join(', '), inkColor),
        _row('Room', b.roomLabel, inkColor),
        _row(
          'Check-in',
          '${_DateFormatter.shortDate(b.checkin)} ${b.checkinTime}',
          inkColor,
        ),
        _row(
          'Check-out',
          '${_DateFormatter.shortDate(b.checkout)} ${b.checkoutTime}',
          inkColor,
        ),
        _row('Nights', '${b.nights}', inkColor),
        _row(
          'Serial No.',
          b.serialNumber.isNotEmpty ? b.serialNumber : '—',
          inkColor,
        ),
        if (b.idType.isNotEmpty) _row('ID Type', b.idType, inkColor),
        if (b.idNumber.isNotEmpty) _row('ID Number', b.idNumber, inkColor),
        if (b.notes.isNotEmpty) _row('Notes', b.notes, inkColor),
      ],
    );
  }

  Widget _row(String label, String value, Color inkColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 90,
            child: Text(
              label,
              style: TextStyle(fontSize: 13.0, color: inkColor.withAlpha(160)),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                fontSize: 13.0,
                fontWeight: FontWeight.w600,
                color: inkColor,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _FinancialsTab extends StatelessWidget {
  final BookingModel booking;
  final List<PaymentModel> payments;
  final bool isLoading;
  final Color inkColor;

  const _FinancialsTab({
    required this.booking,
    required this.payments,
    required this.isLoading,
    required this.inkColor,
  });

  @override
  Widget build(BuildContext context) {
    final b = booking;
    final dueColor = b.due > 0
        ? const Color(0xFFA2432F)
        : const Color(0xFF3D6B4A);

    return ListView(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      children: [
        // Summary card
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFF123F34).withAlpha(15),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF123F34).withAlpha(40)),
          ),
          child: Column(
            children: [
              _fRow(
                'Tariff / Night',
                CurrencyFormatter.format(b.tariff),
                inkColor,
              ),
              _fRow('Nights', '${b.nights}', inkColor),
              _fRow(
                'Room Charges',
                CurrencyFormatter.format(b.roomCharges),
                inkColor,
              ),
              if (b.extra > 0)
                _fRow(
                  'Extra Charges',
                  CurrencyFormatter.format(b.extra),
                  inkColor,
                ),
              if (b.discount > 0)
                _fRow(
                  'Discount',
                  '- ${CurrencyFormatter.format(b.discount)}',
                  const Color(0xFF3D6B4A),
                ),
              const Divider(height: 16),
              _fRow(
                'Total',
                CurrencyFormatter.format(b.total),
                inkColor,
                bold: true,
              ),
              _fRow(
                'Received',
                CurrencyFormatter.format(b.received),
                const Color(0xFF3D6B4A),
                bold: true,
              ),
              _fRow(
                'Balance Due',
                CurrencyFormatter.format(b.due),
                dueColor,
                bold: true,
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Text(
          'Payment History',
          style: TextStyle(
            fontSize: 14.0,
            fontWeight: FontWeight.w700,
            color: inkColor,
          ),
        ),
        const SizedBox(height: 8),
        if (isLoading)
          const Center(child: CircularProgressIndicator())
        else if (payments.isEmpty)
          Text(
            'No payments recorded',
            style: TextStyle(fontSize: 13.0, color: inkColor.withAlpha(140)),
          )
        else
          ...payments.map((p) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      '${p.date.toIso8601String().split('T').first} · ${p.modeLabel} · ${p.typeLabel}',
                      style: TextStyle(
                        fontSize: 13.0,
                        color: inkColor.withAlpha(160),
                      ),
                    ),
                  ),
                  Text(
                    CurrencyFormatter.format(p.amount),
                    style: TextStyle(
                      fontSize: 13.0,
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFF3D6B4A),
                    ),
                  ),
                ],
              ),
            );
          }),
      ],
    );
  }

  Widget _fRow(
    String label,
    String value,
    Color valueColor, {
    bool bold = false,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(fontSize: 13.0, color: inkColor.withAlpha(160)),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 13.0,
              fontWeight: bold ? FontWeight.w700 : FontWeight.w500,
              color: valueColor,
            ),
          ),
        ],
      ),
    );
  }
}
