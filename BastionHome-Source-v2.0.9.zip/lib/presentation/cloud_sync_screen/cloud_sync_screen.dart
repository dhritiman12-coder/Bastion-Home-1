import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import '../../services/account_service.dart';
import '../../services/cloud_sync_service.dart';
import '../../widgets/app_back_button.dart';
import '../../widgets/credential_text_form_field.dart';
import 'workspace_access_screen.dart';

class CloudSyncScreen extends StatefulWidget {
  const CloudSyncScreen({super.key});

  @override
  State<CloudSyncScreen> createState() => _CloudSyncScreenState();
}

class _CloudSyncScreenState extends State<CloudSyncScreen> {
  final _sync = CloudSyncService();
  final _url = TextEditingController();
  final _key = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _propertyName = TextEditingController(text: 'Bastion Home');
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _url.text = _sync.projectUrl ?? '';
  }

  @override
  void dispose() {
    _url.dispose();
    _key.dispose();
    _email.dispose();
    _password.dispose();
    _propertyName.dispose();
    super.dispose();
  }

  Future<void> _run(
    Future<void> Function() action, {
    TextEditingController? clearOnError,
  }) async {
    setState(() => _busy = true);
    try {
      await action();
    } catch (error) {
      clearOnError?.clear();
      TextInput.finishAutofillContext(shouldSave: false);
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(_cleanError(error))));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _cleanError(Object error) => error
      .toString()
      .replaceFirst('Invalid argument(s): ', '')
      .replaceFirst('Bad state: ', '');

  Future<void> _configure() => _run(() async {
    await _sync.configureProject(url: _url.text, publishableKey: _key.text);
  });

  Future<void> _signIn() => _run(() async {
    await _sync.signIn(identifier: _email.text, password: _password.text);
  }, clearOnError: _password);

  Future<void> _createWorkspace() =>
      _run(() => _sync.createWorkspace(_propertyName.text));

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: _sync,
    builder: (context, _) => Scaffold(
      appBar: AppBar(
        leading: const AppBackButton(),
        title: const Text('Cloud Sync'),
        actions: [
          if (_sync.isConnected)
            IconButton(
              tooltip: 'Sync now',
              onPressed: _busy ? null : () => _run(_sync.syncNow),
              icon: const Icon(Icons.sync),
            ),
        ],
      ),
      body: AbsorbPointer(
        absorbing: _busy,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
          children: [
            _StatusCard(sync: _sync, busy: _busy),
            const SizedBox(height: 16),
            if (!_sync.isConfigured) _projectSetup(),
            if (_sync.isConfigured && !_sync.isSignedIn) _accountSignIn(),
            if (_sync.isSignedIn && !_sync.isConnected) _workspaceSetup(),
            if (_sync.isConnected) _connectedWorkspace(),
          ],
        ),
      ),
    ),
  );

  Widget _projectSetup() => _Section(
    title: 'Connect Cloud Project',
    icon: Icons.cloud_outlined,
    children: [
      const Text(
        'Enter the Project URL and publishable key from the Supabase Connect panel. The secret service-role key must never be entered here.',
      ),
      const SizedBox(height: 14),
      TextField(
        controller: _url,
        keyboardType: TextInputType.url,
        autocorrect: false,
        decoration: const InputDecoration(labelText: 'Project URL'),
      ),
      const SizedBox(height: 12),
      TextField(
        controller: _key,
        autocorrect: false,
        decoration: const InputDecoration(labelText: 'Publishable key'),
      ),
      const SizedBox(height: 16),
      FilledButton.icon(
        onPressed: _configure,
        icon: const Icon(Icons.link),
        label: const Text('Connect Project'),
      ),
    ],
  );

  Widget _accountSignIn() => _Section(
    title: 'Cloud Account',
    icon: Icons.person_outline,
    children: [
      CredentialTextFormField(
        controller: _email,
        labelText: 'Employee username or owner email',
        keyboardType: TextInputType.emailAddress,
      ),
      const SizedBox(height: 12),
      CredentialTextFormField(
        controller: _password,
        labelText: 'Password',
        secret: true,
        textInputAction: TextInputAction.done,
        onFieldSubmitted: (_) => _signIn(),
      ),
      const SizedBox(height: 16),
      FilledButton.icon(
        onPressed: _signIn,
        icon: const Icon(Icons.login),
        label: const Text('Sign In'),
      ),
      const SizedBox(height: 8),
      const Text(
        'The primary owner creates and approves all employee accounts.',
        textAlign: TextAlign.center,
      ),
      TextButton(
        onPressed: () => _run(_sync.resetProject),
        child: const Text('Use a different cloud project'),
      ),
    ],
  );

  Widget _workspaceSetup() => _Section(
    title: 'Property Workspace',
    icon: Icons.business_outlined,
    children: [
      if (AccountService().isAdmin) ...[
        TextField(
          controller: _propertyName,
          decoration: const InputDecoration(labelText: 'Property name'),
        ),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: _createWorkspace,
          icon: const Icon(Icons.add_business_outlined),
          label: const Text('Create New Workspace'),
        ),
      ],
      const Text(
        'This cloud account is not approved for this business. Only the primary owner can create and approve staff accounts.',
        textAlign: TextAlign.center,
      ),
      const SizedBox(height: 8),
      TextButton(
        onPressed: () => _run(_sync.signOut),
        child: const Text('Sign out of cloud account'),
      ),
    ],
  );

  Widget _connectedWorkspace() => _Section(
    title: _sync.workspaceName ?? 'Connected Workspace',
    icon: Icons.cloud_done_outlined,
    children: [
      ListTile(
        contentPadding: EdgeInsets.zero,
        leading: const Icon(Icons.account_circle_outlined),
        title: Text(_sync.signedInEmail ?? ''),
        subtitle: Text(_roleLabel(_sync.cloudRole)),
      ),
      ListTile(
        contentPadding: EdgeInsets.zero,
        leading: const Icon(Icons.sync),
        title: const Text('Automatic synchronization'),
        subtitle: Text(
          _sync.lastSyncedAt == null
              ? 'Waiting for first sync'
              : 'Last synced ${DateFormat('d MMM, h:mm a').format(_sync.lastSyncedAt!)}',
        ),
      ),
      FilledButton.icon(
        onPressed: () => _run(_sync.syncNow),
        icon: const Icon(Icons.sync),
        label: const Text('Sync Now'),
      ),
      if (_sync.isCloudAdmin && AccountService().isAdmin) ...[
        const SizedBox(height: 12),
        OutlinedButton.icon(
          onPressed: () => Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (_) => const WorkspaceAccessScreen(),
            ),
          ),
          icon: const Icon(Icons.manage_accounts_outlined),
          label: const Text('Manage Business Access'),
        ),
        const SizedBox(height: 12),
        const Text(
          'Create staff usernames and temporary passwords from Manage Business Access.',
        ),
      ],
      const SizedBox(height: 12),
      TextButton.icon(
        onPressed: () => _run(_sync.signOut),
        icon: const Icon(Icons.cloud_off_outlined),
        label: const Text('Disconnect This Device'),
      ),
    ],
  );

  String _roleLabel(String? role) {
    switch (role) {
      case 'primary_admin':
        return 'Protected primary owner';
      case 'backup_admin':
        return 'Backup cloud administrator';
      case 'admin':
        return 'Cloud administrator';
      case 'employee':
        return 'Employee device';
      default:
        return 'Workspace member';
    }
  }
}

class _StatusCard extends StatelessWidget {
  final CloudSyncService sync;
  final bool busy;
  const _StatusCard({required this.sync, required this.busy});

  @override
  Widget build(BuildContext context) {
    final (icon, title, message) = switch (sync.status) {
      CloudSyncStatus.notConfigured => (
        Icons.cloud_off_outlined,
        'Cloud sync is not configured',
        'This phone continues to work offline.',
      ),
      CloudSyncStatus.signedOut => (
        Icons.cloud_queue,
        'Project connected',
        'Sign in to synchronize this phone.',
      ),
      CloudSyncStatus.ready => (
        Icons.cloud_done_outlined,
        'Cloud sync is active',
        'Changes are shared automatically while online.',
      ),
      CloudSyncStatus.syncing => (
        Icons.sync,
        'Synchronizing',
        'Updating records across connected devices.',
      ),
      CloudSyncStatus.error => (
        Icons.cloud_off_outlined,
        'Sync needs attention',
        sync.lastError ?? 'Try again when the connection is available.',
      ),
    };
    return Card(
      child: ListTile(
        leading: busy || sync.status == CloudSyncStatus.syncing
            ? const SizedBox.square(
                dimension: 24,
                child: CircularProgressIndicator(strokeWidth: 2),
              )
            : Icon(icon),
        title: Text(title),
        subtitle: Text(message),
      ),
    );
  }
}

class _Section extends StatelessWidget {
  final String title;
  final IconData icon;
  final List<Widget> children;
  const _Section({
    required this.title,
    required this.icon,
    required this.children,
  });

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      Row(
        children: [
          Icon(icon, size: 20),
          const SizedBox(width: 8),
          Expanded(
            child: Text(title, style: Theme.of(context).textTheme.titleLarge),
          ),
        ],
      ),
      const SizedBox(height: 14),
      ...children,
    ],
  );
}
