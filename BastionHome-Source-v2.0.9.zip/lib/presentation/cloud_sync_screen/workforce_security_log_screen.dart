import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../services/cloud_sync_service.dart';
import '../../widgets/app_back_button.dart';

class WorkforceSecurityLogScreen extends StatefulWidget {
  final String userId;
  final String username;
  final String displayName;

  const WorkforceSecurityLogScreen({
    required this.userId,
    required this.username,
    required this.displayName,
    super.key,
  });

  @override
  State<WorkforceSecurityLogScreen> createState() =>
      _WorkforceSecurityLogScreenState();
}

class _WorkforceSecurityLogScreenState
    extends State<WorkforceSecurityLogScreen> {
  List<Map<String, dynamic>> _events = const [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final events = await CloudSyncService().getSecurityEvents(
        userId: widget.userId,
      );
      if (!mounted) return;
      setState(() {
        _events = events;
        _loading = false;
        _error = null;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = error.toString().replaceFirst('Bad state: ', '');
      });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      leading: const AppBackButton(),
      title: const Text('Account Security Log'),
      actions: [
        IconButton(
          tooltip: 'Refresh security log',
          onPressed: _loading ? null : _load,
          icon: const Icon(Icons.refresh),
        ),
      ],
    ),
    body: _loading
        ? const Center(child: CircularProgressIndicator())
        : _error != null
        ? Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Text(_error!),
            ),
          )
        : RefreshIndicator(
            onRefresh: _load,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
              children: [
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const CircleAvatar(
                    child: Icon(Icons.badge_outlined),
                  ),
                  title: Text(widget.displayName),
                  subtitle: Text('@${widget.username}'),
                ),
                const SizedBox(height: 8),
                if (_events.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24),
                    child: Text('No account security changes recorded.'),
                  )
                else
                  for (final event in _events)
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: Icon(
                        _eventIcon(event['event_type']?.toString()),
                      ),
                      title: Text(_eventLabel(event['event_type']?.toString())),
                      subtitle: Text(_eventDetail(event)),
                    ),
                const Divider(height: 28),
                const Text(
                  'Passwords are never stored in this log. It records only security actions, the affected account, and the time.',
                ),
              ],
            ),
          ),
  );

  String _formatDate(dynamic value) {
    final parsed = DateTime.tryParse(value?.toString() ?? '');
    if (parsed == null) return 'Time unavailable';
    return DateFormat('d MMM yyyy, h:mm a').format(parsed.toLocal());
  }

  IconData _eventIcon(String? type) => switch (type) {
    'account_created' => Icons.person_add_alt_1,
    'password_changed' => Icons.password_outlined,
    'password_reset_by_owner' => Icons.lock_reset_outlined,
    'account_deleted' => Icons.person_remove_outlined,
    'permission_denied' => Icons.block_outlined,
    'settings_access_attempt' => Icons.settings_outlined,
    'failed_pin_lockout' => Icons.lock_clock_outlined,
    'role_mismatch' => Icons.admin_panel_settings_outlined,
    _ => Icons.security_outlined,
  };

  String _eventLabel(String? type) => switch (type) {
    'account_created' => 'Account created by owner',
    'password_changed' => 'Password changed by employee',
    'password_reset_by_owner' => 'Temporary password issued by owner',
    'account_deleted' => 'Account deleted by owner',
    'permission_denied' => 'Restricted action was denied',
    'settings_access_attempt' => 'Administrator settings access was denied',
    'failed_pin_lockout' => 'Account locked after failed PIN attempts',
    'role_mismatch' => 'Attempted to use a different local role',
    _ => 'Security setting changed',
  };

  String _eventDetail(Map<String, dynamic> event) {
    final metadata = event['metadata'];
    final resource = metadata is Map
        ? metadata['resource']?.toString().replaceAll('_', ' ')
        : null;
    final time = _formatDate(event['created_at']);
    return resource == null || resource.isEmpty ? time : '$resource · $time';
  }
}
