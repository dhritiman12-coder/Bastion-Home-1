import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../models/app_user.dart';
import '../../services/cloud_sync_service.dart';
import '../../services/workforce_credential_policy.dart';
import '../../widgets/app_back_button.dart';
import '../../widgets/credential_text_form_field.dart';
import 'workforce_security_log_screen.dart';

class WorkspaceAccessScreen extends StatefulWidget {
  const WorkspaceAccessScreen({super.key});

  @override
  State<WorkspaceAccessScreen> createState() => _WorkspaceAccessScreenState();
}

class _WorkspaceAccessScreenState extends State<WorkspaceAccessScreen> {
  final _sync = CloudSyncService();
  List<Map<String, dynamic>> _members = const [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (mounted) setState(() => _loading = true);
    try {
      final members = await _sync.getWorkspaceMembers();
      if (!mounted) return;
      setState(() {
        _members = members;
        _loading = false;
        _error = null;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = _cleanError(error);
      });
    }
  }

  String _cleanError(Object error) => error
      .toString()
      .replaceFirst('Bad state: ', '')
      .replaceFirst('PostgrestException(message: ', '')
      .replaceFirst(RegExp(r', code:.*$'), '');

  Future<void> _createAccount() async {
    final created = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const _CloudAccountEditorDialog(),
    );
    if (created == true) await _load();
  }

  Future<void> _resetPassword(Map<String, dynamic> member) async {
    final password = TextEditingController();
    final confirm = TextEditingController();
    final formKey = GlobalKey<FormState>();
    final accepted = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Issue Temporary Password'),
        content: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'The employee must replace this password at the next sign-in.',
              ),
              const SizedBox(height: 14),
              CredentialTextFormField(
                controller: password,
                labelText: 'Temporary password',
                secret: true,
                validator: (value) =>
                    WorkforceCredentialPolicy.passwordError(value ?? ''),
              ),
              const SizedBox(height: 12),
              CredentialTextFormField(
                controller: confirm,
                labelText: 'Confirm password',
                secret: true,
                validator: (value) =>
                    value == password.text ? null : 'Passwords do not match',
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (formKey.currentState!.validate()) {
                Navigator.pop(dialogContext, true);
              }
            },
            child: const Text('Reset Password'),
          ),
        ],
      ),
    );
    try {
      if (accepted == true) {
        setState(() => _loading = true);
        await _sync.resetManagedCloudPassword(
          userId: member['user_id'] as String,
          temporaryPassword: password.text,
        );
        await _load();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Temporary password issued')),
          );
        }
      }
    } catch (error) {
      if (mounted) {
        setState(() => _loading = false);
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(_cleanError(error))));
      }
    } finally {
      password.dispose();
      confirm.dispose();
    }
  }

  Future<void> _deleteAccount(Map<String, dynamic> member) async {
    final name = member['display_name']?.toString() ?? 'This account';
    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        icon: Icon(
          Icons.person_remove_outlined,
          color: Theme.of(dialogContext).colorScheme.error,
        ),
        title: const Text('Delete cloud account?'),
        content: Text(
          '$name will lose cloud access. Their business records and security history will be kept.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Delete Account'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    setState(() => _loading = true);
    try {
      await _sync.deleteManagedCloudAccount(member['user_id'] as String);
      await _load();
    } catch (error) {
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(_cleanError(error))));
    }
  }

  Future<void> _openSecurityLog(Map<String, dynamic> member) async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute(
        builder: (_) => WorkforceSecurityLogScreen(
          userId: member['user_id'] as String,
          username: member['username']?.toString() ?? '',
          displayName: member['display_name']?.toString() ?? 'Staff account',
        ),
      ),
    );
  }

  Future<void> _changeStatus(Map<String, dynamic> member) async {
    final active = member['active'] as bool? ?? true;
    final name = member['display_name']?.toString().trim();
    final nextActive = !active;
    if (!nextActive) {
      final confirmed = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => AlertDialog(
          icon: Icon(
            Icons.person_off_outlined,
            color: Theme.of(dialogContext).colorScheme.error,
          ),
          title: const Text('Disable business access?'),
          content: Text(
            '${name?.isNotEmpty == true ? name : 'This account'} will be blocked from opening or synchronizing business data on connected phones. You can restore access later.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Disable Access'),
            ),
          ],
        ),
      );
      if (confirmed != true) return;
    }
    await _update(
      member,
      active: nextActive,
      permissions: _permissions(member),
    );
  }

  Future<void> _editPermissions(Map<String, dynamic> member) async {
    var selected = _permissions(member);
    final saved = await showDialog<Set<String>>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Employee Permissions'),
          content: SizedBox(
            width: 520,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  for (final permission in AppPermission.values)
                    CheckboxListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(permission.label),
                      subtitle: employeeCorePermissions.contains(permission)
                          ? const Text('Required for every active employee')
                          : null,
                      value: selected.contains(permission.name),
                      onChanged: employeeCorePermissions.contains(permission)
                          ? null
                          : (value) => setDialogState(() {
                              if (value == true) {
                                selected = {...selected, permission.name};
                              } else {
                                selected = {...selected}
                                  ..remove(permission.name);
                              }
                            }),
                    ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, selected),
              child: const Text('Save Permissions'),
            ),
          ],
        ),
      ),
    );
    if (saved == null) return;
    await _update(
      member,
      active: member['active'] as bool? ?? true,
      permissions: saved,
    );
  }

  Set<String> _permissions(Map<String, dynamic> member) {
    final permissions = Set<String>.from(
      member['permissions'] as List? ?? const [],
    );
    if (member['role'] == 'employee') {
      permissions.addAll(employeeCorePermissions.map((item) => item.name));
    }
    return permissions;
  }

  Future<void> _update(
    Map<String, dynamic> member, {
    required bool active,
    required Set<String> permissions,
  }) async {
    setState(() => _loading = true);
    try {
      await _sync.updateMemberAccess(
        userId: member['user_id'] as String,
        active: active,
        permissions: member['role'] == 'employee'
            ? ({...permissions}
                ..addAll(employeeCorePermissions.map((item) => item.name)))
            : permissions,
      );
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Workspace access updated')),
        );
      }
    } catch (error) {
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(_cleanError(error))));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      leading: const AppBackButton(),
      title: const Text('Business Access'),
      actions: [
        IconButton(
          tooltip: 'Refresh accounts',
          onPressed: _loading ? null : _load,
          icon: const Icon(Icons.refresh),
        ),
      ],
    ),
    floatingActionButton: _sync.isPrimaryCloudAdmin
        ? FloatingActionButton.extended(
            onPressed: _loading ? null : _createAccount,
            icon: const Icon(Icons.person_add_alt_1),
            label: const Text('Create Account'),
          )
        : null,
    body: _loading && _members.isEmpty
        ? const Center(child: CircularProgressIndicator())
        : _error != null
        ? _ErrorState(message: _error!, onRetry: _load)
        : RefreshIndicator(
            onRefresh: _load,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 96),
              children: [
                Text(
                  _sync.isPrimaryCloudAdmin
                      ? 'You are the protected primary owner. Only you can change administrator and employee access.'
                      : 'Only the primary owner can change access. You can review the currently authorized accounts.',
                ),
                const SizedBox(height: 16),
                for (final member in _members) _memberTile(member),
              ],
            ),
          ),
  );

  Widget _memberTile(Map<String, dynamic> member) {
    final role = member['role']?.toString() ?? 'employee';
    final active = member['active'] as bool? ?? true;
    final isPrimary = role == 'primary_admin';
    final isEmployee = role == 'employee';
    final canControl = _sync.isPrimaryCloudAdmin && !isPrimary;
    final name = member['display_name']?.toString().trim();
    final username = member['username']?.toString().trim();
    final changedAt = DateTime.tryParse(
      member['password_changed_at']?.toString() ?? '',
    );
    final mustChange = member['must_change_password'] as bool? ?? false;
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 12, 10, 12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(
              child: Icon(
                isPrimary
                    ? Icons.verified_user_outlined
                    : isEmployee
                    ? Icons.badge_outlined
                    : Icons.admin_panel_settings_outlined,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name?.isNotEmpty == true ? name! : 'Unnamed account',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${_roleLabel(role)} • ${active ? 'Active' : 'Disabled'}',
                  ),
                  if (username?.isNotEmpty == true)
                    Text(
                      '@$username',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  if (mustChange)
                    Text(
                      'Temporary password must be changed',
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.error,
                      ),
                    )
                  else if (changedAt != null)
                    Text(
                      'Password changed ${DateFormat('d MMM yyyy, h:mm a').format(changedAt.toLocal())}',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  if (isEmployee) ...[
                    const SizedBox(height: 6),
                    Text(
                      _permissions(member).isEmpty
                          ? 'No operational permissions'
                          : _permissions(
                              member,
                            ).map(_permissionLabel).join(', '),
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ],
              ),
            ),
            if (canControl)
              PopupMenuButton<String>(
                tooltip: 'Account controls',
                onSelected: (action) {
                  if (action == 'permissions') _editPermissions(member);
                  if (action == 'status') _changeStatus(member);
                  if (action == 'security') _openSecurityLog(member);
                  if (action == 'reset') _resetPassword(member);
                  if (action == 'delete') _deleteAccount(member);
                },
                itemBuilder: (context) => [
                  if (isEmployee)
                    const PopupMenuItem(
                      value: 'permissions',
                      child: Text('Edit permissions'),
                    ),
                  PopupMenuItem(
                    value: 'status',
                    child: Text(active ? 'Disable access' : 'Restore access'),
                  ),
                  if (username?.isNotEmpty == true) ...[
                    const PopupMenuItem(
                      value: 'security',
                      child: Text('Security log'),
                    ),
                    const PopupMenuItem(
                      value: 'reset',
                      child: Text('Reset password'),
                    ),
                    const PopupMenuItem(
                      value: 'delete',
                      child: Text('Delete account'),
                    ),
                  ],
                ],
              ),
          ],
        ),
      ),
    );
  }

  String _roleLabel(String role) => switch (role) {
    'primary_admin' => 'Primary owner',
    'backup_admin' => 'Backup administrator',
    'admin' => 'Administrator',
    _ => 'Employee',
  };

  String _permissionLabel(String value) {
    for (final permission in AppPermission.values) {
      if (permission.name == value) return permission.label;
    }
    return value;
  }
}

class _CloudAccountEditorDialog extends StatefulWidget {
  const _CloudAccountEditorDialog();

  @override
  State<_CloudAccountEditorDialog> createState() =>
      _CloudAccountEditorDialogState();
}

class _CloudAccountEditorDialogState extends State<_CloudAccountEditorDialog> {
  final _formKey = GlobalKey<FormState>();
  final _displayName = TextEditingController();
  final _username = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  String _role = 'employee';
  final Set<String> _permissions = {
    AppPermission.createBookings.name,
    AppPermission.viewOccupancy.name,
    AppPermission.recordExpenses.name,
  };
  bool _saving = false;

  @override
  void dispose() {
    _displayName.dispose();
    _username.dispose();
    _password.dispose();
    _confirm.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      await CloudSyncService().createManagedCloudAccount(
        username: _username.text,
        displayName: _displayName.text,
        temporaryPassword: _password.text,
        role: _role,
        permissions: _permissions,
      );
      if (mounted) Navigator.pop(context, true);
    } catch (error) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            error
                .toString()
                .replaceFirst('Bad state: ', '')
                .replaceFirst('Invalid argument(s): ', ''),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('Create Cloud Account'),
    content: SizedBox(
      width: 520,
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: _displayName,
                textCapitalization: TextCapitalization.words,
                decoration: const InputDecoration(labelText: 'Employee name'),
                validator: (value) => (value?.trim().length ?? 0) >= 2
                    ? null
                    : 'Enter the employee name',
              ),
              const SizedBox(height: 12),
              CredentialTextFormField(
                controller: _username,
                labelText: 'Sign-in username',
                helperText: 'Letters, numbers, dots, dashes, or underscores',
                validator: (value) =>
                    WorkforceCredentialPolicy.isValidUsername(value ?? '')
                    ? null
                    : 'Enter a valid 3 to 40 character username',
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                initialValue: _role,
                decoration: const InputDecoration(labelText: 'Account type'),
                items: const [
                  DropdownMenuItem(value: 'employee', child: Text('Employee')),
                  DropdownMenuItem(
                    value: 'admin',
                    child: Text('Administrator'),
                  ),
                  DropdownMenuItem(
                    value: 'backup_admin',
                    child: Text('Backup administrator'),
                  ),
                ],
                onChanged: (value) =>
                    setState(() => _role = value ?? 'employee'),
              ),
              const SizedBox(height: 12),
              CredentialTextFormField(
                controller: _password,
                labelText: 'Temporary password',
                helperText:
                    '10+ characters with uppercase, lowercase, and a number',
                secret: true,
                validator: (value) =>
                    WorkforceCredentialPolicy.passwordError(value ?? ''),
              ),
              const SizedBox(height: 12),
              CredentialTextFormField(
                controller: _confirm,
                labelText: 'Confirm temporary password',
                secret: true,
                validator: (value) =>
                    value == _password.text ? null : 'Passwords do not match',
              ),
              if (_role == 'employee') ...[
                const Divider(height: 28),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Employee permissions',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
                for (final permission in AppPermission.values)
                  CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    title: Text(permission.label),
                    subtitle: employeeCorePermissions.contains(permission)
                        ? const Text('Required for every active employee')
                        : null,
                    value: _permissions.contains(permission.name),
                    onChanged: employeeCorePermissions.contains(permission)
                        ? null
                        : (selected) => setState(() {
                            if (selected == true) {
                              _permissions.add(permission.name);
                            } else {
                              _permissions.remove(permission.name);
                            }
                          }),
                  ),
              ] else
                const Padding(
                  padding: EdgeInsets.only(top: 16),
                  child: Text(
                    'Administrators receive full operational access. Only the primary owner can manage their account.',
                  ),
                ),
            ],
          ),
        ),
      ),
    ),
    actions: [
      TextButton(
        onPressed: _saving ? null : () => Navigator.pop(context),
        child: const Text('Cancel'),
      ),
      FilledButton.icon(
        onPressed: _saving ? null : _save,
        icon: const Icon(Icons.person_add_alt_1),
        label: Text(_saving ? 'Creating...' : 'Create Account'),
      ),
    ],
  );
}

class _ErrorState extends StatelessWidget {
  final String message;
  final Future<void> Function() onRetry;
  const _ErrorState({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.cloud_off_outlined, size: 42),
          const SizedBox(height: 12),
          Text(message, textAlign: TextAlign.center),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: onRetry,
            icon: const Icon(Icons.refresh),
            label: const Text('Try Again'),
          ),
        ],
      ),
    ),
  );
}
