import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../database/repositories/booking_repository.dart';
import '../../core/app_constants.dart';
import '../../models/booking_model.dart';
import '../../models/app_user.dart';
import '../../services/account_service.dart';
import '../../services/cloud_sync_service.dart';
import '../../services/data_change_service.dart';
import '../../utils/currency_formatter.dart';
import '../bookings_screen/enhanced_booking_form_screen.dart';

class OccupancyScreen extends StatefulWidget {
  final bool employeeMode;
  const OccupancyScreen({super.key, this.employeeMode = false});

  @override
  State<OccupancyScreen> createState() => _OccupancyScreenState();
}

class _OccupancyScreenState extends State<OccupancyScreen> {
  final BookingRepository _repo = BookingRepository();
  final ScrollController _horizontalController = ScrollController();
  DateTime _selectedMonth = DateTime(DateTime.now().year, DateTime.now().month);
  List<BookingModel> _bookings = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
    DataChangeService().addListener(_handleDataChange);
  }

  @override
  void dispose() {
    DataChangeService().removeListener(_handleDataChange);
    _horizontalController.dispose();
    super.dispose();
  }

  void _handleDataChange() {
    if (mounted) _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final bookings = await _repo.getBookingsForOccupancy(
        _selectedMonth.year,
        _selectedMonth.month,
      );
      if (!mounted) return;
      setState(() {
        _bookings = bookings;
        _isLoading = false;
      });
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  int get _daysInMonth {
    return DateTime(_selectedMonth.year, _selectedMonth.month + 1, 0).day;
  }

  // Returns booking occupying given room on given day, or null
  BookingModel? _bookingForRoomDay(String room, int day) {
    final date = DateTime(_selectedMonth.year, _selectedMonth.month, day);
    for (final b in _bookings) {
      if (b.roomLabel == room &&
          !b.checkin.isAfter(date) &&
          b.checkout.isAfter(date)) {
        return b;
      }
    }
    return null;
  }

  void _previousMonth() {
    setState(() {
      _selectedMonth = DateTime(_selectedMonth.year, _selectedMonth.month - 1);
    });
    _loadData();
  }

  void _nextMonth() {
    setState(() {
      _selectedMonth = DateTime(_selectedMonth.year, _selectedMonth.month + 1);
    });
    _loadData();
  }

  Future<void> _openNewBooking(String room, int day) async {
    final account = AccountService();
    final user = account.currentUser;
    final cloud = CloudSyncService();
    if (!await cloud.verifyActiveMembership()) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Cloud access could not be verified. Check the connection and sign in again.',
            ),
          ),
        );
      }
      return;
    }
    if (user == null || !account.can(AppPermission.createBookings)) {
      await cloud.reportSecurityEvent(
        'permission_denied',
        resource: 'occupancy',
        attemptedAction: 'create_booking_from_chart',
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Booking access is not enabled.')),
        );
      }
      return;
    }
    if (!mounted) return;
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => EnhancedBookingFormScreen(
          createdBy: account.currentAuditLabel,
          initialRoom: room,
          initialCheckin: DateTime(
            _selectedMonth.year,
            _selectedMonth.month,
            day,
          ),
        ),
      ),
    );
    if (saved == true) {
      await CloudSyncService().syncNow();
      await _loadData();
    }
  }

  void _showBookingDetail(BookingModel booking) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _BookingDetailSheet(
        booking: booking,
        showFinancials: !widget.employeeMode,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF0D1F25) : const Color(0xFFF7F4EE);
    final cardColor = isDark ? const Color(0xFF123F34) : Colors.white;
    final inkColor = isDark ? Colors.white : const Color(0xFF0E332B);
    final accentColor = const Color(0xFF8E2A18);
    final occupiedColor = const Color(0xFF123F34);

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: isDark
            ? const Color(0xFF0E332B)
            : const Color(0xFF123F34),
        elevation: 0,
        title: Text(
          'Occupancy',
          style: theme.textTheme.titleLarge?.copyWith(color: Colors.white),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            tooltip: 'Refresh occupancy',
            onPressed: _loadData,
            icon: const Icon(Icons.refresh_rounded, color: Colors.white),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: accentColor.withAlpha(80)),
        ),
      ),
      body: Column(
        children: [
          // Month selector
          Container(
            color: isDark ? const Color(0xFF0E332B) : const Color(0xFF123F34),
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: const Icon(Icons.chevron_left, color: Colors.white),
                  onPressed: _previousMonth,
                ),
                Text(
                  DateFormatter.monthYear(_selectedMonth),
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18.0,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.chevron_right, color: Colors.white),
                  onPressed: _nextMonth,
                ),
              ],
            ),
          ),
          // Legend
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
            child: Row(
              children: [
                Container(
                  width: 14,
                  height: 14,
                  decoration: BoxDecoration(
                    color: occupiedColor,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
                SizedBox(width: 2.w),
                Text(
                  'Occupied',
                  style: TextStyle(fontSize: 13.0, color: inkColor),
                ),
                SizedBox(width: 4.w),
                Container(
                  width: 14,
                  height: 14,
                  decoration: BoxDecoration(
                    color: isDark ? Colors.white12 : Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
                SizedBox(width: 2.w),
                Text(
                  'Vacant',
                  style: TextStyle(fontSize: 13.0, color: inkColor),
                ),
                const Spacer(),
                Text(
                  'Tap cell for details',
                  style: TextStyle(
                    fontSize: 12.0,
                    color: inkColor.withAlpha(120),
                  ),
                ),
              ],
            ),
          ),
          // Grid
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : SingleChildScrollView(
                    child: Padding(
                      padding: EdgeInsets.only(
                        left: 2.w,
                        right: 2.w,
                        bottom: 2.h,
                      ),
                      child: _buildImprovedGrid(
                        cardColor,
                        occupiedColor,
                        inkColor,
                        isDark,
                      ),
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  // Kept for compatibility with older saved widget states during hot restart.
  // ignore: unused_element
  Widget _buildGrid(
    Color cardColor,
    Color occupiedColor,
    Color inkColor,
    bool isDark,
  ) {
    final rooms = AppConstants.rooms;
    const cellW = 52.0;
    const cellH = 44.0;
    const labelW = 70.0;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header row with day numbers
        Row(
          children: [
            SizedBox(width: labelW),
            ...List.generate(_daysInMonth, (i) {
              final day = i + 1;
              final date = DateTime(
                _selectedMonth.year,
                _selectedMonth.month,
                day,
              );
              final isWeekend = date.weekday == 6 || date.weekday == 7;
              return Container(
                width: cellW,
                height: 28,
                alignment: Alignment.center,
                child: Text(
                  day.toString(),
                  style: TextStyle(
                    fontSize: 12.0,
                    fontWeight: FontWeight.w600,
                    color: isWeekend
                        ? const Color(0xFF8E2A18)
                        : inkColor.withAlpha(160),
                  ),
                ),
              );
            }),
          ],
        ),
        // Room rows
        ...rooms.map((room) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Row(
              children: [
                // Room label
                Container(
                  width: labelW,
                  height: cellH,
                  alignment: Alignment.centerLeft,
                  padding: const EdgeInsets.only(left: 4),
                  child: Text(
                    room,
                    style: TextStyle(
                      fontSize: 13.0,
                      fontWeight: FontWeight.w600,
                      color: inkColor,
                    ),
                  ),
                ),
                // Day cells
                ...List.generate(_daysInMonth, (i) {
                  final day = i + 1;
                  final booking = _bookingForRoomDay(room, day);
                  final isOccupied = booking != null;
                  // Check if this is the checkout day (show as vacant)
                  final date = DateTime(
                    _selectedMonth.year,
                    _selectedMonth.month,
                    day,
                  );
                  final isCheckout =
                      booking != null &&
                      booking.checkout.year == date.year &&
                      booking.checkout.month == date.month &&
                      booking.checkout.day == date.day;

                  final effectivelyOccupied = isOccupied && !isCheckout;

                  return GestureDetector(
                    onTap: effectivelyOccupied
                        ? () => _showBookingDetail(booking)
                        : null,
                    child: Container(
                      width: cellW,
                      height: cellH,
                      margin: const EdgeInsets.symmetric(horizontal: 1),
                      decoration: BoxDecoration(
                        color: effectivelyOccupied
                            ? occupiedColor
                            : (isDark ? Colors.white10 : Colors.grey.shade100),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                          color: effectivelyOccupied
                              ? occupiedColor.withAlpha(200)
                              : Colors.grey.withAlpha(40),
                          width: 0.5,
                        ),
                      ),
                      alignment: Alignment.center,
                      child: effectivelyOccupied
                          ? Text(
                              _initials(booking.guest),
                              style: TextStyle(
                                fontSize: 12.0,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                              ),
                              overflow: TextOverflow.ellipsis,
                            )
                          : null,
                    ),
                  );
                }),
              ],
            ),
          );
        }),
      ],
    );
  }

  Widget _buildImprovedGrid(
    Color cardColor,
    Color occupiedColor,
    Color inkColor,
    bool isDark,
  ) {
    const cellW = 52.0;
    const rowH = 58.0;
    const headerH = 50.0;
    const labelW = 104.0;
    final theme = Theme.of(context);
    final colors = theme.colorScheme;
    final rooms = AppConstants.rooms;
    final now = DateTime.now();
    final canCreate = AccountService().can(AppPermission.createBookings);
    var occupiedRoomNights = 0;
    for (final room in rooms) {
      for (var day = 1; day <= _daysInMonth; day++) {
        if (_bookingForRoomDay(room, day) != null) occupiedRoomNights++;
      }
    }
    final totalRoomNights = rooms.length * _daysInMonth;
    final occupancyRate = totalRoomNights == 0
        ? 0
        : (occupiedRoomNights / totalRoomNights * 100).round();

    Widget stat(String value, String label, IconData icon) => Expanded(
      child: Container(
        constraints: const BoxConstraints(minHeight: 76),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: colors.outlineVariant),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 18, color: colors.secondary),
            const SizedBox(height: 4),
            Text(value, style: theme.textTheme.titleLarge),
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.bodySmall?.copyWith(
                color: colors.onSurfaceVariant,
              ),
            ),
          ],
        ),
      ),
    );

    return Column(
      children: [
        Row(
          children: [
            stat('$occupancyRate%', 'Occupancy', Icons.hotel_rounded),
            const SizedBox(width: 8),
            stat('${_bookings.length}', 'Bookings', Icons.event_rounded),
            const SizedBox(width: 8),
            stat('${rooms.length}', 'Rooms', Icons.meeting_room_outlined),
          ],
        ),
        const SizedBox(height: 12),
        Container(
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: colors.outlineVariant),
          ),
          clipBehavior: Clip.antiAlias,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                width: labelW,
                child: Column(
                  children: [
                    Container(
                      height: headerH,
                      alignment: Alignment.centerLeft,
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      color: colors.primaryContainer,
                      child: Text(
                        'ROOM',
                        style: theme.textTheme.labelLarge?.copyWith(
                          color: colors.onPrimaryContainer,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    for (final room in rooms)
                      Container(
                        height: rowH,
                        alignment: Alignment.centerLeft,
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        decoration: BoxDecoration(
                          color: cardColor,
                          border: Border(
                            top: BorderSide(color: colors.outlineVariant),
                            right: BorderSide(color: colors.outlineVariant),
                          ),
                        ),
                        child: Text(
                          room,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: theme.textTheme.titleMedium?.copyWith(
                            color: isDark ? Colors.white : colors.primary,
                            fontSize: 15,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              Expanded(
                child: Scrollbar(
                  controller: _horizontalController,
                  thumbVisibility: true,
                  trackVisibility: true,
                  child: SingleChildScrollView(
                    controller: _horizontalController,
                    scrollDirection: Axis.horizontal,
                    child: SizedBox(
                      width: _daysInMonth * cellW,
                      child: Column(
                        children: [
                          Row(
                            children: List.generate(_daysInMonth, (index) {
                              final day = index + 1;
                              final date = DateTime(
                                _selectedMonth.year,
                                _selectedMonth.month,
                                day,
                              );
                              final weekend = date.weekday >= 6;
                              final today = DateUtils.isSameDay(date, now);
                              const weekdays = [
                                'M',
                                'T',
                                'W',
                                'T',
                                'F',
                                'S',
                                'S',
                              ];
                              return Container(
                                width: cellW,
                                height: headerH,
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                  color: today
                                      ? colors.secondaryContainer
                                      : colors.primaryContainer.withAlpha(140),
                                  border: Border(
                                    left: BorderSide(
                                      color: colors.outlineVariant,
                                    ),
                                  ),
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      weekdays[date.weekday - 1],
                                      style: theme.textTheme.labelSmall
                                          ?.copyWith(
                                            color: weekend
                                                ? colors.secondary
                                                : colors.onPrimaryContainer,
                                            fontWeight: FontWeight.w700,
                                          ),
                                    ),
                                    Text(
                                      '$day',
                                      style: theme.textTheme.titleMedium
                                          ?.copyWith(
                                            color: colors.onPrimaryContainer,
                                            fontWeight: FontWeight.w800,
                                          ),
                                    ),
                                  ],
                                ),
                              );
                            }),
                          ),
                          for (final room in rooms)
                            Row(
                              children: List.generate(_daysInMonth, (index) {
                                final day = index + 1;
                                final date = DateTime(
                                  _selectedMonth.year,
                                  _selectedMonth.month,
                                  day,
                                );
                                final booking = _bookingForRoomDay(room, day);
                                final occupied = booking != null;
                                final today = DateUtils.isSameDay(date, now);
                                return Tooltip(
                                  message: occupied
                                      ? '${booking.guest} · ${booking.roomLabel}'
                                      : canCreate
                                      ? 'Add booking for $room'
                                      : '$room is vacant',
                                  child: InkWell(
                                    onTap: occupied
                                        ? () => _showBookingDetail(booking)
                                        : canCreate
                                        ? () => _openNewBooking(room, day)
                                        : null,
                                    child: Container(
                                      width: cellW,
                                      height: rowH,
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        color: occupied
                                            ? occupiedColor
                                            : (isDark
                                                  ? Colors.white10
                                                  : colors
                                                        .surfaceContainerHighest
                                                        .withAlpha(135)),
                                        border: Border(
                                          left: BorderSide(
                                            color: colors.outlineVariant,
                                          ),
                                          top: BorderSide(
                                            color: colors.outlineVariant,
                                          ),
                                          bottom: today
                                              ? BorderSide(
                                                  color: colors.secondary,
                                                  width: 3,
                                                )
                                              : BorderSide.none,
                                        ),
                                      ),
                                      child: occupied
                                          ? Text(
                                              _initials(booking.guest),
                                              style: theme.textTheme.labelLarge
                                                  ?.copyWith(
                                                    color: Colors.white,
                                                    fontWeight: FontWeight.w800,
                                                  ),
                                            )
                                          : canCreate
                                          ? Icon(
                                              Icons.add_rounded,
                                              size: 17,
                                              color: inkColor.withAlpha(80),
                                            )
                                          : null,
                                    ),
                                  ),
                                );
                              }),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  String _initials(String name) {
    final parts = name.trim().split(' ');
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    }
    return name.substring(0, name.length.clamp(0, 2)).toUpperCase();
  }
}

class _BookingDetailSheet extends StatelessWidget {
  final BookingModel booking;
  final bool showFinancials;
  const _BookingDetailSheet({
    required this.booking,
    required this.showFinancials,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF123F34) : Colors.white;
    final inkColor = isDark ? Colors.white : const Color(0xFF0E332B);

    Color statusColor;
    switch (booking.payStatus) {
      case PayStatus.paid:
        statusColor = const Color(0xFF3D6B4A);
        break;
      case PayStatus.partial:
        statusColor = const Color(0xFF8E2A18);
        break;
      case PayStatus.unpaid:
        statusColor = const Color(0xFFA2432F);
        break;
      default:
        statusColor = Colors.grey;
    }

    return Container(
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      padding: EdgeInsets.all(4.w),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey.withAlpha(80),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: Text(
                  booking.guest,
                  style: TextStyle(
                    fontSize: 20.0,
                    fontWeight: FontWeight.w700,
                    color: inkColor,
                  ),
                ),
              ),
              if (showFinancials)
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: statusColor.withAlpha(30),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: statusColor.withAlpha(100)),
                  ),
                  child: Text(
                    booking.payStatus.name.toUpperCase(),
                    style: TextStyle(
                      fontSize: 12.0,
                      fontWeight: FontWeight.w700,
                      color: statusColor,
                    ),
                  ),
                ),
            ],
          ),
          SizedBox(height: 0.5.h),
          Text(
            '${booking.id} · ${booking.roomLabel}',
            style: TextStyle(fontSize: 13.0, color: inkColor.withAlpha(160)),
          ),
          SizedBox(height: 2.h),
          _row('Check-in', DateFormatter.format(booking.checkin), inkColor),
          _row('Check-out', DateFormatter.format(booking.checkout), inkColor),
          _row('Nights', '${booking.nights}', inkColor),
          if (showFinancials) ...[
            _row('Total', CurrencyFormatter.format(booking.total), inkColor),
            _row(
              'Received',
              CurrencyFormatter.format(booking.received),
              inkColor,
            ),
            _row(
              'Due',
              CurrencyFormatter.format(booking.due),
              inkColor,
              valueColor: booking.due > 0
                  ? const Color(0xFFA2432F)
                  : const Color(0xFF3D6B4A),
            ),
          ],
          SizedBox(height: 2.h),
        ],
      ),
    );
  }

  Widget _row(String label, String value, Color inkColor, {Color? valueColor}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(fontSize: 14.0, color: inkColor.withAlpha(160)),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 14.0,
              fontWeight: FontWeight.w600,
              color: valueColor ?? inkColor,
            ),
          ),
        ],
      ),
    );
  }
}
