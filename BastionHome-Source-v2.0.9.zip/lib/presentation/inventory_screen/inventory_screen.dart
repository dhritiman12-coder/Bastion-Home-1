import 'package:flutter/material.dart';
import '../../widgets/app_back_button.dart';

import '../../core/app_constants.dart';
import '../../database/repositories/inventory_repository.dart';
import '../../services/app_settings_service.dart';
import '../../services/account_service.dart';
import '../../widgets/confirm_trash_dialog.dart';

class InventoryScreen extends StatefulWidget {
  const InventoryScreen({super.key});

  @override
  State<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends State<InventoryScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final InventoryRepository _repo = InventoryRepository();

  // Per-room data
  final Map<String, List<InventoryItem>> _roomItems = {};
  List<InventoryItem> _lowStockItems = [];
  bool _loading = true;
  String _selectedCategory = 'All';
  bool _showLowStockOnly = false;

  static const List<String> _categories = [
    'All',
    'Linens',
    'Toiletries',
    'Supplies',
    'Pantry',
  ];

  static const Map<String, IconData> _categoryIcons = {
    'Linens': Icons.bed_outlined,
    'Toiletries': Icons.soap_outlined,
    'Supplies': Icons.cleaning_services_outlined,
    'Pantry': Icons.kitchen_outlined,
    'All': Icons.inventory_2_outlined,
  };

  static const Map<String, Color> _categoryColors = {
    'Linens': Color(0xFF123F34),
    'Toiletries': Color(0xFF4A7C8A),
    'Supplies': Color(0xFF8E2A18),
    'Pantry': Color(0xFF3D6B4A),
    'All': Color(0xFF52645F),
  };

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: AppConstants.rooms.length + 1,
      vsync: this,
    );
    _loadData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() => _loading = true);
    try {
      final low = await _repo.getLowStockItems();
      final Map<String, List<InventoryItem>> roomData = {};
      for (final room in AppConstants.rooms) {
        roomData[room] = await _repo.getByRoom(room);
      }
      if (mounted) {
        setState(() {
          _lowStockItems = low;
          _roomItems.addAll(roomData);
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  List<InventoryItem> _filteredItems(String room) {
    final items = _roomItems[room] ?? [];
    return items.where((item) {
      final catMatch =
          _selectedCategory == 'All' || item.category == _selectedCategory;
      final lowMatch = !_showLowStockOnly || item.isLowStock;
      return catMatch && lowMatch;
    }).toList();
  }

  Future<void> _showAddEditDialog({
    InventoryItem? item,
    String? defaultRoom,
  }) async {
    final rooms = AppConstants.rooms;
    String selectedRoom = item?.room ?? defaultRoom ?? rooms.first;
    String selectedCategory = item?.category ?? 'Linens';
    final nameCtrl = TextEditingController(text: item?.itemName ?? '');
    final stockCtrl = TextEditingController(
      text: item?.currentStock.toString() ?? '0',
    );
    final minCtrl = TextEditingController(
      text: item?.minStock.toString() ?? '1',
    );
    final reorderCtrl = TextEditingController(
      text: item?.reorderQty.toString() ?? '5',
    );
    final unitCtrl = TextEditingController(
      text: item?.unit ?? AppSettingsService().defaultStockUnit,
    );
    final notesCtrl = TextEditingController(text: item?.notes ?? '');
    final formKey = GlobalKey<FormState>();

    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) {
          return AlertDialog(
            backgroundColor: const Color(0xFFFCFAF7),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            title: Text(
              item == null ? 'Add Inventory Item' : 'Edit Item',
              style: TextStyle(
                fontWeight: FontWeight.w700,
                fontSize: 16,
                color: const Color(0xFF0E332B),
              ),
            ),
            content: SizedBox(
              width: double.maxFinite,
              child: Form(
                key: formKey,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Room
                      DropdownButtonFormField<String>(
                        initialValue: selectedRoom,
                        decoration: _inputDec('Room'),
                        items: rooms
                            .map(
                              (r) => DropdownMenuItem(
                                value: r,
                                child: Text(r, style: TextStyle(fontSize: 13)),
                              ),
                            )
                            .toList(),
                        onChanged: (v) =>
                            setDialogState(() => selectedRoom = v!),
                      ),
                      const SizedBox(height: 10),
                      // Category
                      DropdownButtonFormField<String>(
                        initialValue: selectedCategory,
                        decoration: _inputDec('Category'),
                        items: ['Linens', 'Toiletries', 'Supplies', 'Pantry']
                            .map(
                              (c) => DropdownMenuItem(
                                value: c,
                                child: Text(c, style: TextStyle(fontSize: 13)),
                              ),
                            )
                            .toList(),
                        onChanged: (v) =>
                            setDialogState(() => selectedCategory = v!),
                      ),
                      const SizedBox(height: 10),
                      TextFormField(
                        controller: nameCtrl,
                        decoration: _inputDec('Item Name'),
                        style: TextStyle(fontSize: 13),
                        validator: (v) =>
                            v == null || v.trim().isEmpty ? 'Required' : null,
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              controller: stockCtrl,
                              decoration: _inputDec('Current Stock'),
                              keyboardType: TextInputType.number,
                              style: TextStyle(fontSize: 13),
                              validator: (v) {
                                final value = int.tryParse(v ?? '');
                                return value == null || value < 0
                                    ? 'Use 0 or more'
                                    : null;
                              },
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: TextFormField(
                              controller: unitCtrl,
                              decoration: _inputDec('Unit'),
                              style: TextStyle(fontSize: 13),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              controller: minCtrl,
                              decoration: _inputDec('Min Stock'),
                              keyboardType: TextInputType.number,
                              style: TextStyle(fontSize: 13),
                              validator: (v) {
                                final value = int.tryParse(v ?? '');
                                return value == null || value < 0
                                    ? 'Use 0 or more'
                                    : null;
                              },
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: TextFormField(
                              controller: reorderCtrl,
                              decoration: _inputDec('Reorder Qty'),
                              keyboardType: TextInputType.number,
                              style: TextStyle(fontSize: 13),
                              validator: (v) {
                                final value = int.tryParse(v ?? '');
                                return value == null || value < 0
                                    ? 'Use 0 or more'
                                    : null;
                              },
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      TextFormField(
                        controller: notesCtrl,
                        decoration: _inputDec('Notes (optional)'),
                        style: TextStyle(fontSize: 13),
                        maxLines: 2,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: Text(
                  'Cancel',
                  style: TextStyle(color: const Color(0xFF52645F)),
                ),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF123F34),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                onPressed: () async {
                  if (!formKey.currentState!.validate()) return;
                  final newItem = InventoryItem(
                    id: item?.id,
                    room: selectedRoom,
                    category: selectedCategory,
                    itemName: nameCtrl.text.trim(),
                    currentStock: int.parse(stockCtrl.text),
                    minStock: int.parse(minCtrl.text),
                    reorderQty: int.parse(reorderCtrl.text),
                    unit: unitCtrl.text.trim().isEmpty
                        ? 'pcs'
                        : unitCtrl.text.trim(),
                    notes: notesCtrl.text.trim(),
                    updatedAt: DateTime.now().toIso8601String(),
                  );
                  if (item == null) {
                    await _repo.insert(newItem);
                  } else {
                    await _repo.update(newItem);
                  }
                  if (ctx.mounted) Navigator.pop(ctx, true);
                },
                child: Text(
                  item == null ? 'Add' : 'Save',
                  style: TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
            ],
          );
        },
      ),
    );
    if (result == true) await _loadData();
  }

  Future<void> _adjustStock(InventoryItem item) async {
    final ctrl = TextEditingController(text: item.currentStock.toString());
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFFFCFAF7),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: Text(
          'Update Stock',
          style: TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: 15,
            color: const Color(0xFF0E332B),
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${item.itemName} · ${item.room}',
              style: TextStyle(fontSize: 13, color: const Color(0xFF52645F)),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                IconButton(
                  onPressed: () {
                    final v = int.tryParse(ctrl.text) ?? 0;
                    if (v > 0) ctrl.text = (v - 1).toString();
                  },
                  icon: const Icon(
                    Icons.remove_circle_outline,
                    color: Color(0xFFA2432F),
                  ),
                  padding: EdgeInsets.zero,
                ),
                Expanded(
                  child: TextField(
                    controller: ctrl,
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                    decoration: _inputDec(''),
                  ),
                ),
                IconButton(
                  onPressed: () {
                    final v = int.tryParse(ctrl.text) ?? 0;
                    ctrl.text = (v + 1).toString();
                  },
                  icon: const Icon(
                    Icons.add_circle_outline,
                    color: Color(0xFF123F34),
                  ),
                  padding: EdgeInsets.zero,
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              'Min: ${item.minStock} ${item.unit}  •  Reorder: ${item.reorderQty} ${item.unit}',
              style: TextStyle(fontSize: 11, color: const Color(0xFF7B8A86)),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(
              'Cancel',
              style: TextStyle(color: const Color(0xFF52645F)),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF123F34),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            onPressed: () async {
              final v = int.tryParse(ctrl.text);
              if (v == null || v < 0) return;
              await _repo.updateStock(item.id!, v);
              if (ctx.mounted) Navigator.pop(ctx, true);
            },
            child: Text(
              'Update',
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
    if (result == true) await _loadData();
  }

  Future<void> _deleteItem(InventoryItem item) async {
    if (await confirmMoveToTrash(
      context,
      itemName: '${item.itemName} from ${item.room}',
    )) {
      try {
        await _repo.delete(item.id!);
        await _loadData();
      } catch (error) {
        if (mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text(error.toString())));
        }
      }
    }
  }

  InputDecoration _inputDec(String label) => InputDecoration(
    labelText: label.isEmpty ? null : label,
    filled: true,
    fillColor: const Color(0xFFF0EEE9),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: BorderSide.none,
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: const BorderSide(color: Color(0xFFDCE4E0), width: 1),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: const BorderSide(color: Color(0xFF123F34), width: 1.5),
    ),
    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
    labelStyle: const TextStyle(color: Color(0xFF52645F), fontSize: 12),
  );

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF0D1F25) : const Color(0xFFF7F4EE);

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        leading: const AppBackButton(),
        backgroundColor: isDark
            ? const Color(0xFF0E332B)
            : const Color(0xFF123F34),
        elevation: 0,
        title: Text(
          'BASTION HOME',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20.0,
            fontWeight: FontWeight.w700,
            letterSpacing: 0,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(
              _showLowStockOnly
                  ? Icons.warning_rounded
                  : Icons.warning_amber_outlined,
              color: _showLowStockOnly
                  ? const Color(0xFFFFD54F)
                  : Colors.white70,
            ),
            tooltip: 'Low Stock Only',
            onPressed: () =>
                setState(() => _showLowStockOnly = !_showLowStockOnly),
          ),
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: Colors.white70),
            onPressed: _loadData,
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          indicatorColor: const Color(0xFF8E2A18),
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white60,
          tabAlignment: TabAlignment.start,
          labelStyle: TextStyle(fontSize: 13.0, fontWeight: FontWeight.w600),
          tabs: [
            const Tab(text: 'Alerts'),
            ...AppConstants.rooms.map((r) => Tab(text: r)),
          ],
        ),
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFF123F34)),
            )
          : Column(
              children: [
                // Category filter chips
                _buildCategoryFilter(),
                // Tab content
                Expanded(
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      _buildAlertsTab(),
                      ...AppConstants.rooms.map((r) => _buildRoomTab(r)),
                    ],
                  ),
                ),
              ],
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          final idx = _tabController.index;
          final defaultRoom = idx > 0 ? AppConstants.rooms[idx - 1] : null;
          _showAddEditDialog(defaultRoom: defaultRoom);
        },
        backgroundColor: const Color(0xFF123F34),
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }

  Widget _buildCategoryFilter() {
    return Container(
      color: const Color(0xFF123F34).withAlpha(10),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: _categories.map((cat) {
            final selected = _selectedCategory == cat;
            final color = _categoryColors[cat] ?? const Color(0xFF52645F);
            return Padding(
              padding: const EdgeInsets.only(right: 8),
              child: FilterChip(
                selected: selected,
                label: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      _categoryIcons[cat] ?? Icons.category_outlined,
                      size: 14,
                      color: selected ? Colors.white : color,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      cat,
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        color: selected ? Colors.white : color,
                      ),
                    ),
                  ],
                ),
                backgroundColor: color.withAlpha(15),
                selectedColor: color,
                checkmarkColor: Colors.white,
                showCheckmark: false,
                side: BorderSide(color: color.withAlpha(60), width: 1),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(50),
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 4,
                ),
                onSelected: (_) => setState(() => _selectedCategory = cat),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildAlertsTab() {
    final lowItems = _lowStockItems.where((item) {
      final catMatch =
          _selectedCategory == 'All' || item.category == _selectedCategory;
      return catMatch;
    }).toList();

    if (lowItems.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.check_circle_outline_rounded,
              size: 56,
              color: const Color(0xFF3D6B4A).withAlpha(180),
            ),
            const SizedBox(height: 12),
            Text(
              'All stocked up!',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: const Color(0xFF3D6B4A),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'No low-stock items across all rooms.',
              style: TextStyle(fontSize: 13, color: const Color(0xFF52645F)),
            ),
          ],
        ),
      );
    }

    // Group by room
    final Map<String, List<InventoryItem>> byRoom = {};
    for (final item in lowItems) {
      byRoom.putIfAbsent(item.room, () => []).add(item);
    }

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        // Summary banner
        Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFFA2432F).withAlpha(15),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: const Color(0xFFA2432F).withAlpha(60),
              width: 1,
            ),
          ),
          child: Row(
            children: [
              const Icon(
                Icons.warning_amber_rounded,
                color: Color(0xFFA2432F),
                size: 22,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${lowItems.length} item${lowItems.length > 1 ? 's' : ''} need restocking',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: const Color(0xFFA2432F),
                      ),
                    ),
                    Text(
                      'Across ${byRoom.length} room${byRoom.length > 1 ? 's' : ''} — tap any item to update stock',
                      style: TextStyle(
                        fontSize: 11,
                        color: const Color(0xFF52645F),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        // Items grouped by room
        ...byRoom.entries.map(
          (entry) => Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(bottom: 6, top: 4),
                child: Text(
                  entry.key,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF123F34),
                    letterSpacing: 0,
                  ),
                ),
              ),
              ...entry.value.map((item) => _buildItemCard(item, compact: true)),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildRoomTab(String room) {
    final items = _filteredItems(room);
    if (items.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.inventory_2_outlined,
              size: 48,
              color: const Color(0xFF7B8A86),
            ),
            const SizedBox(height: 10),
            Text(
              'No items found',
              style: TextStyle(fontSize: 14, color: const Color(0xFF52645F)),
            ),
          ],
        ),
      );
    }

    // Group by category
    final Map<String, List<InventoryItem>> byCategory = {};
    for (final item in items) {
      byCategory.putIfAbsent(item.category, () => []).add(item);
    }

    // Room summary stats
    final allRoomItems = _roomItems[room] ?? [];
    final lowCount = allRoomItems.where((i) => i.isLowStock).length;
    final outCount = allRoomItems.where((i) => i.isOutOfStock).length;

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        // Room stats row
        _buildRoomStatsRow(allRoomItems.length, lowCount, outCount),
        const SizedBox(height: 12),
        // Items by category
        ...byCategory.entries.map(
          (entry) => Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildCategoryHeader(entry.key),
              ...entry.value.map((item) => _buildItemCard(item)),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildRoomStatsRow(int total, int low, int out) {
    return Row(
      children: [
        _buildStatChip(
          label: 'Total',
          value: total.toString(),
          color: const Color(0xFF123F34),
          icon: Icons.inventory_2_outlined,
        ),
        const SizedBox(width: 8),
        _buildStatChip(
          label: 'Low Stock',
          value: low.toString(),
          color: low > 0 ? const Color(0xFF8E2A18) : const Color(0xFF3D6B4A),
          icon: Icons.warning_amber_outlined,
        ),
        const SizedBox(width: 8),
        _buildStatChip(
          label: 'Out of Stock',
          value: out.toString(),
          color: out > 0 ? const Color(0xFFA2432F) : const Color(0xFF3D6B4A),
          icon: Icons.remove_shopping_cart_outlined,
        ),
      ],
    );
  }

  Widget _buildStatChip({
    required String label,
    required String value,
    required Color color,
    required IconData icon,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
        decoration: BoxDecoration(
          color: color.withAlpha(15),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withAlpha(50), width: 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 16, color: color),
            const SizedBox(height: 4),
            Text(
              value,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: color,
              ),
            ),
            Text(
              label,
              style: TextStyle(fontSize: 10, color: const Color(0xFF52645F)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryHeader(String category) {
    final color = _categoryColors[category] ?? const Color(0xFF52645F);
    final icon = _categoryIcons[category] ?? Icons.category_outlined;
    return Padding(
      padding: const EdgeInsets.only(bottom: 6, top: 2),
      child: Row(
        children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 6),
          Text(
            category.toUpperCase(),
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: color,
              letterSpacing: 0,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(child: Divider(color: color.withAlpha(40), thickness: 1)),
        ],
      ),
    );
  }

  Widget _buildItemCard(InventoryItem item, {bool compact = false}) {
    final isOut = item.isOutOfStock;
    final isLow = item.isLowStock && !isOut;
    final statusColor = isOut
        ? const Color(0xFFA2432F)
        : isLow
        ? const Color(0xFF8E2A18)
        : const Color(0xFF3D6B4A);
    final statusLabel = isOut
        ? 'OUT'
        : isLow
        ? 'LOW'
        : 'OK';
    final catColor = _categoryColors[item.category] ?? const Color(0xFF52645F);

    // Stock progress
    final maxStock = (item.minStock * 3).clamp(item.currentStock + 1, 999);
    final progress = (item.currentStock / maxStock).clamp(0.0, 1.0);

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      color: const Color(0xFFFFFFFF),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
        side: BorderSide(
          color: (isOut || isLow)
              ? statusColor.withAlpha(80)
              : const Color(0xFFEAE4DC),
          width: isOut ? 1.5 : 1,
        ),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: () => _adjustStock(item),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  // Category dot
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: catColor,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      item.itemName,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFF0E332B),
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  // Status badge
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: statusColor.withAlpha(20),
                      borderRadius: BorderRadius.circular(50),
                      border: Border.all(
                        color: statusColor.withAlpha(80),
                        width: 1,
                      ),
                    ),
                    child: Text(
                      statusLabel,
                      style: TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.w700,
                        color: statusColor,
                        letterSpacing: 0,
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  // Edit
                  GestureDetector(
                    onTap: () => _showAddEditDialog(item: item),
                    child: const Icon(
                      Icons.edit_outlined,
                      size: 16,
                      color: Color(0xFF7B8A86),
                    ),
                  ),
                  if (AccountService().isAdmin) ...[
                    const SizedBox(width: 6),
                    GestureDetector(
                      onTap: () => _deleteItem(item),
                      child: const Icon(
                        Icons.delete_outline,
                        size: 16,
                        color: Color(0xFFA2432F),
                      ),
                    ),
                  ],
                ],
              ),
              const SizedBox(height: 8),
              // Stock bar
              Row(
                children: [
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: progress,
                        minHeight: 6,
                        backgroundColor: const Color(0xFFEAE4DC),
                        valueColor: AlwaysStoppedAnimation<Color>(statusColor),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    '${item.currentStock} ${item.unit}',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: statusColor,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Row(
                children: [
                  Text(
                    'Min: ${item.minStock} ${item.unit}',
                    style: TextStyle(
                      fontSize: 10,
                      color: const Color(0xFF7B8A86),
                    ),
                  ),
                  const SizedBox(width: 10),
                  if (isLow || isOut)
                    Row(
                      children: [
                        Icon(
                          Icons.shopping_cart_outlined,
                          size: 11,
                          color: statusColor,
                        ),
                        const SizedBox(width: 3),
                        Text(
                          'Reorder: ${item.reorderQty} ${item.unit}',
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            color: statusColor,
                          ),
                        ),
                      ],
                    ),
                  if (compact) ...[
                    const Spacer(),
                    Text(
                      item.room,
                      style: TextStyle(
                        fontSize: 10,
                        color: const Color(0xFF123F34),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ],
              ),
              if (item.notes.isNotEmpty) ...[
                const SizedBox(height: 4),
                Text(
                  item.notes,
                  style: TextStyle(
                    fontSize: 10,
                    color: const Color(0xFF7B8A86),
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
