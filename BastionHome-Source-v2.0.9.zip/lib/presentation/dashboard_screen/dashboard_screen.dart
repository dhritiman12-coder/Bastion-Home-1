import 'package:flutter/material.dart';

import '../../database/repositories/booking_repository.dart';
import '../../database/repositories/payment_repository.dart';
import '../../database/repositories/expense_repository.dart';
import '../../models/booking_model.dart';
import '../../theme/app_theme.dart';
import '../../utils/currency_formatter.dart';
import '../../services/booking_serial_service.dart';
import '../../services/data_change_service.dart';
import '../../widgets/brand_logo.dart';
import '../bookings_screen/enhanced_booking_form_screen.dart';
import '../payments_screen/payments_screen.dart';
import './widgets/cost_summary_row_widget.dart';
import './widgets/dashboard_metrics_grid_widget.dart';
import './widgets/reporting_month_selector_widget.dart';
import './widgets/room_status_list_widget.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final BookingRepository _bookingRepo = BookingRepository();
  final PaymentRepository _paymentRepo = PaymentRepository();
  final ExpenseRepository _expenseRepo = ExpenseRepository();
  final BookingSerialService _serialService = BookingSerialService();

  DateTime _reportingMonth = DateTime(
    DateTime.now().year,
    DateTime.now().month,
  );
  bool _isLoading = true;
  int _loadGeneration = 0;

  List<BookingModel> _allBookings = [];
  double _paymentsReceivedMonth = 0;
  double _dailyExpensesMonth = 0;
  double _monthlyRecurringTotal = 0;
  double _yearlyRecurringTotal = 0;
  int _monthSerialCount = 0;

  @override
  void initState() {
    super.initState();
    _loadData(showLoading: true);
    DataChangeService().addListener(_handleDataChange);
  }

  @override
  void dispose() {
    DataChangeService().removeListener(_handleDataChange);
    super.dispose();
  }

  void _handleDataChange() {
    if (mounted) _loadData();
  }

  Future<void> _loadData({bool showLoading = false}) async {
    final generation = ++_loadGeneration;
    if (showLoading && mounted && !_isLoading) {
      setState(() => _isLoading = true);
    }
    try {
      final bookings = await _bookingRepo.getAllBookings();
      final paymentsReceived = await _paymentRepo.getTotalReceivedForMonth(
        _reportingMonth.year,
        _reportingMonth.month,
      );
      final dailyExpenses = await _expenseRepo.getDailyExpensesTotalForMonth(
        _reportingMonth.year,
        _reportingMonth.month,
      );
      final monthlyTotal = await _expenseRepo.getMonthlyExpensesTotal();
      final yearlyTotal = await _expenseRepo.getYearlyExpensesTotal();
      final serialCount = await _serialService.getCurrentCount(DateTime.now());

      if (!mounted || generation != _loadGeneration) return;
      setState(() {
        _allBookings = bookings;
        _paymentsReceivedMonth = paymentsReceived;
        _dailyExpensesMonth = dailyExpenses;
        _monthlyRecurringTotal = monthlyTotal;
        _yearlyRecurringTotal = yearlyTotal;
        _monthSerialCount = serialCount;
        _isLoading = false;
      });
    } catch (e) {
      if (mounted && generation == _loadGeneration) {
        setState(() => _isLoading = false);
      }
    }
  }

  // ── Dashboard Calculations ─────────────────────────────────────────────────

  DateTime get _firstDayOfMonth =>
      DateTime(_reportingMonth.year, _reportingMonth.month, 1);

  DateTime get _firstDayOfNextMonth =>
      DateTime(_reportingMonth.year, _reportingMonth.month + 1, 1);

  int get _daysInMonth =>
      _firstDayOfNextMonth.difference(_firstDayOfMonth).inDays;

  int _roomNightsInMonth(BookingModel b) {
    if (b.status == BookingStatus.cancelled) return 0;
    final start = b.checkin.isAfter(_firstDayOfMonth)
        ? b.checkin
        : _firstDayOfMonth;
    final end = b.checkout.isBefore(_firstDayOfNextMonth)
        ? b.checkout
        : _firstDayOfNextMonth;
    final nights = end.difference(start).inDays;
    return nights < 0 ? 0 : nights;
  }

  int get _occupiedRoomsToday {
    final today = DateTime.now();
    return _allBookings.where((b) {
      return b.status != BookingStatus.cancelled &&
          !b.checkin.isAfter(today) &&
          b.checkout.isAfter(today);
    }).length;
  }

  double get _occupancyTodayPct => (_occupiedRoomsToday / 5) * 100;

  double get _occupancyRateMonth {
    final roomNights = _allBookings.fold<int>(
      0,
      (sum, b) => sum + _roomNightsInMonth(b),
    );
    return (roomNights / (5 * _daysInMonth)) * 100;
  }

  int get _roomNightsSold =>
      _allBookings.fold<int>(0, (sum, b) => sum + _roomNightsInMonth(b));

  int get _bookingsThisMonth => _allBookings.where((b) {
    return b.status != BookingStatus.cancelled &&
        !b.checkin.isBefore(_firstDayOfMonth) &&
        b.checkin.isBefore(_firstDayOfNextMonth);
  }).length;

  double get _roomRevenueMonth => _allBookings.fold<double>(
    0,
    (sum, b) => sum + (_roomNightsInMonth(b) * b.tariff),
  );

  double get _duesOutstanding => _allBookings.fold<double>(0, (sum, b) {
    if (b.status == BookingStatus.cancelled) return sum;
    return b.due > 0 ? sum + b.due : sum;
  });

  double get _estMonthlyRunningCost =>
      _dailyExpensesMonth +
      _monthlyRecurringTotal +
      (_yearlyRecurringTotal / 12);

  List<RoomStatusData> get _roomStatusToday {
    final today = DateTime.now();
    return List.generate(5, (i) {
      final roomLabel = 'Room ${i + 1}';
      final booking = _allBookings.where((b) {
        return b.roomLabel == roomLabel &&
            b.status != BookingStatus.cancelled &&
            !b.checkin.isAfter(today) &&
            b.checkout.isAfter(today);
      }).firstOrNull;

      return RoomStatusData(
        roomLabel: roomLabel,
        guestName: booking?.guest,
        checkout: booking?.checkout,
        bookingId: booking?.id,
        status: booking?.status,
      );
    });
  }

  void _previousMonth() {
    setState(() {
      _reportingMonth = DateTime(
        _reportingMonth.year,
        _reportingMonth.month - 1,
      );
    });
    _loadData();
  }

  void _nextMonth() {
    setState(() {
      _reportingMonth = DateTime(
        _reportingMonth.year,
        _reportingMonth.month + 1,
      );
    });
    _loadData();
  }

  void _openNewBooking() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const EnhancedBookingFormScreen()),
    );
    _loadData();
  }

  void _openRecordPayment() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const PaymentFormScreen()),
    );
    _loadData();
  }

  @override
  Widget build(BuildContext context) {
    final isTablet = MediaQuery.of(context).size.width >= 600;
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: isTablet ? _buildTabletLayout() : _buildPhoneLayout(),
      ),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          FloatingActionButton.extended(
            heroTag: 'fab_payment',
            onPressed: _openRecordPayment,
            icon: const Icon(Icons.payments_rounded, size: 18),
            label: Text(
              'Record Payment',
              style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
            ),
            backgroundColor: AppTheme.brassAccent,
            foregroundColor: Colors.white,
            elevation: 3,
          ),
          const SizedBox(height: 10),
          FloatingActionButton.extended(
            heroTag: 'fab_booking',
            onPressed: _openNewBooking,
            icon: const Icon(Icons.add_rounded, size: 18),
            label: Text(
              'New Booking',
              style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
            ),
            backgroundColor: AppTheme.deepTeal,
            foregroundColor: Colors.white,
            elevation: 3,
          ),
        ],
      ),
    );
  }

  Widget _buildPhoneLayout() {
    return CustomScrollView(
      slivers: [
        _buildAppBar(),
        SliverToBoxAdapter(
          child: _isLoading
              ? const Padding(
                  padding: EdgeInsets.only(top: 60),
                  child: Center(child: CircularProgressIndicator()),
                )
              : Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ReportingMonthSelectorWidget(
                        reportingMonth: _reportingMonth,
                        onPrevious: _previousMonth,
                        onNext: _nextMonth,
                      ),
                      const SizedBox(height: 16),
                      DashboardMetricsGridWidget(
                        occupiedRooms: _occupiedRoomsToday,
                        occupancyTodayPct: _occupancyTodayPct,
                        occupancyRateMonth: _occupancyRateMonth,
                        roomNightsSold: _roomNightsSold,
                        bookingsMonth: _bookingsThisMonth,
                        roomRevenueMonth: _roomRevenueMonth,
                        paymentsReceived: _paymentsReceivedMonth,
                        duesOutstanding: _duesOutstanding,
                        dailyExpenses: _dailyExpensesMonth,
                      ),
                      const SizedBox(height: 14),
                      CostSummaryRowWidget(
                        monthlyRecurring: _monthlyRecurringTotal,
                        yearlyRecurring: _yearlyRecurringTotal,
                        estRunningCost: _estMonthlyRunningCost,
                      ),
                      const SizedBox(height: 20),
                      _buildRoomStatusSection(),
                    ],
                  ),
                ),
        ),
      ],
    );
  }

  Widget _buildTabletLayout() {
    return CustomScrollView(
      slivers: [
        _buildAppBar(),
        SliverToBoxAdapter(
          child: _isLoading
              ? const Padding(
                  padding: EdgeInsets.only(top: 60),
                  child: Center(child: CircularProgressIndicator()),
                )
              : Padding(
                  padding: const EdgeInsets.fromLTRB(24, 8, 24, 120),
                  child: Column(
                    children: [
                      ReportingMonthSelectorWidget(
                        reportingMonth: _reportingMonth,
                        onPrevious: _previousMonth,
                        onNext: _nextMonth,
                      ),
                      const SizedBox(height: 16),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 6,
                            child: Column(
                              children: [
                                DashboardMetricsGridWidget(
                                  occupiedRooms: _occupiedRoomsToday,
                                  occupancyTodayPct: _occupancyTodayPct,
                                  occupancyRateMonth: _occupancyRateMonth,
                                  roomNightsSold: _roomNightsSold,
                                  bookingsMonth: _bookingsThisMonth,
                                  roomRevenueMonth: _roomRevenueMonth,
                                  paymentsReceived: _paymentsReceivedMonth,
                                  duesOutstanding: _duesOutstanding,
                                  dailyExpenses: _dailyExpensesMonth,
                                ),
                                const SizedBox(height: 14),
                                CostSummaryRowWidget(
                                  monthlyRecurring: _monthlyRecurringTotal,
                                  yearlyRecurring: _yearlyRecurringTotal,
                                  estRunningCost: _estMonthlyRunningCost,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(flex: 4, child: _buildRoomStatusSection()),
                        ],
                      ),
                    ],
                  ),
                ),
        ),
      ],
    );
  }

  SliverAppBar _buildAppBar() {
    final theme = Theme.of(context);
    return SliverAppBar(
      backgroundColor: theme.scaffoldBackgroundColor,
      elevation: 0,
      scrolledUnderElevation: 1,
      shadowColor: Colors.black.withAlpha(20),
      pinned: true,
      title: const BrandLogo(
        width: 128,
        height: 48,
        alignment: Alignment.centerLeft,
      ),
      actions: [
        // Monthly serial count badge
        if (_monthSerialCount > 0)
          Container(
            margin: const EdgeInsets.only(right: 4),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: AppTheme.brassAccent.withAlpha(30),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              '#$_monthSerialCount this month',
              style: TextStyle(
                fontSize: 10,
                color: AppTheme.brassAccent,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        IconButton(
          onPressed: _loadData,
          icon: Icon(
            Icons.refresh_rounded,
            color: theme.colorScheme.primary,
            size: 22,
          ),
          tooltip: 'Refresh',
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  Widget _buildRoomStatusSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(
              Icons.sensor_door_outlined,
              size: 18,
              color: AppTheme.deepTeal,
            ),
            const SizedBox(width: 8),
            Text(
              'Room Status Today',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Theme.of(context).colorScheme.onSurface,
              ),
            ),
            const Spacer(),
            Text(
              DateFormatter.format(DateTime.now()),
              style: TextStyle(
                fontSize: 12,
                color: AppTheme.brassAccent,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        RoomStatusListWidget(rooms: _roomStatusToday),
      ],
    );
  }
}
