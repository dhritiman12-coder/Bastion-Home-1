import 'package:flutter/material.dart';
import '../../../models/booking_model.dart';
import '../../../theme/app_theme.dart';
import '../../../utils/currency_formatter.dart';

class RoomStatusData {
  final String roomLabel;
  final String? guestName;
  final DateTime? checkout;
  final String? bookingId;
  final BookingStatus? status;

  const RoomStatusData({
    required this.roomLabel,
    this.guestName,
    this.checkout,
    this.bookingId,
    this.status,
  });

  bool get isOccupied => guestName != null;
}

class RoomStatusListWidget extends StatelessWidget {
  final List<RoomStatusData> rooms;

  const RoomStatusListWidget({required this.rooms, super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: rooms
          .map(
            (room) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _RoomStatusTile(room: room),
            ),
          )
          .toList(),
    );
  }
}

class _RoomStatusTile extends StatelessWidget {
  final RoomStatusData room;

  const _RoomStatusTile({required this.room});

  @override
  Widget build(BuildContext context) {
    final isOccupied = room.isOccupied;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: isOccupied ? AppTheme.deepTeal.withAlpha(15) : Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: isOccupied
              ? AppTheme.deepTeal.withAlpha(51)
              : const Color(0xFFEAE4DC),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          // Room indicator dot
          Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isOccupied
                  ? AppTheme.brassAccent
                  : const Color(0xFFCDD5D8),
            ),
          ),
          const SizedBox(width: 10),
          // Room label
          SizedBox(
            width: 60,
            child: Text(
              room.roomLabel,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: AppTheme.deepTealDark,
              ),
            ),
          ),
          const SizedBox(width: 8),
          // Guest info
          Expanded(
            child: isOccupied
                ? Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        room.guestName!,
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          color: AppTheme.deepTealDark,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                      if (room.bookingId != null)
                        Text(
                          room.bookingId!,
                          style: TextStyle(
                            fontSize: 11,
                            color: AppTheme.textSecondaryLight,
                          ),
                        ),
                    ],
                  )
                : Text(
                    '— vacant —',
                    style: TextStyle(
                      fontSize: 13,
                      color: AppTheme.textMutedLight,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
          ),
          // Checkout date
          if (isOccupied && room.checkout != null)
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  'Checkout',
                  style: TextStyle(
                    fontSize: 10,
                    color: AppTheme.textSecondaryLight,
                  ),
                ),
                Text(
                  DateFormatter.format(room.checkout!),
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.deepTeal,
                    fontFeatures: const [FontFeature.tabularFigures()],
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }
}
