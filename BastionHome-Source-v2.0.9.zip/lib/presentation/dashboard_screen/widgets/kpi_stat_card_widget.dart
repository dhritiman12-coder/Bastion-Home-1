import 'package:flutter/material.dart';
import '../../../theme/app_theme.dart';

class KpiStatCardWidget extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color? valueColor;
  final Color? backgroundColor;
  final bool isAlert;

  const KpiStatCardWidget({
    required this.icon,
    required this.label,
    required this.value,
    this.valueColor,
    this.backgroundColor,
    this.isAlert = false,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final bgColor =
        backgroundColor ??
        (isAlert ? AppTheme.alertRed.withAlpha(15) : Colors.white);
    final borderColor = isAlert
        ? AppTheme.alertRed.withAlpha(51)
        : const Color(0xFFEAE4DC);
    final resolvedValueColor =
        valueColor ?? (isAlert ? AppTheme.alertRed : AppTheme.deepTealDark);

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: borderColor, width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(10),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(
              color: isAlert
                  ? AppTheme.alertRed.withAlpha(31)
                  : AppTheme.deepTeal.withAlpha(26),
              borderRadius: BorderRadius.circular(7),
            ),
            child: Icon(
              icon,
              size: 15,
              color: isAlert ? AppTheme.alertRed : AppTheme.deepTeal,
            ),
          ),
          const SizedBox(height: 6),
          Flexible(
            child: Text(
              value,
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w700,
                color: resolvedValueColor,
                fontFeatures: const [FontFeature.tabularFigures()],
                height: 1.1,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            label,
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w400,
              color: AppTheme.textSecondaryLight,
              height: 1.3,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}
