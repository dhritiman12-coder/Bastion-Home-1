import 'package:flutter/material.dart';
import '../../../theme/app_theme.dart';
import '../../../utils/currency_formatter.dart';

class ReportingMonthSelectorWidget extends StatelessWidget {
  final DateTime reportingMonth;
  final VoidCallback onPrevious;
  final VoidCallback onNext;

  const ReportingMonthSelectorWidget({
    required this.reportingMonth,
    required this.onPrevious,
    required this.onNext,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
      decoration: BoxDecoration(
        color: AppTheme.brassAccent.withAlpha(26),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.brassAccent.withAlpha(64), width: 1),
      ),
      child: Row(
        children: [
          _ArrowButton(icon: Icons.chevron_left_rounded, onTap: onPrevious),
          Expanded(
            child: Column(
              children: [
                Text(
                  'REPORTING MONTH',
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.brassAccent,
                    letterSpacing: 0,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  DateFormatter.monthYear(reportingMonth),
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.deepTealDark,
                    fontFeatures: const [FontFeature.tabularFigures()],
                  ),
                ),
              ],
            ),
          ),
          _ArrowButton(icon: Icons.chevron_right_rounded, onTap: onNext),
        ],
      ),
    );
  }
}

class _ArrowButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _ArrowButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        splashColor: AppTheme.brassAccent.withAlpha(38),
        child: Container(
          width: 40,
          height: 44,
          alignment: Alignment.center,
          child: Icon(icon, color: AppTheme.brassAccent, size: 24),
        ),
      ),
    );
  }
}
