import 'package:flutter/material.dart';
import '../../../theme/app_theme.dart';
import '../../../utils/currency_formatter.dart';

class CostSummaryRowWidget extends StatelessWidget {
  final double monthlyRecurring;
  final double yearlyRecurring;
  final double estRunningCost;

  const CostSummaryRowWidget({
    required this.monthlyRecurring,
    required this.yearlyRecurring,
    required this.estRunningCost,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _CostCard(
            label: 'Monthly\nRecurring',
            value: CurrencyFormatter.format(monthlyRecurring),
            icon: Icons.repeat_rounded,
            color: AppTheme.deepTeal,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: _CostCard(
            label: 'Yearly\nRecurring',
            value: CurrencyFormatter.format(yearlyRecurring),
            icon: Icons.event_repeat_rounded,
            color: AppTheme.brassAccent,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: _CostCard(
            label: 'Est. Running\nCost (Mo.)',
            value: CurrencyFormatter.format(estRunningCost),
            icon: Icons.calculate_outlined,
            color: AppTheme.deepTealDark,
            isHighlight: true,
          ),
        ),
      ],
    );
  }
}

class _CostCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  final bool isHighlight;

  const _CostCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
    this.isHighlight = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: isHighlight ? AppTheme.deepTeal.withAlpha(15) : Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: isHighlight
              ? AppTheme.deepTeal.withAlpha(51)
              : const Color(0xFFEAE4DC),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(10),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 16, color: color),
          const SizedBox(height: 6),
          Text(
            value,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: color,
              fontFeatures: const [FontFeature.tabularFigures()],
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 3),
          Text(
            label,
            style: TextStyle(
              fontSize: 10,
              color: AppTheme.textSecondaryLight,
              height: 1.3,
            ),
          ),
        ],
      ),
    );
  }
}
