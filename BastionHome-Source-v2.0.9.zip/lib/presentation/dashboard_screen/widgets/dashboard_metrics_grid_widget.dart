import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';
import '../../../utils/currency_formatter.dart';
import './kpi_stat_card_widget.dart';

class DashboardMetricsGridWidget extends StatelessWidget {
  final int occupiedRooms;
  final double occupancyTodayPct;
  final double occupancyRateMonth;
  final int roomNightsSold;
  final int bookingsMonth;
  final double roomRevenueMonth;
  final double paymentsReceived;
  final double duesOutstanding;
  final double dailyExpenses;

  const DashboardMetricsGridWidget({
    required this.occupiedRooms,
    required this.occupancyTodayPct,
    required this.occupancyRateMonth,
    required this.roomNightsSold,
    required this.bookingsMonth,
    required this.roomRevenueMonth,
    required this.paymentsReceived,
    required this.duesOutstanding,
    required this.dailyExpenses,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final metrics = [
      // Row 1 — Occupancy
      _MetricData(
        icon: Icons.sensor_door_outlined,
        label: 'Rooms Today',
        value: '$occupiedRooms / 5',
      ),
      _MetricData(
        icon: Icons.percent_rounded,
        label: 'Occupancy Today',
        value: '${occupancyTodayPct.toStringAsFixed(1)}%',
      ),
      _MetricData(
        icon: Icons.bar_chart_rounded,
        label: 'Occ. Rate (Mo.)',
        value: '${occupancyRateMonth.toStringAsFixed(1)}%',
      ),
      // Row 2 — Bookings & Revenue
      _MetricData(
        icon: Icons.nights_stay_outlined,
        label: 'Room-Nights',
        value: roomNightsSold.toString(),
      ),
      _MetricData(
        icon: Icons.book_online_outlined,
        label: 'Bookings (Mo.)',
        value: bookingsMonth.toString(),
      ),
      _MetricData(
        icon: Icons.hotel_outlined,
        label: 'Room Revenue',
        value: CurrencyFormatter.formatCompact(roomRevenueMonth),
      ),
      // Row 3 — Payments & Expenses
      _MetricData(
        icon: Icons.account_balance_wallet_outlined,
        label: 'Received (Mo.)',
        value: CurrencyFormatter.formatCompact(paymentsReceived),
        valueColor: AppTheme.successGreen,
      ),
      _MetricData(
        icon: Icons.warning_amber_rounded,
        label: 'Dues Outstanding',
        value: CurrencyFormatter.formatCompact(duesOutstanding),
        isAlert: duesOutstanding > 0,
      ),
      _MetricData(
        icon: Icons.receipt_long_outlined,
        label: 'Daily Expenses',
        value: CurrencyFormatter.formatCompact(dailyExpenses),
      ),
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 0.82,
      ),
      itemCount: metrics.length,
      itemBuilder: (context, index) {
        final m = metrics[index];
        return KpiStatCardWidget(
          icon: m.icon,
          label: m.label,
          value: m.value,
          valueColor: m.valueColor,
          isAlert: m.isAlert,
        );
      },
    );
  }
}

class _MetricData {
  final IconData icon;
  final String label;
  final String value;
  final Color? valueColor;
  final bool isAlert;

  const _MetricData({
    required this.icon,
    required this.label,
    required this.value,
    this.valueColor,
    this.isAlert = false,
  });
}
