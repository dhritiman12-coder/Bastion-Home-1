import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:image_picker/image_picker.dart';

import '../../services/logo_service.dart';
import '../../services/booking_serial_service.dart';
import '../../widgets/brand_logo.dart';
import '../../widgets/app_back_button.dart';
import '../../services/account_service.dart';
import '../../widgets/admin_access_denied.dart';

class BrandingSettingsScreen extends StatefulWidget {
  const BrandingSettingsScreen({super.key});

  @override
  State<BrandingSettingsScreen> createState() => _BrandingSettingsScreenState();
}

class _BrandingSettingsScreenState extends State<BrandingSettingsScreen> {
  final LogoService _logoService = LogoService();
  final BookingSerialService _serialService = BookingSerialService();
  final ImagePicker _picker = ImagePicker();

  late TextEditingController _nameCtrl;
  late TextEditingController _addressCtrl;
  late TextEditingController _gstNumberCtrl;
  late TextEditingController _gstPercentCtrl;

  String? _logoPath;
  bool _isLoading = true;
  bool _isSaving = false;
  List<Map<String, dynamic>> _serialLogs = [];

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController();
    _addressCtrl = TextEditingController();
    _gstNumberCtrl = TextEditingController();
    _gstPercentCtrl = TextEditingController();
    _loadSettings();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _addressCtrl.dispose();
    _gstNumberCtrl.dispose();
    _gstPercentCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadSettings() async {
    final settings = await _logoService.getAllSettings();
    final logs = await _serialService.getAllMonthlyLogs();
    if (!mounted) return;
    setState(() {
      _nameCtrl.text = settings['guestHouseName'] ?? 'Bastion Home Guest House';
      _addressCtrl.text = settings['guestHouseAddress'] ?? '';
      _gstNumberCtrl.text = settings['gstNumber'] ?? '';
      _gstPercentCtrl.text = (settings['gstPercent'] as double? ?? 0)
          .toStringAsFixed(0);
      _logoPath = settings['logoPath'] as String?;
      _serialLogs = logs;
      _isLoading = false;
    });
  }

  Future<void> _pickLogo() async {
    try {
      final XFile? file = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 80,
        maxWidth: 800,
        maxHeight: 800,
        requestFullMetadata: false,
      );
      if (file == null) return;

      final bytes = await file.readAsBytes();
      if (bytes.length > 5 * 1024 * 1024) {
        throw const FormatException('Logo image must be smaller than 5 MB');
      }
      final dataUrl = 'data:image/png;base64,${base64Encode(bytes)}';
      await _logoService.setLogoPath(dataUrl);
      if (!mounted) return;
      setState(() => _logoPath = dataUrl);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Logo updated successfully')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Could not load logo: $e')));
      }
    }
  }

  Future<void> _removeLogo() async {
    await _logoService.clearLogo();
    if (!mounted) return;
    setState(() => _logoPath = null);
  }

  Future<void> _saveSettings() async {
    setState(() => _isSaving = true);
    try {
      await _logoService.setGuestHouseName(_nameCtrl.text.trim());
      await _logoService.setGuestHouseAddress(_addressCtrl.text.trim());
      await _logoService.setGstNumber(_gstNumberCtrl.text.trim());
      await _logoService.setGstPercent(
        double.tryParse(_gstPercentCtrl.text) ?? 0,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Settings saved successfully')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not save property settings')),
      );
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!AccountService().isAdmin) {
      return const AdminAccessDenied(resource: 'branding_settings');
    }
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF0D1F25) : const Color(0xFFF7F4EE);
    final inkColor = isDark ? Colors.white : const Color(0xFF0E332B);
    final fieldFill = isDark ? const Color(0xFF123F34) : Colors.white;
    final accentColor = const Color(0xFF8E2A18);

    InputDecoration fieldDec(String label, {String? hint}) => InputDecoration(
      labelText: label,
      hintText: hint,
      filled: true,
      fillColor: fieldFill,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.grey.withAlpha(60)),
      ),
      contentPadding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
    );

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        leading: const AppBackButton(color: Colors.white),
        backgroundColor: isDark
            ? const Color(0xFF0E332B)
            : const Color(0xFF123F34),
        title: Text(
          'Branding & Settings',
          style: TextStyle(color: Colors.white, fontSize: 18.0),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          TextButton(
            onPressed: _isSaving ? null : _saveSettings,
            child: Text(
              _isSaving ? 'Saving…' : 'Save',
              style: TextStyle(
                color: accentColor,
                fontWeight: FontWeight.w700,
                fontSize: 16.0,
              ),
            ),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: EdgeInsets.all(4.w),
              children: [
                // Logo Section
                _sectionHeader(
                  'Guest House Logo',
                  Icons.image_outlined,
                  inkColor,
                ),
                SizedBox(height: 1.5.h),
                Center(
                  child: Column(
                    children: [
                      GestureDetector(
                        onTap: _pickLogo,
                        child: Container(
                          width: 72.w,
                          height: 18.h,
                          padding: EdgeInsets.all(3.w),
                          decoration: BoxDecoration(
                            color: fieldFill,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: accentColor, width: 2),
                          ),
                          child: _logoPath != null
                              ? _buildLogoWidget(_logoPath!)
                              : const BrandLogo(),
                        ),
                      ),
                      SizedBox(height: 1.h),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          TextButton.icon(
                            onPressed: _pickLogo,
                            icon: const Icon(Icons.upload_outlined, size: 16),
                            label: Text(
                              'Change Logo',
                              style: TextStyle(fontSize: 13.0),
                            ),
                          ),
                          if (_logoPath != null) ...[
                            SizedBox(width: 2.w),
                            TextButton.icon(
                              onPressed: _removeLogo,
                              icon: const Icon(
                                Icons.delete_outline,
                                size: 16,
                                color: Colors.red,
                              ),
                              label: Text(
                                'Remove',
                                style: TextStyle(
                                  fontSize: 13.0,
                                  color: Colors.red,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                      Text(
                        'Default: official Bastion Home logo',
                        style: TextStyle(
                          fontSize: 11.0,
                          color: inkColor.withAlpha(120),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 3.h),

                // Guest House Info
                _sectionHeader(
                  'Guest House Info',
                  Icons.business_outlined,
                  inkColor,
                ),
                SizedBox(height: 1.5.h),

                TextField(
                  controller: _nameCtrl,
                  decoration: fieldDec('Guest House Name'),
                ),
                SizedBox(height: 2.h),

                TextField(
                  controller: _addressCtrl,
                  decoration: fieldDec('Address'),
                  maxLines: 2,
                ),
                SizedBox(height: 3.h),

                // Tax Settings
                _sectionHeader(
                  'Tax & GST Settings',
                  Icons.percent_outlined,
                  inkColor,
                ),
                SizedBox(height: 1.5.h),

                TextField(
                  controller: _gstNumberCtrl,
                  decoration: fieldDec(
                    'GST Number',
                    hint: 'e.g. 27XXXXX1234Z1',
                  ),
                ),
                SizedBox(height: 2.h),

                TextField(
                  controller: _gstPercentCtrl,
                  decoration: fieldDec('GST % (0 to disable)'),
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                  ),
                ),
                SizedBox(height: 3.h),

                // Monthly Serial Logs
                _sectionHeader(
                  'Monthly Serial Log',
                  Icons.list_alt_outlined,
                  inkColor,
                ),
                SizedBox(height: 1.5.h),

                if (_serialLogs.isEmpty)
                  Container(
                    padding: EdgeInsets.all(4.w),
                    decoration: BoxDecoration(
                      color: fieldFill,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.grey.withAlpha(60)),
                    ),
                    child: Text(
                      'No bookings recorded yet.',
                      style: TextStyle(
                        fontSize: 13.0,
                        color: inkColor.withAlpha(140),
                      ),
                      textAlign: TextAlign.center,
                    ),
                  )
                else
                  Container(
                    decoration: BoxDecoration(
                      color: fieldFill,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.grey.withAlpha(60)),
                    ),
                    child: Column(
                      children: _serialLogs.asMap().entries.map((entry) {
                        final i = entry.key;
                        final log = entry.value;
                        return Column(
                          children: [
                            Padding(
                              padding: EdgeInsets.symmetric(
                                horizontal: 4.w,
                                vertical: 1.2.h,
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 2.w,
                                      vertical: 0.4.h,
                                    ),
                                    decoration: BoxDecoration(
                                      color: accentColor.withAlpha(30),
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Text(
                                      log['month'] as String,
                                      style: TextStyle(
                                        fontSize: 12.0,
                                        fontWeight: FontWeight.w600,
                                        color: accentColor,
                                      ),
                                    ),
                                  ),
                                  const Spacer(),
                                  Text(
                                    '${log['count']} booking${(log['count'] as int) != 1 ? 's' : ''}',
                                    style: TextStyle(
                                      fontSize: 13.0,
                                      fontWeight: FontWeight.w600,
                                      color: inkColor,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            if (i < _serialLogs.length - 1)
                              Divider(
                                height: 1,
                                color: Colors.grey.withAlpha(40),
                              ),
                          ],
                        );
                      }).toList(),
                    ),
                  ),
                SizedBox(height: 4.h),
              ],
            ),
    );
  }

  Widget _buildLogoWidget(String path) {
    if (path.startsWith('data:')) {
      final separator = path.indexOf(',');
      if (separator > 0) {
        return Image.memory(
          base64Decode(path.substring(separator + 1)),
          fit: BoxFit.contain,
          errorBuilder: (_, __, ___) => const BrandLogo(),
        );
      }
      return const BrandLogo();
    }
    return const BrandLogo(fit: BoxFit.contain);
  }

  Widget _sectionHeader(String title, IconData icon, Color inkColor) {
    return Row(
      children: [
        Icon(icon, size: 16, color: const Color(0xFF8E2A18)),
        SizedBox(width: 2.w),
        Text(
          title,
          style: TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: 14.0,
            color: const Color(0xFF8E2A18),
          ),
        ),
        SizedBox(width: 2.w),
        Expanded(child: Divider(color: const Color(0xFF8E2A18).withAlpha(60))),
      ],
    );
  }
}
