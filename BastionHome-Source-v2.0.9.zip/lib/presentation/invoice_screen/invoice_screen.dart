import 'package:flutter/material.dart';
import '../../widgets/app_back_button.dart';
import 'package:sizer/sizer.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../models/booking_model.dart';
import '../../services/logo_service.dart';
import '../../services/download_service.dart';
import '../../utils/currency_formatter.dart';
import '../../widgets/brand_logo.dart';

class InvoiceScreen extends StatefulWidget {
  final BookingModel booking;
  const InvoiceScreen({super.key, required this.booking});

  @override
  State<InvoiceScreen> createState() => _InvoiceScreenState();
}

class _InvoiceScreenState extends State<InvoiceScreen> {
  final LogoService _logoService = LogoService();
  Map<String, dynamic> _settings = {};
  double _gstPercent = 0;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final settings = await _logoService.getAllSettings();
    if (!mounted) return;
    setState(() {
      _settings = settings;
      _gstPercent = (settings['gstPercent'] as double?) ?? 0;
      _isLoading = false;
    });
  }

  double get _subtotal => widget.booking.total;
  double get _gstAmount => _subtotal * _gstPercent / 100;
  double get _grandTotal => _subtotal + _gstAmount;

  String get _invoiceNumber {
    final b = widget.booking;
    final now = DateTime.now();
    final mm = now.month.toString().padLeft(2, '0');
    return 'INV-${b.id}-$mm${now.year}';
  }

  String _formatDate(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';

  Future<void> _exportInvoice() async {
    final content = _buildInvoiceText();
    try {
      final location = await DownloadService().saveText(
        fileName: '$_invoiceNumber.txt',
        contents: content,
        mimeType: 'text/plain',
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Invoice downloaded to $location')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not download invoice: $error')),
      );
    }
  }

  Future<void> _shareViaWhatsApp() async {
    final content = _buildInvoiceText();
    final encoded = Uri.encodeComponent(content);
    final waUrl = 'https://wa.me/?text=$encoded';
    final uri = Uri.parse(waUrl);
    try {
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('WhatsApp is not installed or unavailable.'),
              backgroundColor: Color(0xFFA2432F),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Could not open WhatsApp: $e'),
            backgroundColor: const Color(0xFFA2432F),
          ),
        );
      }
    }
  }

  String _buildInvoiceText() {
    final b = widget.booking;
    final guestHouseName =
        _settings['guestHouseName'] ?? 'Bastion Home Guest House';
    final guestHouseAddress = _settings['guestHouseAddress'] ?? '';
    final gstNumber = _settings['gstNumber'] ?? '';
    final sep = '─' * 40;

    return '''
$guestHouseName
$guestHouseAddress
${gstNumber.isNotEmpty ? 'GST: $gstNumber' : ''}

INVOICE
$sep
Invoice No : $_invoiceNumber
Date       : ${_formatDate(DateTime.now())}
$sep

GUEST DETAILS
Name       : ${b.guest}
Address    : ${b.address.isNotEmpty ? b.address : 'N/A'}
ID Type    : ${b.idType.isNotEmpty ? b.idType : 'N/A'}
ID Number  : ${b.idNumber.isNotEmpty ? b.idNumber : 'N/A'}
Phone      : ${b.phone.isNotEmpty ? b.phone : 'N/A'}

BOOKING DETAILS
Serial No  : ${b.serialNumber.isNotEmpty ? b.serialNumber : 'N/A'}
Source     : ${b.bookingSourceLabel}
Room       : ${b.roomLabel}
Check-in   : ${_formatDate(b.checkin)} ${b.checkinTime}
Check-out  : ${_formatDate(b.checkout)} ${b.checkoutTime}
Nights     : ${b.nights}
Guests     : ${b.guests}
$sep

BILLING
Tariff/Night : ${CurrencyFormatter.format(b.tariff)}
Room Charges : ${CurrencyFormatter.format(b.roomCharges)}
${b.extra > 0 ? 'Add. Charges : ${CurrencyFormatter.format(b.extra)}' : ''}
${b.discount > 0 ? 'Discount     : - ${CurrencyFormatter.format(b.discount)}' : ''}
Sub-Total    : ${CurrencyFormatter.format(_subtotal)}
${_gstPercent > 0 ? 'GST (${_gstPercent.toStringAsFixed(0)}%)  : ${CurrencyFormatter.format(_gstAmount)}' : ''}
$sep
TOTAL PAYABLE: ${CurrencyFormatter.format(_grandTotal)}
$sep

Payment Mode : ${b.paymentMode}

Signature: _______________________
           Manager / Owner

Thank you for staying with us!
''';
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF0D1F25) : const Color(0xFFF7F4EE);
    final cardColor = isDark ? const Color(0xFF123F34) : Colors.white;
    final inkColor = isDark ? Colors.white : const Color(0xFF0E332B);
    final accentColor = const Color(0xFF8E2A18);
    final b = widget.booking;
    final guestHouseName =
        _settings['guestHouseName'] ?? 'Bastion Home Guest House';
    final guestHouseAddress = _settings['guestHouseAddress'] ?? '';
    final gstNumber = _settings['gstNumber'] ?? '';

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        leading: const AppBackButton(),
        backgroundColor: isDark
            ? const Color(0xFF0E332B)
            : const Color(0xFF123F34),
        title: Text(
          'Invoice',
          style: TextStyle(color: Colors.white, fontSize: 18.0),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: const Icon(Icons.share_outlined, color: Colors.white),
            tooltip: 'Download invoice',
            onPressed: _exportInvoice,
          ),
          IconButton(
            icon: const Icon(
              Icons.chat_outlined,
              color: Colors.white,
              size: 22,
            ),
            tooltip: 'Share via WhatsApp',
            onPressed: _shareViaWhatsApp,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: EdgeInsets.all(4.w),
              child: Container(
                decoration: BoxDecoration(
                  color: cardColor,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withAlpha(20),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Header
                    Container(
                      padding: EdgeInsets.all(4.w),
                      decoration: BoxDecoration(
                        color: const Color(0xFF123F34),
                        borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(12),
                        ),
                      ),
                      child: Column(
                        children: [
                          Container(
                            width: 220,
                            height: 86,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 8,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFBF8F3),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: const BrandLogo(),
                          ),
                          SizedBox(height: 1.h),
                          Text(
                            guestHouseName,
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                              fontSize: 18.0,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          if (guestHouseAddress.isNotEmpty) ...[
                            SizedBox(height: 0.5.h),
                            Text(
                              guestHouseAddress,
                              style: TextStyle(
                                color: Colors.white.withAlpha(180),
                                fontSize: 12.0,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ],
                          if (gstNumber.isNotEmpty) ...[
                            SizedBox(height: 0.3.h),
                            Text(
                              'GST: $gstNumber',
                              style: TextStyle(
                                color: Colors.white.withAlpha(160),
                                fontSize: 11.0,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),

                    Padding(
                      padding: EdgeInsets.all(4.w),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Invoice meta
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'INVOICE',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w800,
                                      fontSize: 20.0,
                                      color: accentColor,
                                    ),
                                  ),
                                  Text(
                                    _invoiceNumber,
                                    style: TextStyle(
                                      fontSize: 12.0,
                                      color: inkColor.withAlpha(160),
                                    ),
                                  ),
                                ],
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(
                                    'Date',
                                    style: TextStyle(
                                      fontSize: 11.0,
                                      color: inkColor.withAlpha(140),
                                    ),
                                  ),
                                  Text(
                                    _formatDate(DateTime.now()),
                                    style: TextStyle(
                                      fontSize: 13.0,
                                      fontWeight: FontWeight.w600,
                                      color: inkColor,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(height: 2.h),
                          Divider(color: Colors.grey.withAlpha(60)),
                          SizedBox(height: 1.h),

                          // Guest details
                          _invoiceSection('GUEST DETAILS', inkColor),
                          SizedBox(height: 1.h),
                          _invoiceRow('Name', b.guest, inkColor),
                          if (b.address.isNotEmpty)
                            _invoiceRow('Address', b.address, inkColor),
                          if (b.idType.isNotEmpty)
                            _invoiceRow('ID Type', b.idType, inkColor),
                          if (b.idNumber.isNotEmpty)
                            _invoiceRow('ID Number', b.idNumber, inkColor),
                          if (b.phone.isNotEmpty)
                            _invoiceRow('Phone', b.phone, inkColor),
                          SizedBox(height: 2.h),

                          // Booking details
                          _invoiceSection('BOOKING DETAILS', inkColor),
                          SizedBox(height: 1.h),
                          if (b.serialNumber.isNotEmpty)
                            _invoiceRow('Serial No', b.serialNumber, inkColor),
                          _invoiceRow(
                            'Booking Source',
                            b.bookingSourceLabel,
                            inkColor,
                          ),
                          _invoiceRow('Room', b.roomLabel, inkColor),
                          _invoiceRow(
                            'Check-in',
                            '${_formatDate(b.checkin)} ${b.checkinTime}',
                            inkColor,
                          ),
                          _invoiceRow(
                            'Check-out',
                            '${_formatDate(b.checkout)} ${b.checkoutTime}',
                            inkColor,
                          ),
                          _invoiceRow('Nights', '${b.nights}', inkColor),
                          _invoiceRow('Guests', '${b.guests}', inkColor),
                          SizedBox(height: 2.h),

                          // Billing
                          _invoiceSection('BILLING', inkColor),
                          SizedBox(height: 1.h),
                          _invoiceRow(
                            'Tariff / Night',
                            CurrencyFormatter.format(b.tariff),
                            inkColor,
                          ),
                          _invoiceRow(
                            'Room Charges (${b.nights} nights)',
                            CurrencyFormatter.format(b.roomCharges),
                            inkColor,
                          ),
                          if (b.extra > 0)
                            _invoiceRow(
                              'Additional Charges',
                              CurrencyFormatter.format(b.extra),
                              inkColor,
                            ),
                          if (b.discount > 0)
                            _invoiceRow(
                              'Discount',
                              '- ${CurrencyFormatter.format(b.discount)}',
                              inkColor,
                            ),
                          Divider(color: Colors.grey.withAlpha(60)),
                          _invoiceRow(
                            'Sub-Total',
                            CurrencyFormatter.format(_subtotal),
                            inkColor,
                          ),
                          if (_gstPercent > 0)
                            _invoiceRow(
                              'GST (${_gstPercent.toStringAsFixed(0)}%)',
                              CurrencyFormatter.format(_gstAmount),
                              inkColor,
                            ),
                          SizedBox(height: 1.h),

                          // Grand total
                          Container(
                            padding: EdgeInsets.symmetric(
                              horizontal: 3.w,
                              vertical: 1.5.h,
                            ),
                            decoration: BoxDecoration(
                              color: accentColor.withAlpha(25),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: accentColor.withAlpha(80),
                              ),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'TOTAL PAYABLE',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w800,
                                    fontSize: 16.0,
                                    color: accentColor,
                                  ),
                                ),
                                Text(
                                  CurrencyFormatter.format(_grandTotal),
                                  style: TextStyle(
                                    fontWeight: FontWeight.w800,
                                    fontSize: 18.0,
                                    color: accentColor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 2.h),

                          // Payment mode
                          _invoiceRow('Payment Mode', b.paymentMode, inkColor),
                          SizedBox(height: 3.h),

                          // Signature
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    width: 30.w,
                                    height: 0.2.h,
                                    color: inkColor.withAlpha(120),
                                  ),
                                  SizedBox(height: 0.5.h),
                                  Text(
                                    'Manager / Owner',
                                    style: TextStyle(
                                      fontSize: 12.0,
                                      color: inkColor.withAlpha(160),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(height: 2.h),

                          // Footer
                          Center(
                            child: Text(
                              'Thank you for staying with us!',
                              style: TextStyle(
                                fontSize: 12.0,
                                color: inkColor.withAlpha(140),
                                fontStyle: FontStyle.italic,
                              ),
                            ),
                          ),
                          SizedBox(height: 1.h),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
      floatingActionButton: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton.extended(
            heroTag: 'whatsapp_fab',
            onPressed: _shareViaWhatsApp,
            backgroundColor: const Color(0xFF25D366),
            icon: const Icon(Icons.chat_outlined, color: Colors.white),
            label: Text(
              'WhatsApp',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          const SizedBox(width: 12),
          FloatingActionButton.extended(
            heroTag: 'export_fab',
            onPressed: _exportInvoice,
            backgroundColor: const Color(0xFF8E2A18),
            icon: const Icon(Icons.download_outlined, color: Colors.white),
            label: Text(
              'Download',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _invoiceSection(String title, Color inkColor) {
    return Text(
      title,
      style: TextStyle(
        fontWeight: FontWeight.w700,
        fontSize: 12.0,
        color: const Color(0xFF8E2A18),
        letterSpacing: 0,
      ),
    );
  }

  Widget _invoiceRow(String label, String value, Color inkColor) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 0.4.h),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 35.w,
            child: Text(
              label,
              style: TextStyle(fontSize: 12.0, color: inkColor.withAlpha(160)),
            ),
          ),
          Text(
            ':  ',
            style: TextStyle(fontSize: 12.0, color: inkColor.withAlpha(120)),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                fontSize: 12.0,
                fontWeight: FontWeight.w600,
                color: inkColor,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
