import 'package:flutter/material.dart';
import '../../widgets/app_back_button.dart';
import 'package:sizer/sizer.dart';
import 'package:intl/intl.dart';

import '../../database/repositories/seasonal_rate_repository.dart';
import '../../theme/app_theme.dart';
import '../../utils/currency_formatter.dart';
import '../../services/account_service.dart';
import '../../widgets/confirm_trash_dialog.dart';

class SeasonalRatesScreen extends StatefulWidget {
  const SeasonalRatesScreen({super.key});

  @override
  State<SeasonalRatesScreen> createState() => _SeasonalRatesScreenState();
}

class _SeasonalRatesScreenState extends State<SeasonalRatesScreen>
    with SingleTickerProviderStateMixin {
  final _repo = SeasonalRateRepository();
  List<SeasonalRate> _rates = [];
  bool _loading = true;
  late TabController _tabController;

  static const List<String> _rooms = [
    'All Rooms',
    'Room 1',
    'Room 2',
    'Room 3',
    'Room 4',
    'Room 5',
  ];

  static const List<String> _rateTypes = [
    'Standard',
    'Peak',
    'Off-Peak',
    'Custom',
  ];

  static const Map<String, Color> _rateTypeColors = {
    'Standard': AppTheme.deepTeal,
    'Peak': Color(0xFFA2432F),
    'Off-Peak': AppTheme.successGreen,
    'Custom': AppTheme.brassAccent,
  };

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _load();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final rates = await _repo.getAll();
    if (!mounted) return;
    setState(() {
      _rates = rates;
      _loading = false;
    });
  }

  List<SeasonalRate> get _activeRates =>
      _rates.where((r) => r.isActive).toList();
  List<SeasonalRate> get _allRates => _rates;

  void _showAddEditDialog({SeasonalRate? existing}) {
    showDialog(
      context: context,
      builder: (_) => _RateFormDialog(
        existing: existing,
        rooms: _rooms,
        rateTypes: _rateTypes,
        onSave: (rate) async {
          if (existing == null) {
            await _repo.insert(rate);
          } else {
            await _repo.update(rate);
          }
          await _load();
        },
      ),
    );
  }

  Future<void> _deleteRate(SeasonalRate rate) async {
    if (await confirmMoveToTrash(context, itemName: rate.name)) {
      try {
        await _repo.delete(rate.id!);
        await _load();
      } catch (error) {
        if (mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text(error.toString())));
        }
      }
    }
  }

  Future<void> _toggleRate(SeasonalRate rate) async {
    await _repo.toggleActive(rate.id!, !rate.isActive);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundLight,
      appBar: AppBar(
        leading: const AppBackButton(),
        title: Text(
          'Seasonal Rates',
          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 26.0),
        ),
        backgroundColor: AppTheme.backgroundLight,
        elevation: 0,
        bottom: TabBar(
          controller: _tabController,
          labelStyle: TextStyle(fontWeight: FontWeight.w600, fontSize: 14.0),
          unselectedLabelStyle: TextStyle(fontSize: 14.0),
          labelColor: AppTheme.deepTeal,
          unselectedLabelColor: AppTheme.textSecondaryLight,
          indicatorColor: AppTheme.deepTeal,
          indicatorWeight: 2.5,
          tabs: const [
            Tab(text: 'Active Rates'),
            Tab(text: 'All Rates'),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddEditDialog(),
        backgroundColor: AppTheme.deepTeal,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_rounded),
        label: Text('Add Rate', style: TextStyle(fontWeight: FontWeight.w600)),
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: AppTheme.deepTeal),
            )
          : Column(
              children: [
                _SummaryBanner(activeRates: _activeRates),
                Expanded(
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      _RatesList(
                        rates: _activeRates,
                        rateTypeColors: _rateTypeColors,
                        onEdit: (r) => _showAddEditDialog(existing: r),
                        onDelete: _deleteRate,
                        onToggle: _toggleRate,
                        emptyMessage: 'No active rates.\nTap + to add one.',
                      ),
                      _RatesList(
                        rates: _allRates,
                        rateTypeColors: _rateTypeColors,
                        onEdit: (r) => _showAddEditDialog(existing: r),
                        onDelete: _deleteRate,
                        onToggle: _toggleRate,
                        emptyMessage:
                            'No rates defined yet.\nTap + to add one.',
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}

// ── Summary Banner ──────────────────────────────────────────────────────────

class _SummaryBanner extends StatelessWidget {
  final List<SeasonalRate> activeRates;

  const _SummaryBanner({required this.activeRates});

  @override
  Widget build(BuildContext context) {
    if (activeRates.isEmpty) return const SizedBox.shrink();

    final now = DateTime.now();
    final todayStr = now.toIso8601String().split('T').first;
    final currentRates = activeRates.where((r) {
      return r.startDate.compareTo(todayStr) <= 0 &&
          r.endDate.compareTo(todayStr) >= 0;
    }).toList();

    if (currentRates.isEmpty) return const SizedBox.shrink();

    return Container(
      margin: EdgeInsets.fromLTRB(3.w, 1.5.h, 3.w, 0),
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.2.h),
      decoration: BoxDecoration(
        color: AppTheme.deepTeal.withAlpha(15),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.deepTeal.withAlpha(50)),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.local_offer_rounded,
            color: AppTheme.deepTeal,
            size: 18,
          ),
          SizedBox(width: 2.w),
          Expanded(
            child: Text(
              '${currentRates.length} rate${currentRates.length > 1 ? 's' : ''} active today  •  '
              '${currentRates.map((r) => r.room == 'All Rooms' ? 'All' : r.room).join(', ')}',
              style: TextStyle(
                fontSize: 14.0,
                fontWeight: FontWeight.w500,
                color: AppTheme.deepTeal,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}

// ── Rates List ──────────────────────────────────────────────────────────────

class _RatesList extends StatelessWidget {
  final List<SeasonalRate> rates;
  final Map<String, Color> rateTypeColors;
  final void Function(SeasonalRate) onEdit;
  final void Function(SeasonalRate) onDelete;
  final void Function(SeasonalRate) onToggle;
  final String emptyMessage;

  const _RatesList({
    required this.rates,
    required this.rateTypeColors,
    required this.onEdit,
    required this.onDelete,
    required this.onToggle,
    required this.emptyMessage,
  });

  @override
  Widget build(BuildContext context) {
    if (rates.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.price_change_outlined,
              size: 48,
              color: AppTheme.textMutedLight,
            ),
            SizedBox(height: 1.5.h),
            Text(
              emptyMessage,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16.0,
                color: AppTheme.textSecondaryLight,
              ),
            ),
          ],
        ),
      );
    }

    return ListView.separated(
      padding: EdgeInsets.fromLTRB(3.w, 1.5.h, 3.w, 10.h),
      itemCount: rates.length,
      separatorBuilder: (_, __) => SizedBox(height: 1.h),
      itemBuilder: (_, i) => _RateCard(
        rate: rates[i],
        typeColor: rateTypeColors[rates[i].rateType] ?? AppTheme.brassAccent,
        onEdit: () => onEdit(rates[i]),
        onDelete: () => onDelete(rates[i]),
        onToggle: () => onToggle(rates[i]),
      ),
    );
  }
}

// ── Rate Card ───────────────────────────────────────────────────────────────

class _RateCard extends StatelessWidget {
  final SeasonalRate rate;
  final Color typeColor;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback onToggle;

  const _RateCard({
    required this.rate,
    required this.typeColor,
    required this.onEdit,
    required this.onDelete,
    required this.onToggle,
  });

  String _fmt(String dateStr) {
    try {
      final d = DateTime.parse(dateStr);
      return DateFormat('d MMM yyyy').format(d);
    } catch (_) {
      return dateStr;
    }
  }

  bool get _isCurrentlyActive {
    final now = DateTime.now().toIso8601String().split('T').first;
    return rate.isActive &&
        rate.startDate.compareTo(now) <= 0 &&
        rate.endDate.compareTo(now) >= 0;
  }

  int get _daysSpan {
    try {
      final s = DateTime.parse(rate.startDate);
      final e = DateTime.parse(rate.endDate);
      return e.difference(s).inDays + 1;
    } catch (_) {
      return 0;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: rate.isActive ? 1.0 : 0.55,
      child: Container(
        decoration: BoxDecoration(
          color: AppTheme.surfaceLight,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: _isCurrentlyActive
                ? AppTheme.deepTeal.withAlpha(80)
                : const Color(0xFFDCE4E0),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withAlpha(8),
              blurRadius: 6,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header row
            Padding(
              padding: EdgeInsets.fromLTRB(3.w, 1.5.h, 2.w, 0),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: typeColor.withAlpha(20),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: typeColor.withAlpha(60)),
                    ),
                    child: Text(
                      rate.rateType,
                      style: TextStyle(
                        fontSize: 12.0,
                        fontWeight: FontWeight.w600,
                        color: typeColor,
                      ),
                    ),
                  ),
                  SizedBox(width: 2.w),
                  if (_isCurrentlyActive)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 7,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: AppTheme.successGreen.withAlpha(20),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        'Active Now',
                        style: TextStyle(
                          fontSize: 12.0,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.successGreen,
                        ),
                      ),
                    ),
                  const Spacer(),
                  Switch(
                    value: rate.isActive,
                    onChanged: (_) => onToggle(),
                    activeThumbColor: AppTheme.deepTeal,
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                  IconButton(
                    icon: const Icon(Icons.edit_outlined, size: 18),
                    color: AppTheme.textSecondaryLight,
                    onPressed: onEdit,
                    visualDensity: VisualDensity.compact,
                    padding: EdgeInsets.zero,
                  ),
                  if (AccountService().isAdmin)
                    IconButton(
                      icon: const Icon(Icons.delete_outline_rounded, size: 18),
                      color: AppTheme.alertRed,
                      onPressed: onDelete,
                      visualDensity: VisualDensity.compact,
                      padding: EdgeInsets.zero,
                    ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(3.w, 0.8.h, 3.w, 1.5.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    rate.name,
                    style: TextStyle(
                      fontSize: 18.0,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.textPrimaryLight,
                    ),
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                  ),
                  SizedBox(height: 0.6.h),
                  Row(
                    children: [
                      const Icon(
                        Icons.calendar_today_outlined,
                        size: 13,
                        color: AppTheme.textSecondaryLight,
                      ),
                      SizedBox(width: 1.w),
                      Text(
                        '${_fmt(rate.startDate)}  →  ${_fmt(rate.endDate)}',
                        style: TextStyle(
                          fontSize: 13.0,
                          color: AppTheme.textSecondaryLight,
                        ),
                      ),
                      SizedBox(width: 2.w),
                      Text(
                        '($_daysSpan days)',
                        style: TextStyle(
                          fontSize: 12.0,
                          color: AppTheme.textMutedLight,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 0.5.h),
                  Row(
                    children: [
                      const Icon(
                        Icons.bed_outlined,
                        size: 13,
                        color: AppTheme.textSecondaryLight,
                      ),
                      SizedBox(width: 1.w),
                      Text(
                        rate.room,
                        style: TextStyle(
                          fontSize: 13.0,
                          color: AppTheme.textSecondaryLight,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        '${CurrencyFormatter.format(rate.ratePerNight)} / night',
                        style: TextStyle(
                          fontSize: 18.0,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.deepTeal,
                        ),
                      ),
                    ],
                  ),
                  if (rate.notes.isNotEmpty) ...[
                    SizedBox(height: 0.5.h),
                    Text(
                      rate.notes,
                      style: TextStyle(
                        fontSize: 12.0,
                        color: AppTheme.textMutedLight,
                        fontStyle: FontStyle.italic,
                      ),
                      overflow: TextOverflow.ellipsis,
                      maxLines: 2,
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Add / Edit Dialog ───────────────────────────────────────────────────────

class _RateFormDialog extends StatefulWidget {
  final SeasonalRate? existing;
  final List<String> rooms;
  final List<String> rateTypes;
  final Future<void> Function(SeasonalRate) onSave;

  const _RateFormDialog({
    required this.existing,
    required this.rooms,
    required this.rateTypes,
    required this.onSave,
  });

  @override
  State<_RateFormDialog> createState() => _RateFormDialogState();
}

class _RateFormDialogState extends State<_RateFormDialog> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameCtrl;
  late TextEditingController _rateCtrl;
  late TextEditingController _notesCtrl;
  late String _selectedRoom;
  late String _selectedType;
  DateTime? _startDate;
  DateTime? _endDate;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _nameCtrl = TextEditingController(text: e?.name ?? '');
    _rateCtrl = TextEditingController(
      text: e != null ? e.ratePerNight.toStringAsFixed(0) : '',
    );
    _notesCtrl = TextEditingController(text: e?.notes ?? '');
    _selectedRoom = e?.room ?? 'All Rooms';
    _selectedType = e?.rateType ?? 'Custom';
    _startDate = e != null ? DateTime.tryParse(e.startDate) : null;
    _endDate = e != null ? DateTime.tryParse(e.endDate) : null;
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _rateCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  String _fmtDate(DateTime? d) =>
      d == null ? 'Select date' : DateFormat('d MMM yyyy').format(d);

  Future<void> _pickDate(bool isStart) async {
    final initial = isStart
        ? (_startDate ?? DateTime.now())
        : (_endDate ??
              (_startDate ?? DateTime.now()).add(const Duration(days: 1)));
    final first = isStart ? DateTime(2020) : (_startDate ?? DateTime(2020));
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: first,
      lastDate: DateTime(2035),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(
          colorScheme: const ColorScheme.light(
            primary: AppTheme.deepTeal,
            onPrimary: Colors.white,
          ),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() {
        if (isStart) {
          _startDate = picked;
          if (_endDate != null && _endDate!.isBefore(picked)) {
            _endDate = picked.add(const Duration(days: 1));
          }
        } else {
          _endDate = picked;
        }
      });
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_startDate == null || _endDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select start and end dates.')),
      );
      return;
    }
    setState(() => _saving = true);
    final rate = SeasonalRate(
      id: widget.existing?.id,
      name: _nameCtrl.text.trim(),
      room: _selectedRoom,
      startDate: _startDate!.toIso8601String().split('T').first,
      endDate: _endDate!.toIso8601String().split('T').first,
      ratePerNight: double.tryParse(_rateCtrl.text.trim()) ?? 0,
      rateType: _selectedType,
      notes: _notesCtrl.text.trim(),
      isActive: widget.existing?.isActive ?? true,
    );
    await widget.onSave(rate);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existing != null;
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      insetPadding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 4.h),
      child: SingleChildScrollView(
        padding: EdgeInsets.all(4.w),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                isEdit ? 'Edit Rate' : 'New Seasonal Rate',
                style: TextStyle(
                  fontSize: 22.0,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textPrimaryLight,
                ),
              ),
              SizedBox(height: 2.h),

              // Rate name
              TextFormField(
                controller: _nameCtrl,
                decoration: const InputDecoration(
                  labelText: 'Rate Name',
                  hintText: 'e.g. Summer Peak, Diwali Special',
                ),
                validator: (v) =>
                    v == null || v.trim().isEmpty ? 'Enter a name' : null,
              ),
              SizedBox(height: 1.5.h),

              // Rate type chips
              Text(
                'Rate Type',
                style: TextStyle(
                  fontSize: 14.0,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textSecondaryLight,
                ),
              ),
              SizedBox(height: 0.8.h),
              Wrap(
                spacing: 2.w,
                runSpacing: 0.5.h,
                children: widget.rateTypes.map((t) {
                  final selected = _selectedType == t;
                  return ChoiceChip(
                    label: Text(t),
                    selected: selected,
                    onSelected: (_) => setState(() => _selectedType = t),
                    selectedColor: AppTheme.deepTeal,
                    labelStyle: TextStyle(
                      fontSize: 13.0,
                      color: selected
                          ? Colors.white
                          : AppTheme.textPrimaryLight,
                      fontWeight: FontWeight.w500,
                    ),
                    backgroundColor: AppTheme.surfaceVariantLight,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(50),
                    ),
                    side: BorderSide.none,
                  );
                }).toList(),
              ),
              SizedBox(height: 1.5.h),

              // Room selector
              DropdownButtonFormField<String>(
                initialValue: _selectedRoom,
                decoration: const InputDecoration(labelText: 'Apply To Room'),
                items: widget.rooms
                    .map((r) => DropdownMenuItem(value: r, child: Text(r)))
                    .toList(),
                onChanged: (v) => setState(() => _selectedRoom = v!),
                style: TextStyle(
                  fontSize: 18.0,
                  color: AppTheme.textPrimaryLight,
                ),
              ),
              SizedBox(height: 1.5.h),

              // Date range
              Text(
                'Date Range',
                style: TextStyle(
                  fontSize: 14.0,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textSecondaryLight,
                ),
              ),
              SizedBox(height: 0.8.h),
              Row(
                children: [
                  Expanded(
                    child: _DatePickerTile(
                      label: 'Start Date',
                      value: _fmtDate(_startDate),
                      onTap: () => _pickDate(true),
                    ),
                  ),
                  SizedBox(width: 2.w),
                  const Icon(
                    Icons.arrow_forward_rounded,
                    size: 16,
                    color: AppTheme.textMutedLight,
                  ),
                  SizedBox(width: 2.w),
                  Expanded(
                    child: _DatePickerTile(
                      label: 'End Date',
                      value: _fmtDate(_endDate),
                      onTap: () => _pickDate(false),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 1.5.h),

              // Rate per night
              TextFormField(
                controller: _rateCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Rate per Night (₹)',
                  prefixText: '₹ ',
                ),
                validator: (v) {
                  if (v == null || v.trim().isEmpty) return 'Enter a rate';
                  if (double.tryParse(v.trim()) == null) {
                    return 'Invalid number';
                  }
                  return null;
                },
              ),
              SizedBox(height: 1.5.h),

              // Notes
              TextFormField(
                controller: _notesCtrl,
                maxLines: 2,
                decoration: const InputDecoration(
                  labelText: 'Notes (optional)',
                  hintText: 'e.g. Applies to OTA listings, includes breakfast',
                ),
              ),
              SizedBox(height: 2.5.h),

              // Actions
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppTheme.textSecondaryLight,
                        side: const BorderSide(color: Color(0xFFDCE4E0)),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        padding: EdgeInsets.symmetric(vertical: 1.4.h),
                      ),
                      child: Text(
                        'Cancel',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _saving ? null : _submit,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.deepTeal,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        padding: EdgeInsets.symmetric(vertical: 1.4.h),
                      ),
                      child: _saving
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : Text(
                              isEdit ? 'Update' : 'Save Rate',
                              style: TextStyle(fontWeight: FontWeight.w600),
                            ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Date Picker Tile ────────────────────────────────────────────────────────

class _DatePickerTile extends StatelessWidget {
  final String label;
  final String value;
  final VoidCallback onTap;

  const _DatePickerTile({
    required this.label,
    required this.value,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.2.h),
        decoration: BoxDecoration(
          color: AppTheme.surfaceVariantLight,
          borderRadius: BorderRadius.circular(10),
          border: const Border.fromBorderSide(
            BorderSide(color: Color(0xFFDCE4E0)),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(fontSize: 12.0, color: AppTheme.textMutedLight),
            ),
            const SizedBox(height: 2),
            Text(
              value,
              style: TextStyle(
                fontSize: 13.0,
                fontWeight: FontWeight.w600,
                color: value == 'Select date'
                    ? AppTheme.textMutedLight
                    : AppTheme.textPrimaryLight,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}
