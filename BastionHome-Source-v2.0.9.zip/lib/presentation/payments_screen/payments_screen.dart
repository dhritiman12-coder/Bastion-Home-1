import 'package:flutter/material.dart';
import '../../widgets/app_back_button.dart';

import '../../database/repositories/payment_repository.dart';
import '../../database/repositories/booking_repository.dart';
import '../../models/payment_model.dart';
import '../../models/booking_model.dart';
import '../../utils/currency_formatter.dart';
import '../../utils/input_validators.dart';
import '../../core/app_constants.dart';
import '../../services/account_service.dart';
import '../../widgets/confirm_trash_dialog.dart';

class PaymentsScreen extends StatefulWidget {
  const PaymentsScreen({super.key});

  @override
  State<PaymentsScreen> createState() => _PaymentsScreenState();
}

class _PaymentsScreenState extends State<PaymentsScreen> {
  final PaymentRepository _repo = PaymentRepository();
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  String _modeFilter = 'All';
  bool _isLoading = true;

  List<PaymentModel> _allPayments = [];
  List<PaymentModel> _filteredPayments = [];

  final List<String> _modeFilters = ['All', ...AppConstants.paymentModes];

  @override
  void initState() {
    super.initState();
    _loadData();
    _searchController.addListener(() {
      setState(() {
        _searchQuery = _searchController.text.toLowerCase();
        _applyFilters();
      });
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final payments = await _repo.getAllPayments();
      if (!mounted) return;
      setState(() {
        _allPayments = payments;
        _isLoading = false;
        _applyFilters();
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
    }
  }

  void _applyFilters() {
    _filteredPayments = _allPayments.where((p) {
      final matchesSearch =
          _searchQuery.isEmpty ||
          p.bookingId.toLowerCase().contains(_searchQuery) ||
          p.guestName.toLowerCase().contains(_searchQuery);
      final matchesMode = _modeFilter == 'All' || p.modeLabel == _modeFilter;
      return matchesSearch && matchesMode;
    }).toList();
  }

  double get _totalReceived => _filteredPayments
      .where((p) => p.amount > 0)
      .fold(0.0, (s, p) => s + p.amount);

  double get _totalRefunded => _filteredPayments
      .where((p) => p.amount < 0)
      .fold(0.0, (s, p) => s + p.amount.abs());

  void _openPaymentForm({PaymentModel? payment}) async {
    final result = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => PaymentFormScreen(payment: payment)),
    );
    if (!mounted) return;
    if (result == true) _loadData();
  }

  Future<void> _deletePayment(PaymentModel payment) async {
    final label =
        '${CurrencyFormatter.format(payment.amount)} payment for ${payment.bookingId}';
    if (await confirmMoveToTrash(context, itemName: label)) {
      try {
        await _repo.deletePayment(payment.dbId!);
        _loadData();
      } catch (error) {
        if (mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text(error.toString())));
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colors = theme.colorScheme;
    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            _buildSearchBar(),
            _buildFilterChips(),
            _buildSummaryStrip(),
            Expanded(child: _buildPaymentList()),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openPaymentForm(),
        icon: const Icon(Icons.add_rounded, size: 20),
        label: Text(
          'Record Payment',
          style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
        ),
        backgroundColor: colors.secondary,
        foregroundColor: colors.onSecondary,
        elevation: 3,
      ),
    );
  }

  Widget _buildHeader() {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      color: theme.scaffoldBackgroundColor,
      child: Row(
        children: [
          AppBackButton(color: theme.colorScheme.onSurface),
          const SizedBox(width: 4),
          Text(
            'Payments',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w700,
              color: theme.colorScheme.onSurface,
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: theme.colorScheme.primary.withAlpha(26),
              borderRadius: BorderRadius.circular(50),
            ),
            child: Text(
              '${_filteredPayments.length} records',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w500,
                color: theme.colorScheme.primary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    final colors = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
      child: Container(
        height: 44,
        decoration: BoxDecoration(
          color: colors.surface,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: colors.outlineVariant),
        ),
        child: Row(
          children: [
            const SizedBox(width: 12),
            Icon(
              Icons.search_rounded,
              size: 18,
              color: colors.onSurfaceVariant,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller: _searchController,
                style: TextStyle(fontSize: 14, color: colors.onSurface),
                decoration: InputDecoration(
                  hintText: 'Search booking ID or guest…',
                  hintStyle: TextStyle(
                    fontSize: 14,
                    color: colors.onSurfaceVariant,
                  ),
                  border: InputBorder.none,
                  isDense: true,
                  contentPadding: EdgeInsets.zero,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChips() {
    final colors = Theme.of(context).colorScheme;
    return SizedBox(
      height: 36,
      child: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        scrollDirection: Axis.horizontal,
        itemCount: _modeFilters.length,
        itemBuilder: (_, i) {
          final filter = _modeFilters[i];
          final isSelected = _modeFilter == filter;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: GestureDetector(
              onTap: () {
                setState(() {
                  _modeFilter = filter;
                  _applyFilters();
                });
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 7,
                ),
                decoration: BoxDecoration(
                  color: isSelected ? colors.primary : colors.surface,
                  borderRadius: BorderRadius.circular(50),
                  border: Border.all(
                    color: isSelected ? colors.primary : colors.outlineVariant,
                  ),
                ),
                child: Text(
                  filter,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: isSelected ? colors.onPrimary : colors.onSurface,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildSummaryStrip() {
    final colors = Theme.of(context).colorScheme;
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 4),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: colors.primary,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Received',
                  style: TextStyle(
                    fontSize: 11,
                    color: colors.onPrimary.withAlpha(210),
                  ),
                ),
                Text(
                  CurrencyFormatter.format(_totalReceived),
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: colors.onPrimary,
                  ),
                ),
              ],
            ),
          ),
          Container(
            width: 1,
            height: 32,
            color: colors.onPrimary.withAlpha(80),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  'Refunded',
                  style: TextStyle(
                    fontSize: 11,
                    color: colors.onPrimary.withAlpha(210),
                  ),
                ),
                Text(
                  CurrencyFormatter.format(_totalRefunded),
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: colors.onPrimary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPaymentList() {
    final colors = Theme.of(context).colorScheme;
    if (_isLoading) return const Center(child: CircularProgressIndicator());

    if (_filteredPayments.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.payments_outlined,
              size: 56,
              color: colors.onSurfaceVariant,
            ),
            const SizedBox(height: 16),
            Text(
              'No payments found',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: colors.onSurface,
              ),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
      itemCount: _filteredPayments.length,
      itemBuilder: (_, i) {
        final p = _filteredPayments[i];
        return Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: _PaymentTile(
            payment: p,
            onEdit: () => _openPaymentForm(payment: p),
            onDelete: () => _deletePayment(p),
          ),
        );
      },
    );
  }
}

class _PaymentTile extends StatelessWidget {
  final PaymentModel payment;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const _PaymentTile({
    required this.payment,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final isRefund = payment.amount < 0;
    final colors = Theme.of(context).colorScheme;
    return Container(
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: colors.outlineVariant),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(8),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        leading: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: isRefund ? colors.errorContainer : colors.primaryContainer,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(
            isRefund ? Icons.undo_rounded : Icons.payments_rounded,
            color: isRefund
                ? colors.onErrorContainer
                : colors.onPrimaryContainer,
            size: 20,
          ),
        ),
        title: Row(
          children: [
            Expanded(
              child: Text(
                payment.guestName.isNotEmpty
                    ? payment.guestName
                    : payment.bookingId,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: colors.onSurface,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Text(
              CurrencyFormatter.format(payment.amount),
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: isRefund ? colors.error : colors.primary,
              ),
            ),
          ],
        ),
        subtitle: Text(
          '${DateFormatter.format(payment.date)} · ${payment.bookingId} · ${payment.typeLabel} · ${payment.modeLabel}',
          style: TextStyle(fontSize: 11, color: colors.onSurfaceVariant),
          overflow: TextOverflow.ellipsis,
        ),
        trailing: PopupMenuButton<String>(
          onSelected: (v) {
            if (v == 'edit') onEdit();
            if (v == 'delete') onDelete();
          },
          itemBuilder: (_) => [
            const PopupMenuItem(value: 'edit', child: Text('Edit')),
            if (AccountService().isAdmin)
              const PopupMenuItem(value: 'delete', child: Text('Delete')),
          ],
          child: Icon(
            Icons.more_vert,
            size: 20,
            color: colors.onSurfaceVariant,
          ),
        ),
      ),
    );
  }
}

// ── Payment Form Screen ────────────────────────────────────────────────────────

class PaymentFormScreen extends StatefulWidget {
  final PaymentModel? payment;
  const PaymentFormScreen({super.key, this.payment});

  @override
  State<PaymentFormScreen> createState() => _PaymentFormScreenState();
}

class _PaymentFormScreenState extends State<PaymentFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final PaymentRepository _repo = PaymentRepository();
  final BookingRepository _bookingRepo = BookingRepository();

  late TextEditingController _bookingIdCtrl;
  late TextEditingController _amountCtrl;
  late TextEditingController _byCtrl;
  late TextEditingController _notesCtrl;

  DateTime _date = DateTime.now();
  String _mode = AppConstants.paymentModes.first;
  String _type = AppConstants.paymentTypes.first;
  List<BookingModel> _bookings = [];
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    final p = widget.payment;
    _bookingIdCtrl = TextEditingController(text: p?.bookingId ?? '');
    _amountCtrl = TextEditingController(
      text: p != null ? p.amount.toString() : '',
    );
    _byCtrl = TextEditingController(
      text: p?.by.isNotEmpty == true
          ? p!.by
          : AccountService().currentAuditLabel,
    );
    _notesCtrl = TextEditingController(text: p?.notes ?? '');
    if (p != null) {
      _date = p.date;
      _mode = p.modeLabel;
      _type = p.typeLabel;
    }
    _loadBookings();
  }

  Future<void> _loadBookings() async {
    final bookings = await _bookingRepo.getAllBookings();
    if (!mounted) return;
    setState(() => _bookings = bookings);
  }

  @override
  void dispose() {
    _bookingIdCtrl.dispose();
    _amountCtrl.dispose();
    _byCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSaving = true);
    try {
      final enteredAmount = double.parse(_amountCtrl.text.trim());
      final payment = PaymentModel(
        dbId: widget.payment?.dbId,
        date: _date,
        bookingId: _bookingIdCtrl.text.trim(),
        amount: _type == 'Refund' ? -enteredAmount.abs() : enteredAmount,
        mode: PaymentModel.modeFromString(_mode),
        type: PaymentModel.typeFromString(_type),
        by: widget.payment?.by.isNotEmpty == true
            ? widget.payment!.by
            : AccountService().currentAuditLabel,
        notes: _notesCtrl.text.trim(),
      );
      if (widget.payment == null) {
        await _repo.insertPayment(payment);
      } else {
        await _repo.updatePayment(payment);
      }
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      setState(() => _isSaving = false);
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    }
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2020),
      lastDate: DateTime(DateTime.now().year + 10),
    );
    if (picked != null && mounted) setState(() => _date = picked);
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF0D1F25) : const Color(0xFFF7F4EE);
    final fieldFill = isDark ? const Color(0xFF123F34) : Colors.white;

    InputDecoration fieldDec(String label) => InputDecoration(
      labelText: label,
      filled: true,
      fillColor: fieldFill,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.grey.withAlpha(60)),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    );

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        leading: const AppBackButton(color: Colors.white),
        backgroundColor: const Color(0xFF123F34),
        title: Text(
          widget.payment == null ? 'Record Payment' : 'Edit Payment',
          style: TextStyle(color: Colors.white, fontSize: 14),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          TextButton(
            onPressed: _isSaving ? null : _save,
            child: Text(
              'Save',
              style: TextStyle(
                color: const Color(0xFF8E2A18),
                fontWeight: FontWeight.w700,
                fontSize: 14,
              ),
            ),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            GestureDetector(
              onTap: _pickDate,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 14,
                ),
                decoration: BoxDecoration(
                  color: fieldFill,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.grey.withAlpha(60)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.calendar_today, size: 18),
                    const SizedBox(width: 12),
                    Text(
                      DateFormatter.format(_date),
                      style: TextStyle(fontSize: 14),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              initialValue: _bookings.any((b) => b.id == _bookingIdCtrl.text)
                  ? _bookingIdCtrl.text
                  : null,
              decoration: fieldDec('Booking ID *'),
              items: _bookings
                  .map(
                    (b) => DropdownMenuItem(
                      value: b.id,
                      child: Text(
                        '${b.id} - ${b.guest}',
                        style: TextStyle(fontSize: 13),
                      ),
                    ),
                  )
                  .toList(),
              onChanged: (v) => setState(() => _bookingIdCtrl.text = v ?? ''),
              validator: (v) => (v == null || v.isEmpty) ? 'Required' : null,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _amountCtrl,
              decoration: fieldDec('Amount (₹) *'),
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              validator: (value) => InputValidators.money(
                value,
                required: true,
                allowZero: false,
              ),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              initialValue: _mode,
              decoration: fieldDec('Payment Mode'),
              items: AppConstants.paymentModes
                  .map(
                    (m) => DropdownMenuItem(
                      value: m,
                      child: Text(m, style: TextStyle(fontSize: 13)),
                    ),
                  )
                  .toList(),
              onChanged: (v) => setState(() => _mode = v!),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              initialValue: _type,
              decoration: fieldDec('Payment Type'),
              items: AppConstants.paymentTypes
                  .map(
                    (t) => DropdownMenuItem(
                      value: t,
                      child: Text(t, style: TextStyle(fontSize: 13)),
                    ),
                  )
                  .toList(),
              onChanged: (v) => setState(() => _type = v!),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _byCtrl,
              readOnly: true,
              decoration: fieldDec('Received By'),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _notesCtrl,
              decoration: fieldDec('Notes'),
              maxLines: 3,
            ),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }
}
