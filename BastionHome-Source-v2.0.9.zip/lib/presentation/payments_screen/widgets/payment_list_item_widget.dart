import 'package:flutter/material.dart';
import '../../../models/payment_model.dart';
import '../../../theme/app_theme.dart';
import '../../../utils/currency_formatter.dart';

// Rich data row — anatomy locked:
// [amount large + colour] left | [booking ID + guest + mode chip + type badge] right
class PaymentListItemWidget extends StatelessWidget {
  final PaymentModel payment;

  const PaymentListItemWidget({required this.payment, super.key});

  @override
  Widget build(BuildContext context) {
    final isRefund = payment.amount < 0;
    final amountColor = isRefund ? AppTheme.alertRed : AppTheme.successGreen;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isRefund
              ? AppTheme.alertRed.withAlpha(38)
              : const Color(0xFFEAE4DC),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(8),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Left: amount column
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                CurrencyFormatter.format(payment.amount),
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: amountColor,
                  fontFeatures: const [FontFeature.tabularFigures()],
                ),
              ),
              const SizedBox(height: 3),
              _ModeBadge(mode: payment.modeLabel),
            ],
          ),
          const SizedBox(width: 14),
          // Right: booking + guest + type
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      payment.bookingId,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.brassAccent,
                      ),
                    ),
                    const Spacer(),
                    _TypeBadge(type: payment.typeLabel),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  payment.guestName.isNotEmpty ? payment.guestName : 'Guest',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: AppTheme.deepTealDark,
                  ),
                ),
                if (payment.by.isNotEmpty || payment.notes.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(
                    [
                      if (payment.by.isNotEmpty) 'By: ${payment.by}',
                      if (payment.notes.isNotEmpty) payment.notes,
                    ].join(' · '),
                    style: TextStyle(
                      fontSize: 11,
                      color: AppTheme.textMutedLight,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ModeBadge extends StatelessWidget {
  final String mode;

  const _ModeBadge({required this.mode});

  @override
  Widget build(BuildContext context) {
    IconData icon;
    switch (mode) {
      case 'UPI':
        icon = Icons.phone_android_rounded;
        break;
      case 'Card':
        icon = Icons.credit_card_rounded;
        break;
      case 'Bank Transfer':
        icon = Icons.account_balance_rounded;
        break;
      case 'Cheque':
        icon = Icons.description_outlined;
        break;
      default:
        icon = Icons.payments_outlined;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: AppTheme.deepTeal.withAlpha(20),
        borderRadius: BorderRadius.circular(50),
        border: Border.all(color: AppTheme.deepTeal.withAlpha(38), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 10, color: AppTheme.deepTeal),
          const SizedBox(width: 4),
          Text(
            mode,
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w500,
              color: AppTheme.deepTeal,
            ),
          ),
        ],
      ),
    );
  }
}

class _TypeBadge extends StatelessWidget {
  final String type;

  const _TypeBadge({required this.type});

  @override
  Widget build(BuildContext context) {
    Color bg, border, text;
    switch (type) {
      case 'Refund':
        bg = AppTheme.alertRed.withAlpha(26);
        border = AppTheme.alertRed.withAlpha(64);
        text = AppTheme.alertRed;
        break;
      case 'Full Payment':
        bg = AppTheme.successGreen.withAlpha(26);
        border = AppTheme.successGreen.withAlpha(64);
        text = AppTheme.successGreen;
        break;
      case 'Advance':
        bg = AppTheme.brassAccent.withAlpha(26);
        border = AppTheme.brassAccent.withAlpha(64);
        text = AppTheme.brassAccent;
        break;
      default: // Balance
        bg = AppTheme.deepTeal.withAlpha(20);
        border = AppTheme.deepTeal.withAlpha(51);
        text = AppTheme.deepTeal;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(50),
        border: Border.all(color: border, width: 1),
      ),
      child: Text(
        type,
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w600,
          color: text,
          letterSpacing: 0,
        ),
      ),
    );
  }
}
