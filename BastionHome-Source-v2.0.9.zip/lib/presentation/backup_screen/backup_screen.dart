import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../../widgets/app_back_button.dart';
import 'package:path/path.dart' as path;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';

import '../../database/database_helper.dart';
import '../../services/notification_service.dart';
import '../../services/id_vault_service.dart';
import '../../services/app_settings_service.dart';
import '../../services/logo_service.dart';
import '../../services/download_service.dart';
import '../../utils/currency_formatter.dart';

class BackupScreen extends StatefulWidget {
  const BackupScreen({super.key});

  @override
  State<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends State<BackupScreen> {
  static const int _maxBackupBytes = 100 * 1024 * 1024;
  final DatabaseHelper _db = DatabaseHelper();
  final IdVaultService _vault = IdVaultService();
  String? _lastBackupTime;
  bool _isExporting = false;
  bool _isImporting = false;

  @override
  void initState() {
    super.initState();
    _loadLastBackupTime();
  }

  Future<void> _loadLastBackupTime() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _lastBackupTime = prefs.getString('last_backup_time');
    });
  }

  Future<void> _exportJson() async {
    setState(() => _isExporting = true);
    try {
      final data = await _db.exportAll();
      data['idImages'] = await _exportIdImages(data);
      data['appSettings'] = AppSettingsService().toBackupMap();
      data['propertySettings'] = await LogoService().getAllSettings();
      final json = const JsonEncoder.withIndent('  ').convert(data);
      final now = DateTime.now();
      final fileName =
          'bastion_home_backup_${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}.json';

      final location = await _writeExportFile(fileName, json);

      final prefs = await SharedPreferences.getInstance();
      final timeStr = DateFormatter.format(now);
      await prefs.setString('last_backup_time', timeStr);
      if (mounted) setState(() => _lastBackupTime = timeStr);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Backup downloaded to $location'),
            backgroundColor: Color(0xFF3D6B4A),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Export failed: $e')));
      }
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  Future<void> _exportCsv() async {
    setState(() => _isExporting = true);
    try {
      final db = await _db.database;
      final buffer = StringBuffer();
      const tables = {
        'BOOKINGS': 'bookings',
        'PAYMENTS': 'payments',
        'DAILY EXPENSES': 'daily_expenses',
        'MONTHLY EXPENSES': 'monthly_expenses',
        'YEARLY EXPENSES': 'yearly_expenses',
        'GUEST IDS': 'id_records',
        'INVENTORY': 'inventory',
      };
      for (final table in tables.entries) {
        final rows = await db.query(table.value);
        if (buffer.isNotEmpty) buffer.writeln();
        buffer.writeln('=== ${table.key} ===');
        if (rows.isNotEmpty) {
          buffer.writeln(rows.first.keys.map(_csvCell).join(','));
          for (final row in rows) {
            buffer.writeln(row.values.map(_csvCell).join(','));
          }
        }
      }

      final location = await _writeExportFile(
        'bastion_home_export.csv',
        buffer.toString(),
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('CSV downloaded to $location'),
            backgroundColor: Color(0xFF3D6B4A),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('CSV export failed: $e')));
      }
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  Future<void> _importJson() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Restore from Backup'),
        content: const Text(
          'This will replace ALL current data with the backup. This cannot be undone. Are you sure?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text(
              'Restore',
              style: TextStyle(color: Color(0xFFA2432F)),
            ),
          ),
        ],
      ),
    );
    if (confirm != true) return;

    final selected = await FilePicker.pickFile(
      type: FileType.custom,
      allowedExtensions: const ['json'],
    );
    if (selected == null) return;
    final selectedLength = await selected.length();
    if (selectedLength == null || selectedLength > _maxBackupBytes) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Backup is larger than the 100 MB limit'),
          ),
        );
      }
      return;
    }

    setState(() => _isImporting = true);
    try {
      final json = utf8.decode(await selected.readAsBytes());
      final data = jsonDecode(json) as Map<String, dynamic>;
      await _db.validateBackup(data);
      final decodedImages = _decodeIdImages(data['idImages']);
      final restoredFiles = await _restoreIdImages(decodedImages);
      _remapIdImageReferences(data, restoredFiles);
      try {
        await _db.importAll(data);
      } catch (_) {
        await Future.wait(restoredFiles.values.map(_vault.delete));
        rethrow;
      }
      if (data['appSettings'] is Map) {
        await AppSettingsService().restoreFromBackup(
          Map<String, dynamic>.from(data['appSettings'] as Map),
        );
      }
      if (data['propertySettings'] is Map) {
        await LogoService().restoreSettings(
          Map<String, dynamic>.from(data['propertySettings'] as Map),
        );
      }
      await NotificationService().scheduleAllNotifications();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Data restored successfully! Restart the app to see changes.',
            ),
            backgroundColor: Color(0xFF3D6B4A),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Import failed: Invalid JSON format')),
        );
      }
    } finally {
      if (mounted) setState(() => _isImporting = false);
    }
  }

  Future<String> _writeExportFile(String fileName, String contents) =>
      DownloadService().saveText(
        fileName: fileName,
        contents: contents,
        mimeType: fileName.endsWith('.json') ? 'application/json' : 'text/csv',
      );

  Future<Map<String, String>> _exportIdImages(Map<String, dynamic> data) async {
    final names = <String>{};
    for (final row in data['id_records'] as List<dynamic>? ?? const []) {
      final name = (row as Map)['fileName'] as String? ?? '';
      if (name.endsWith('.bhid')) names.add(name);
    }
    for (final row in data['bookings'] as List<dynamic>? ?? const []) {
      final map = row as Map;
      final front = map['idFrontPath'] as String? ?? '';
      final back = map['idBackPath'] as String? ?? '';
      if (front.endsWith('.bhid')) names.add(front);
      if (back.endsWith('.bhid')) names.add(back);
    }

    final images = <String, String>{};
    for (final name in names) {
      images[name] = base64Encode(await _vault.readDecrypted(name));
    }
    return images;
  }

  Map<String, List<int>> _decodeIdImages(dynamic value) {
    if (value == null) return const {};
    if (value is! Map) throw const FormatException('Invalid ID image backup');
    if (value.length > 10000) {
      throw const FormatException('Too many ID images in backup');
    }
    final decoded = <String, List<int>>{};
    for (final entry in value.entries) {
      if (entry.key is! String || entry.value is! String) {
        throw const FormatException('Invalid ID image backup entry');
      }
      final fileName = entry.key as String;
      if (fileName != path.basename(fileName) || !fileName.endsWith('.bhid')) {
        throw const FormatException('Invalid ID image backup name');
      }
      final encoded = entry.value as String;
      if (encoded.length > (IdVaultService.maxImageBytes * 4 ~/ 3) + 8) {
        throw const FormatException('ID image backup entry is too large');
      }
      final bytes = base64Decode(encoded);
      if (bytes.isEmpty || bytes.length > IdVaultService.maxImageBytes) {
        throw const FormatException('Invalid ID image backup entry');
      }
      decoded[fileName] = bytes;
    }
    return decoded;
  }

  Future<Map<String, String>> _restoreIdImages(
    Map<String, List<int>> images,
  ) async {
    final restored = <String, String>{};
    try {
      for (final entry in images.entries) {
        restored[entry.key] = await _vault.storeBytes(entry.value);
      }
      return restored;
    } catch (_) {
      await Future.wait(restored.values.map(_vault.delete));
      rethrow;
    }
  }

  void _remapIdImageReferences(
    Map<String, dynamic> data,
    Map<String, String> restoredFiles,
  ) {
    for (final value in data['id_records'] as List<dynamic>? ?? const []) {
      final row = value as Map;
      final oldName = row['fileName'];
      if (oldName is String && restoredFiles.containsKey(oldName)) {
        row['fileName'] = restoredFiles[oldName];
      }
    }
    for (final value in data['bookings'] as List<dynamic>? ?? const []) {
      final row = value as Map;
      for (final field in const ['idFrontPath', 'idBackPath']) {
        final oldName = row[field];
        if (oldName is String && restoredFiles.containsKey(oldName)) {
          row[field] = restoredFiles[oldName];
        }
      }
    }
  }

  String _csvCell(dynamic value) {
    final text = (value ?? '').toString().replaceAll('"', '""');
    return '"$text"';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF0D1F25) : const Color(0xFFF7F4EE);
    final cardColor = isDark ? const Color(0xFF123F34) : Colors.white;
    final inkColor = isDark ? Colors.white : const Color(0xFF0E332B);
    final accentColor = const Color(0xFF8E2A18);

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        leading: const AppBackButton(color: Colors.white),
        backgroundColor: isDark
            ? const Color(0xFF0E332B)
            : const Color(0xFF123F34),
        elevation: 0,
        title: Text(
          'BASTION HOME',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20.0,
            fontWeight: FontWeight.w700,
            letterSpacing: 0,
          ),
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: accentColor.withAlpha(80)),
        ),
      ),
      body: ListView(
        padding: EdgeInsets.all(4.w),
        children: [
          SizedBox(height: 1.h),
          Text(
            'Backup & Restore',
            style: TextStyle(
              fontSize: 24.0,
              fontWeight: FontWeight.w700,
              color: inkColor,
            ),
          ),
          SizedBox(height: 0.5.h),
          Text(
            'All data is stored locally on this device. Export regularly to prevent data loss.',
            style: TextStyle(fontSize: 13.0, color: inkColor.withAlpha(160)),
          ),
          SizedBox(height: 2.h),

          // Last backup info
          if (_lastBackupTime != null)
            Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: const Color(0xFF3D6B4A).withAlpha(20),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: const Color(0xFF3D6B4A).withAlpha(60),
                ),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.check_circle_outline,
                    color: Color(0xFF3D6B4A),
                    size: 20,
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    'Last backup: $_lastBackupTime',
                    style: TextStyle(
                      fontSize: 13.0,
                      color: const Color(0xFF3D6B4A),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          if (_lastBackupTime == null)
            Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: const Color(0xFFA2432F).withAlpha(20),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: const Color(0xFFA2432F).withAlpha(60),
                ),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.warning_amber_outlined,
                    color: Color(0xFFA2432F),
                    size: 20,
                  ),
                  SizedBox(width: 2.w),
                  Expanded(
                    child: Text(
                      'No backup found. Export your data now to prevent loss.',
                      style: TextStyle(
                        fontSize: 13.0,
                        color: const Color(0xFFA2432F),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),

          SizedBox(height: 3.h),

          // Export section
          _sectionHeader('Download Data', inkColor),
          SizedBox(height: 1.h),

          _actionCard(
            cardColor: cardColor,
            inkColor: inkColor,
            icon: Icons.backup_outlined,
            iconColor: const Color(0xFF123F34),
            title: 'Download Full Backup (JSON)',
            subtitle:
                'Complete database export. Use this for backup and restore.',
            buttonLabel: 'Download JSON',
            buttonColor: const Color(0xFF123F34),
            isLoading: _isExporting,
            onTap: _exportJson,
          ),
          SizedBox(height: 1.5.h),

          _actionCard(
            cardColor: cardColor,
            inkColor: inkColor,
            icon: Icons.table_chart_outlined,
            iconColor: accentColor,
            title: 'Download as CSV',
            subtitle: 'Bookings, payments, and expenses in spreadsheet format.',
            buttonLabel: 'Download CSV',
            buttonColor: accentColor,
            isLoading: _isExporting,
            onTap: _exportCsv,
          ),

          SizedBox(height: 3.h),

          // Import section
          _sectionHeader('Restore Data', inkColor),
          SizedBox(height: 1.h),

          _actionCard(
            cardColor: cardColor,
            inkColor: inkColor,
            icon: Icons.restore_outlined,
            iconColor: const Color(0xFFA2432F),
            title: 'Restore from JSON Backup',
            subtitle:
                'Replaces all current data. Use only with a valid JSON backup.',
            buttonLabel: 'Restore',
            buttonColor: const Color(0xFFA2432F),
            isLoading: _isImporting,
            onTap: _importJson,
          ),

          SizedBox(height: 3.h),

          // Info section
          Container(
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withAlpha(isDark ? 30 : 10),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(
                      Icons.info_outline,
                      size: 18,
                      color: Color(0xFF8E2A18),
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Privacy & Data',
                      style: TextStyle(
                        fontSize: 14.0,
                        fontWeight: FontWeight.w700,
                        color: inkColor,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 1.h),
                Text(
                  '• Local data is encrypted on this device\n'
                  '• Operational records sync only when Cloud Sync is configured\n'
                  '• Guest ID images and app PINs are never cloud-synchronized\n'
                  '• No analytics, ads, or tracking\n'
                  '• Export files contain guest personal data — handle securely\n'
                  '• Recommended: export backup weekly',
                  style: TextStyle(
                    fontSize: 13.0,
                    color: inkColor.withAlpha(160),
                    height: 1.6,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 4.h),
        ],
      ),
    );
  }

  Widget _sectionHeader(String title, Color inkColor) {
    return Text(
      title,
      style: TextStyle(
        fontSize: 16.0,
        fontWeight: FontWeight.w700,
        color: inkColor,
        letterSpacing: 0,
      ),
    );
  }

  Widget _actionCard({
    required Color cardColor,
    required Color inkColor,
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    required String buttonLabel,
    required Color buttonColor,
    required bool isLoading,
    required VoidCallback onTap,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(15),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      padding: EdgeInsets.all(4.w),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: iconColor.withAlpha(20),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: iconColor, size: 22),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 14.0,
                    fontWeight: FontWeight.w600,
                    color: inkColor,
                  ),
                ),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: 12.0,
                    color: inkColor.withAlpha(140),
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          SizedBox(width: 2.w),
          ElevatedButton(
            onPressed: isLoading ? null : onTap,
            style: ElevatedButton.styleFrom(
              backgroundColor: buttonColor,
              foregroundColor: Colors.white,
              padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: isLoading
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: Colors.white,
                    ),
                  )
                : Text(
                    buttonLabel,
                    style: TextStyle(
                      fontSize: 13.0,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
