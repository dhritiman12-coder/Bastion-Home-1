import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import '../../widgets/app_back_button.dart';
import 'package:sizer/sizer.dart';

import '../../models/booking_model.dart';
import '../../models/payment_model.dart';
import '../../database/repositories/booking_repository.dart';
import '../../database/repositories/payment_repository.dart';
import '../../theme/app_theme.dart';
import '../../utils/currency_formatter.dart';
import '../../services/id_vault_service.dart';
import '../../utils/phone_normalizer.dart';
import '../invoice_screen/invoice_screen.dart';

class CustomerDetailsScreen extends StatefulWidget {
  final BookingModel initialBooking;

  const CustomerDetailsScreen({required this.initialBooking, super.key});

  @override
  State<CustomerDetailsScreen> createState() => _CustomerDetailsScreenState();
}

class _CustomerDetailsScreenState extends State<CustomerDetailsScreen>
    with SingleTickerProviderStateMixin {
  final BookingRepository _bookingRepo = BookingRepository();
  final PaymentRepository _paymentRepo = PaymentRepository();
  final IdVaultService _vault = IdVaultService();

  late TabController _tabController;

  List<BookingModel> _allBookings = [];
  List<PaymentModel> _allPayments = [];
  bool _isLoading = true;

  double get _lifetimeSpend {
    return _allBookings.fold(0.0, (sum, b) {
      if (b.status == BookingStatus.cancelled) return sum;
      return sum + b.total;
    });
  }

  double get _lifetimeReceived {
    return _allPayments.fold(0.0, (sum, p) => sum + p.amount);
  }

  double get _lifetimeDue => _lifetimeSpend - _lifetimeReceived;

  int get _totalStays =>
      _allBookings.where((b) => b.status != BookingStatus.cancelled).length;

  int get _totalNights => _allBookings
      .where((b) => b.status != BookingStatus.cancelled)
      .fold(0, (sum, b) => sum + b.nights);

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final guestName = widget.initialBooking.guest.trim().toLowerCase();
      final guestPhone = PhoneNormalizer.canonical(widget.initialBooking.phone);

      final allBookings = await _bookingRepo.getAllBookings();
      final matchedBookings = allBookings.where((b) {
        if (guestPhone.isNotEmpty) {
          return PhoneNormalizer.canonical(b.phone) == guestPhone;
        }
        return b.guest.trim().toLowerCase() == guestName;
      }).toList()..sort((a, b) => b.checkin.compareTo(a.checkin));

      final bookingIds = matchedBookings.map((b) => b.id).toSet();
      final allPayments = await _paymentRepo.getAllPayments();
      final matchedPayments =
          allPayments.where((p) => bookingIds.contains(p.bookingId)).toList()
            ..sort((a, b) => b.date.compareTo(a.date));

      setState(() {
        _allBookings = matchedBookings;
        _allPayments = matchedPayments;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF0D1F25) : AppTheme.backgroundLight;
    final inkColor = isDark ? Colors.white : AppTheme.deepTealDark;

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        leading: const AppBackButton(color: Colors.white),
        backgroundColor: isDark
            ? const Color(0xFF0E332B)
            : AppTheme.deepTealDark,
        elevation: 0,
        title: Text(
          'Guest Profile',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20.0,
            fontWeight: FontWeight.w600,
            letterSpacing: 0,
          ),
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            color: AppTheme.brassAccent.withAlpha(80),
          ),
        ),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: AppTheme.deepTeal),
            )
          : Column(
              children: [
                _ProfileHeader(
                  booking: widget.initialBooking,
                  totalStays: _totalStays,
                  totalNights: _totalNights,
                  lifetimeSpend: _lifetimeSpend,
                  lifetimeDue: _lifetimeDue,
                  isDark: isDark,
                  inkColor: inkColor,
                ),
                _TabBar(tabController: _tabController),
                Expanded(
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      _BookingHistoryTab(
                        bookings: _allBookings,
                        isDark: isDark,
                        inkColor: inkColor,
                        onInvoiceTap: (b) => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => InvoiceScreen(booking: b),
                          ),
                        ),
                      ),
                      _PaymentRecordsTab(
                        payments: _allPayments,
                        isDark: isDark,
                        inkColor: inkColor,
                      ),
                      _IdRecordsTab(
                        booking: widget.initialBooking,
                        vault: _vault,
                        isDark: isDark,
                        inkColor: inkColor,
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}

// ── Profile Header ────────────────────────────────────────────────────────────

class _ProfileHeader extends StatelessWidget {
  final BookingModel booking;
  final int totalStays;
  final int totalNights;
  final double lifetimeSpend;
  final double lifetimeDue;
  final bool isDark;
  final Color inkColor;

  const _ProfileHeader({
    required this.booking,
    required this.totalStays,
    required this.totalNights,
    required this.lifetimeSpend,
    required this.lifetimeDue,
    required this.isDark,
    required this.inkColor,
  });

  @override
  Widget build(BuildContext context) {
    final cardColor = isDark ? const Color(0xFF0E332B) : AppTheme.deepTealDark;

    return Container(
      color: cardColor,
      padding: EdgeInsets.fromLTRB(4.w, 2.h, 4.w, 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Avatar + Name + Contact
          Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: AppTheme.brassAccent.withAlpha(40),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: AppTheme.brassAccent.withAlpha(100),
                    width: 1.5,
                  ),
                ),
                child: Center(
                  child: Text(
                    booking.guest.isNotEmpty
                        ? booking.guest[0].toUpperCase()
                        : '?',
                    style: TextStyle(
                      fontSize: 32.0,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.brassAccent,
                    ),
                  ),
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      booking.guest,
                      style: TextStyle(
                        fontSize: 20.0,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                    ),
                    if (booking.phone.isNotEmpty) ...[
                      SizedBox(height: 0.3.h),
                      Row(
                        children: [
                          Icon(
                            Icons.phone_outlined,
                            size: 12,
                            color: Colors.white.withAlpha(160),
                          ),
                          SizedBox(width: 1.w),
                          Text(
                            booking.phone,
                            style: TextStyle(
                              fontSize: 13.0,
                              color: Colors.white.withAlpha(160),
                            ),
                          ),
                        ],
                      ),
                    ],
                    if (booking.address.isNotEmpty) ...[
                      SizedBox(height: 0.3.h),
                      Row(
                        children: [
                          Icon(
                            Icons.location_on_outlined,
                            size: 12,
                            color: Colors.white.withAlpha(120),
                          ),
                          SizedBox(width: 1.w),
                          Expanded(
                            child: Text(
                              booking.address,
                              style: TextStyle(
                                fontSize: 12.0,
                                color: Colors.white.withAlpha(120),
                              ),
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          // ID info row
          if (booking.idType.isNotEmpty || booking.idNumber.isNotEmpty)
            Container(
              padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
              decoration: BoxDecoration(
                color: Colors.white.withAlpha(12),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.badge_outlined,
                    size: 14,
                    color: AppTheme.brassLight,
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    booking.idType.isNotEmpty ? booking.idType : 'ID',
                    style: TextStyle(
                      fontSize: 13.0,
                      color: AppTheme.brassLight,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  if (booking.idNumber.isNotEmpty) ...[
                    Text(
                      '  ·  ',
                      style: TextStyle(color: Colors.white.withAlpha(80)),
                    ),
                    Text(
                      booking.idNumber,
                      style: TextStyle(
                        fontSize: 13.0,
                        color: Colors.white.withAlpha(180),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          SizedBox(height: 2.h),
          // Stats row
          Row(
            children: [
              _StatChip(
                label: 'Stays',
                value: '$totalStays',
                icon: Icons.hotel_outlined,
              ),
              SizedBox(width: 2.w),
              _StatChip(
                label: 'Nights',
                value: '$totalNights',
                icon: Icons.nights_stay_outlined,
              ),
              SizedBox(width: 2.w),
              _StatChip(
                label: 'Lifetime Spend',
                value: CurrencyFormatter.format(lifetimeSpend),
                icon: Icons.currency_rupee_rounded,
                highlight: true,
              ),
              if (lifetimeDue > 0) ...[
                SizedBox(width: 2.w),
                _StatChip(
                  label: 'Due',
                  value: CurrencyFormatter.format(lifetimeDue),
                  icon: Icons.warning_amber_rounded,
                  isAlert: true,
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final bool highlight;
  final bool isAlert;

  const _StatChip({
    required this.label,
    required this.value,
    required this.icon,
    this.highlight = false,
    this.isAlert = false,
  });

  @override
  Widget build(BuildContext context) {
    final bgColor = isAlert
        ? AppTheme.alertRed.withAlpha(40)
        : highlight
        ? AppTheme.brassAccent.withAlpha(40)
        : Colors.white.withAlpha(15);
    final textColor = isAlert
        ? const Color(0xFFFF8A80)
        : highlight
        ? AppTheme.brassLight
        : Colors.white.withAlpha(200);

    return Expanded(
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 1.h),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: isAlert
                ? AppTheme.alertRed.withAlpha(80)
                : highlight
                ? AppTheme.brassAccent.withAlpha(80)
                : Colors.white.withAlpha(20),
            width: 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 12, color: textColor),
            SizedBox(height: 0.3.h),
            Text(
              value,
              style: TextStyle(
                fontSize: 12.0,
                fontWeight: FontWeight.w700,
                color: textColor,
              ),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
            Text(
              label,
              style: TextStyle(fontSize: 11.0, color: textColor.withAlpha(160)),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Tab Bar ───────────────────────────────────────────────────────────────────

class _TabBar extends StatelessWidget {
  final TabController tabController;

  const _TabBar({required this.tabController});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      color: isDark ? const Color(0xFF123F34) : AppTheme.deepTeal,
      child: TabBar(
        controller: tabController,
        indicatorColor: AppTheme.brassAccent,
        indicatorWeight: 2.5,
        labelColor: Colors.white,
        unselectedLabelColor: Colors.white.withAlpha(120),
        labelStyle: TextStyle(fontSize: 13.0, fontWeight: FontWeight.w600),
        unselectedLabelStyle: TextStyle(
          fontSize: 13.0,
          fontWeight: FontWeight.w400,
        ),
        tabs: const [
          Tab(text: 'Bookings'),
          Tab(text: 'Payments'),
          Tab(text: 'ID Records'),
        ],
      ),
    );
  }
}

// ── Booking History Tab ───────────────────────────────────────────────────────

class _BookingHistoryTab extends StatelessWidget {
  final List<BookingModel> bookings;
  final bool isDark;
  final Color inkColor;
  final void Function(BookingModel) onInvoiceTap;

  const _BookingHistoryTab({
    required this.bookings,
    required this.isDark,
    required this.inkColor,
    required this.onInvoiceTap,
  });

  @override
  Widget build(BuildContext context) {
    if (bookings.isEmpty) {
      return _EmptyState(
        icon: Icons.hotel_outlined,
        message: 'No booking history found',
        isDark: isDark,
        inkColor: inkColor,
      );
    }

    return ListView.builder(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
      itemCount: bookings.length,
      itemBuilder: (_, i) => _BookingHistoryCard(
        booking: bookings[i],
        isDark: isDark,
        inkColor: inkColor,
        onInvoiceTap: () => onInvoiceTap(bookings[i]),
      ),
    );
  }
}

class _BookingHistoryCard extends StatelessWidget {
  final BookingModel booking;
  final bool isDark;
  final Color inkColor;
  final VoidCallback onInvoiceTap;

  const _BookingHistoryCard({
    required this.booking,
    required this.isDark,
    required this.inkColor,
    required this.onInvoiceTap,
  });

  Color get _statusColor {
    switch (booking.status) {
      case BookingStatus.checkedIn:
        return AppTheme.successGreen;
      case BookingStatus.checkedOut:
        return AppTheme.deepTeal;
      case BookingStatus.cancelled:
        return AppTheme.alertRed;
      case BookingStatus.noShow:
        return AppTheme.brassAccent;
      default:
        return const Color(0xFF5C6BC0);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cardColor = isDark ? const Color(0xFF123F34) : Colors.white;
    final payStatus = booking.payStatus;

    Color payColor;
    String payLabel;
    switch (payStatus) {
      case PayStatus.paid:
        payColor = AppTheme.successGreen;
        payLabel = 'Paid';
        break;
      case PayStatus.partial:
        payColor = AppTheme.brassAccent;
        payLabel = 'Partial';
        break;
      case PayStatus.unpaid:
        payColor = AppTheme.alertRed;
        payLabel = 'Unpaid';
        break;
      default:
        payColor = AppTheme.textMutedLight;
        payLabel = '—';
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFEAE4DC)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(isDark ? 40 : 10),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Status strip
          Container(
            width: 4,
            decoration: BoxDecoration(
              color: _statusColor,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(12),
                bottomLeft: Radius.circular(12),
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.2.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Row 1: Booking ID + Room + Status
                  Row(
                    children: [
                      Text(
                        booking.id,
                        style: TextStyle(
                          fontSize: 13.0,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.brassAccent,
                        ),
                      ),
                      SizedBox(width: 2.w),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 7,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: AppTheme.deepTeal.withAlpha(20),
                          borderRadius: BorderRadius.circular(50),
                        ),
                        child: Text(
                          booking.roomLabel,
                          style: TextStyle(
                            fontSize: 12.0,
                            fontWeight: FontWeight.w500,
                            color: AppTheme.deepTeal,
                          ),
                        ),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 7,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: _statusColor.withAlpha(25),
                          borderRadius: BorderRadius.circular(50),
                        ),
                        child: Text(
                          booking.statusLabel,
                          style: TextStyle(
                            fontSize: 12.0,
                            fontWeight: FontWeight.w600,
                            color: _statusColor,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 0.6.h),
                  // Row 2: Dates + Nights
                  Row(
                    children: [
                      Icon(
                        Icons.calendar_today_outlined,
                        size: 11,
                        color: AppTheme.textMutedLight,
                      ),
                      SizedBox(width: 1.w),
                      Expanded(
                        child: Text(
                          '${_fmtDate(booking.checkin)} → ${_fmtDate(booking.checkout)}  (${booking.nights}n)',
                          style: TextStyle(
                            fontSize: 12.0,
                            color: AppTheme.textSecondaryLight,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 0.6.h),
                  // Row 3: Financials
                  Row(
                    children: [
                      Text(
                        CurrencyFormatter.format(booking.total),
                        style: TextStyle(
                          fontSize: 13.0,
                          fontWeight: FontWeight.w700,
                          color: inkColor,
                        ),
                      ),
                      SizedBox(width: 2.w),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: payColor.withAlpha(25),
                          borderRadius: BorderRadius.circular(50),
                        ),
                        child: Text(
                          payLabel,
                          style: TextStyle(
                            fontSize: 12.0,
                            fontWeight: FontWeight.w600,
                            color: payColor,
                          ),
                        ),
                      ),
                      if (booking.due > 0) ...[
                        SizedBox(width: 2.w),
                        Text(
                          'Due: ${CurrencyFormatter.format(booking.due)}',
                          style: TextStyle(
                            fontSize: 12.0,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.alertRed,
                          ),
                        ),
                      ],
                      const Spacer(),
                      GestureDetector(
                        onTap: onInvoiceTap,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: AppTheme.brassAccent.withAlpha(20),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(
                              color: AppTheme.brassAccent.withAlpha(60),
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.receipt_long_outlined,
                                size: 12,
                                color: AppTheme.brassAccent,
                              ),
                              SizedBox(width: 1.w),
                              Text(
                                'Invoice',
                                style: TextStyle(
                                  fontSize: 12.0,
                                  fontWeight: FontWeight.w600,
                                  color: AppTheme.brassAccent,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  if (booking.serialNumber.isNotEmpty) ...[
                    SizedBox(height: 0.4.h),
                    Text(
                      'Serial: ${booking.serialNumber}',
                      style: TextStyle(
                        fontSize: 11.0,
                        color: AppTheme.textMutedLight,
                      ),
                    ),
                  ],
                  SizedBox(height: 0.4.h),
                  Text(
                    'Source: ${booking.bookingSourceLabel}',
                    style: TextStyle(
                      fontSize: 11.0,
                      color: AppTheme.textMutedLight,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _fmtDate(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
}

// ── Payment Records Tab ───────────────────────────────────────────────────────

class _PaymentRecordsTab extends StatelessWidget {
  final List<PaymentModel> payments;
  final bool isDark;
  final Color inkColor;

  const _PaymentRecordsTab({
    required this.payments,
    required this.isDark,
    required this.inkColor,
  });

  @override
  Widget build(BuildContext context) {
    if (payments.isEmpty) {
      return _EmptyState(
        icon: Icons.payments_outlined,
        message: 'No payment records found',
        isDark: isDark,
        inkColor: inkColor,
      );
    }

    final totalReceived = payments.fold(0.0, (s, p) => s + p.amount);

    return Column(
      children: [
        // Summary banner
        Container(
          margin: EdgeInsets.fromLTRB(4.w, 1.5.h, 4.w, 0),
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.2.h),
          decoration: BoxDecoration(
            color: AppTheme.successGreen.withAlpha(20),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppTheme.successGreen.withAlpha(60)),
          ),
          child: Row(
            children: [
              Icon(
                Icons.check_circle_outline_rounded,
                size: 16,
                color: AppTheme.successGreen,
              ),
              SizedBox(width: 2.w),
              Text(
                'Total Received',
                style: TextStyle(
                  fontSize: 13.0,
                  color: AppTheme.successGreen,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const Spacer(),
              Text(
                CurrencyFormatter.format(totalReceived),
                style: TextStyle(
                  fontSize: 16.0,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.successGreen,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
            itemCount: payments.length,
            itemBuilder: (_, i) => _PaymentCard(
              payment: payments[i],
              isDark: isDark,
              inkColor: inkColor,
            ),
          ),
        ),
      ],
    );
  }
}

class _PaymentCard extends StatelessWidget {
  final PaymentModel payment;
  final bool isDark;
  final Color inkColor;

  const _PaymentCard({
    required this.payment,
    required this.isDark,
    required this.inkColor,
  });

  @override
  Widget build(BuildContext context) {
    final cardColor = isDark ? const Color(0xFF123F34) : Colors.white;
    final isRefund = payment.type == PaymentType.refund;

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.2.h),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFFEAE4DC)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(isDark ? 30 : 8),
            blurRadius: 5,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: isRefund
                  ? AppTheme.alertRed.withAlpha(20)
                  : AppTheme.successGreen.withAlpha(20),
              borderRadius: BorderRadius.circular(9),
            ),
            child: Icon(
              isRefund ? Icons.undo_rounded : Icons.arrow_downward_rounded,
              size: 18,
              color: isRefund ? AppTheme.alertRed : AppTheme.successGreen,
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      payment.typeLabel,
                      style: TextStyle(
                        fontSize: 13.0,
                        fontWeight: FontWeight.w600,
                        color: inkColor,
                      ),
                    ),
                    SizedBox(width: 2.w),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 1,
                      ),
                      decoration: BoxDecoration(
                        color: AppTheme.deepTeal.withAlpha(20),
                        borderRadius: BorderRadius.circular(50),
                      ),
                      child: Text(
                        payment.modeLabel,
                        style: TextStyle(
                          fontSize: 11.0,
                          color: AppTheme.deepTeal,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 0.2.h),
                Row(
                  children: [
                    Text(
                      payment.bookingId,
                      style: TextStyle(
                        fontSize: 12.0,
                        color: AppTheme.brassAccent,
                      ),
                    ),
                    Text(
                      '  ·  ${_fmtDate(payment.date)}',
                      style: TextStyle(
                        fontSize: 12.0,
                        color: AppTheme.textMutedLight,
                      ),
                    ),
                  ],
                ),
                if (payment.notes.isNotEmpty) ...[
                  SizedBox(height: 0.2.h),
                  Text(
                    payment.notes,
                    style: TextStyle(
                      fontSize: 11.0,
                      color: AppTheme.textMutedLight,
                    ),
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                  ),
                ],
              ],
            ),
          ),
          Text(
            '${isRefund ? '-' : '+'}${CurrencyFormatter.format(payment.amount)}',
            style: TextStyle(
              fontSize: 14.0,
              fontWeight: FontWeight.w700,
              color: isRefund ? AppTheme.alertRed : AppTheme.successGreen,
            ),
          ),
        ],
      ),
    );
  }

  String _fmtDate(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
}

// ── ID Records Tab ────────────────────────────────────────────────────────────

class _IdRecordsTab extends StatelessWidget {
  final BookingModel booking;
  final IdVaultService vault;
  final bool isDark;
  final Color inkColor;

  const _IdRecordsTab({
    required this.booking,
    required this.vault,
    required this.isDark,
    required this.inkColor,
  });

  @override
  Widget build(BuildContext context) {
    final cardColor = isDark ? const Color(0xFF123F34) : Colors.white;
    final hasId = booking.idType.isNotEmpty || booking.idNumber.isNotEmpty;
    final hasFront = booking.idFrontPath.isNotEmpty;
    final hasBack = booking.idBackPath.isNotEmpty;

    if (!hasId && !hasFront && !hasBack) {
      return _EmptyState(
        icon: Icons.badge_outlined,
        message: 'No ID records captured for this guest',
        isDark: isDark,
        inkColor: inkColor,
      );
    }

    return ListView(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
      children: [
        // ID Details card
        if (hasId)
          Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFEAE4DC)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withAlpha(isDark ? 40 : 10),
                  blurRadius: 6,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.badge_outlined,
                      size: 16,
                      color: AppTheme.brassAccent,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Identity Document',
                      style: TextStyle(
                        fontSize: 14.0,
                        fontWeight: FontWeight.w600,
                        color: inkColor,
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: AppTheme.successGreen.withAlpha(25),
                        borderRadius: BorderRadius.circular(50),
                      ),
                      child: Text(
                        booking.idTaken ? 'Captured' : 'Pending',
                        style: TextStyle(
                          fontSize: 12.0,
                          fontWeight: FontWeight.w600,
                          color: booking.idTaken
                              ? AppTheme.successGreen
                              : AppTheme.brassAccent,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 1.5.h),
                _InfoRow(
                  label: 'ID Type',
                  value: booking.idType.isNotEmpty ? booking.idType : '—',
                  inkColor: inkColor,
                ),
                SizedBox(height: 0.8.h),
                _InfoRow(
                  label: 'ID Number',
                  value: booking.idNumber.isNotEmpty ? booking.idNumber : '—',
                  inkColor: inkColor,
                  mono: true,
                ),
                SizedBox(height: 0.8.h),
                _InfoRow(
                  label: 'Guest Name',
                  value: booking.guest,
                  inkColor: inkColor,
                ),
                if (booking.phone.isNotEmpty) ...[
                  SizedBox(height: 0.8.h),
                  _InfoRow(
                    label: 'Phone',
                    value: booking.phone,
                    inkColor: inkColor,
                    mono: true,
                  ),
                ],
                if (booking.address.isNotEmpty) ...[
                  SizedBox(height: 0.8.h),
                  _InfoRow(
                    label: 'Address',
                    value: booking.address,
                    inkColor: inkColor,
                  ),
                ],
                if (booking.otherOccupantNames.isNotEmpty) ...[
                  SizedBox(height: 0.8.h),
                  _InfoRow(
                    label: 'Other Occupants',
                    value: booking.otherOccupantNames.join(', '),
                    inkColor: inkColor,
                  ),
                ],
              ],
            ),
          ),
        // ID Images
        if (hasFront || hasBack) ...[
          Text(
            'ID IMAGES',
            style: TextStyle(
              fontSize: 12.0,
              fontWeight: FontWeight.w700,
              color: AppTheme.textMutedLight,
              letterSpacing: 0,
            ),
          ),
          SizedBox(height: 1.h),
          Row(
            children: [
              if (hasFront)
                Expanded(
                  child: _IdImageCard(
                    label: 'Front',
                    path: booking.idFrontPath,
                    vault: vault,
                    isDark: isDark,
                    inkColor: inkColor,
                  ),
                ),
              if (hasFront && hasBack) SizedBox(width: 3.w),
              if (hasBack)
                Expanded(
                  child: _IdImageCard(
                    label: 'Back',
                    path: booking.idBackPath,
                    vault: vault,
                    isDark: isDark,
                    inkColor: inkColor,
                  ),
                ),
            ],
          ),
        ],
      ],
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  final Color inkColor;
  final bool mono;

  const _InfoRow({
    required this.label,
    required this.value,
    required this.inkColor,
    this.mono = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 25.w,
          child: Text(
            label,
            style: TextStyle(fontSize: 12.0, color: AppTheme.textMutedLight),
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: mono
                ? TextStyle(
                    fontSize: 13.0,
                    fontWeight: FontWeight.w500,
                    color: inkColor,
                  )
                : TextStyle(
                    fontSize: 13.0,
                    fontWeight: FontWeight.w500,
                    color: inkColor,
                  ),
          ),
        ),
      ],
    );
  }
}

class _IdImageCard extends StatelessWidget {
  final String label;
  final String path;
  final IdVaultService vault;
  final bool isDark;
  final Color inkColor;

  const _IdImageCard({
    required this.label,
    required this.path,
    required this.vault,
    required this.isDark,
    required this.inkColor,
  });

  @override
  Widget build(BuildContext context) {
    final cardColor = isDark ? const Color(0xFF123F34) : Colors.white;

    return Container(
      height: 15.h,
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFFEAE4DC)),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Stack(
          fit: StackFit.expand,
          children: [
            _buildImage(path),
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 4),
                color: Colors.black.withAlpha(120),
                child: Text(
                  label,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 12.0,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildImage(String path) {
    if (path.endsWith('.bhid')) {
      return FutureBuilder<List<int>>(
        future: vault.readDecrypted(path),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return Image.memory(
              Uint8List.fromList(snapshot.data!),
              fit: BoxFit.cover,
            );
          }
          return _placeholder();
        },
      );
    }
    if (path.startsWith('http')) return _placeholder();
    return Image.file(
      File(path),
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => _placeholder(),
    );
  }

  Widget _placeholder() {
    return Container(
      color: AppTheme.deepTeal.withAlpha(20),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.image_outlined, size: 28, color: AppTheme.textMutedLight),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(fontSize: 9, color: AppTheme.textMutedLight),
          ),
        ],
      ),
    );
  }
}

// ── Empty State ───────────────────────────────────────────────────────────────

class _EmptyState extends StatelessWidget {
  final IconData icon;
  final String message;
  final bool isDark;
  final Color inkColor;

  const _EmptyState({
    required this.icon,
    required this.message,
    required this.isDark,
    required this.inkColor,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 44, color: inkColor.withAlpha(60)),
          SizedBox(height: 1.h),
          Text(
            message,
            style: TextStyle(fontSize: 14.0, color: inkColor.withAlpha(100)),
          ),
        ],
      ),
    );
  }
}
