import 'package:flutter/material.dart';
import '../../widgets/app_back_button.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_constants.dart';
import '../../database/repositories/expense_repository.dart';
import '../../services/notification_service.dart';
import '../../services/account_service.dart';
import '../../utils/currency_formatter.dart';
import '../../utils/input_validators.dart';
import '../../widgets/confirm_trash_dialog.dart';

class ExpensesScreen extends StatefulWidget {
  const ExpensesScreen({super.key});

  @override
  State<ExpensesScreen> createState() => _ExpensesScreenState();
}

class _ExpensesScreenState extends State<ExpensesScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF0D1F25) : const Color(0xFFF7F4EE);
    final accentColor = const Color(0xFF8E2A18);
    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        leading: const AppBackButton(color: Colors.white),
        backgroundColor: isDark
            ? const Color(0xFF0E332B)
            : const Color(0xFF123F34),
        elevation: 0,
        title: Text(
          'BASTION HOME',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20.0,
            fontWeight: FontWeight.w700,
            letterSpacing: 0,
          ),
        ),
        centerTitle: true,
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: accentColor,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white60,
          labelStyle: TextStyle(fontSize: 13.0, fontWeight: FontWeight.w600),
          tabs: const [
            Tab(text: 'Daily'),
            Tab(text: 'Monthly'),
            Tab(text: 'Yearly'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: const [
          DailyExpensesTab(),
          MonthlyExpensesTab(),
          YearlyExpensesTab(),
        ],
      ),
    );
  }
}

// ── Daily Expenses Tab ─────────────────────────────────────────────────────────

class DailyExpensesTab extends StatefulWidget {
  const DailyExpensesTab({super.key});

  @override
  State<DailyExpensesTab> createState() => _DailyExpensesTabState();
}

class _DailyExpensesTabState extends State<DailyExpensesTab> {
  final ExpenseRepository _repo = ExpenseRepository();
  DateTime _selectedMonth = DateTime(DateTime.now().year, DateTime.now().month);
  List<DailyExpense> _expenses = [];
  double _total = 0;
  bool _isLoading = true;
  int _loadRevision = 0;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final revision = ++_loadRevision;
    final month = _selectedMonth;
    setState(() => _isLoading = true);
    try {
      final expenses = await _repo.getDailyExpensesForMonth(
        month.year,
        month.month,
      );
      final total = await _repo.getDailyExpensesTotalForMonth(
        month.year,
        month.month,
      );
      if (!mounted || revision != _loadRevision) return;
      setState(() {
        _expenses = expenses;
        _total = total;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted || revision != _loadRevision) return;
      setState(() => _isLoading = false);
    }
  }

  void _openForm({DailyExpense? expense}) async {
    final result = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => DailyExpenseFormScreen(expense: expense),
      ),
    );
    if (!mounted) return;
    if (result == true) _loadData();
  }

  Future<void> _delete(DailyExpense expense) async {
    if (!await confirmMoveToTrash(context, itemName: expense.head)) return;
    try {
      await _repo.deleteDailyExpense(expense.id!);
      _loadData();
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(error.toString())));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF0D1F25) : const Color(0xFFF7F4EE);
    final inkColor = isDark ? Colors.white : const Color(0xFF0E332B);
    return Scaffold(
      backgroundColor: bgColor,
      floatingActionButton: FloatingActionButton(
        onPressed: () => _openForm(),
        backgroundColor: const Color(0xFF123F34),
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: Column(
        children: [
          // Month selector
          Container(
            color: isDark
                ? const Color(0xFF0E332B).withAlpha(80)
                : Colors.white.withAlpha(80),
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: Icon(Icons.chevron_left, color: inkColor),
                  onPressed: () {
                    setState(
                      () => _selectedMonth = DateTime(
                        _selectedMonth.year,
                        _selectedMonth.month - 1,
                      ),
                    );
                    _loadData();
                  },
                ),
                Text(
                  DateFormatter.monthYear(_selectedMonth),
                  style: TextStyle(
                    fontSize: 16.0,
                    fontWeight: FontWeight.w600,
                    color: inkColor,
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.chevron_right, color: inkColor),
                  onPressed: () {
                    setState(
                      () => _selectedMonth = DateTime(
                        _selectedMonth.year,
                        _selectedMonth.month + 1,
                      ),
                    );
                    _loadData();
                  },
                ),
              ],
            ),
          ),
          // Total banner
          Container(
            margin: EdgeInsets.all(4.w),
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
            decoration: BoxDecoration(
              color: const Color(0xFF123F34),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Total Expenses',
                  style: TextStyle(color: Colors.white70, fontSize: 14.0),
                ),
                Text(
                  CurrencyFormatter.format(_total),
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _expenses.isEmpty
                ? Center(
                    child: Text(
                      'No expenses for this month',
                      style: TextStyle(color: inkColor.withAlpha(120)),
                    ),
                  )
                : ListView.builder(
                    padding: EdgeInsets.symmetric(horizontal: 4.w),
                    itemCount: _expenses.length,
                    itemBuilder: (_, i) => _DailyExpenseTile(
                      expense: _expenses[i],
                      onEdit: () => _openForm(expense: _expenses[i]),
                      onDelete: () => _delete(_expenses[i]),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

class _DailyExpenseTile extends StatelessWidget {
  final DailyExpense expense;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const _DailyExpenseTile({
    required this.expense,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cardColor = isDark ? const Color(0xFF123F34) : Colors.white;
    final inkColor = isDark ? Colors.white : const Color(0xFF0E332B);

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(isDark ? 30 : 10),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ListTile(
        contentPadding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 0.3.h),
        title: Row(
          children: [
            Expanded(
              child: Text(
                expense.head,
                style: TextStyle(
                  fontSize: 14.0,
                  fontWeight: FontWeight.w600,
                  color: inkColor,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Text(
              CurrencyFormatter.format(expense.amount),
              style: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.w700,
                color: const Color(0xFFA2432F),
              ),
            ),
          ],
        ),
        subtitle: Text(
          '${DateFormatter.format(expense.date)} · ${expense.spentOn.isNotEmpty ? expense.spentOn : expense.vendor} · ${expense.mode}',
          style: TextStyle(fontSize: 12.0, color: inkColor.withAlpha(140)),
          overflow: TextOverflow.ellipsis,
        ),
        trailing: PopupMenuButton<String>(
          onSelected: (v) {
            if (v == 'edit') onEdit();
            if (v == 'delete') onDelete();
          },
          itemBuilder: (_) => [
            const PopupMenuItem(value: 'edit', child: Text('Edit')),
            if (AccountService().isAdmin)
              const PopupMenuItem(value: 'delete', child: Text('Delete')),
          ],
          child: const Icon(Icons.more_vert, size: 20),
        ),
      ),
    );
  }
}

// ── Monthly Expenses Tab ───────────────────────────────────────────────────────

class MonthlyExpensesTab extends StatefulWidget {
  const MonthlyExpensesTab({super.key});

  @override
  State<MonthlyExpensesTab> createState() => _MonthlyExpensesTabState();
}

class _MonthlyExpensesTabState extends State<MonthlyExpensesTab> {
  final ExpenseRepository _repo = ExpenseRepository();
  List<MonthlyExpense> _expenses = [];
  double _total = 0;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final expenses = await _repo.getAllMonthlyExpenses();
      final total = await _repo.getMonthlyExpensesTotal();
      if (!mounted) return;
      setState(() {
        _expenses = expenses;
        _total = total;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
    }
  }

  void _openForm({MonthlyExpense? expense}) async {
    final result = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => MonthlyExpenseFormScreen(expense: expense),
      ),
    );
    if (!mounted) return;
    if (result == true) _loadData();
  }

  Future<void> _delete(MonthlyExpense expense) async {
    if (!await confirmMoveToTrash(context, itemName: expense.head)) return;
    try {
      await _repo.deleteMonthlyExpense(expense.id!);
      await NotificationService().scheduleAllNotifications();
      _loadData();
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(error.toString())));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF0D1F25) : const Color(0xFFF7F4EE);
    return Scaffold(
      backgroundColor: bgColor,
      floatingActionButton: FloatingActionButton(
        onPressed: () => _openForm(),
        backgroundColor: const Color(0xFF123F34),
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: Column(
        children: [
          Container(
            margin: EdgeInsets.all(4.w),
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
            decoration: BoxDecoration(
              color: const Color(0xFF123F34),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Monthly Total',
                  style: TextStyle(color: Colors.white70, fontSize: 14.0),
                ),
                Text(
                  CurrencyFormatter.format(_total),
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : ListView.builder(
                    padding: EdgeInsets.symmetric(horizontal: 4.w),
                    itemCount: _expenses.length,
                    itemBuilder: (_, i) => _MonthlyExpenseTile(
                      expense: _expenses[i],
                      onEdit: () => _openForm(expense: _expenses[i]),
                      onDelete: () => _delete(_expenses[i]),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

class _MonthlyExpenseTile extends StatelessWidget {
  final MonthlyExpense expense;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const _MonthlyExpenseTile({
    required this.expense,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cardColor = isDark ? const Color(0xFF123F34) : Colors.white;
    final inkColor = isDark ? Colors.white : const Color(0xFF0E332B);

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(isDark ? 30 : 10),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ListTile(
        contentPadding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 0.3.h),
        title: Row(
          children: [
            Expanded(
              child: Text(
                expense.head,
                style: TextStyle(
                  fontSize: 14.0,
                  fontWeight: FontWeight.w600,
                  color: inkColor,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Text(
              expense.amount > 0
                  ? CurrencyFormatter.format(expense.amount)
                  : '—',
              style: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.w700,
                color: expense.amount > 0
                    ? const Color(0xFFA2432F)
                    : inkColor.withAlpha(120),
              ),
            ),
          ],
        ),
        subtitle: Text(
          'Due: ${expense.dueDay}th · ${expense.autopay == 'Yes' ? 'Autopay' : 'Manual'}${expense.payee.isNotEmpty ? ' · ${expense.payee}' : ''}',
          style: TextStyle(fontSize: 12.0, color: inkColor.withAlpha(140)),
        ),
        trailing: PopupMenuButton<String>(
          onSelected: (v) {
            if (v == 'edit') onEdit();
            if (v == 'delete') onDelete();
          },
          itemBuilder: (_) => [
            const PopupMenuItem(value: 'edit', child: Text('Edit')),
            if (AccountService().isAdmin)
              const PopupMenuItem(value: 'delete', child: Text('Delete')),
          ],
          child: const Icon(Icons.more_vert, size: 20),
        ),
      ),
    );
  }
}

// ── Yearly Expenses Tab ────────────────────────────────────────────────────────

class YearlyExpensesTab extends StatefulWidget {
  const YearlyExpensesTab({super.key});

  @override
  State<YearlyExpensesTab> createState() => _YearlyExpensesTabState();
}

class _YearlyExpensesTabState extends State<YearlyExpensesTab> {
  final ExpenseRepository _repo = ExpenseRepository();
  List<YearlyExpense> _expenses = [];
  double _total = 0;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final expenses = await _repo.getAllYearlyExpenses();
      final total = await _repo.getYearlyExpensesTotal();
      if (!mounted) return;
      setState(() {
        _expenses = expenses;
        _total = total;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
    }
  }

  void _openForm({YearlyExpense? expense}) async {
    final result = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => YearlyExpenseFormScreen(expense: expense),
      ),
    );
    if (!mounted) return;
    if (result == true) _loadData();
  }

  Future<void> _delete(YearlyExpense expense) async {
    if (!await confirmMoveToTrash(context, itemName: expense.head)) return;
    try {
      await _repo.deleteYearlyExpense(expense.id!);
      await NotificationService().scheduleAllNotifications();
      _loadData();
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(error.toString())));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF0D1F25) : const Color(0xFFF7F4EE);
    return Scaffold(
      backgroundColor: bgColor,
      floatingActionButton: FloatingActionButton(
        onPressed: () => _openForm(),
        backgroundColor: const Color(0xFF123F34),
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: Column(
        children: [
          Container(
            margin: EdgeInsets.all(4.w),
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
            decoration: BoxDecoration(
              color: const Color(0xFF123F34),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Annual Total',
                  style: TextStyle(color: Colors.white70, fontSize: 14.0),
                ),
                Text(
                  CurrencyFormatter.format(_total),
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : ListView.builder(
                    padding: EdgeInsets.symmetric(horizontal: 4.w),
                    itemCount: _expenses.length,
                    itemBuilder: (_, i) => _YearlyExpenseTile(
                      expense: _expenses[i],
                      onEdit: () => _openForm(expense: _expenses[i]),
                      onDelete: () => _delete(_expenses[i]),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

class _YearlyExpenseTile extends StatelessWidget {
  final YearlyExpense expense;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const _YearlyExpenseTile({
    required this.expense,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cardColor = isDark ? const Color(0xFF123F34) : Colors.white;
    final inkColor = isDark ? Colors.white : const Color(0xFF0E332B);

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(isDark ? 30 : 10),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ListTile(
        contentPadding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 0.3.h),
        title: Row(
          children: [
            Expanded(
              child: Text(
                expense.head,
                style: TextStyle(
                  fontSize: 14.0,
                  fontWeight: FontWeight.w600,
                  color: inkColor,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Text(
              expense.amount > 0
                  ? CurrencyFormatter.format(expense.amount)
                  : '—',
              style: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.w700,
                color: expense.amount > 0
                    ? const Color(0xFFA2432F)
                    : inkColor.withAlpha(120),
              ),
            ),
          ],
        ),
        subtitle: Text(
          'Due: ${expense.dueMonth}${expense.renewal.isNotEmpty ? ' · Renewal: ${expense.renewal}' : ''}${expense.reminder == 'Yes' ? ' · Reminder' : ''}',
          style: TextStyle(fontSize: 12.0, color: inkColor.withAlpha(140)),
        ),
        trailing: PopupMenuButton<String>(
          onSelected: (v) {
            if (v == 'edit') onEdit();
            if (v == 'delete') onDelete();
          },
          itemBuilder: (_) => [
            const PopupMenuItem(value: 'edit', child: Text('Edit')),
            if (AccountService().isAdmin)
              const PopupMenuItem(value: 'delete', child: Text('Delete')),
          ],
          child: const Icon(Icons.more_vert, size: 20),
        ),
      ),
    );
  }
}

// ── Daily Expense Form ─────────────────────────────────────────────────────────

class DailyExpenseFormScreen extends StatefulWidget {
  final DailyExpense? expense;
  final String? recordedBy;
  final bool employeeMode;
  const DailyExpenseFormScreen({
    super.key,
    this.expense,
    this.recordedBy,
    this.employeeMode = false,
  });

  @override
  State<DailyExpenseFormScreen> createState() => _DailyExpenseFormScreenState();
}

class _DailyExpenseFormScreenState extends State<DailyExpenseFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final ExpenseRepository _repo = ExpenseRepository();

  late TextEditingController _spentOnCtrl;
  late TextEditingController _amountCtrl;
  late TextEditingController _vendorCtrl;
  late TextEditingController _byCtrl;
  late TextEditingController _notesCtrl;

  DateTime _date = DateTime.now();
  String _head = AppConstants.expenseHeads.first;
  String _mode = AppConstants.paymentModes.first;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    final e = widget.expense;
    _spentOnCtrl = TextEditingController(text: e?.spentOn ?? '');
    _amountCtrl = TextEditingController(
      text: e != null && e.amount > 0 ? e.amount.toString() : '',
    );
    _vendorCtrl = TextEditingController(text: e?.vendor ?? '');
    _byCtrl = TextEditingController(
      text: e?.by.isNotEmpty == true
          ? e!.by
          : AccountService().currentAuditLabel.isNotEmpty
          ? AccountService().currentAuditLabel
          : widget.recordedBy ?? '',
    );
    _notesCtrl = TextEditingController(text: e?.notes ?? '');
    if (e != null) {
      _date = e.date;
      _head = e.head;
      _mode = e.mode;
    }
  }

  @override
  void dispose() {
    _spentOnCtrl.dispose();
    _amountCtrl.dispose();
    _vendorCtrl.dispose();
    _byCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSaving = true);
    try {
      final expense = DailyExpense(
        id: widget.expense?.id,
        date: _date,
        head: _head,
        spentOn: _spentOnCtrl.text.trim(),
        amount: double.parse(_amountCtrl.text.trim()),
        vendor: _vendorCtrl.text.trim(),
        mode: _mode,
        by: widget.expense?.by.isNotEmpty == true
            ? widget.expense!.by
            : AccountService().currentAuditLabel.isNotEmpty
            ? AccountService().currentAuditLabel
            : _byCtrl.text.trim(),
        notes: _notesCtrl.text.trim(),
      );
      if (widget.expense == null) {
        await _repo.insertDailyExpense(expense);
      } else {
        await _repo.updateDailyExpense(expense);
      }
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        setState(() => _isSaving = false);
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Could not save expense: $e')));
      }
    }
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2020),
      lastDate: DateTime(DateTime.now().year + 10),
    );
    if (picked != null && mounted) setState(() => _date = picked);
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF0D1F25) : const Color(0xFFF7F4EE);
    final inkColor = isDark ? Colors.white : const Color(0xFF0E332B);
    final fieldFill = isDark ? const Color(0xFF123F34) : Colors.white;

    InputDecoration fieldDec(String label) => InputDecoration(
      labelText: label,
      filled: true,
      fillColor: fieldFill,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.grey.withAlpha(60)),
      ),
      contentPadding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
    );

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        leading: const AppBackButton(color: Colors.white),
        backgroundColor: isDark
            ? const Color(0xFF0E332B)
            : const Color(0xFF123F34),
        title: Text(
          widget.expense == null ? 'Add Expense' : 'Edit Expense',
          style: TextStyle(color: Colors.white, fontSize: 18.0),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          TextButton(
            onPressed: _isSaving ? null : _save,
            child: Text(
              'Save',
              style: TextStyle(
                color: const Color(0xFF8E2A18),
                fontWeight: FontWeight.w700,
                fontSize: 16.0,
              ),
            ),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: EdgeInsets.all(4.w),
          children: [
            GestureDetector(
              onTap: _pickDate,
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
                decoration: BoxDecoration(
                  color: fieldFill,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.grey.withAlpha(60)),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.calendar_today,
                      size: 18,
                      color: inkColor.withAlpha(160),
                    ),
                    SizedBox(width: 3.w),
                    Text(
                      DateFormatter.format(_date),
                      style: TextStyle(fontSize: 14.0, color: inkColor),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 2.h),
            DropdownButtonFormField<String>(
              initialValue: _head,
              decoration: fieldDec('Expense Head'),
              items: AppConstants.expenseHeads
                  .map(
                    (h) => DropdownMenuItem(
                      value: h,
                      child: Text(h, style: TextStyle(fontSize: 14.0)),
                    ),
                  )
                  .toList(),
              onChanged: (v) => setState(() => _head = v!),
            ),
            SizedBox(height: 2.h),
            TextFormField(
              controller: _spentOnCtrl,
              decoration: fieldDec('Spent On'),
            ),
            SizedBox(height: 2.h),
            TextFormField(
              controller: _amountCtrl,
              decoration: fieldDec('Amount (₹) *'),
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              validator: (value) => InputValidators.money(
                value,
                required: true,
                allowZero: false,
              ),
            ),
            SizedBox(height: 2.h),
            TextFormField(
              controller: _vendorCtrl,
              decoration: fieldDec('Vendor'),
            ),
            SizedBox(height: 2.h),
            DropdownButtonFormField<String>(
              initialValue: _mode,
              decoration: fieldDec('Payment Mode'),
              items: AppConstants.paymentModes
                  .map(
                    (m) => DropdownMenuItem(
                      value: m,
                      child: Text(m, style: TextStyle(fontSize: 14.0)),
                    ),
                  )
                  .toList(),
              onChanged: (v) => setState(() => _mode = v!),
            ),
            SizedBox(height: 2.h),
            TextFormField(
              controller: _byCtrl,
              readOnly: true,
              decoration: fieldDec('Recorded By'),
            ),
            SizedBox(height: 2.h),
            TextFormField(
              controller: _notesCtrl,
              decoration: fieldDec('Notes'),
              maxLines: 3,
            ),
            SizedBox(height: 4.h),
          ],
        ),
      ),
    );
  }
}

// ── Monthly Expense Form ───────────────────────────────────────────────────────

class MonthlyExpenseFormScreen extends StatefulWidget {
  final MonthlyExpense? expense;
  const MonthlyExpenseFormScreen({super.key, this.expense});

  @override
  State<MonthlyExpenseFormScreen> createState() =>
      _MonthlyExpenseFormScreenState();
}

class _MonthlyExpenseFormScreenState extends State<MonthlyExpenseFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final ExpenseRepository _repo = ExpenseRepository();

  late TextEditingController _descCtrl;
  late TextEditingController _payeeCtrl;
  late TextEditingController _amountCtrl;
  late TextEditingController _notesCtrl;

  String _head = AppConstants.expenseHeads.first;
  int _dueDay = 1;
  String _autopay = 'No';
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    final e = widget.expense;
    _descCtrl = TextEditingController(text: e?.desc ?? '');
    _payeeCtrl = TextEditingController(text: e?.payee ?? '');
    _amountCtrl = TextEditingController(
      text: e != null && e.amount > 0 ? e.amount.toString() : '',
    );
    _notesCtrl = TextEditingController(text: e?.notes ?? '');
    if (e != null) {
      _head = e.head;
      _dueDay = e.dueDay;
      _autopay = e.autopay;
    }
  }

  @override
  void dispose() {
    _descCtrl.dispose();
    _payeeCtrl.dispose();
    _amountCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSaving = true);
    try {
      final expense = MonthlyExpense(
        id: widget.expense?.id,
        head: _head,
        desc: _descCtrl.text.trim(),
        payee: _payeeCtrl.text.trim(),
        amount: double.tryParse(_amountCtrl.text) ?? 0,
        dueDay: _dueDay,
        autopay: _autopay,
        notes: _notesCtrl.text.trim(),
      );
      if (widget.expense == null) {
        await _repo.insertMonthlyExpense(expense);
      } else {
        await _repo.updateMonthlyExpense(expense);
      }
      await NotificationService().scheduleAllNotifications();
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      setState(() => _isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF0D1F25) : const Color(0xFFF7F4EE);
    final fieldFill = isDark ? const Color(0xFF123F34) : Colors.white;

    InputDecoration fieldDec(String label) => InputDecoration(
      labelText: label,
      filled: true,
      fillColor: fieldFill,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.grey.withAlpha(60)),
      ),
      contentPadding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
    );

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        leading: const AppBackButton(color: Colors.white),
        backgroundColor: isDark
            ? const Color(0xFF0E332B)
            : const Color(0xFF123F34),
        title: Text(
          widget.expense == null
              ? 'Add Monthly Expense'
              : 'Edit Monthly Expense',
          style: TextStyle(color: Colors.white, fontSize: 18.0),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          TextButton(
            onPressed: _isSaving ? null : _save,
            child: Text(
              'Save',
              style: TextStyle(
                color: const Color(0xFF8E2A18),
                fontWeight: FontWeight.w700,
                fontSize: 16.0,
              ),
            ),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: EdgeInsets.all(4.w),
          children: [
            DropdownButtonFormField<String>(
              initialValue: _head,
              decoration: fieldDec('Expense Head'),
              items: AppConstants.expenseHeads
                  .map(
                    (h) => DropdownMenuItem(
                      value: h,
                      child: Text(h, style: TextStyle(fontSize: 14.0)),
                    ),
                  )
                  .toList(),
              onChanged: (v) => setState(() => _head = v!),
            ),
            SizedBox(height: 2.h),
            TextFormField(
              controller: _descCtrl,
              decoration: fieldDec('Description'),
            ),
            SizedBox(height: 2.h),
            TextFormField(
              controller: _payeeCtrl,
              decoration: fieldDec('Payee'),
            ),
            SizedBox(height: 2.h),
            TextFormField(
              controller: _amountCtrl,
              decoration: fieldDec('Amount (₹)'),
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              validator: InputValidators.money,
            ),
            SizedBox(height: 2.h),
            DropdownButtonFormField<int>(
              initialValue: _dueDay,
              decoration: fieldDec('Due Day'),
              items: List.generate(31, (i) => i + 1)
                  .map(
                    (d) => DropdownMenuItem(
                      value: d,
                      child: Text('$d', style: TextStyle(fontSize: 14.0)),
                    ),
                  )
                  .toList(),
              onChanged: (v) => setState(() => _dueDay = v!),
            ),
            SizedBox(height: 2.h),
            DropdownButtonFormField<String>(
              initialValue: _autopay,
              decoration: fieldDec('Autopay'),
              items: ['Yes', 'No']
                  .map(
                    (v) => DropdownMenuItem(
                      value: v,
                      child: Text(v, style: TextStyle(fontSize: 14.0)),
                    ),
                  )
                  .toList(),
              onChanged: (v) => setState(() => _autopay = v!),
            ),
            SizedBox(height: 2.h),
            TextFormField(
              controller: _notesCtrl,
              decoration: fieldDec('Notes'),
              maxLines: 3,
            ),
            SizedBox(height: 4.h),
          ],
        ),
      ),
    );
  }
}

// ── Yearly Expense Form ────────────────────────────────────────────────────────

class YearlyExpenseFormScreen extends StatefulWidget {
  final YearlyExpense? expense;
  const YearlyExpenseFormScreen({super.key, this.expense});

  @override
  State<YearlyExpenseFormScreen> createState() =>
      _YearlyExpenseFormScreenState();
}

class _YearlyExpenseFormScreenState extends State<YearlyExpenseFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final ExpenseRepository _repo = ExpenseRepository();

  late TextEditingController _descCtrl;
  late TextEditingController _authorityCtrl;
  late TextEditingController _amountCtrl;
  late TextEditingController _renewalCtrl;
  late TextEditingController _notesCtrl;

  String _head = AppConstants.expenseHeads.first;
  String _dueMonth = AppConstants.months.first;
  String _reminder = 'No';
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    final e = widget.expense;
    _descCtrl = TextEditingController(text: e?.desc ?? '');
    _authorityCtrl = TextEditingController(text: e?.authority ?? '');
    _amountCtrl = TextEditingController(
      text: e != null && e.amount > 0 ? e.amount.toString() : '',
    );
    _renewalCtrl = TextEditingController(text: e?.renewal ?? '');
    _notesCtrl = TextEditingController(text: e?.notes ?? '');
    if (e != null) {
      _head = e.head;
      _dueMonth = e.dueMonth;
      _reminder = e.reminder;
    }
  }

  @override
  void dispose() {
    _descCtrl.dispose();
    _authorityCtrl.dispose();
    _amountCtrl.dispose();
    _renewalCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSaving = true);
    try {
      final expense = YearlyExpense(
        id: widget.expense?.id,
        head: _head,
        desc: _descCtrl.text.trim(),
        authority: _authorityCtrl.text.trim(),
        amount: double.tryParse(_amountCtrl.text) ?? 0,
        dueMonth: _dueMonth,
        renewal: _renewalCtrl.text.trim(),
        reminder: _reminder,
        notes: _notesCtrl.text.trim(),
      );
      if (widget.expense == null) {
        await _repo.insertYearlyExpense(expense);
      } else {
        await _repo.updateYearlyExpense(expense);
      }
      await NotificationService().scheduleAllNotifications();
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      setState(() => _isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF0D1F25) : const Color(0xFFF7F4EE);
    final fieldFill = isDark ? const Color(0xFF123F34) : Colors.white;

    InputDecoration fieldDec(String label) => InputDecoration(
      labelText: label,
      filled: true,
      fillColor: fieldFill,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.grey.withAlpha(60)),
      ),
      contentPadding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
    );

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        leading: const AppBackButton(color: Colors.white),
        backgroundColor: isDark
            ? const Color(0xFF0E332B)
            : const Color(0xFF123F34),
        title: Text(
          widget.expense == null ? 'Add Yearly Expense' : 'Edit Yearly Expense',
          style: TextStyle(color: Colors.white, fontSize: 18.0),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          TextButton(
            onPressed: _isSaving ? null : _save,
            child: Text(
              'Save',
              style: TextStyle(
                color: const Color(0xFF8E2A18),
                fontWeight: FontWeight.w700,
                fontSize: 16.0,
              ),
            ),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: EdgeInsets.all(4.w),
          children: [
            DropdownButtonFormField<String>(
              initialValue: _head,
              decoration: fieldDec('Expense Head'),
              items: AppConstants.expenseHeads
                  .map(
                    (h) => DropdownMenuItem(
                      value: h,
                      child: Text(h, style: TextStyle(fontSize: 14.0)),
                    ),
                  )
                  .toList(),
              onChanged: (v) => setState(() => _head = v!),
            ),
            SizedBox(height: 2.h),
            TextFormField(
              controller: _descCtrl,
              decoration: fieldDec('Description'),
            ),
            SizedBox(height: 2.h),
            TextFormField(
              controller: _authorityCtrl,
              decoration: fieldDec('Authority / Issuing Body'),
            ),
            SizedBox(height: 2.h),
            TextFormField(
              controller: _amountCtrl,
              decoration: fieldDec('Amount (₹)'),
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              validator: InputValidators.money,
            ),
            SizedBox(height: 2.h),
            DropdownButtonFormField<String>(
              initialValue: _dueMonth,
              decoration: fieldDec('Due Month'),
              items: AppConstants.months
                  .map(
                    (m) => DropdownMenuItem(
                      value: m,
                      child: Text(m, style: TextStyle(fontSize: 14.0)),
                    ),
                  )
                  .toList(),
              onChanged: (v) => setState(() => _dueMonth = v!),
            ),
            SizedBox(height: 2.h),
            TextFormField(
              controller: _renewalCtrl,
              decoration: fieldDec('Renewal Date (yyyy-mm-dd)'),
            ),
            SizedBox(height: 2.h),
            DropdownButtonFormField<String>(
              initialValue: _reminder,
              decoration: fieldDec('Reminder'),
              items: ['Yes', 'No']
                  .map(
                    (v) => DropdownMenuItem(
                      value: v,
                      child: Text(v, style: TextStyle(fontSize: 14.0)),
                    ),
                  )
                  .toList(),
              onChanged: (v) => setState(() => _reminder = v!),
            ),
            SizedBox(height: 2.h),
            TextFormField(
              controller: _notesCtrl,
              decoration: fieldDec('Notes'),
              maxLines: 3,
            ),
            SizedBox(height: 4.h),
          ],
        ),
      ),
    );
  }
}
