import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../services/trash_service.dart';
import '../../widgets/app_back_button.dart';

class TrashScreen extends StatefulWidget {
  const TrashScreen({super.key});

  @override
  State<TrashScreen> createState() => _TrashScreenState();
}

class _TrashScreenState extends State<TrashScreen> {
  final _service = TrashService();
  List<TrashItem> _items = const [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final items = await _service.getItems();
      if (mounted) setState(() => _items = items);
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(error.toString())));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _restore(TrashItem item) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Restore record?'),
        content: Text('Restore "${item.title}" to the app on all devices?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Restore'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    try {
      await _service.restore(item.syncId);
      await _load();
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(error.toString())));
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(leading: const AppBackButton(), title: const Text('Trash')),
    body: _loading
        ? const Center(child: CircularProgressIndicator())
        : _items.isEmpty
        ? const Center(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.delete_sweep_outlined, size: 48),
                  SizedBox(height: 12),
                  Text('Trash is empty'),
                ],
              ),
            ),
          )
        : RefreshIndicator(
            onRefresh: _load,
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
              itemCount: _items.length,
              separatorBuilder: (_, _) => const SizedBox(height: 8),
              itemBuilder: (context, index) {
                final item = _items[index];
                final hours = item.remaining.inHours.clamp(0, 24 * 366);
                final days = (hours / 24).ceil();
                return Card(
                  child: ListTile(
                    leading: const Icon(Icons.restore_from_trash_outlined),
                    title: Text(item.title),
                    subtitle: Text(
                      '${item.typeLabel} - deleted by ${item.deletedBy}\n'
                      '${DateFormat('d MMM, h:mm a').format(item.deletedAt)} - '
                      '$days day${days == 1 ? '' : 's'} remaining'
                      '${item.hasExtendedIdRetention ? '\nID photo protected by one-year retention' : ''}',
                    ),
                    isThreeLine: true,
                    trailing: IconButton(
                      tooltip: 'Restore',
                      onPressed: () => _restore(item),
                      icon: const Icon(Icons.restore),
                    ),
                  ),
                );
              },
            ),
          ),
  );
}
