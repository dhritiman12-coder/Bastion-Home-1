import 'dart:async';

import 'package:flutter/material.dart';
import '../../widgets/app_back_button.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_constants.dart';
import '../../database/repositories/id_repository.dart';
import '../../database/repositories/booking_repository.dart';
import '../../models/booking_model.dart';
import '../../utils/currency_formatter.dart';
import '../../services/id_vault_service.dart';
import '../../services/account_service.dart';
import '../../services/id_retention_policy.dart';
import '../../widgets/confirm_trash_dialog.dart';

class GuestIdsScreen extends StatefulWidget {
  const GuestIdsScreen({super.key});

  @override
  State<GuestIdsScreen> createState() => _GuestIdsScreenState();
}

class _GuestIdsScreenState extends State<GuestIdsScreen> {
  final IdRepository _repo = IdRepository();
  List<IdRecord> _records = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final records = await _repo.getAllIdRecords();
      if (!mounted) return;
      setState(() {
        _records = records;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
    }
  }

  void _openForm({IdRecord? record}) async {
    final result = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => IdFormScreen(record: record)),
    );
    if (!mounted) return;
    if (result == true) _loadData();
  }

  Future<void> _delete(IdRecord record) async {
    final name = record.guestName.isEmpty ? record.bookingId : record.guestName;
    if (await confirmMoveToTrash(context, itemName: 'ID record for $name')) {
      try {
        await _repo.deleteIdRecord(record.id!);
        _loadData();
      } catch (error) {
        if (mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text(error.toString())));
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF0D1F25) : const Color(0xFFF7F4EE);
    final inkColor = isDark ? Colors.white : const Color(0xFF0E332B);
    final accentColor = const Color(0xFF8E2A18);

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        leading: const AppBackButton(color: Colors.white),
        backgroundColor: isDark
            ? const Color(0xFF0E332B)
            : const Color(0xFF123F34),
        elevation: 0,
        title: Text(
          'BASTION HOME',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20.0,
            fontWeight: FontWeight.w700,
            letterSpacing: 0,
          ),
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: accentColor.withAlpha(80)),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _openForm(),
        backgroundColor: const Color(0xFF123F34),
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.fromLTRB(4.w, 2.h, 4.w, 1.h),
            child: Text(
              'Guest IDs',
              style: TextStyle(
                fontSize: 24.0,
                fontWeight: FontWeight.w700,
                color: inkColor,
              ),
            ),
          ),
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _records.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.badge_outlined,
                          size: 48,
                          color: inkColor.withAlpha(80),
                        ),
                        SizedBox(height: 1.h),
                        Text(
                          'No ID records yet',
                          style: TextStyle(color: inkColor.withAlpha(120)),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: EdgeInsets.symmetric(
                      horizontal: 4.w,
                      vertical: 1.h,
                    ),
                    itemCount: _records.length,
                    itemBuilder: (_, i) => _IdRecordTile(
                      record: _records[i],
                      onEdit: () => _openForm(record: _records[i]),
                      onDelete: () => _delete(_records[i]),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

class _IdRecordTile extends StatelessWidget {
  final IdRecord record;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const _IdRecordTile({
    required this.record,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final cardColor = isDark ? const Color(0xFF123F34) : Colors.white;
    final inkColor = isDark ? Colors.white : const Color(0xFF0E332B);
    final isUnverified = record.verified == 'No';
    final retainedUntil = record.capturedAt == null
        ? null
        : IdRetentionPolicy.retainUntil(record.capturedAt!).toLocal();

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(isDark ? 40 : 15),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
        border: isUnverified
            ? Border.all(
                color: const Color(0xFFA2432F).withAlpha(120),
                width: 1,
              )
            : null,
      ),
      child: ListTile(
        contentPadding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 0.5.h),
        leading: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: const Color(0xFF123F34).withAlpha(isDark ? 60 : 20),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(
            Icons.badge_outlined,
            color: const Color(0xFF123F34),
            size: 22,
          ),
        ),
        title: Row(
          children: [
            Expanded(
              child: Text(
                record.guestName.isNotEmpty
                    ? record.guestName
                    : record.bookingId,
                style: TextStyle(
                  fontSize: 14.0,
                  fontWeight: FontWeight.w600,
                  color: inkColor,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            if (isUnverified)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: const Color(0xFFA2432F).withAlpha(20),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.flag, size: 10, color: Color(0xFFA2432F)),
                    const SizedBox(width: 2),
                    Text(
                      'Unverified',
                      style: TextStyle(
                        fontSize: 11.0,
                        color: const Color(0xFFA2432F),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${record.idType} · ${record.idNumber}',
              style: TextStyle(fontSize: 13.0, color: inkColor.withAlpha(160)),
            ),
            Text(
              '${record.bookingId} · ${DateFormatter.format(record.date)} · ${record.copyType}',
              style: TextStyle(fontSize: 12.0, color: inkColor.withAlpha(120)),
            ),
            if (retainedUntil != null)
              Text(
                'Photo retained until ${DateFormatter.format(retainedUntil)}',
                style: TextStyle(
                  fontSize: 12.0,
                  color: inkColor.withAlpha(140),
                ),
              ),
          ],
        ),
        trailing: PopupMenuButton<String>(
          onSelected: (v) {
            if (v == 'edit') onEdit();
            if (v == 'delete') onDelete();
          },
          itemBuilder: (_) => [
            const PopupMenuItem(value: 'edit', child: Text('Edit')),
            if (AccountService().isAdmin)
              const PopupMenuItem(value: 'delete', child: Text('Delete')),
          ],
          child: const Icon(Icons.more_vert, size: 20),
        ),
      ),
    );
  }
}

// ── ID Form Screen ─────────────────────────────────────────────────────────────

class IdFormScreen extends StatefulWidget {
  final IdRecord? record;
  const IdFormScreen({super.key, this.record});

  @override
  State<IdFormScreen> createState() => _IdFormScreenState();
}

class _IdFormScreenState extends State<IdFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final IdRepository _repo = IdRepository();
  final BookingRepository _bookingRepo = BookingRepository();
  final IdVaultService _vault = IdVaultService();

  late TextEditingController _bookingIdCtrl;
  late TextEditingController _idNumberCtrl;
  late TextEditingController _fileNameCtrl;
  late TextEditingController _storageCtrl;
  late TextEditingController _notesCtrl;

  DateTime _date = DateTime.now();
  String _idType = AppConstants.idTypes.first;
  String _copyType = AppConstants.copyTypes.first;
  String _verified = 'No';
  List<BookingModel> _bookings = [];
  bool _isSaving = false;
  bool _isCapturing = false;
  DateTime? _capturedAt;
  final Set<String> _temporaryImages = {};
  final Set<String> _imagesToDeleteAfterSave = {};
  bool _didSave = false;

  @override
  void initState() {
    super.initState();
    final r = widget.record;
    _bookingIdCtrl = TextEditingController(text: r?.bookingId ?? '');
    _idNumberCtrl = TextEditingController(text: r?.idNumber ?? '');
    _fileNameCtrl = TextEditingController(text: r?.fileName ?? '');
    _storageCtrl = TextEditingController(text: r?.storage ?? '');
    _notesCtrl = TextEditingController(text: r?.notes ?? '');
    if (r != null) {
      _date = r.date;
      _idType = r.idType;
      _copyType = r.copyType;
      _verified = r.verified;
      _capturedAt = r.capturedAt;
    }
    _loadBookings();
    _restoreRecoveredCapture();
  }

  Future<void> _loadBookings() async {
    final bookings = await _bookingRepo.getAllBookings();
    if (!mounted) return;
    setState(() => _bookings = bookings);
  }

  Future<void> _restoreRecoveredCapture() async {
    try {
      final recovered = await _vault.claimRecoveredCapture('guest-id');
      if (recovered == null || !mounted) return;
      _temporaryImages.add(recovered.fileName);
      setState(() {
        _fileNameCtrl.text = recovered.fileName;
        _capturedAt = DateTime.now().toUtc();
        _storageCtrl.text = 'Encrypted device vault';
        _copyType = 'Scanned';
      });
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Recovered the ID photo from camera')),
        );
      });
    } catch (e) {
      debugPrint('Could not restore the interrupted ID capture: $e');
    }
  }

  @override
  void dispose() {
    if (!_didSave) {
      for (final fileName in _temporaryImages) {
        unawaited(_deleteImageBestEffort(fileName));
      }
    }
    _bookingIdCtrl.dispose();
    _idNumberCtrl.dispose();
    _fileNameCtrl.dispose();
    _storageCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSaving = true);
    try {
      final record = IdRecord(
        id: widget.record?.id,
        date: _date,
        bookingId: _bookingIdCtrl.text.trim(),
        idType: _idType,
        idNumber: _maskIdNumber(_idNumberCtrl.text),
        copyType: _copyType,
        fileName: _fileNameCtrl.text.trim(),
        capturedAt: _capturedAt,
        storage: _storageCtrl.text.trim(),
        verified: _verified,
        notes: _notesCtrl.text.trim(),
      );
      if (widget.record == null) {
        await _repo.insertIdRecord(record);
      } else {
        await _repo.updateIdRecord(record);
      }
      _didSave = true;
      _temporaryImages.clear();
      for (final fileName in _imagesToDeleteAfterSave) {
        await _deleteImageBestEffort(fileName);
      }
      _imagesToDeleteAfterSave.clear();
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        setState(() => _isSaving = false);
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error saving: $e')));
      }
    }
  }

  String _maskIdNumber(String input) {
    final value = input.trim();
    final visibleStart =
        value.replaceAll(RegExp(r'[^A-Za-z0-9]'), '').length - 4;
    var seen = 0;
    return value.split('').map((character) {
      if (!RegExp(r'[A-Za-z0-9]').hasMatch(character)) return character;
      final masked = seen < visibleStart ? 'X' : character;
      seen++;
      return masked;
    }).join();
  }

  Future<void> _captureId(ImageSource source) async {
    final previous = _fileNameCtrl.text;
    if (previous.endsWith('.bhid') &&
        !_temporaryImages.contains(previous) &&
        IdRetentionPolicy.isProtected(_capturedAt)) {
      final retainedUntil = IdRetentionPolicy.retainUntil(
        _capturedAt!,
      ).toLocal();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'This ID photo must be retained until ${DateFormatter.format(retainedUntil)}.',
          ),
        ),
      );
      return;
    }
    setState(() => _isCapturing = true);
    try {
      final fileName = await _vault.capture(source, recoverySlot: 'guest-id');
      if (fileName != null && !mounted) {
        await _vault.delete(fileName);
        return;
      }
      if (fileName != null) {
        _temporaryImages.add(fileName);
        setState(() {
          _fileNameCtrl.text = fileName;
          _capturedAt = DateTime.now().toUtc();
          _storageCtrl.text = 'Encrypted device vault';
          _copyType = 'Scanned';
        });
        if (previous.endsWith('.bhid')) await _retireImage(previous);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not secure the ID image: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isCapturing = false);
    }
  }

  Future<void> _retireImage(String fileName) async {
    if (_temporaryImages.remove(fileName)) {
      await _deleteImageBestEffort(fileName);
    } else {
      _imagesToDeleteAfterSave.add(fileName);
    }
  }

  Future<void> _deleteImageBestEffort(String fileName) async {
    try {
      await _vault.delete(fileName);
    } catch (error) {
      debugPrint('Could not remove unused ID image: $error');
    }
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2020),
      lastDate: DateTime(DateTime.now().year + 10),
    );
    if (picked != null && mounted) setState(() => _date = picked);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF0D1F25) : const Color(0xFFF7F4EE);
    final inkColor = isDark ? Colors.white : const Color(0xFF0E332B);

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        leading: const AppBackButton(color: Colors.white),
        backgroundColor: isDark
            ? const Color(0xFF0E332B)
            : const Color(0xFF123F34),
        title: Text(
          widget.record == null ? 'Add ID Record' : 'Edit ID Record',
          style: TextStyle(color: Colors.white, fontSize: 18.0),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          TextButton(
            onPressed: _isSaving ? null : _save,
            child: Text(
              'Save',
              style: TextStyle(
                color: const Color(0xFF8E2A18),
                fontWeight: FontWeight.w700,
                fontSize: 16.0,
              ),
            ),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: EdgeInsets.all(4.w),
          children: [
            _buildDateField(inkColor),
            SizedBox(height: 2.h),
            _buildBookingIdField(inkColor),
            SizedBox(height: 2.h),
            _buildDropdown(
              'ID Type',
              _idType,
              AppConstants.idTypes,
              (v) => setState(() => _idType = v!),
              inkColor,
            ),
            SizedBox(height: 2.h),
            _buildTextField(
              _idNumberCtrl,
              'ID Number (masked)',
              inkColor,
              hint: 'e.g. XXXX-XXXX-1234',
            ),
            SizedBox(height: 2.h),
            _buildDropdown(
              'Copy Type',
              _copyType,
              AppConstants.copyTypes,
              (v) => setState(() => _copyType = v!),
              inkColor,
            ),
            SizedBox(height: 2.h),
            Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: isDark ? const Color(0xFF123F34) : Colors.white,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.grey.withAlpha(60)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _fileNameCtrl.text.isEmpty
                        ? 'No encrypted image attached'
                        : 'Encrypted image attached',
                    style: TextStyle(
                      color: inkColor,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      OutlinedButton.icon(
                        onPressed: _isCapturing
                            ? null
                            : () => _captureId(ImageSource.camera),
                        icon: const Icon(Icons.camera_alt_outlined),
                        label: const Text('Camera'),
                      ),
                      OutlinedButton.icon(
                        onPressed: _isCapturing
                            ? null
                            : () => _captureId(ImageSource.gallery),
                        icon: const Icon(Icons.photo_library_outlined),
                        label: const Text('Photos'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: 2.h),
            _buildDropdown(
              'Verified',
              _verified,
              ['Yes', 'No'],
              (v) => setState(() => _verified = v!),
              inkColor,
            ),
            SizedBox(height: 2.h),
            _buildTextField(
              _notesCtrl,
              'Notes',
              inkColor,
              required: false,
              maxLines: 3,
            ),
            SizedBox(height: 4.h),
          ],
        ),
      ),
    );
  }

  Widget _buildDateField(Color inkColor) {
    return GestureDetector(
      onTap: _pickDate,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
        decoration: BoxDecoration(
          color: Theme.of(context).brightness == Brightness.dark
              ? const Color(0xFF123F34)
              : Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.grey.withAlpha(60)),
        ),
        child: Row(
          children: [
            Icon(
              Icons.calendar_today,
              size: 18,
              color: inkColor.withAlpha(160),
            ),
            SizedBox(width: 3.w),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Date',
                  style: TextStyle(
                    fontSize: 12.0,
                    color: inkColor.withAlpha(120),
                  ),
                ),
                Text(
                  DateFormatter.format(_date),
                  style: TextStyle(
                    fontSize: 14.0,
                    fontWeight: FontWeight.w600,
                    color: inkColor,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBookingIdField(Color inkColor) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Booking ID *',
          style: TextStyle(fontSize: 13.0, color: inkColor.withAlpha(160)),
        ),
        SizedBox(height: 0.5.h),
        DropdownButtonFormField<String>(
          initialValue: _bookings.any((b) => b.id == _bookingIdCtrl.text)
              ? _bookingIdCtrl.text
              : null,
          decoration: InputDecoration(
            hintText: 'Select booking',
            filled: true,
            fillColor: Theme.of(context).brightness == Brightness.dark
                ? const Color(0xFF123F34)
                : Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(color: Colors.grey.withAlpha(60)),
            ),
            contentPadding: EdgeInsets.symmetric(
              horizontal: 4.w,
              vertical: 1.5.h,
            ),
          ),
          items: _bookings
              .map(
                (b) => DropdownMenuItem(
                  value: b.id,
                  child: Text(
                    '${b.id} - ${b.guest}',
                    style: TextStyle(fontSize: 14.0),
                  ),
                ),
              )
              .toList(),
          onChanged: (v) => setState(() => _bookingIdCtrl.text = v ?? ''),
          validator: (v) => (v == null || v.isEmpty) ? 'Required' : null,
        ),
      ],
    );
  }

  Widget _buildTextField(
    TextEditingController ctrl,
    String label,
    Color inkColor, {
    bool required = true,
    String? hint,
    int maxLines = 1,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          required ? '$label *' : label,
          style: TextStyle(fontSize: 13.0, color: inkColor.withAlpha(160)),
        ),
        SizedBox(height: 0.5.h),
        TextFormField(
          controller: ctrl,
          maxLines: maxLines,
          decoration: InputDecoration(
            hintText: hint,
            filled: true,
            fillColor: Theme.of(context).brightness == Brightness.dark
                ? const Color(0xFF123F34)
                : Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(color: Colors.grey.withAlpha(60)),
            ),
            contentPadding: EdgeInsets.symmetric(
              horizontal: 4.w,
              vertical: 1.5.h,
            ),
          ),
          validator: required
              ? (v) => (v == null || v.trim().isEmpty) ? 'Required' : null
              : null,
        ),
      ],
    );
  }

  Widget _buildDropdown(
    String label,
    String value,
    List<String> options,
    void Function(String?) onChanged,
    Color inkColor,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(fontSize: 13.0, color: inkColor.withAlpha(160)),
        ),
        SizedBox(height: 0.5.h),
        DropdownButtonFormField<String>(
          initialValue: value,
          decoration: InputDecoration(
            filled: true,
            fillColor: Theme.of(context).brightness == Brightness.dark
                ? const Color(0xFF123F34)
                : Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(color: Colors.grey.withAlpha(60)),
            ),
            contentPadding: EdgeInsets.symmetric(
              horizontal: 4.w,
              vertical: 1.5.h,
            ),
          ),
          items: options
              .map(
                (o) => DropdownMenuItem(
                  value: o,
                  child: Text(o, style: TextStyle(fontSize: 14.0)),
                ),
              )
              .toList(),
          onChanged: onChanged,
        ),
      ],
    );
  }
}
