import 'package:flutter/material.dart';

import '../../models/app_user.dart';
import '../../services/account_service.dart';
import '../../widgets/admin_access_denied.dart';
import '../analytics_screen/analytics_screen.dart';
import '../backup_screen/backup_screen.dart';
import '../branding_screen/branding_settings_screen.dart';
import '../guest_ids_screen/guest_ids_screen.dart';
import '../inventory_screen/inventory_screen.dart';
import '../payments_screen/payments_screen.dart';
import '../seasonal_rates_screen/seasonal_rates_screen.dart';
import '../settings_screen/settings_screen.dart';
import '../staff_screen/staff_management_screen.dart';
import '../trash_screen/trash_screen.dart';
import '../cloud_sync_screen/cloud_sync_screen.dart';
import '../customers_screen/customer_master_screen.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  void _open(BuildContext context, Widget screen) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) {
    if (!AccountService().isAdmin) {
      return const AdminAccessDenied(resource: 'administrator_menu');
    }
    final user = AccountService().currentUser!;
    final sections = <({String title, List<_MoreItem> items})>[
      (
        title: 'Operations',
        items: [
          const _MoreItem(
            title: 'Stock & Inventory',
            subtitle: 'Room supplies, pantry items and reorder levels',
            icon: Icons.inventory_2_outlined,
            screen: InventoryScreen(),
          ),
          const _MoreItem(
            title: 'Payments',
            subtitle: 'Receipts, advances, balances and refunds',
            icon: Icons.payments_outlined,
            screen: PaymentsScreen(),
          ),
          const _MoreItem(
            title: 'Guest IDs',
            subtitle: 'Identity records and verification',
            icon: Icons.badge_outlined,
            screen: GuestIdsScreen(),
          ),
          if (user.role.isAdmin)
            const _MoreItem(
              title: 'Customer Master',
              subtitle: 'Search guests by phone, booking or serial number',
              icon: Icons.manage_search_outlined,
              screen: CustomerMasterScreen(),
            ),
          const _MoreItem(
            title: 'Seasonal Rates',
            subtitle: 'Rate periods and room tariffs',
            icon: Icons.sell_outlined,
            screen: SeasonalRatesScreen(),
          ),
        ],
      ),
      (
        title: 'Management',
        items: [
          const _MoreItem(
            title: 'Reports & Analytics',
            subtitle: 'Revenue, expenses, occupancy and trends',
            icon: Icons.analytics_outlined,
            screen: AnalyticsScreen(),
          ),
          const _MoreItem(
            title: 'Accounts & Access',
            subtitle: 'Accounts, PINs and permissions',
            icon: Icons.people_outline,
            screen: StaffManagementScreen(),
          ),
          const _MoreItem(
            title: 'Branding & Property',
            subtitle: 'Logo, property, tax and invoice details',
            icon: Icons.business_outlined,
            screen: BrandingSettingsScreen(),
          ),
          const _MoreItem(
            title: 'Backup & Restore',
            subtitle: 'Export, restore and share business records',
            icon: Icons.backup_outlined,
            screen: BackupScreen(),
          ),
          const _MoreItem(
            title: 'Cloud Sync',
            subtitle: 'Keep authorized phones up to date',
            icon: Icons.cloud_sync_outlined,
            screen: CloudSyncScreen(),
          ),
          if (user.role.isAdmin)
            const _MoreItem(
              title: 'Trash',
              subtitle: 'Restore recently deleted business records',
              icon: Icons.delete_sweep_outlined,
              screen: TrashScreen(),
            ),
          const _MoreItem(
            title: 'Settings',
            subtitle: 'App-wide controls, units, display and security',
            icon: Icons.settings_outlined,
            screen: SettingsScreen(),
          ),
        ],
      ),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('More')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
        children: [
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            leading: CircleAvatar(
              backgroundColor: Theme.of(context).colorScheme.primaryContainer,
              child: const Icon(Icons.admin_panel_settings_outlined),
            ),
            title: Text(user.displayName),
            subtitle: Text(user.role.label),
            trailing: IconButton(
              tooltip: 'Sign out',
              onPressed: AccountService().logout,
              icon: const Icon(Icons.logout),
            ),
          ),
          for (final section in sections) ...[
            Padding(
              padding: const EdgeInsets.fromLTRB(4, 22, 4, 8),
              child: Text(
                section.title,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: Theme.of(context).colorScheme.secondary,
                ),
              ),
            ),
            for (final item in section.items)
              Card(
                child: ListTile(
                  leading: Icon(item.icon),
                  title: Text(item.title),
                  subtitle: Text(item.subtitle),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _open(context, item.screen),
                ),
              ),
          ],
        ],
      ),
    );
  }
}

class _MoreItem {
  final String title;
  final String subtitle;
  final IconData icon;
  final Widget screen;
  const _MoreItem({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.screen,
  });
}
