import 'dart:math';

class IdRetentionPolicy {
  const IdRetentionPolicy._();

  static DateTime retainUntil(DateTime capturedAt) {
    final utc = capturedAt.toUtc();
    final targetYear = utc.year + 1;
    final lastDay = DateTime.utc(targetYear, utc.month + 1, 0).day;
    return DateTime.utc(
      targetYear,
      utc.month,
      min(utc.day, lastDay),
      utc.hour,
      utc.minute,
      utc.second,
      utc.millisecond,
      utc.microsecond,
    );
  }

  static bool isProtected(DateTime? capturedAt, {DateTime? now}) =>
      capturedAt != null &&
      retainUntil(capturedAt).isAfter((now ?? DateTime.now()).toUtc());

  static DateTime trashExpiry({
    required String table,
    required Map<String, dynamic> row,
    required DateTime deletedAt,
  }) {
    final recoveryExpiry = deletedAt.toUtc().add(const Duration(days: 7));
    final captures = <DateTime>[];
    if (table == 'bookings') {
      final hasFront = (row['idFrontPath']?.toString() ?? '').isNotEmpty;
      final hasBack = (row['idBackPath']?.toString() ?? '').isNotEmpty;
      if (hasFront) {
        captures.add(
          _date(row['idFrontCapturedAt']) ??
              _date(row['syncUpdatedAt']) ??
              _date(row['checkin']) ??
              deletedAt,
        );
      }
      if (hasBack) {
        captures.add(
          _date(row['idBackCapturedAt']) ??
              _date(row['syncUpdatedAt']) ??
              _date(row['checkin']) ??
              deletedAt,
        );
      }
    } else if (table == 'id_records' &&
        (row['fileName']?.toString() ?? '').isNotEmpty) {
      captures.add(
        _date(row['capturedAt']) ??
            _date(row['syncUpdatedAt']) ??
            _date(row['date']) ??
            deletedAt,
      );
    }
    var expiry = recoveryExpiry;
    for (final capture in captures) {
      final retained = retainUntil(capture);
      if (retained.isAfter(expiry)) expiry = retained;
    }
    return expiry;
  }

  static DateTime? _date(Object? value) {
    final text = value?.toString().trim() ?? '';
    return text.isEmpty ? null : DateTime.tryParse(text)?.toUtc();
  }
}
