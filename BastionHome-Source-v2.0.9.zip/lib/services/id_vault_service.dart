import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:cryptography/cryptography.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class RecoveredIdCapture {
  const RecoveredIdCapture({required this.fileName, required this.slot});

  final String fileName;
  final String slot;
}

class IdVaultService {
  static const int maxImageBytes = 15 * 1024 * 1024;
  static const _keyName = 'bastion_home_id_vault_key_v1';
  static const _pendingCaptureSlotKey = 'pending_id_capture_slot_v1';
  static const _recoveredCaptureFileKey = 'recovered_id_capture_file_v1';
  static const _recoveredCaptureSlotKey = 'recovered_id_capture_slot_v1';
  static const _storage = FlutterSecureStorage();
  static final _cipher = AesGcm.with256bits();
  static const _header = [0x42, 0x48, 0x56, 0x31]; // BHV1

  final ImagePicker _picker = ImagePicker();

  Future<String?> capture(
    ImageSource source, {
    String recoverySlot = 'guest-id',
  }) async {
    SharedPreferences? preferences;
    if (!kIsWeb && Platform.isAndroid && source == ImageSource.camera) {
      preferences = await SharedPreferences.getInstance();
      await preferences.setString(_pendingCaptureSlotKey, recoverySlot);
    }

    try {
      final selected = await _picker.pickImage(
        source: source,
        imageQuality: 75,
        maxWidth: 1600,
        maxHeight: 1600,
        requestFullMetadata: false,
      );
      if (selected == null) return null;
      return await _storeSelectedFile(selected);
    } finally {
      await preferences?.remove(_pendingCaptureSlotKey);
    }
  }

  /// Saves a camera result left behind when Android recreated the activity.
  Future<void> recoverLostCapture() async {
    if (kIsWeb || !Platform.isAndroid) return;

    final response = await _picker.retrieveLostData();
    if (response.isEmpty) return;

    final preferences = await SharedPreferences.getInstance();
    final slot = preferences.getString(_pendingCaptureSlotKey) ?? 'guest-id';
    if (response.exception != null) {
      await preferences.remove(_pendingCaptureSlotKey);
      throw response.exception!;
    }

    final files = response.files;
    final selected = files != null && files.isNotEmpty
        ? files.first
        : response.file;
    if (selected == null) {
      await preferences.remove(_pendingCaptureSlotKey);
      return;
    }

    final fileName = await _storeSelectedFile(selected);
    await preferences.setString(_recoveredCaptureFileKey, fileName);
    await preferences.setString(_recoveredCaptureSlotKey, slot);
    await preferences.remove(_pendingCaptureSlotKey);
  }

  Future<RecoveredIdCapture?> claimRecoveredCapture(String slotPrefix) async {
    final preferences = await SharedPreferences.getInstance();
    final fileName = preferences.getString(_recoveredCaptureFileKey);
    final slot = preferences.getString(_recoveredCaptureSlotKey);
    if (fileName == null || slot == null || !slot.startsWith(slotPrefix)) {
      return null;
    }

    await preferences.remove(_recoveredCaptureFileKey);
    await preferences.remove(_recoveredCaptureSlotKey);
    return RecoveredIdCapture(fileName: fileName, slot: slot);
  }

  Future<String> _storeSelectedFile(XFile selected) async {
    final plainBytes = await selected.readAsBytes();
    return storeBytes(plainBytes);
  }

  Future<String> storeBytes(List<int> plainBytes, {String? fileName}) async {
    if (plainBytes.isEmpty) {
      throw const FormatException('The selected ID image is empty.');
    }
    if (plainBytes.length > maxImageBytes) {
      throw const FormatException('The selected ID image is too large.');
    }
    final key = await _getOrCreateKey();
    final nonce = _cipher.newNonce();
    final box = await _cipher.encrypt(
      plainBytes,
      secretKey: SecretKey(key),
      nonce: nonce,
    );

    final directory = await _vaultDirectory();
    final safeName = fileName != null && fileName.endsWith('.bhid')
        ? p.basename(fileName)
        : 'guest_id_${DateTime.now().microsecondsSinceEpoch}.bhid';
    final output = File(p.join(directory.path, safeName));
    final sink = output.openWrite();
    try {
      sink.add(_header);
      sink.add(box.nonce);
      sink.add(box.mac.bytes);
      sink.add(box.cipherText);
      await sink.flush();
    } finally {
      await sink.close();
    }
    return safeName;
  }

  Future<Uint8List> readDecrypted(String fileName) async {
    final safeName = p.basename(fileName);
    if (safeName != fileName || !safeName.endsWith('.bhid')) {
      throw const FormatException('Invalid Bastion ID vault file name');
    }
    final directory = await _vaultDirectory();
    final file = File(p.join(directory.path, safeName));
    final length = await file.length();
    if (length > maxImageBytes + 32) {
      throw const FormatException('The Bastion ID vault file is too large');
    }
    final bytes = await file.readAsBytes();
    if (bytes.length < 32 ||
        !_header.asMap().entries.every((e) => bytes[e.key] == e.value)) {
      throw const FormatException('Invalid Bastion ID vault file');
    }

    final nonce = bytes.sublist(4, 16);
    final mac = Mac(bytes.sublist(16, 32));
    final cipherText = bytes.sublist(32);
    final key = await _getOrCreateKey();
    final plainBytes = await _cipher.decrypt(
      SecretBox(cipherText, nonce: nonce, mac: mac),
      secretKey: SecretKey(key),
    );
    return plainBytes is Uint8List
        ? plainBytes
        : Uint8List.fromList(plainBytes);
  }

  Future<void> delete(String fileName) async {
    if (fileName.isEmpty) return;
    final directory = await _vaultDirectory();
    final file = File(p.join(directory.path, p.basename(fileName)));
    if (await file.exists()) await file.delete();
  }

  Future<Directory> _vaultDirectory() async {
    final support = await getApplicationSupportDirectory();
    return Directory(p.join(support.path, 'id_vault')).create(recursive: true);
  }

  Future<List<int>> _getOrCreateKey() async {
    final existing = await _storage.read(key: _keyName);
    if (existing != null && existing.isNotEmpty) {
      return base64Url.decode(existing);
    }

    final random = Random.secure();
    final bytes = List<int>.generate(32, (_) => random.nextInt(256));
    await _storage.write(key: _keyName, value: base64UrlEncode(bytes));
    return bytes;
  }
}
