import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../database/database_helper.dart';
import 'data_change_service.dart';
import 'notification_service.dart';
import 'trash_service.dart';
import 'workforce_credential_policy.dart';

enum CloudSyncStatus { notConfigured, signedOut, ready, syncing, error }

/// Thrown when the cloud rejects a username/password pair (as opposed to the
/// network being unreachable or the account lacking business access).
class CloudCredentialException implements Exception {
  final String message;
  const CloudCredentialException([
    this.message = 'Incorrect username or password.',
  ]);

  @override
  String toString() => message;
}

class _SecureSupabaseStorage extends LocalStorage {
  static const _sessionKey = 'bastion_supabase_session';
  final FlutterSecureStorage _storage;

  _SecureSupabaseStorage(this._storage);

  @override
  Future<void> initialize() async {}

  @override
  Future<String?> accessToken() => _storage.read(key: _sessionKey);

  @override
  Future<bool> hasAccessToken() => _storage.containsKey(key: _sessionKey);

  @override
  Future<void> persistSession(String persistSessionString) =>
      _storage.write(key: _sessionKey, value: persistSessionString);

  @override
  Future<void> removePersistedSession() => _storage.delete(key: _sessionKey);
}

class CloudSyncService extends ChangeNotifier {
  static const employeeCorePermissionNames = <String>{
    'createBookings',
    'viewOccupancy',
    'recordExpenses',
  };
  static final CloudSyncService _instance = CloudSyncService._internal();
  factory CloudSyncService() => _instance;
  CloudSyncService._internal();

  static const _projectUrlKey = 'bastion_supabase_url';
  static const _publishableKeyKey = 'bastion_supabase_publishable_key';
  static const _workspaceIdKey = 'bastion_supabase_workspace_id';
  static const _deviceIdKey = 'bastion_sync_device_id';
  static const _cloudRoleKey = 'bastion_cloud_role';
  static const _cloudPermissionsKey = 'bastion_cloud_permissions';
  static const _cloudUserIdKey = 'bastion_cloud_user_id';
  static const _memberDisplayNameKey = 'bastion_cloud_display_name';
  static const _memberUsernameKey = 'bastion_cloud_username';
  static const _mustChangePasswordKey = 'bastion_must_change_password';
  static const _lastSecurityEventKeyPrefix = 'bastion_last_security_event_';
  static const officialProjectUrl = 'https://okvtvqoxymkmralfuonn.supabase.co';
  static const officialPublishableKey =
      'sb_publishable_Do5FITTHo41A7Hf8tzlBGw_0eDjIcOS';

  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage();
  final DatabaseHelper _db = DatabaseHelper();
  RealtimeChannel? _channel;
  Timer? _syncTimer;
  final Map<String, DateTime> _reportedSecurityEvents = {};
  bool _initialized = false;
  bool _supabaseInitialized = false;
  bool _syncing = false;
  bool _syncRequested = false;
  bool _applyingRemote = false;
  bool? _connectedForTesting;
  int _sessionEpoch = 0;

  CloudSyncStatus status = CloudSyncStatus.notConfigured;
  String? projectUrl;
  String? _publishableKey;
  String? workspaceId;
  String? workspaceName;
  String? cloudRole;
  Set<String> cloudPermissions = const {};
  String? cloudUserId;
  String? memberDisplayName;
  String? memberUsername;
  bool mustChangeCloudPassword = false;
  DateTime? passwordChangedAt;
  String? lastError;
  DateTime? lastSyncedAt;
  String? _deviceId;

  bool get isConfigured => projectUrl != null && projectUrl!.isNotEmpty;
  bool get isSignedIn =>
      _supabaseInitialized && Supabase.instance.client.auth.currentUser != null;
  bool get isConnected => isSignedIn && workspaceId != null;
  bool get hasCloudAuthority => cloudRole != null;
  bool get isRevoked => cloudRole == 'revoked';
  bool get hasActiveCloudAuthority =>
      (_connectedForTesting ?? isConnected) &&
      hasCloudAuthority &&
      !isRevoked &&
      cloudRole != 'unapproved';
  bool hasEmployeePermission(String permission) =>
      cloudRole == 'employee' &&
      (employeeCorePermissionNames.contains(permission) ||
          cloudPermissions.contains(permission));
  bool get isPrimaryCloudAdmin => cloudRole == 'primary_admin';

  /// The app username of the cloud account this phone is currently signed in
  /// to, or null when no cloud account is attached.
  String? get sessionUsername {
    if (!hasCloudAuthority) return null;
    final named = memberUsername?.trim().toLowerCase();
    if (named != null && named.isNotEmpty) return named;
    return switch (cloudRole) {
      'primary_admin' => 'admin',
      'backup_admin' => 'backup-admin',
      _ => null,
    };
  }

  bool isSessionFor(String username) {
    final current = sessionUsername;
    return current != null && current == username.trim().toLowerCase();
  }

  bool get isCloudAdmin =>
      const {'primary_admin', 'backup_admin', 'admin'}.contains(cloudRole);
  bool get canInviteEmployees => isCloudAdmin;
  bool get canInviteAdministrators => isPrimaryCloudAdmin;
  String? get websiteBookingEndpoint =>
      projectUrl == null ? null : '$projectUrl/functions/v1/website-bookings';
  String? get signedInEmail => _supabaseInitialized
      ? Supabase.instance.client.auth.currentUser?.email
      : null;

  Future<void> initialize() async {
    if (_initialized) return;
    _initialized = true;
    DataChangeService().addListener(_onLocalDataChanged);
    await TrashService().purgeExpired();
    projectUrl =
        await _secureStorage.read(key: _projectUrlKey) ?? officialProjectUrl;
    final key =
        await _secureStorage.read(key: _publishableKeyKey) ??
        officialPublishableKey;
    _publishableKey = key;
    await _secureStorage.write(key: _projectUrlKey, value: projectUrl);
    await _secureStorage.write(key: _publishableKeyKey, value: key);
    workspaceId = await _secureStorage.read(key: _workspaceIdKey);
    cloudRole = await _secureStorage.read(key: _cloudRoleKey);
    cloudUserId = await _secureStorage.read(key: _cloudUserIdKey);
    memberDisplayName = await _secureStorage.read(key: _memberDisplayNameKey);
    memberUsername = await _secureStorage.read(key: _memberUsernameKey);
    mustChangeCloudPassword =
        await _secureStorage.read(key: _mustChangePasswordKey) == 'true';
    final storedPermissions = await _secureStorage.read(
      key: _cloudPermissionsKey,
    );
    if (storedPermissions != null) {
      final decoded = jsonDecode(storedPermissions);
      if (decoded is List) {
        cloudPermissions = decoded.map((value) => value.toString()).toSet();
      }
    }
    _deviceId = await _secureStorage.read(key: _deviceIdKey);
    if (_deviceId == null) {
      _deviceId = _newDeviceId();
      await _secureStorage.write(key: _deviceIdKey, value: _deviceId);
    }
    if (projectUrl == null) {
      status = CloudSyncStatus.notConfigured;
      notifyListeners();
      return;
    }
    try {
      await _initializeSupabase(projectUrl!, key);
      if (isSignedIn) {
        await _loadMembership();
        if (isConnected) {
          await syncNow();
          _subscribeToChanges();
          await _checkForSecurityAlerts();
        }
      } else {
        status = CloudSyncStatus.signedOut;
      }
    } catch (error) {
      _setError(error);
    }
    notifyListeners();
  }

  Future<void> configureProject({
    required String url,
    required String publishableKey,
  }) async {
    final normalizedUrl = url.trim().replaceAll(RegExp(r'/$'), '');
    final key = publishableKey.trim();
    final uri = Uri.tryParse(normalizedUrl);
    if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) {
      throw ArgumentError('Enter a valid HTTPS Supabase project URL.');
    }
    if (key.length < 20) {
      throw ArgumentError('Enter the project publishable key.');
    }
    if (_supabaseInitialized &&
        (projectUrl != normalizedUrl || _publishableKey != key)) {
      await signOut();
      await Supabase.instance.dispose();
      _supabaseInitialized = false;
    }
    projectUrl = normalizedUrl;
    _publishableKey = key;
    await _secureStorage.write(key: _projectUrlKey, value: normalizedUrl);
    await _secureStorage.write(key: _publishableKeyKey, value: key);
    await _initializeSupabase(normalizedUrl, key);
    status = isSignedIn ? CloudSyncStatus.ready : CloudSyncStatus.signedOut;
    lastError = null;
    notifyListeners();
  }

  Future<void> _initializeSupabase(String url, String key) async {
    if (_supabaseInitialized) return;
    await Supabase.initialize(
      url: url,
      publishableKey: key,
      authOptions: FlutterAuthClientOptions(
        localStorage: _SecureSupabaseStorage(_secureStorage),
        detectSessionInUri: false,
      ),
      debug: kDebugMode,
    );
    _supabaseInitialized = true;
  }

  /// Signs this phone in to the given cloud account. Any approved account may
  /// be used on any phone: when a different account was previously attached,
  /// its cached authority is replaced by the new account's.
  Future<void> signIn({
    required String identifier,
    required String password,
  }) async {
    _requireConfigured();
    final normalized = identifier.trim().toLowerCase();
    try {
      if (WorkforceCredentialPolicy.isPrimaryOwnerAlias(normalized)) {
        final response = await _invokeOwnerLogin(password);
        final data = Map<String, dynamic>.from(response.data as Map);
        final refreshToken = data['refresh_token']?.toString() ?? '';
        final accessToken = data['access_token']?.toString() ?? '';
        if (refreshToken.isEmpty || accessToken.isEmpty) {
          throw StateError('Owner sign-in did not return a valid session.');
        }
        await Supabase.instance.client.auth.setSession(
          refreshToken,
          accessToken: accessToken,
        );
      } else {
        await Supabase.instance.client.auth.signInWithPassword(
          email: WorkforceCredentialPolicy.signInIdentifier(normalized),
          password: password,
        );
      }
    } on AuthException catch (error) {
      final text = error.message.toLowerCase();
      final code = error.statusCode;
      if (code == '400' ||
          code == '401' ||
          code == '422' ||
          text.contains('invalid login credentials') ||
          text.contains('invalid credentials')) {
        throw const CloudCredentialException();
      }
      throw StateError(error.message);
    }
    await _resetSessionState();
    await _loadMembership();
    if (!hasActiveCloudAuthority) {
      await Supabase.instance.client.auth.signOut(scope: SignOutScope.local);
      throw StateError('This account does not have active business access.');
    }
    status = CloudSyncStatus.ready;
    if (isConnected) {
      await syncNow();
      _subscribeToChanges();
      await _checkForSecurityAlerts();
    }
    notifyListeners();
  }

  /// Drops everything cached about the previously attached cloud account
  /// without ending the Supabase session that was just established.
  Future<void> _resetSessionState() async {
    _sessionEpoch++;
    _syncRequested = false;
    _syncTimer?.cancel();
    _reportedSecurityEvents.clear();
    if (_channel != null) {
      await Supabase.instance.client.removeChannel(_channel!);
      _channel = null;
    }
    workspaceId = null;
    workspaceName = null;
    await _secureStorage.delete(key: _workspaceIdKey);
    await _clearCachedAuthority();
  }

  Future<FunctionResponse> _invokeOwnerLogin(String password) async {
    try {
      final response = await Supabase.instance.client.functions.invoke(
        'owner-login',
        body: {'username': 'admin', 'password': password},
      );
      if (response.data is! Map) {
        throw StateError('Owner sign-in service returned an invalid response.');
      }
      return response;
    } on FunctionException catch (error) {
      final details = error.details;
      final message = details is Map && details['error'] != null
          ? details['error'].toString()
          : null;
      if (error.status == 400) {
        throw CloudCredentialException(
          message ?? 'Incorrect username or password.',
        );
      }
      throw StateError(message ?? 'Owner sign-in service is unavailable.');
    }
  }

  Future<void> signOut() async {
    _sessionEpoch++;
    _syncRequested = false;
    _syncTimer?.cancel();
    if (_channel != null) {
      await Supabase.instance.client.removeChannel(_channel!);
      _channel = null;
    }
    if (_supabaseInitialized) await Supabase.instance.client.auth.signOut();
    workspaceId = null;
    workspaceName = null;
    await _secureStorage.delete(key: _workspaceIdKey);
    await _clearCachedAuthority();
    status = isConfigured
        ? CloudSyncStatus.signedOut
        : CloudSyncStatus.notConfigured;
    notifyListeners();
  }

  Future<void> resetProject() async {
    if (hasCloudAuthority &&
        cloudRole != 'unapproved' &&
        !isPrimaryCloudAdmin) {
      throw StateError(
        'Only the primary owner can remove this device from the business.',
      );
    }
    await signOut();
    if (_supabaseInitialized) {
      await Supabase.instance.dispose();
      _supabaseInitialized = false;
    }
    await _secureStorage.delete(key: _projectUrlKey);
    await _secureStorage.delete(key: _publishableKeyKey);
    projectUrl = null;
    _publishableKey = null;
    await _clearCachedAuthority();
    status = CloudSyncStatus.notConfigured;
    lastError = null;
    notifyListeners();
  }

  Future<void> createWorkspace(String name) async {
    _requireSignedIn();
    final result = await Supabase.instance.client.rpc<String>(
      'create_bastion_workspace',
      params: {'workspace_name': name.trim()},
    );
    workspaceId = result;
    await _secureStorage.write(key: _workspaceIdKey, value: workspaceId);
    await _loadMembership();
    await syncNow();
    _subscribeToChanges();
  }

  Future<void> updateMyDisplayName(String displayName) async {
    _requireConnected();
    await Supabase.instance.client.rpc<void>(
      'update_my_bastion_display_name',
      params: {
        'target_workspace': workspaceId,
        'member_name': displayName.trim(),
      },
    );
    await _loadMembership();
    notifyListeners();
  }

  Future<List<Map<String, dynamic>>> getWorkspaceMembers() async {
    if (!isCloudAdmin || workspaceId == null) {
      throw StateError('Administrator cloud access is required.');
    }
    final rows = await Supabase.instance.client
        .from('bastion_workspace_members')
        .select(
          'user_id, role, username, display_name, active, permissions, '
          'must_change_password, password_changed_at, joined_at, updated_at',
        )
        .eq('workspace_id', workspaceId!)
        .order('joined_at');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<Map<String, dynamic>> createManagedCloudAccount({
    required String username,
    required String displayName,
    required String temporaryPassword,
    required String role,
    required Set<String> permissions,
  }) async {
    _requirePrimaryOwner();
    final response = await _invokeWorkforce({
      'action': 'create',
      'workspace_id': workspaceId,
      'username': WorkforceCredentialPolicy.normalizeUsername(username),
      'display_name': displayName.trim(),
      'temporary_password': temporaryPassword,
      'role': role,
      'permissions': permissions.toList()..sort(),
    });
    return response;
  }

  Future<void> resetManagedCloudPassword({
    required String userId,
    required String temporaryPassword,
  }) async {
    _requirePrimaryOwner();
    await _invokeWorkforce({
      'action': 'reset_password',
      'workspace_id': workspaceId,
      'user_id': userId,
      'temporary_password': temporaryPassword,
    });
  }

  Future<void> deleteManagedCloudAccount(String userId) async {
    _requirePrimaryOwner();
    await _invokeWorkforce({
      'action': 'delete',
      'workspace_id': workspaceId,
      'user_id': userId,
    });
  }

  Future<void> changeCloudPassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    _requireConnected();
    final validation = WorkforceCredentialPolicy.passwordError(newPassword);
    if (validation != null) throw ArgumentError(validation);
    await Supabase.instance.client.auth.updateUser(
      UserAttributes(password: newPassword, currentPassword: currentPassword),
    );
    await Supabase.instance.client.rpc<void>(
      'record_my_bastion_password_change',
      params: {'target_workspace': workspaceId},
    );
    await _loadMembership();
    notifyListeners();
  }

  Future<List<Map<String, dynamic>>> getSecurityEvents({String? userId}) async {
    if (!isCloudAdmin || workspaceId == null) {
      throw StateError('Administrator cloud access is required.');
    }
    var query = Supabase.instance.client
        .from('bastion_security_events')
        .select(
          'id, target_user_id, target_username, event_type, actor_user_id, '
          'metadata, created_at',
        )
        .eq('workspace_id', workspaceId!);
    if (userId != null) query = query.eq('target_user_id', userId);
    final rows = await query.order('created_at', ascending: false).limit(200);
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> reportSecurityEvent(
    String eventType, {
    required String resource,
    required String attemptedAction,
  }) async {
    if (!isSignedIn || workspaceId == null || isRevoked) return;
    final key = '$eventType:$resource:$attemptedAction';
    final now = DateTime.now();
    final previous = _reportedSecurityEvents[key];
    if (previous != null &&
        now.difference(previous) < const Duration(seconds: 30)) {
      return;
    }
    _reportedSecurityEvents[key] = now;
    try {
      await _invokeWorkforce({
        'action': 'report_security_event',
        'workspace_id': workspaceId,
        'event_type': eventType,
        'metadata': {
          'resource': resource,
          'attempted_action': attemptedAction,
          'source': 'mobile_app',
          'device_id': _deviceId,
        },
      });
    } catch (error) {
      debugPrint('Security event could not be reported: $error');
    }
  }

  Future<Map<String, dynamic>> _invokeWorkforce(
    Map<String, dynamic> body,
  ) async {
    try {
      final response = await Supabase.instance.client.functions.invoke(
        'manage-workforce',
        body: body,
      );
      if (response.data is! Map) {
        throw StateError(
          'Cloud workforce service returned an invalid response.',
        );
      }
      return Map<String, dynamic>.from(response.data as Map);
    } on FunctionException catch (error) {
      final details = error.details;
      if (details is Map && details['error'] != null) {
        throw StateError(details['error'].toString());
      }
      throw StateError('Cloud workforce service is unavailable.');
    }
  }

  Future<void> updateMemberAccess({
    required String userId,
    required bool active,
    required Set<String> permissions,
  }) async {
    if (!isPrimaryCloudAdmin || workspaceId == null) {
      throw StateError('Only the primary owner can change workspace access.');
    }
    await Supabase.instance.client.rpc<void>(
      'update_bastion_member_access',
      params: {
        'target_workspace': workspaceId,
        'target_user': userId,
        'target_active': active,
        'target_permissions': permissions.toList()..sort(),
      },
    );
  }

  Future<Map<String, dynamic>?> getWebsiteBookingChannel() async {
    if (!isCloudAdmin || workspaceId == null) {
      throw StateError('Administrator cloud access is required.');
    }
    final result = await Supabase.instance.client
        .from('bastion_website_channels')
        .select('id, enabled, allowed_origin, created_at, updated_at')
        .eq('workspace_id', workspaceId!)
        .maybeSingle();
    return result == null ? null : Map<String, dynamic>.from(result);
  }

  Future<String> createWebsiteBookingChannel({String? allowedOrigin}) async {
    if (!isCloudAdmin || workspaceId == null) {
      throw StateError('Administrator cloud access is required.');
    }
    return Supabase.instance.client.rpc<String>(
      'create_bastion_website_channel',
      params: {
        'target_workspace': workspaceId,
        'website_origin': allowedOrigin?.trim() ?? '',
      },
    );
  }

  Future<void> updateWebsiteBookingChannel({
    required bool enabled,
    String? allowedOrigin,
  }) async {
    if (!isCloudAdmin || workspaceId == null) {
      throw StateError('Administrator cloud access is required.');
    }
    await Supabase.instance.client
        .from('bastion_website_channels')
        .update({
          'enabled': enabled,
          'allowed_origin': allowedOrigin?.trim() ?? '',
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        })
        .eq('workspace_id', workspaceId!);
  }

  Future<void> _loadMembership() async {
    if (!isSignedIn) return;
    final userId = Supabase.instance.client.auth.currentUser!.id;
    var query = Supabase.instance.client
        .from('bastion_workspace_members')
        .select(
          'workspace_id, role, username, display_name, active, permissions, '
          'must_change_password, password_changed_at',
        )
        .eq('user_id', userId);
    final rows = await query;
    final memberships = List<Map<String, dynamic>>.from(rows);
    Map<String, dynamic>? selected;
    for (final membership in memberships) {
      if (membership['workspace_id'] == workspaceId) selected = membership;
    }
    selected ??= memberships.isEmpty ? null : memberships.first;
    if (selected == null) {
      workspaceId = null;
      workspaceName = null;
      await _secureStorage.delete(key: _workspaceIdKey);
      if (!hasCloudAuthority) {
        cloudRole = 'unapproved';
        cloudPermissions = const {};
        memberDisplayName = null;
        memberUsername = null;
        mustChangeCloudPassword = false;
        passwordChangedAt = null;
        cloudUserId = userId;
        await _persistAuthority();
      }
      return;
    }
    workspaceId = selected['workspace_id'] as String;
    final active = selected['active'] as bool? ?? true;
    cloudRole = active ? selected['role'] as String : 'revoked';
    cloudPermissions = active
        ? Set<String>.from(selected['permissions'] as List? ?? const [])
        : const {};
    if (active && cloudRole == 'employee') {
      cloudPermissions = {...cloudPermissions, ...employeeCorePermissionNames};
    }
    memberDisplayName = selected['display_name'] as String?;
    memberUsername = selected['username'] as String?;
    mustChangeCloudPassword =
        selected['must_change_password'] as bool? ?? false;
    passwordChangedAt = DateTime.tryParse(
      selected['password_changed_at']?.toString() ?? '',
    );
    cloudUserId = userId;
    await _secureStorage.write(key: _workspaceIdKey, value: workspaceId);
    await _persistAuthority();
    if (!active) {
      workspaceName = null;
      status = CloudSyncStatus.error;
      lastError = 'Your access to this business has been disabled.';
      return;
    }
    final workspace = await Supabase.instance.client
        .from('bastion_workspaces')
        .select('name')
        .eq('id', workspaceId!)
        .single();
    workspaceName = workspace['name'] as String;
  }

  Future<bool> refreshMembership() async {
    _requireSignedIn();
    await _loadMembership();
    notifyListeners();
    return isConnected && !isRevoked;
  }

  Future<bool> verifyActiveMembership() async {
    if (!hasCloudAuthority) return true;
    if (!isSignedIn) return false;
    try {
      return await refreshMembership();
    } catch (_) {
      return false;
    }
  }

  Future<void> _persistAuthority() async {
    if (cloudRole == null) {
      await _secureStorage.delete(key: _cloudRoleKey);
    } else {
      await _secureStorage.write(key: _cloudRoleKey, value: cloudRole);
    }
    if (cloudUserId == null) {
      await _secureStorage.delete(key: _cloudUserIdKey);
    } else {
      await _secureStorage.write(key: _cloudUserIdKey, value: cloudUserId);
    }
    if (memberDisplayName == null) {
      await _secureStorage.delete(key: _memberDisplayNameKey);
    } else {
      await _secureStorage.write(
        key: _memberDisplayNameKey,
        value: memberDisplayName,
      );
    }
    if (memberUsername == null) {
      await _secureStorage.delete(key: _memberUsernameKey);
    } else {
      await _secureStorage.write(
        key: _memberUsernameKey,
        value: memberUsername,
      );
    }
    await _secureStorage.write(
      key: _mustChangePasswordKey,
      value: mustChangeCloudPassword.toString(),
    );
    await _secureStorage.write(
      key: _cloudPermissionsKey,
      value: jsonEncode(cloudPermissions.toList()..sort()),
    );
  }

  Future<void> _clearCachedAuthority() async {
    cloudRole = null;
    cloudPermissions = const {};
    cloudUserId = null;
    memberDisplayName = null;
    memberUsername = null;
    mustChangeCloudPassword = false;
    passwordChangedAt = null;
    await _secureStorage.delete(key: _cloudRoleKey);
    await _secureStorage.delete(key: _cloudPermissionsKey);
    await _secureStorage.delete(key: _cloudUserIdKey);
    await _secureStorage.delete(key: _memberDisplayNameKey);
    await _secureStorage.delete(key: _memberUsernameKey);
    await _secureStorage.delete(key: _mustChangePasswordKey);
  }

  void _requirePrimaryOwner() {
    if (!isPrimaryCloudAdmin || workspaceId == null) {
      throw StateError('Only the primary owner can manage cloud accounts.');
    }
  }

  Future<void> syncNow() async {
    if (!isConnected) return;
    if (_syncing) {
      _syncRequested = true;
      return;
    }
    final syncEpoch = _sessionEpoch;
    final activeWorkspaceId = workspaceId!;
    _syncing = true;
    status = CloudSyncStatus.syncing;
    lastError = null;
    notifyListeners();
    try {
      await TrashService().purgeExpired();
      if (isCloudAdmin) {
        final localPurges = await _db.getLocalPurgedRecords();
        for (var offset = 0; offset < localPurges.length; offset += 100) {
          final end = min(offset + 100, localPurges.length);
          final batch = localPurges.sublist(offset, end).map((record) {
            return {...record, 'workspace_id': activeWorkspaceId};
          }).toList();
          await Supabase.instance.client
              .from('bastion_purged_records')
              .upsert(
                batch,
                onConflict: 'workspace_id,record_id',
                ignoreDuplicates: true,
              );
        }
      }
      final remotePurges = await _fetchAll(
        'bastion_purged_records',
        columns: 'record_id',
        workspace: activeWorkspaceId,
      );
      final remote = await _fetchAll(
        'bastion_sync_records',
        columns:
            'record_id, entity_type, payload, updated_at, deleted_at, deleted_by',
        workspace: activeWorkspaceId,
      );
      _applyingRemote = true;
      try {
        await _db.applyRemotePurges(
          remotePurges.map((row) => row['record_id'] as String).toList(),
        );
        await _db.applyRemoteSyncRecords(remote);
      } finally {
        _applyingRemote = false;
      }

      var local = await _db.getLocalSyncRecords();
      if (cloudRole == 'employee') {
        local = local.where((record) {
          if (record['deleted_at'] != null) return false;
          return switch (record['entity_type']) {
            'bookings' => hasEmployeePermission('createBookings'),
            'daily_expenses' => hasEmployeePermission('recordExpenses'),
            _ => false,
          };
        }).toList();
      }
      final remoteById = <String, Map<String, dynamic>>{
        for (final record in remote)
          if (record['record_id'] is String)
            record['record_id'] as String: record,
      };
      local = local
          .where(
            (record) => shouldUploadRecord(
              record,
              remoteById[record['record_id']?.toString()],
            ),
          )
          .toList();
      for (var offset = 0; offset < local.length; offset += 100) {
        final end = min(offset + 100, local.length);
        final batch = local.sublist(offset, end).map((record) {
          return {
            ...record,
            'workspace_id': activeWorkspaceId,
            'source_device': _deviceId,
          };
        }).toList();
        await Supabase.instance.client
            .from('bastion_sync_records')
            .upsert(batch, onConflict: 'workspace_id,record_id');
      }
      if (_sessionEpoch == syncEpoch && workspaceId == activeWorkspaceId) {
        lastSyncedAt = DateTime.now();
        status = CloudSyncStatus.ready;
      }
    } catch (error) {
      if (_sessionEpoch == syncEpoch) _setError(error);
    } finally {
      _syncing = false;
      final shouldRunAgain = _syncRequested;
      _syncRequested = false;
      if (shouldRunAgain &&
          _sessionEpoch == syncEpoch &&
          workspaceId == activeWorkspaceId &&
          isConnected) {
        _scheduleSync(Duration.zero);
      }
      notifyListeners();
    }
  }

  Future<List<Map<String, dynamic>>> _fetchAll(
    String table, {
    required String columns,
    required String workspace,
  }) async {
    final output = <Map<String, dynamic>>[];
    const pageSize = 500;
    for (var start = 0; ; start += pageSize) {
      final rows = await Supabase.instance.client
          .from(table)
          .select(columns)
          .eq('workspace_id', workspace)
          .order('record_id')
          .range(start, start + pageSize - 1);
      final page = List<Map<String, dynamic>>.from(rows);
      output.addAll(page);
      if (page.length < pageSize) break;
    }
    return output;
  }

  void _subscribeToChanges() {
    if (!isConnected || _channel != null) return;
    final filter = PostgresChangeFilter(
      type: PostgresChangeFilterType.eq,
      column: 'workspace_id',
      value: workspaceId!,
    );
    _channel = Supabase.instance.client
        .channel('bastion-sync-$workspaceId')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'bastion_sync_records',
          filter: filter,
          callback: (payload) {
            final sourceDevice =
                payload.newRecord['source_device']?.toString() ??
                payload.oldRecord['source_device']?.toString();
            if (sourceDevice == _deviceId) return;
            _scheduleSync(const Duration(milliseconds: 700));
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'bastion_purged_records',
          filter: filter,
          callback: (_) => _scheduleSync(const Duration(milliseconds: 700)),
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'bastion_security_events',
          filter: filter,
          callback: (payload) {
            if (!isCloudAdmin) return;
            unawaited(_notifySecurityAlert(payload.newRecord));
          },
        )
        .subscribe();
  }

  Future<void> _checkForSecurityAlerts() async {
    if (!isCloudAdmin || workspaceId == null) return;
    try {
      final rows = await Supabase.instance.client
          .from('bastion_security_events')
          .select('id, target_username, event_type, created_at')
          .eq('workspace_id', workspaceId!)
          .inFilter('event_type', const [
            'permission_denied',
            'settings_access_attempt',
            'failed_pin_lockout',
            'role_mismatch',
          ])
          .order('created_at', ascending: false)
          .limit(1);
      final events = List<Map<String, dynamic>>.from(rows);
      if (events.isEmpty) return;
      final event = events.first;
      final eventId = event['id']?.toString();
      if (eventId == null) return;
      final storageKey = '$_lastSecurityEventKeyPrefix$workspaceId';
      if (await _secureStorage.read(key: storageKey) == eventId) return;
      await _notifySecurityAlert(event);
    } catch (error) {
      debugPrint('Security alerts could not be checked: $error');
    }
  }

  Future<void> _notifySecurityAlert(Map<String, dynamic> event) async {
    final eventType = event['event_type']?.toString();
    if (!_isDeniedAccessEvent(eventType) || workspaceId == null) return;
    final eventId = event['id']?.toString();
    if (eventId != null) {
      await _secureStorage.write(
        key: '$_lastSecurityEventKeyPrefix$workspaceId',
        value: eventId,
      );
    }
    final username = event['target_username']?.toString() ?? 'account';
    await NotificationService().showSecurityAlert(
      title: 'Bastion Home security alert',
      body: '$username attempted a restricted action. Review the security log.',
    );
  }

  static bool _isDeniedAccessEvent(String? eventType) => const {
    'permission_denied',
    'settings_access_attempt',
    'failed_pin_lockout',
    'role_mismatch',
  }.contains(eventType);

  void _onLocalDataChanged() {
    if (_applyingRemote) return;
    if (!isConnected) return;
    if (_syncing) {
      _syncRequested = true;
    } else {
      _scheduleSync(const Duration(seconds: 2));
    }
  }

  void _scheduleSync(Duration delay) {
    _syncTimer?.cancel();
    _syncTimer = Timer(delay, syncNow);
  }

  void _requireConfigured() {
    if (!_supabaseInitialized) {
      throw StateError('Configure the cloud project first.');
    }
  }

  void _requireSignedIn() {
    _requireConfigured();
    if (!isSignedIn) throw StateError('Sign in to cloud sync first.');
  }

  void _requireConnected() {
    _requireSignedIn();
    if (!isConnected || isRevoked) {
      throw StateError('Active workspace access is required.');
    }
  }

  void _setError(Object error) {
    lastError = error.toString();
    status = CloudSyncStatus.error;
  }

  @visibleForTesting
  static bool shouldUploadRecord(
    Map<String, dynamic> local,
    Map<String, dynamic>? remote,
  ) {
    if (remote == null) return true;
    final localUpdated = DateTime.tryParse(
      local['updated_at']?.toString() ?? '',
    )?.toUtc();
    final remoteUpdated = DateTime.tryParse(
      remote['updated_at']?.toString() ?? '',
    )?.toUtc();
    if (localUpdated == null) return false;
    if (remoteUpdated == null) return true;
    return localUpdated.isAfter(remoteUpdated);
  }

  @visibleForTesting
  void setAuthorityForTesting({
    String? role,
    Set<String> permissions = const {},
    bool connected = true,
  }) {
    cloudRole = role;
    cloudPermissions = permissions;
    _connectedForTesting = role == null ? null : connected;
  }

  String _newDeviceId() {
    final random = Random.secure();
    return List.generate(
      24,
      (_) => random.nextInt(16).toRadixString(16),
    ).join();
  }
}
