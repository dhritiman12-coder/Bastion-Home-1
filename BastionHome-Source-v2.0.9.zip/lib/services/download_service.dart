import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';
import 'package:universal_html/html.dart' as html;

class DownloadService {
  static const MethodChannel _channel = MethodChannel(
    'in.bastionhome.manager/downloads',
  );

  Future<String> saveText({
    required String fileName,
    required String contents,
    String mimeType = 'text/plain',
  }) => saveBytes(
    fileName: fileName,
    bytes: Uint8List.fromList(utf8.encode(contents)),
    mimeType: mimeType,
  );

  Future<String> saveBytes({
    required String fileName,
    required Uint8List bytes,
    required String mimeType,
  }) async {
    final safeName = sanitizeFileName(fileName);
    if (kIsWeb) {
      final blob = html.Blob([bytes], mimeType);
      final url = html.Url.createObjectUrlFromBlob(blob);
      try {
        html.AnchorElement(href: url)
          ..download = safeName
          ..click();
      } finally {
        html.Url.revokeObjectUrl(url);
      }
      return safeName;
    }

    if (Platform.isAndroid || Platform.isIOS) {
      final temporaryRoot = await getTemporaryDirectory();
      final transferDirectory = Directory(
        path.join(
          temporaryRoot.path,
          'bastion_download_${DateTime.now().microsecondsSinceEpoch}',
        ),
      );
      await transferDirectory.create(recursive: true);
      final transferFile = File(path.join(transferDirectory.path, safeName));
      try {
        await transferFile.writeAsBytes(bytes, flush: true);
        final location = await _channel.invokeMethod<String>('saveFile', {
          'sourcePath': transferFile.path,
          'fileName': safeName,
          'mimeType': mimeType,
        });
        if (location == null || location.trim().isEmpty) {
          throw const FileSystemException('The device did not save the file');
        }
        return location;
      } finally {
        if (await transferDirectory.exists()) {
          await transferDirectory.delete(recursive: true);
        }
      }
    }

    final downloads = await getDownloadsDirectory();
    final directory = downloads ?? await getApplicationDocumentsDirectory();
    await directory.create(recursive: true);
    final destination = await _uniqueFile(directory, safeName);
    await destination.writeAsBytes(bytes, flush: true);
    return destination.path;
  }

  @visibleForTesting
  static String sanitizeFileName(String value) {
    final segments = value.trim().split(RegExp(r'[/\\]'));
    final baseName = segments.last.replaceAll(
      RegExp(r'[<>:"/\\|?*\x00-\x1F]'),
      '_',
    );
    final withoutTrailingDots = baseName.replaceAll(RegExp(r'[. ]+$'), '');
    return withoutTrailingDots.isEmpty
        ? 'bastion_download'
        : withoutTrailingDots;
  }

  static Future<File> _uniqueFile(Directory directory, String fileName) async {
    var candidate = File(path.join(directory.path, fileName));
    if (!await candidate.exists()) return candidate;
    final extension = path.extension(fileName);
    final stem = path.basenameWithoutExtension(fileName);
    for (var suffix = 2; suffix < 10000; suffix++) {
      candidate = File(path.join(directory.path, '$stem ($suffix)$extension'));
      if (!await candidate.exists()) return candidate;
    }
    throw const FileSystemException('Could not create a unique download name');
  }
}
