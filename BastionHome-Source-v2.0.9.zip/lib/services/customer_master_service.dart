import '../models/booking_model.dart';
import '../utils/phone_normalizer.dart';

class CustomerSummary {
  CustomerSummary({
    required this.key,
    required this.normalizedPhone,
    required this.bookings,
  });

  final String key;
  final String normalizedPhone;
  final List<BookingModel> bookings;

  BookingModel get latestBooking => bookings.first;
  String get displayName => latestBooking.guest;
  String get displayPhone => latestBooking.phone;
  Set<String> get knownNames => bookings
      .map((booking) => booking.guest.trim())
      .where((name) => name.isNotEmpty)
      .toSet();
  DateTime get firstVisit => bookings
      .map((booking) => booking.checkin)
      .reduce((a, b) => a.isBefore(b) ? a : b);
  DateTime get lastVisit => bookings
      .map((booking) => booking.checkin)
      .reduce((a, b) => a.isAfter(b) ? a : b);
  int get completedStays => bookings
      .where((booking) => booking.status == BookingStatus.checkedOut)
      .length;
  int get validBookings => bookings
      .where(
        (booking) =>
            booking.status != BookingStatus.cancelled &&
            booking.status != BookingStatus.noShow,
      )
      .length;
  int get totalNights => bookings
      .where(
        (booking) =>
            booking.status != BookingStatus.cancelled &&
            booking.status != BookingStatus.noShow,
      )
      .fold(0, (sum, booking) => sum + booking.nights);
  bool get isFrequent => completedStays >= 2;
}

class CustomerMasterService {
  const CustomerMasterService._();

  static List<CustomerSummary> build(List<BookingModel> bookings) {
    final grouped = <String, List<BookingModel>>{};
    for (final booking in bookings) {
      final phone = PhoneNormalizer.canonical(booking.phone);
      final key = phone.isEmpty ? 'booking:${booking.id}' : 'phone:$phone';
      grouped.putIfAbsent(key, () => []).add(booking);
    }

    final summaries = grouped.entries.map((entry) {
      final values = entry.value
        ..sort((a, b) => b.checkin.compareTo(a.checkin));
      return CustomerSummary(
        key: entry.key,
        normalizedPhone: entry.key.startsWith('phone:')
            ? entry.key.substring(6)
            : '',
        bookings: values,
      );
    }).toList()..sort((a, b) => b.lastVisit.compareTo(a.lastVisit));
    return summaries;
  }

  static bool matches(CustomerSummary customer, String query) {
    final text = query.trim().toLowerCase();
    if (text.isEmpty) return true;
    final queryDigits = PhoneNormalizer.digitsOnly(text);
    return customer.bookings.any((booking) {
      final haystack = [
        booking.guest,
        booking.phone,
        booking.id,
        booking.serialNumber,
        booking.otherOccupants,
      ].join(' ').toLowerCase();
      if (haystack.contains(text)) return true;
      if (queryDigits.isEmpty) return false;
      return PhoneNormalizer.canonical(booking.phone).contains(queryDigits);
    });
  }

  static bool hasBookingInPeriod(
    CustomerSummary customer, {
    int? year,
    int? month,
  }) => customer.bookings.any(
    (booking) =>
        (year == null || booking.checkin.year == year) &&
        (month == null || booking.checkin.month == month),
  );
}
