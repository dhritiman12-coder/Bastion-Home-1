import '../database/database_helper.dart';

/// Generates monthly serial numbers in format: [N]/[MM-YYYY]
/// Resets to 1 on the first day of each new month.
class BookingSerialService {
  final DatabaseHelper _db = DatabaseHelper();

  /// Previews the next available serial without consuming it.
  Future<String> previewNextSerial(DateTime date) =>
      _db.nextAvailableBookingSerial(date);

  /// Returns the number of saved bookings carrying a serial for the month.
  Future<int> getCurrentCount(DateTime date) async {
    final monthKey = _monthKey(date);
    final rows = await _db.rawQuery(
      "SELECT COUNT(*) AS count FROM bookings WHERE serialNumber LIKE ? AND serialNumber != ''",
      ['%/$monthKey'],
    );
    return (rows.first['count'] as num?)?.toInt() ?? 0;
  }

  /// Returns all monthly serial logs as a list of {month, count} maps
  Future<List<Map<String, dynamic>>> getAllMonthlyLogs() async {
    final rows = await _db.rawQuery('''
      SELECT SUBSTR(serialNumber, INSTR(serialNumber, '/') + 1) AS month,
             COUNT(*) AS count
      FROM bookings
      WHERE serialNumber != '' AND INSTR(serialNumber, '/') > 0
      GROUP BY month
      ORDER BY SUBSTR(month, 4, 4) DESC, SUBSTR(month, 1, 2) DESC
      ''');
    return rows
        .map(
          (row) => {
            'month': row['month']?.toString() ?? '',
            'count': (row['count'] as num?)?.toInt() ?? 0,
          },
        )
        .where((row) => (row['month'] as String).isNotEmpty)
        .toList();
  }

  String _monthKey(DateTime date) {
    final mm = date.month.toString().padLeft(2, '0');
    return '$mm-${date.year}';
  }
}
