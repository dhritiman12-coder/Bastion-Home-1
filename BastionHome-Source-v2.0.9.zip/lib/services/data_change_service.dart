import 'package:flutter/foundation.dart';

class DataChangeService extends ChangeNotifier {
  static final DataChangeService _instance = DataChangeService._internal();
  factory DataChangeService() => _instance;
  DataChangeService._internal();

  int _revision = 0;
  int get revision => _revision;

  void markChanged() {
    _revision++;
    notifyListeners();
  }
}
