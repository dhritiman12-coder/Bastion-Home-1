import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

import '../database/repositories/expense_repository.dart';
import '../database/repositories/booking_repository.dart';
import '../database/repositories/inventory_repository.dart';
import '../models/booking_model.dart';
import '../utils/currency_formatter.dart';
import 'app_settings_service.dart';

/// NotificationService handles all local notification scheduling for:
/// - Yearly expense renewals (Trade License, FSSAI, Insurance, etc.) with reminder=Yes
/// - Monthly recurring expense due-days
class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  bool _initialized = false;

  // Notification channel IDs
  static const String _yearlyChannelId = 'bastion_yearly_renewals';
  static const String _yearlyChannelName = 'Yearly Renewals';
  static const String _yearlyChannelDesc =
      'Reminders for yearly license and insurance renewals';

  static const String _monthlyChannelId = 'bastion_monthly_dues';
  static const String _monthlyChannelName = 'Monthly Due Payments';
  static const String _monthlyChannelDesc =
      'Reminders for monthly recurring expense due-days';

  static const String _backupChannelId = 'bastion_weekly_backup';
  static const String _backupChannelName = 'Weekly Backup';
  static const String _backupChannelDesc =
      'Weekly reminder to export a local Bastion Home backup';

  static const String _bookingChannelId = 'bastion_booking_reminders';
  static const String _bookingChannelName = 'Booking Reminders';
  static const String _bookingChannelDesc =
      'Reminders for upcoming guest check-ins';

  static const String _stockChannelId = 'bastion_stock_alerts';
  static const String _stockChannelName = 'Low Stock Alerts';
  static const String _stockChannelDesc =
      'Daily alerts when operating supplies need replenishment';

  static const String _securityChannelId = 'bastion_security_alerts';
  static const String _securityChannelName = 'Security Alerts';
  static const String _securityChannelDesc =
      'Alerts for denied or suspicious account activity';

  // ID ranges to avoid collisions
  // Yearly: 10000 + expense db id
  // Monthly: 20000 + expense db id
  static const int _yearlyIdBase = 10000;
  static const int _monthlyIdBase = 20000;
  static const int _backupReminderId = 30000;
  static const int _bookingIdBase = 40000;
  static const int _stockReminderId = 50000;

  /// Initialize the notification plugin. Call once at app startup.
  Future<void> initialize() async {
    if (_initialized) return;

    // Initialize timezone data
    tz.initializeTimeZones();
    // Default to India timezone
    try {
      tz.setLocalLocation(tz.getLocation('Asia/Kolkata'));
    } catch (_) {
      // Fallback to UTC if timezone not found
    }

    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const DarwinInitializationSettings iosSettings =
        DarwinInitializationSettings(
          requestAlertPermission: true,
          requestBadgePermission: true,
          requestSoundPermission: true,
        );

    const InitializationSettings initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _plugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _onNotificationTapped,
    );

    // Request Android 13+ notification permission
    if (!kIsWeb) {
      final androidPlugin = _plugin
          .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin
          >();
      await androidPlugin?.requestNotificationsPermission();
    }

    _initialized = true;
  }

  void _onNotificationTapped(NotificationResponse response) {
    // Notification tapped — no navigation needed for now
  }

  Future<void> showSecurityAlert({
    required String title,
    required String body,
  }) async {
    if (kIsWeb) return;
    await initialize();
    await _plugin.show(
      DateTime.now().millisecondsSinceEpoch.remainder(1000000000),
      title,
      body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          _securityChannelId,
          _securityChannelName,
          channelDescription: _securityChannelDesc,
          importance: Importance.max,
          priority: Priority.high,
          icon: '@mipmap/ic_launcher',
          enableVibration: true,
          playSound: true,
        ),
        iOS: DarwinNotificationDetails(
          presentAlert: true,
          presentBadge: true,
          presentSound: true,
        ),
      ),
      payload: 'security_alert',
    );
  }

  /// Schedule all notifications from the database.
  /// Call this at startup and whenever expenses are added/updated/deleted.
  Future<void> scheduleAllNotifications() async {
    if (kIsWeb) return;
    await initialize();

    final expenseRepo = ExpenseRepository();
    final settings = AppSettingsService();

    // Cancel all existing scheduled notifications before rescheduling
    await _plugin.cancelAll();

    if (settings.expenseReminders) {
      final yearlyExpenses = await expenseRepo.getAllYearlyExpenses();
      for (final expense in yearlyExpenses) {
        if (expense.reminder == 'Yes' && expense.renewal.isNotEmpty) {
          await _scheduleYearlyRenewalNotification(expense);
        }
      }

      final monthlyExpenses = await expenseRepo.getAllMonthlyExpenses();
      for (final expense in monthlyExpenses) {
        if (expense.dueDay >= 1 && expense.dueDay <= 31) {
          await _scheduleMonthlyDueNotification(expense);
        }
      }
    }

    if (settings.bookingReminders) await _scheduleBookingReminders();
    if (settings.lowStockAlerts) await _scheduleLowStockReminder();
    if (settings.weeklyBackupReminder) await _scheduleWeeklyBackupReminder();
  }

  Future<void> _scheduleBookingReminders() async {
    final bookings = await BookingRepository().getAllBookings();
    final now = DateTime.now();
    for (final booking in bookings) {
      if (booking.status != BookingStatus.booked ||
          booking.checkin.isBefore(now)) {
        continue;
      }
      var reminder = DateTime(
        booking.checkin.year,
        booking.checkin.month,
        booking.checkin.day - 1,
        18,
      );
      if (!reminder.isAfter(now)) {
        reminder = DateTime(
          booking.checkin.year,
          booking.checkin.month,
          booking.checkin.day,
          8,
        );
      }
      if (!reminder.isAfter(now)) continue;
      final stableId = booking.id.codeUnits.fold<int>(
        0,
        (sum, unit) => sum + unit,
      );
      await _scheduleNotification(
        id: _bookingIdBase + stableId,
        title: 'Upcoming Check-in',
        body:
            '${booking.guest} is expected in ${booking.roomLabel} on ${_formatDate(booking.checkin)}.',
        scheduledDate: reminder,
        channelId: _bookingChannelId,
        channelName: _bookingChannelName,
        channelDesc: _bookingChannelDesc,
      );
    }
  }

  Future<void> _scheduleLowStockReminder() async {
    final low = await InventoryRepository().getLowStockItems();
    if (low.isEmpty) return;
    final now = DateTime.now();
    final next = DateTime(now.year, now.month, now.day + 1, 9);
    await _scheduleNotification(
      id: _stockReminderId,
      title: 'Stock Replenishment Needed',
      body:
          '${low.length} stock item${low.length == 1 ? '' : 's'} have reached their reorder level.',
      scheduledDate: next,
      channelId: _stockChannelId,
      channelName: _stockChannelName,
      channelDesc: _stockChannelDesc,
    );
  }

  /// Schedule a yearly renewal notification for an expense.
  /// Fires 7 days before renewal date AND on the renewal date itself.
  Future<void> _scheduleYearlyRenewalNotification(YearlyExpense expense) async {
    if (expense.id == null) return;

    DateTime? renewalDate;
    try {
      renewalDate = DateTime.parse(expense.renewal);
    } catch (_) {
      return; // Invalid date, skip
    }

    final now = DateTime.now();

    // Find the next upcoming renewal (this year or next year)
    DateTime nextRenewal = DateTime(
      now.year,
      renewalDate.month,
      renewalDate.day,
    );
    if (nextRenewal.isBefore(now)) {
      nextRenewal = DateTime(now.year + 1, renewalDate.month, renewalDate.day);
    }

    // 7-day advance reminder
    final reminderDate = nextRenewal.subtract(const Duration(days: 7));
    if (reminderDate.isAfter(now)) {
      await _scheduleNotification(
        id: _yearlyIdBase + expense.id! * 2,
        title: 'Renewal Due in 7 Days',
        body:
            '${expense.head} renewal is due on ${_formatDate(nextRenewal)}. Amount: ${CurrencyFormatter.format(expense.amount)}',
        scheduledDate: reminderDate,
        channelId: _yearlyChannelId,
        channelName: _yearlyChannelName,
        channelDesc: _yearlyChannelDesc,
      );
    }

    // On-day reminder
    final onDayDate = DateTime(
      nextRenewal.year,
      nextRenewal.month,
      nextRenewal.day,
      9,
      0,
    );
    if (onDayDate.isAfter(now)) {
      await _scheduleNotification(
        id: _yearlyIdBase + expense.id! * 2 + 1,
        title: 'Renewal Due Today',
        body:
            '${expense.head} renewal is due today! Amount: ${CurrencyFormatter.format(expense.amount)}. Authority: ${expense.authority.isNotEmpty ? expense.authority : "N/A"}',
        scheduledDate: onDayDate,
        channelId: _yearlyChannelId,
        channelName: _yearlyChannelName,
        channelDesc: _yearlyChannelDesc,
      );
    }
  }

  /// Schedule a monthly recurring due-day notification.
  /// Fires on the due day of the current month (and next month if already past).
  Future<void> _scheduleMonthlyDueNotification(MonthlyExpense expense) async {
    if (expense.id == null) return;

    final now = DateTime.now();

    // Calculate next due date
    DateTime nextDue = _nextDueDate(now, expense.dueDay);

    // Schedule notification at 9 AM on due day
    final scheduledDate = DateTime(
      nextDue.year,
      nextDue.month,
      nextDue.day,
      9,
      0,
    );

    if (scheduledDate.isAfter(now)) {
      await _scheduleNotification(
        id: _monthlyIdBase + expense.id!,
        title: 'Monthly Payment Due',
        body:
            '${expense.head} payment is due today! Amount: ${CurrencyFormatter.format(expense.amount)}${expense.payee.isNotEmpty ? " — ${expense.payee}" : ""}',
        scheduledDate: scheduledDate,
        channelId: _monthlyChannelId,
        channelName: _monthlyChannelName,
        channelDesc: _monthlyChannelDesc,
      );
    }
  }

  Future<void> _scheduleWeeklyBackupReminder() async {
    final now = tz.TZDateTime.now(tz.local);
    var next = tz.TZDateTime(tz.local, now.year, now.month, now.day, 18);
    while (next.weekday != DateTime.sunday || !next.isAfter(now)) {
      next = next.add(const Duration(days: 1));
    }

    await _plugin.zonedSchedule(
      _backupReminderId,
      'Back Up Bastion Home',
      'Export this week\'s JSON backup and keep it in protected storage.',
      next,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          _backupChannelId,
          _backupChannelName,
          channelDescription: _backupChannelDesc,
          importance: Importance.defaultImportance,
          priority: Priority.defaultPriority,
        ),
        iOS: DarwinNotificationDetails(),
      ),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  /// Returns the next occurrence of [dueDay] from [from].
  DateTime _nextDueDate(DateTime from, int dueDay) {
    // Try this month
    final daysInMonth = DateTime(from.year, from.month + 1, 0).day;
    final clampedDay = dueDay.clamp(1, daysInMonth);
    final thisMonth = DateTime(from.year, from.month, clampedDay);

    if (thisMonth.isAfter(from)) {
      return thisMonth;
    }

    // Next month
    final nextMonth = from.month == 12 ? 1 : from.month + 1;
    final nextYear = from.month == 12 ? from.year + 1 : from.year;
    final daysInNextMonth = DateTime(nextYear, nextMonth + 1, 0).day;
    final clampedNextDay = dueDay.clamp(1, daysInNextMonth);
    return DateTime(nextYear, nextMonth, clampedNextDay);
  }

  /// Core method to schedule a single notification using zonedSchedule.
  Future<void> _scheduleNotification({
    required int id,
    required String title,
    required String body,
    required DateTime scheduledDate,
    required String channelId,
    required String channelName,
    required String channelDesc,
  }) async {
    try {
      final tzDate = tz.TZDateTime.from(scheduledDate, tz.local);

      await _plugin.zonedSchedule(
        id,
        title,
        body,
        tzDate,
        NotificationDetails(
          android: AndroidNotificationDetails(
            channelId,
            channelName,
            channelDescription: channelDesc,
            importance: Importance.high,
            priority: Priority.high,
            icon: '@mipmap/ic_launcher',
            enableVibration: true,
            playSound: true,
          ),
          iOS: const DarwinNotificationDetails(
            presentAlert: true,
            presentBadge: true,
            presentSound: true,
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        payload: '$channelId:$id',
      );
    } catch (e) {
      debugPrint(
        'NotificationService: Failed to schedule notification $id: $e',
      );
    }
  }

  /// Cancel all notifications for a specific yearly expense.
  Future<void> cancelYearlyNotifications(int expenseId) async {
    if (kIsWeb) return;
    await _plugin.cancel(_yearlyIdBase + expenseId * 2);
    await _plugin.cancel(_yearlyIdBase + expenseId * 2 + 1);
  }

  /// Cancel notification for a specific monthly expense.
  Future<void> cancelMonthlyNotification(int expenseId) async {
    if (kIsWeb) return;
    await _plugin.cancel(_monthlyIdBase + expenseId);
  }

  /// Cancel all scheduled notifications.
  Future<void> cancelAll() async {
    if (kIsWeb) return;
    await _plugin.cancelAll();
  }

  String _formatDate(DateTime date) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return '${date.day.toString().padLeft(2, '0')}-${months[date.month - 1]}-${date.year}';
  }
}
