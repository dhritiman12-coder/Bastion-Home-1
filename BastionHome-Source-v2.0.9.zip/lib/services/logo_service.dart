import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LogoService extends ChangeNotifier {
  static const String _logoPathKey = 'logo_file_path';
  static const String _guestHouseNameKey = 'guest_house_name';
  static const String _guestHouseAddressKey = 'guest_house_address';
  static const String _gstNumberKey = 'gst_number';
  static const String _gstPercentKey = 'gst_percent';

  static final LogoService _instance = LogoService._internal();
  factory LogoService() => _instance;
  LogoService._internal();

  // In-memory cache for web (stores base64 data URL)
  String? _webLogoDataUrl;

  Future<String?> getLogoPath() async {
    if (kIsWeb) return _webLogoDataUrl;
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_logoPathKey);
  }

  Future<void> setLogoPath(String path) async {
    if (!_isSafeLogoDataUrl(path)) {
      throw const FormatException('Invalid or oversized logo image');
    }
    if (kIsWeb) {
      _webLogoDataUrl = path;
      notifyListeners();
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_logoPathKey, path);
    notifyListeners();
  }

  Future<void> clearLogo() async {
    if (kIsWeb) {
      _webLogoDataUrl = null;
      notifyListeners();
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_logoPathKey);
    notifyListeners();
  }

  Future<String> getGuestHouseName() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_guestHouseNameKey) ?? 'Bastion Home Guest House';
  }

  Future<void> setGuestHouseName(String name) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _guestHouseNameKey,
      name.length <= 200 ? name : name.substring(0, 200),
    );
    notifyListeners();
  }

  Future<String> getGuestHouseAddress() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_guestHouseAddressKey) ?? '';
  }

  Future<void> setGuestHouseAddress(String address) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _guestHouseAddressKey,
      address.length <= 1000 ? address : address.substring(0, 1000),
    );
    notifyListeners();
  }

  Future<String> getGstNumber() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_gstNumberKey) ?? '';
  }

  Future<void> setGstNumber(String gst) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _gstNumberKey,
      gst.length <= 100 ? gst : gst.substring(0, 100),
    );
    notifyListeners();
  }

  Future<double> getGstPercent() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getDouble(_gstPercentKey) ?? 0.0;
  }

  Future<void> setGstPercent(double percent) async {
    final prefs = await SharedPreferences.getInstance();
    final safePercent = percent.isFinite
        ? percent.clamp(0, 100).toDouble()
        : 0.0;
    await prefs.setDouble(_gstPercentKey, safePercent);
    notifyListeners();
  }

  Future<Map<String, dynamic>> getAllSettings() async {
    return {
      'logoPath': await getLogoPath(),
      'guestHouseName': await getGuestHouseName(),
      'guestHouseAddress': await getGuestHouseAddress(),
      'gstNumber': await getGstNumber(),
      'gstPercent': await getGstPercent(),
    };
  }

  Future<void> restoreSettings(Map<String, dynamic> settings) async {
    final logoPath = settings['logoPath'];
    if (logoPath is String && _isSafeLogoDataUrl(logoPath)) {
      await setLogoPath(logoPath);
    } else {
      await clearLogo();
    }
    await setGuestHouseName(
      _safeText(
        settings['guestHouseName'],
        fallback: 'Bastion Home Guest House',
        maxLength: 200,
      ),
    );
    await setGuestHouseAddress(
      _safeText(settings['guestHouseAddress'], maxLength: 1000),
    );
    await setGstNumber(_safeText(settings['gstNumber'], maxLength: 100));
    final gst = settings['gstPercent'];
    await setGstPercent(
      gst is num && gst.isFinite ? gst.toDouble().clamp(0, 100) : 0,
    );
  }

  String _safeText(
    Object? value, {
    String fallback = '',
    required int maxLength,
  }) {
    if (value is! String) return fallback;
    return value.length <= maxLength ? value : value.substring(0, maxLength);
  }

  bool _isSafeLogoDataUrl(String value) {
    if (value.length > 7 * 1024 * 1024) return false;
    final separator = value.indexOf(',');
    if (separator < 0) return false;
    final header = value.substring(0, separator).toLowerCase();
    if (!const {
      'data:image/png;base64',
      'data:image/jpeg;base64',
      'data:image/jpg;base64',
      'data:image/webp;base64',
    }.contains(header)) {
      return false;
    }
    try {
      final bytes = base64Decode(value.substring(separator + 1));
      return bytes.isNotEmpty && bytes.length <= 5 * 1024 * 1024;
    } on FormatException {
      return false;
    }
  }
}
