import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:cryptography/cryptography.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../database/database_helper.dart';
import '../models/app_user.dart';
import 'cloud_sync_service.dart';

/// Outcome of a username + password/PIN sign-in attempt.
class SignInResult {
  final AppUser? user;
  final String? message;
  final bool needsPasswordChange;
  const SignInResult._({
    this.user,
    this.message,
    this.needsPasswordChange = false,
  });
  const SignInResult.success(AppUser user) : this._(user: user);
  const SignInResult.failure(String message) : this._(message: message);
  const SignInResult.passwordChange() : this._(needsPasswordChange: true);
  bool get ok => user != null;
}

class AccountService extends ChangeNotifier {
  static final AccountService _instance = AccountService._internal();
  factory AccountService() => _instance;
  AccountService._internal();

  static const _lastUsernameKey = 'last_signed_in_username';
  static const _maxFailedAttempts = 5;
  static const _lockoutDuration = Duration(minutes: 5);
  static const defaultEmployeePermissions = employeeCorePermissions;

  final DatabaseHelper _db = DatabaseHelper();
  final Pbkdf2 _hasher = Pbkdf2(
    macAlgorithm: Hmac.sha256(),
    iterations: 120000,
    bits: 256,
  );

  AppUser? _currentUser;
  List<AppUser> _users = const [];
  bool _initialized = false;

  AppUser? get currentUser => _currentUser;
  List<AppUser> get users => List.unmodifiable(_users);
  List<AppUser> get loginUsers {
    final result = _users.where((user) => user.active).toList();
    int priority(AppUser user) => switch (user.role) {
      UserRole.primaryAdmin => 0,
      UserRole.administrator => 1,
      UserRole.employee => 2,
      UserRole.backupAdmin => 3,
    };
    result.sort((a, b) {
      final roleOrder = priority(a).compareTo(priority(b));
      return roleOrder != 0
          ? roleOrder
          : a.displayName.toLowerCase().compareTo(b.displayName.toLowerCase());
    });
    return List.unmodifiable(result);
  }

  bool get isInitialized => _initialized;
  bool get needsSetup => _initialized && _users.isEmpty;
  bool get isAdmin {
    final user = _currentUser;
    if (user == null) return false;
    final cloud = CloudSyncService();
    if (!cloud.hasCloudAuthority) return user.role.isAdmin;
    return cloud.hasActiveCloudAuthority &&
        cloud.isCloudAdmin &&
        _roleMatchesCloudAuthority(user.role, cloud.cloudRole);
  }

  bool can(AppPermission permission) {
    final user = _currentUser;
    if (user == null) return false;
    final cloud = CloudSyncService();
    if (!cloud.hasCloudAuthority) return user.can(permission);
    if (!cloud.hasActiveCloudAuthority ||
        !_roleMatchesCloudAuthority(user.role, cloud.cloudRole)) {
      return false;
    }
    if (cloud.isCloudAdmin) return true;
    return cloud.hasEmployeePermission(permission.name);
  }

  bool get isEmployee =>
      _currentUser != null &&
      !isAdmin &&
      _roleMatchesCloudAuthority(
        _currentUser!.role,
        CloudSyncService().cloudRole,
      );
  String get currentAuditLabel =>
      _currentUser == null ? '' : auditLabelFor(_currentUser!);

  static String auditLabelFor(AppUser user) =>
      '${user.displayName} (@${user.username})';

  static bool activityBelongsTo(String value, AppUser user) {
    final normalized = value.trim().toLowerCase();
    return normalized == user.displayName.trim().toLowerCase() ||
        normalized == user.username.trim().toLowerCase() ||
        normalized == auditLabelFor(user).toLowerCase() ||
        normalized.contains('@${user.username.toLowerCase()}');
  }

  Future<void> initialize() async {
    if (_initialized) return;
    await refreshUsers();
    _initialized = true;
    notifyListeners();
  }

  Future<void> refreshUsers() async {
    var rows = await _db.query(
      'app_users',
      orderBy: 'role ASC, displayName ASC',
    );
    if (await _repairProtectedAdminAccounts(rows)) {
      rows = await _db.query('app_users', orderBy: 'role ASC, displayName ASC');
    }
    _users = rows.map(AppUser.fromMap).toList();
    if (_currentUser != null) {
      final matches = _users.where(
        (user) => user.username == _currentUser!.username && user.active,
      );
      _currentUser = matches.isEmpty ? null : matches.first;
    }
    notifyListeners();
  }

  Future<bool> _repairProtectedAdminAccounts(
    List<Map<String, dynamic>> rows,
  ) async {
    var repaired = false;
    for (final row in rows) {
      final username = (row['username'] as String? ?? '').toLowerCase();
      final expectedRole = switch (username) {
        'admin' => UserRole.primaryAdmin,
        'backup-admin' => UserRole.backupAdmin,
        _ => null,
      };
      if (expectedRole == null) continue;
      if (row['role'] == expectedRole.name &&
          (row['active'] as int? ?? 1) == 1) {
        continue;
      }
      await _db.update(
        'app_users',
        {'role': expectedRole.name, 'active': 1},
        where: 'id = ?',
        whereArgs: [row['id']],
      );
      repaired = true;
    }
    return repaired;
  }

  Future<String?> getLastUsername() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_lastUsernameKey);
  }

  Future<void> createInitialAdmins({
    required String primaryName,
    required String primaryPin,
    required String backupName,
    required String backupPin,
  }) async {
    if (_users.isNotEmpty) throw StateError('Accounts are already configured');
    if (primaryName.trim().isEmpty || backupName.trim().isEmpty) {
      throw ArgumentError('Both administrator names are required');
    }
    _validatePin(primaryPin);
    _validatePin(backupPin);
    if (primaryPin == backupPin) {
      throw ArgumentError(
        'Use different PINs for the two administrator accounts',
      );
    }

    final primary = await _newUser(
      username: 'admin',
      displayName: primaryName.trim(),
      role: UserRole.primaryAdmin,
      pin: primaryPin,
      permissions: AppPermission.values.toSet(),
    );
    final backup = await _newUser(
      username: 'backup-admin',
      displayName: backupName.trim(),
      role: UserRole.backupAdmin,
      pin: backupPin,
      permissions: AppPermission.values.toSet(),
    );

    final db = await _db.database;
    await db.transaction((txn) async {
      await txn.insert('app_users', primary.toMap());
      await txn.insert('app_users', backup.toMap());
    });
    await refreshUsers();
  }

  Future<void> createCloudEnrolledAccount({
    required String username,
    required String displayName,
    required String pin,
  }) async {
    final cloud = CloudSyncService();
    if (!cloud.hasActiveCloudAuthority ||
        cloud.isRevoked ||
        cloud.cloudRole == null) {
      throw StateError('Approved cloud workspace access is required');
    }
    final role = roleForCloudAuthority(cloud.cloudRole!);
    if (role == null) throw StateError('This cloud role is not supported');
    _validatePin(pin);
    final fixedUsername = switch (role) {
      UserRole.primaryAdmin => 'admin',
      UserRole.backupAdmin => cloud.sessionUsername ?? 'backup-admin',
      _ => cloud.sessionUsername ?? username.trim().toLowerCase(),
    };
    await _upsertCloudAccount(
      username: fixedUsername,
      displayName: displayName,
      secret: pin,
      role: role,
    );
  }

  Future<void> _upsertCloudAccount({
    required String username,
    required String displayName,
    required String secret,
    required UserRole role,
  }) async {
    final cloud = CloudSyncService();
    final fixedUsername = username.trim().toLowerCase();
    if (!RegExp(r'^[a-z0-9._-]{3,40}$').hasMatch(fixedUsername)) {
      throw ArgumentError(
        'Username must be 3 to 40 letters, numbers, dots, dashes, or underscores',
      );
    }
    if (displayName.trim().length < 2) {
      throw ArgumentError('Display name is required');
    }
    final permissions = role.isAdmin
        ? AppPermission.values.toSet()
        : (AppPermission.values
              .where((item) => cloud.cloudPermissions.contains(item.name))
              .toSet()
            ..addAll(employeeCorePermissions));
    final existing = _users.where(
      (user) => user.username.toLowerCase() == fixedUsername,
    );
    if (existing.isEmpty) {
      final user = await _newUser(
        username: fixedUsername,
        displayName: displayName.trim(),
        role: role,
        pin: secret,
        permissions: permissions,
      );
      await _db.insert('app_users', user.toMap());
    } else {
      final current = existing.first;
      final credentials = await _credentials(secret);
      final updated = current.copyWith(
        displayName: displayName.trim(),
        role: role,
        pinSalt: credentials.$1,
        pinHash: credentials.$2,
        permissions: permissions,
        active: true,
      );
      await _db.update(
        'app_users',
        updated.toMap()..remove('id'),
        where: 'id = ?',
        whereArgs: [current.id],
      );
    }
    await refreshUsers();
  }

  /// Signs in with a username and either the account's cloud password or the
  /// PIN this phone already holds for it. Any approved account can sign in on
  /// any phone: if the phone is attached to a different cloud account (or has
  /// never seen this one), the cloud password is verified online, the phone
  /// switches to that account's authority, and a local record is created so
  /// the same secret also works offline from then on.
  Future<SignInResult> signIn(String username, String secret) async {
    await refreshUsers();
    final identifier = username.trim().toLowerCase();
    if (identifier.isEmpty || secret.isEmpty) {
      return const SignInResult.failure(
        'Enter your username and password or PIN.',
      );
    }
    final prefs = await SharedPreferences.getInstance();
    final lockKey = 'account_lock_until_$identifier';
    final failureKey = 'account_failed_attempts_$identifier';
    final lockedUntil = prefs.getInt(lockKey);
    final nowMs = DateTime.now().millisecondsSinceEpoch;
    if (lockedUntil != null && lockedUntil > nowMs) {
      final minutes = ((lockedUntil - nowMs) / 60000).ceil();
      return SignInResult.failure(
        'Too many incorrect attempts. Try again in $minutes minute(s).',
      );
    }
    if (lockedUntil != null) {
      await prefs.remove(lockKey);
      await prefs.remove(failureKey);
    }

    final cloud = CloudSyncService();
    // Fast path: this phone is already attached to this account, so the PIN
    // (or the password remembered from the last online sign-in) works offline.
    if (cloud.hasActiveCloudAuthority && cloud.isSessionFor(identifier)) {
      final matches = _users.where(
        (user) => user.username.toLowerCase() == identifier && user.active,
      );
      if (matches.isNotEmpty) {
        final user = matches.first;
        if (_isAuthorizedByCloud(user) &&
            await _hashPin(secret, user.pinSalt) == user.pinHash) {
          return SignInResult.success(await _completeLogin(user, prefs));
        }
      }
    }

    // Otherwise verify the cloud account itself.
    try {
      await cloud.signIn(identifier: identifier, password: secret);
    } on CloudCredentialException {
      await _recordFailedAttempt(prefs, identifier);
      return const SignInResult.failure(
        'Incorrect username, password or PIN.',
      );
    } catch (error) {
      return SignInResult.failure(_signInErrorMessage(error));
    }
    if (cloud.mustChangeCloudPassword) {
      return const SignInResult.passwordChange();
    }
    try {
      final user = await _provisionFromCloud(
        secret: secret,
        requestedUsername: identifier,
      );
      return SignInResult.success(await _completeLogin(user, prefs));
    } catch (error) {
      return SignInResult.failure(_signInErrorMessage(error));
    }
  }

  Future<AppUser> _provisionFromCloud({
    required String secret,
    required String requestedUsername,
  }) async {
    final cloud = CloudSyncService();
    final role = roleForCloudAuthority(cloud.cloudRole);
    if (role == null) throw StateError('This cloud role is not supported');
    final username = cloud.sessionUsername ?? requestedUsername;
    final name = cloud.memberDisplayName?.trim() ?? '';
    await _upsertCloudAccount(
      username: username,
      displayName: name.length >= 2 ? name : username,
      secret: secret,
      role: role,
    );
    return _users.firstWhere(
      (user) => user.username.toLowerCase() == username.toLowerCase(),
    );
  }

  Future<AppUser> _completeLogin(AppUser user, SharedPreferences prefs) async {
    final normalized = user.username.toLowerCase();
    await prefs.remove('account_failed_attempts_$normalized');
    await prefs.remove('account_lock_until_$normalized');
    final now = DateTime.now().toIso8601String();
    await _db.update(
      'app_users',
      {'lastLoginAt': now},
      where: 'id = ?',
      whereArgs: [user.id],
    );
    _currentUser = user.copyWith(lastLoginAt: now);
    await prefs.setString(_lastUsernameKey, user.username);
    notifyListeners();
    return _currentUser!;
  }

  Future<void> _recordFailedAttempt(
    SharedPreferences prefs,
    String identifier,
  ) async {
    final lockKey = 'account_lock_until_$identifier';
    final failureKey = 'account_failed_attempts_$identifier';
    final failures = (prefs.getInt(failureKey) ?? 0) + 1;
    if (failures >= _maxFailedAttempts) {
      await prefs.setInt(
        lockKey,
        DateTime.now().add(_lockoutDuration).millisecondsSinceEpoch,
      );
      await prefs.remove(failureKey);
      unawaited(
        CloudSyncService().reportSecurityEvent(
          'failed_pin_lockout',
          resource: 'app_sign_in',
          attemptedAction: 'five_failed_sign_in_attempts',
        ),
      );
    } else {
      await prefs.setInt(failureKey, failures);
    }
  }

  String _signInErrorMessage(Object error) {
    final text = error.toString();
    if (text.contains('SocketException') ||
        text.contains('ClientException') ||
        text.contains('Failed host lookup') ||
        text.contains('XMLHttpRequest') ||
        text.contains('Connection') ||
        text.contains('timed out')) {
      return 'Could not reach Bastion Home Cloud. Connect to the internet to sign in on this phone with this account.';
    }
    return text
        .replaceFirst('Invalid argument(s): ', '')
        .replaceFirst('Bad state: ', '')
        .replaceFirst('Exception: ', '');
  }

  Future<AppUser?> authenticate(String username, String pin) async {
    // Account changes may have been made since the lock screen was created.
    await refreshUsers();
    final normalized = username.trim().toLowerCase();
    final prefs = await SharedPreferences.getInstance();
    final lockKey = 'account_lock_until_$normalized';
    final failureKey = 'account_failed_attempts_$normalized';
    final lockedUntil = prefs.getInt(lockKey);
    final nowMs = DateTime.now().millisecondsSinceEpoch;
    if (lockedUntil != null && lockedUntil > nowMs) return null;
    if (lockedUntil != null) {
      await prefs.remove(lockKey);
      await prefs.remove(failureKey);
    }
    final matches = _users.where(
      (user) => user.username.toLowerCase() == normalized && user.active,
    );
    if (matches.isEmpty) return null;
    final user = matches.first;
    if (!_isAuthorizedByCloud(user)) {
      unawaited(
        CloudSyncService().reportSecurityEvent(
          'role_mismatch',
          resource: 'local_account',
          attemptedAction: 'sign_in_as_${user.role.name}',
        ),
      );
      return null;
    }
    final hash = await _hashPin(pin, user.pinSalt);
    if (hash != user.pinHash) {
      final failures = (prefs.getInt(failureKey) ?? 0) + 1;
      if (failures >= _maxFailedAttempts) {
        await prefs.setInt(
          lockKey,
          DateTime.now().add(_lockoutDuration).millisecondsSinceEpoch,
        );
        await prefs.remove(failureKey);
        unawaited(
          CloudSyncService().reportSecurityEvent(
            'failed_pin_lockout',
            resource: 'app_sign_in',
            attemptedAction: 'five_failed_pin_attempts',
          ),
        );
      } else {
        await prefs.setInt(failureKey, failures);
      }
      return null;
    }

    await prefs.remove(failureKey);
    await prefs.remove(lockKey);

    final now = DateTime.now().toIso8601String();
    await _db.update(
      'app_users',
      {'lastLoginAt': now},
      where: 'id = ?',
      whereArgs: [user.id],
    );
    _currentUser = user.copyWith(lastLoginAt: now);
    await prefs.setString(_lastUsernameKey, user.username);
    notifyListeners();
    return _currentUser;
  }

  Future<bool> resumeLastUserAfterDeviceAuth() async {
    final username = await getLastUsername();
    if (username == null) return false;
    final matches = _users.where(
      (user) => user.username == username && user.active,
    );
    if (matches.isEmpty) return false;
    if (!_isAuthorizedByCloud(matches.first)) return false;
    _currentUser = matches.first;
    notifyListeners();
    return true;
  }

  void logout() {
    _currentUser = null;
    notifyListeners();
  }

  Future<void> addEmployee({
    required String username,
    required String displayName,
    required String pin,
    Set<AppPermission>? permissions,
  }) => addUser(
    username: username,
    displayName: displayName,
    pin: pin,
    role: UserRole.employee,
    permissions: permissions,
  );

  Future<void> addUser({
    required String username,
    required String displayName,
    required String pin,
    required UserRole role,
    Set<AppPermission>? permissions,
  }) async {
    _requireAdmin();
    if (CloudSyncService().hasCloudAuthority && role.isAdmin) {
      throw StateError(
        'Create administrator access from Cloud Sync so it is owner-authorized.',
      );
    }
    if (role == UserRole.primaryAdmin || role == UserRole.backupAdmin) {
      throw ArgumentError('Use Administrator for additional admin accounts');
    }
    if (role.isAdmin && _currentUser?.role != UserRole.primaryAdmin) {
      throw ArgumentError(
        'Only the primary administrator can create administrator accounts',
      );
    }
    _validatePin(pin);
    final normalized = username.trim().toLowerCase();
    if (normalized.isEmpty || displayName.trim().isEmpty) {
      throw ArgumentError('Name and username are required');
    }
    if (!RegExp(r'^[a-z0-9._-]{3,40}$').hasMatch(normalized)) {
      throw ArgumentError(
        'Username must be 3 to 40 letters, numbers, dots, dashes, or underscores',
      );
    }
    if (_users.any((user) => user.username.toLowerCase() == normalized)) {
      throw ArgumentError('That username is already in use');
    }
    final user = await _newUser(
      username: normalized,
      displayName: displayName.trim(),
      role: role,
      pin: pin,
      permissions: role.isAdmin
          ? AppPermission.values.toSet()
          : ({...permissions ?? const <AppPermission>{}}
              ..addAll(employeeCorePermissions)),
    );
    await _db.insert('app_users', user.toMap());
    await refreshUsers();
  }

  Future<void> updateEmployee({
    required AppUser user,
    required String displayName,
    required Set<AppPermission> permissions,
    required bool active,
    String? newPin,
  }) => updateManagedUser(
    user: user,
    displayName: displayName,
    role: UserRole.employee,
    permissions: permissions,
    active: active,
    newPin: newPin,
  );

  Future<void> updateManagedUser({
    required AppUser user,
    required String displayName,
    required UserRole role,
    required Set<AppPermission> permissions,
    required bool active,
    String? newPin,
  }) async {
    _requireAdmin();
    if (user.role == UserRole.primaryAdmin) {
      throw ArgumentError(
        'The primary administrator is protected. Change its PIN from Settings.',
      );
    }
    if (user.role.isAdmin && _currentUser?.role != UserRole.primaryAdmin) {
      throw ArgumentError(
        'Only the primary administrator can change administrator accounts',
      );
    }
    if (role.isAdmin && _currentUser?.role != UserRole.primaryAdmin) {
      throw ArgumentError(
        'Only the primary administrator can grant administrator access',
      );
    }
    if (displayName.trim().isEmpty) {
      throw ArgumentError('Display name is required');
    }
    if (user.role == UserRole.backupAdmin && !active) {
      throw ArgumentError('The backup administrator cannot be deactivated');
    }
    final effectiveRole = user.role == UserRole.backupAdmin
        ? UserRole.backupAdmin
        : role;
    var updated = user.copyWith(
      displayName: displayName.trim(),
      role: effectiveRole,
      permissions: effectiveRole.isAdmin
          ? AppPermission.values.toSet()
          : ({...permissions}..addAll(employeeCorePermissions)),
      active: active,
    );
    if (newPin != null && newPin.isNotEmpty) {
      _validatePin(newPin);
      final credentials = await _credentials(newPin);
      updated = updated.copyWith(
        pinSalt: credentials.$1,
        pinHash: credentials.$2,
      );
    }
    await _db.update(
      'app_users',
      updated.toMap()..remove('id'),
      where: 'id = ?',
      whereArgs: [user.id],
    );
    await refreshUsers();
  }

  Future<void> deleteEmployee(AppUser user) async {
    _requireAdmin();
    final id = user.id;
    if (id == null) throw StateError('This employee account cannot be deleted');
    final matches = _users.where((candidate) => candidate.id == id);
    if (matches.isEmpty) throw StateError('Employee account not found');
    if (matches.first.role != UserRole.employee) {
      throw ArgumentError('Only employee accounts can be deleted');
    }

    final deleted = await _db.deleteAppUser(id);
    if (deleted == 0) throw StateError('Employee account not found');

    final prefs = await SharedPreferences.getInstance();
    final normalized = user.username.toLowerCase();
    await prefs.remove('account_lock_until_$normalized');
    await prefs.remove('account_failed_attempts_$normalized');
    await refreshUsers();
  }

  Future<void> changeOwnPin(String currentPin, String newPin) async {
    final user = _currentUser;
    if (user == null) throw StateError('No account is signed in');
    if (await _hashPin(currentPin, user.pinSalt) != user.pinHash) {
      throw ArgumentError('The current PIN is incorrect');
    }
    _validatePin(newPin);
    final credentials = await _credentials(newPin);
    await _db.update(
      'app_users',
      {'pinSalt': credentials.$1, 'pinHash': credentials.$2},
      where: 'id = ?',
      whereArgs: [user.id],
    );
    _currentUser = user.copyWith(
      pinSalt: credentials.$1,
      pinHash: credentials.$2,
    );
    await refreshUsers();
  }

  Future<AppUser> _newUser({
    required String username,
    required String displayName,
    required UserRole role,
    required String pin,
    required Set<AppPermission> permissions,
  }) async {
    final credentials = await _credentials(pin);
    return AppUser(
      username: username,
      displayName: displayName,
      role: role,
      pinSalt: credentials.$1,
      pinHash: credentials.$2,
      permissions: permissions,
      createdAt: DateTime.now().toIso8601String(),
    );
  }

  Future<(String, String)> _credentials(String pin) async {
    final random = Random.secure();
    final saltBytes = List<int>.generate(16, (_) => random.nextInt(256));
    final salt = base64Encode(saltBytes);
    return (salt, await _hashPin(pin, salt));
  }

  Future<String> _hashPin(String pin, String salt) async {
    final key = await _hasher.deriveKey(
      secretKey: SecretKey(utf8.encode(pin)),
      nonce: base64Decode(salt),
    );
    return base64Encode(await key.extractBytes());
  }

  void _validatePin(String pin) {
    if (!RegExp(r'^\d{6,12}$').hasMatch(pin)) {
      throw ArgumentError('PIN must contain 6 to 12 digits');
    }
  }

  void _requireAdmin() {
    if (!isAdmin) {
      throw StateError('Administrator access is required');
    }
  }

  bool _isAuthorizedByCloud(AppUser user) {
    final cloud = CloudSyncService();
    if (!cloud.hasCloudAuthority) return true;
    return cloud.hasActiveCloudAuthority &&
        _roleMatchesCloudAuthority(user.role, cloud.cloudRole);
  }

  static bool _roleMatchesCloudAuthority(UserRole role, String? cloudRole) =>
      roleForCloudAuthority(cloudRole) == role;

  static UserRole? roleForCloudAuthority(String? cloudRole) =>
      switch (cloudRole) {
        'primary_admin' => UserRole.primaryAdmin,
        'backup_admin' => UserRole.backupAdmin,
        'admin' => UserRole.administrator,
        'employee' => UserRole.employee,
        _ => null,
      };

  @visibleForTesting
  void resetForTesting() {
    _currentUser = null;
    _users = const [];
    _initialized = false;
  }
}
