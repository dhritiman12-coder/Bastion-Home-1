class SyncPayloadValidator {
  static const int _maxFields = 40;
  static const int _maxTextLength = 20000;
  static final RegExp _syncIdPattern = RegExp(
    r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$',
  );

  static bool isValidSyncId(String value) => _syncIdPattern.hasMatch(value);

  static Map<String, dynamic>? validate(String table, Object? rawPayload) {
    if (rawPayload is! Map || rawPayload.length > _maxFields) return null;

    final payload = <String, dynamic>{};
    for (final entry in rawPayload.entries) {
      if (entry.key is! String) return null;
      final key = entry.key as String;
      final value = entry.value;
      if (key.length > 64 || !_isScalar(value)) return null;
      if (value is String && value.length > _maxTextLength) return null;
      if (value is num && !value.isFinite) return null;
      payload[key] = value;
    }

    final valid = switch (table) {
      'bookings' => _booking(payload),
      'payments' => _payment(payload),
      'daily_expenses' => _dailyExpense(payload),
      'monthly_expenses' => _monthlyExpense(payload),
      'yearly_expenses' => _yearlyExpense(payload),
      'id_records' => _idRecord(payload),
      'inventory' => _inventory(payload),
      'seasonal_rates' => _seasonalRate(payload),
      _ => false,
    };
    return valid ? payload : null;
  }

  static bool _booking(Map<String, dynamic> value) {
    final checkin = _date(value['checkin']);
    final checkout = _date(value['checkout']);
    return _text(value['id'], max: 80) &&
        _text(value['guest'], max: 200) &&
        _text(value['room'], max: 80) &&
        checkin != null &&
        checkout != null &&
        checkout.isAfter(checkin) &&
        _optionalText(value['otherOccupants'], max: 4000) &&
        _optionalInt(value['guests'], min: 1, max: 1000) &&
        _optionalMoney(value['tariff']) &&
        _optionalMoney(value['extra']) &&
        _optionalMoney(value['discount']) &&
        _optionalChoice(value['bookingSource'], const {'Online', 'Offline'});
  }

  static bool _payment(Map<String, dynamic> value) =>
      _date(value['date']) != null &&
      _parentSyncId(value['booking_sync_id']) &&
      _signedMoney(value['amount']);

  static bool _dailyExpense(Map<String, dynamic> value) =>
      _date(value['date']) != null &&
      _text(value['head'], max: 200) &&
      _optionalMoney(value['amount']);

  static bool _monthlyExpense(Map<String, dynamic> value) =>
      _text(value['head'], max: 200) &&
      _optionalMoney(value['amount']) &&
      _optionalInt(value['dueDay'], min: 1, max: 31);

  static bool _yearlyExpense(Map<String, dynamic> value) =>
      _text(value['head'], max: 200) && _optionalMoney(value['amount']);

  static bool _idRecord(Map<String, dynamic> value) =>
      _date(value['date']) != null &&
      _parentSyncId(value['booking_sync_id']) &&
      _text(value['idType'], max: 100);

  static bool _inventory(Map<String, dynamic> value) =>
      _text(value['room'], max: 80) &&
      _text(value['category'], max: 100) &&
      _text(value['itemName'], max: 200) &&
      _text(value['unit'], max: 40) &&
      _int(value['currentStock'], min: 0, max: 100000000) &&
      _int(value['minStock'], min: 0, max: 100000000) &&
      _int(value['reorderQty'], min: 0, max: 100000000) &&
      DateTime.tryParse(value['updatedAt']?.toString() ?? '') != null;

  static bool _seasonalRate(Map<String, dynamic> value) {
    final start = _date(value['startDate']);
    final end = _date(value['endDate']);
    return _text(value['name'], max: 200) &&
        _text(value['room'], max: 80) &&
        start != null &&
        end != null &&
        !end.isBefore(start) &&
        _money(value['ratePerNight']) &&
        _optionalInt(value['isActive'], min: 0, max: 1);
  }

  static bool _isScalar(Object? value) =>
      value == null || value is String || value is num || value is bool;

  static bool _text(Object? value, {required int max}) =>
      value is String && value.trim().isNotEmpty && value.length <= max;

  static bool _optionalText(Object? value, {required int max}) =>
      value == null || (value is String && value.length <= max);

  static DateTime? _date(Object? value) {
    if (value is! String || value.length != 10) return null;
    final parsed = DateTime.tryParse(value);
    if (parsed == null) return null;
    final normalized =
        '${parsed.year.toString().padLeft(4, '0')}-'
        '${parsed.month.toString().padLeft(2, '0')}-'
        '${parsed.day.toString().padLeft(2, '0')}';
    return normalized == value ? parsed : null;
  }

  static bool _money(Object? value) =>
      value is num && value.isFinite && value >= 0 && value <= 1000000000;

  static bool _optionalMoney(Object? value) => value == null || _money(value);

  static bool _signedMoney(Object? value) =>
      value is num &&
      value.isFinite &&
      value != 0 &&
      value >= -1000000000 &&
      value <= 1000000000;

  static bool _int(Object? value, {required int min, required int max}) =>
      value is int && value >= min && value <= max;

  static bool _optionalInt(
    Object? value, {
    required int min,
    required int max,
  }) => value == null || _int(value, min: min, max: max);

  static bool _optionalChoice(Object? value, Set<String> allowed) =>
      value == null || (value is String && allowed.contains(value));

  static bool _parentSyncId(Object? value) =>
      value is String && _syncIdPattern.hasMatch(value);
}
