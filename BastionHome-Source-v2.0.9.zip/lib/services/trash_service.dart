import 'dart:convert';

import '../database/database_helper.dart';
import 'account_service.dart';
import 'id_vault_service.dart';

class TrashItem {
  final String syncId;
  final String entityType;
  final Map<String, dynamic> payload;
  final DateTime deletedAt;
  final String deletedBy;
  final DateTime expiresAt;

  const TrashItem({
    required this.syncId,
    required this.entityType,
    required this.payload,
    required this.deletedAt,
    required this.deletedBy,
    required this.expiresAt,
  });

  factory TrashItem.fromMap(Map<String, dynamic> map) => TrashItem(
    syncId: map['syncId'] as String,
    entityType: map['entityType'] as String,
    payload: Map<String, dynamic>.from(
      jsonDecode(map['payload'] as String) as Map,
    ),
    deletedAt: DateTime.parse(map['deletedAt'] as String).toLocal(),
    deletedBy: map['deletedBy'] as String,
    expiresAt: DateTime.parse(map['expiresAt'] as String).toLocal(),
  );

  Duration get remaining => expiresAt.difference(DateTime.now());
  bool get hasExtendedIdRetention =>
      expiresAt.difference(deletedAt) > const Duration(days: 8);

  String get typeLabel {
    switch (entityType) {
      case 'bookings':
        return 'Booking';
      case 'payments':
        return 'Payment';
      case 'daily_expenses':
        return 'Daily expense';
      case 'monthly_expenses':
        return 'Monthly expense';
      case 'yearly_expenses':
        return 'Yearly expense';
      case 'id_records':
        return 'Guest ID record';
      case 'inventory':
        return 'Stock item';
      case 'seasonal_rates':
        return 'Seasonal rate';
      default:
        return 'Record';
    }
  }

  String get title {
    switch (entityType) {
      case 'bookings':
        return '${payload['id'] ?? ''} ${payload['guest'] ?? ''}'.trim();
      case 'payments':
        return '${payload['bookingId'] ?? ''} - ${payload['amount'] ?? ''}';
      case 'daily_expenses':
      case 'monthly_expenses':
      case 'yearly_expenses':
        return payload['head']?.toString() ?? typeLabel;
      case 'id_records':
        return '${payload['bookingId'] ?? ''} ${payload['idType'] ?? ''}'
            .trim();
      case 'inventory':
        return '${payload['itemName'] ?? ''} - ${payload['room'] ?? ''}'.trim();
      case 'seasonal_rates':
        return payload['name']?.toString() ?? typeLabel;
      default:
        return typeLabel;
    }
  }
}

class TrashService {
  static final TrashService _instance = TrashService._internal();
  factory TrashService() => _instance;
  TrashService._internal();

  final DatabaseHelper _db = DatabaseHelper();

  void _requireAdmin() {
    if (!AccountService().isAdmin) {
      throw StateError('Only an administrator can delete or restore records.');
    }
  }

  Future<void> deleteRecord({
    required String table,
    required String keyColumn,
    required Object keyValue,
  }) async {
    _requireAdmin();
    final user = AccountService().currentUser!;
    await _db.moveToTrash(
      table: table,
      keyColumn: keyColumn,
      keyValue: keyValue,
      deletedBy: user.displayName,
      allowExample: true,
    );
  }

  Future<List<TrashItem>> getItems() async {
    _requireAdmin();
    await purgeExpired();
    return (await _db.getTrashEntries()).map(TrashItem.fromMap).toList();
  }

  Future<void> restore(String syncId) async {
    _requireAdmin();
    await _db.restoreFromTrash(syncId);
  }

  Future<void> purgeExpired() async {
    final expired = await _db.purgeExpiredTrash();
    for (final entry in expired) {
      final table = entry['entityType'] as String;
      final payload = Map<String, dynamic>.from(
        jsonDecode(entry['payload'] as String) as Map,
      );
      if (table == 'bookings') {
        for (final key in ['idFrontPath', 'idBackPath']) {
          final path = payload[key]?.toString() ?? '';
          if (path.isNotEmpty) await IdVaultService().delete(path);
        }
      } else if (table == 'id_records') {
        final path = payload['fileName']?.toString() ?? '';
        if (path.isNotEmpty) await IdVaultService().delete(path);
      }
    }
  }
}
