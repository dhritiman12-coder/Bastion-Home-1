import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/booking_model.dart';
import 'download_service.dart';
import 'id_vault_service.dart';
import 'logo_service.dart';

class GuestStayPdfService {
  GuestStayPdfService({IdVaultService? vault})
    : _vault = vault ?? IdVaultService();

  final IdVaultService _vault;

  Future<String> downloadOrShare(BookingModel booking) async {
    final property = await LogoService().getAllSettings();
    final logoBytes = await _loadLogo(property['logoPath'] as String?);
    final bytes = await buildPdf(
      booking: booking,
      propertyName:
          property['guestHouseName'] as String? ?? 'Bastion Home Guest House',
      propertyAddress: property['guestHouseAddress'] as String? ?? '',
      logoBytes: logoBytes,
      idFrontBytes: await _loadIdImage(booking.idFrontPath),
      idBackBytes: await _loadIdImage(booking.idBackPath),
    );
    final safeId = booking.id.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');
    final fileName = 'guest_stay_$safeId.pdf';

    return DownloadService().saveBytes(
      fileName: fileName,
      bytes: bytes,
      mimeType: 'application/pdf',
    );
  }

  Future<Uint8List> buildPdf({
    required BookingModel booking,
    required String propertyName,
    String propertyAddress = '',
    Uint8List? logoBytes,
    Uint8List? idFrontBytes,
    Uint8List? idBackBytes,
  }) async {
    final bodyFontData = await rootBundle.load(
      'assets/fonts/Inter-Variable.ttf',
    );
    final headingFontData = await rootBundle.load(
      'assets/fonts/Lora-Variable.ttf',
    );
    final bodyFont = pw.Font.ttf(bodyFontData);
    final headingFont = pw.Font.ttf(headingFontData);
    final document = pw.Document(
      title: 'Guest stay record ${booking.id}',
      author: propertyName,
      subject: 'Non-financial guest stay and identity record',
      creator: 'Bastion Home Manager',
    );
    final teal = PdfColor.fromInt(0xff123f34);
    final rust = PdfColor.fromInt(0xff8e2a18);
    final pale = PdfColor.fromInt(0xfff7f4ee);
    final border = PdfColor.fromInt(0xffd8d3ca);
    final generatedAt = DateTime.now();
    final details = <List<String>>[
      ['Booking ID', booking.id],
      if (booking.serialNumber.isNotEmpty)
        ['Serial number', booking.serialNumber],
      ['Primary guest', booking.guest],
      ['Phone', _value(booking.phone)],
      ['Address', _value(booking.address)],
      ['Number of guests', booking.guests.toString()],
      ['Room', booking.roomLabel],
      ['Check-in', '${_date(booking.checkin)} ${booking.checkinTime}'],
      ['Check-out', '${_date(booking.checkout)} ${booking.checkoutTime}'],
      ['Booking status', booking.statusLabel],
      ['Booking source', booking.bookingSourceLabel],
      ['ID type', _value(booking.idType)],
      ['ID number', _value(booking.idNumber)],
      ['ID photo recorded', booking.idTaken ? 'Yes' : 'No'],
      ['Processed by', _value(booking.createdBy)],
    ];

    document.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.fromLTRB(40, 36, 40, 42),
        theme: pw.ThemeData.withFont(base: bodyFont, bold: bodyFont),
        header: (context) => pw.Container(
          padding: const pw.EdgeInsets.only(bottom: 10),
          decoration: pw.BoxDecoration(
            border: pw.Border(bottom: pw.BorderSide(color: border)),
          ),
          child: pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.center,
            children: [
              if (logoBytes != null)
                pw.Container(
                  width: 132,
                  height: 52,
                  margin: const pw.EdgeInsets.only(right: 14),
                  child: pw.Image(
                    pw.MemoryImage(logoBytes),
                    fit: pw.BoxFit.contain,
                  ),
                ),
              pw.Expanded(
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.end,
                  children: [
                    pw.Text(
                      propertyName,
                      textAlign: pw.TextAlign.right,
                      style: pw.TextStyle(
                        font: headingFont,
                        color: teal,
                        fontSize: 17,
                        fontWeight: pw.FontWeight.bold,
                      ),
                    ),
                    if (propertyAddress.trim().isNotEmpty)
                      pw.Text(
                        propertyAddress.trim(),
                        textAlign: pw.TextAlign.right,
                        style: pw.TextStyle(fontSize: 8.5, color: teal),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
        footer: (context) => pw.Container(
          padding: const pw.EdgeInsets.only(top: 8),
          decoration: pw.BoxDecoration(
            border: pw.Border(top: pw.BorderSide(color: border)),
          ),
          child: pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text(
                'Generated ${_date(generatedAt)} ${_time(generatedAt)}',
                style: const pw.TextStyle(fontSize: 8),
              ),
              pw.Text(
                'Page ${context.pageNumber} of ${context.pagesCount}',
                style: const pw.TextStyle(fontSize: 8),
              ),
            ],
          ),
        ),
        build: (context) => [
          pw.SizedBox(height: 18),
          pw.Text(
            'GUEST STAY INFORMATION REPORT',
            style: pw.TextStyle(
              font: headingFont,
              fontSize: 19,
              fontWeight: pw.FontWeight.bold,
              color: rust,
            ),
          ),
          pw.SizedBox(height: 4),
          pw.Text(
            'Identity and occupancy record. Financial information is excluded.',
            style: pw.TextStyle(fontSize: 9, color: teal),
          ),
          pw.SizedBox(height: 16),
          _sectionTitle('Guest and stay details', rust, pale),
          pw.TableHelper.fromTextArray(
            context: context,
            data: details,
            cellStyle: const pw.TextStyle(fontSize: 9.5),
            cellPadding: const pw.EdgeInsets.symmetric(
              horizontal: 8,
              vertical: 6,
            ),
            columnWidths: const {
              0: pw.FixedColumnWidth(126),
              1: pw.FlexColumnWidth(),
            },
            headerCount: 0,
            border: pw.TableBorder.all(color: border, width: 0.6),
            oddRowDecoration: pw.BoxDecoration(color: pale),
            cellAlignments: {
              0: pw.Alignment.centerLeft,
              1: pw.Alignment.centerLeft,
            },
          ),
          pw.SizedBox(height: 16),
          _sectionTitle('Other room occupants', rust, pale),
          if (booking.otherOccupantNames.isEmpty)
            pw.Text(
              'No other occupant names were recorded.',
              style: const pw.TextStyle(fontSize: 9.5),
            )
          else
            pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: booking.otherOccupantNames
                  .asMap()
                  .entries
                  .map(
                    (entry) => pw.Padding(
                      padding: const pw.EdgeInsets.only(bottom: 4),
                      child: pw.Text(
                        '${entry.key + 1}. ${entry.value}',
                        style: const pw.TextStyle(fontSize: 9.5),
                      ),
                    ),
                  )
                  .toList(),
            ),
          pw.SizedBox(height: 16),
          _sectionTitle('Customer photo identification', rust, pale),
          if (idFrontBytes == null && idBackBytes == null)
            pw.Text(
              booking.idTaken
                  ? 'The ID image is not available on this device.'
                  : 'No ID image was recorded for this booking.',
              style: const pw.TextStyle(fontSize: 9.5),
            )
          else
            pw.Row(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                if (idFrontBytes != null)
                  pw.Expanded(
                    child: _idImage('Front side', idFrontBytes, border),
                  ),
                if (idFrontBytes != null && idBackBytes != null)
                  pw.SizedBox(width: 12),
                if (idBackBytes != null)
                  pw.Expanded(
                    child: _idImage('Back side', idBackBytes, border),
                  ),
              ],
            ),
          if (booking.notes.trim().isNotEmpty) ...[
            pw.SizedBox(height: 16),
            _sectionTitle('Stay notes', rust, pale),
            pw.Text(
              booking.notes.trim(),
              style: const pw.TextStyle(fontSize: 9.5),
            ),
          ],
          pw.SizedBox(height: 22),
          pw.Text(
            'This report reflects the information recorded in Bastion Home Manager for the stated booking.',
            style: pw.TextStyle(fontSize: 8.5, color: teal),
          ),
        ],
      ),
    );

    return document.save();
  }

  pw.Widget _sectionTitle(String title, PdfColor color, PdfColor fill) {
    return pw.Container(
      width: double.infinity,
      margin: const pw.EdgeInsets.only(bottom: 7),
      padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      color: fill,
      child: pw.Text(
        title,
        style: pw.TextStyle(
          color: color,
          fontSize: 10.5,
          fontWeight: pw.FontWeight.bold,
        ),
      ),
    );
  }

  pw.Widget _idImage(String label, Uint8List bytes, PdfColor border) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(
          label,
          style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold),
        ),
        pw.SizedBox(height: 5),
        pw.Container(
          height: 190,
          padding: const pw.EdgeInsets.all(5),
          decoration: pw.BoxDecoration(
            border: pw.Border.all(color: border, width: 0.6),
          ),
          child: pw.Image(pw.MemoryImage(bytes), fit: pw.BoxFit.contain),
        ),
      ],
    );
  }

  Future<Uint8List?> _loadLogo(String? dataUrl) async {
    if (dataUrl != null && dataUrl.startsWith('data:image/')) {
      final separator = dataUrl.indexOf(',');
      if (separator > 0) {
        try {
          return base64Decode(dataUrl.substring(separator + 1));
        } on FormatException {
          // Fall through to the bundled official logo.
        }
      }
    }
    final data = await rootBundle.load(
      'assets/images/bastion_home_official_logo.png',
    );
    return data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
  }

  Future<Uint8List?> _loadIdImage(String imagePath) async {
    if (imagePath.isEmpty) return null;
    try {
      if (imagePath.endsWith('.bhid')) {
        return await _vault.readDecrypted(imagePath);
      }
      if (imagePath.startsWith('data:image/')) {
        final separator = imagePath.indexOf(',');
        if (separator > 0) {
          return base64Decode(imagePath.substring(separator + 1));
        }
      }
      if (!kIsWeb) {
        final file = File(imagePath);
        if (await file.exists()) return await file.readAsBytes();
      }
    } catch (error) {
      debugPrint('Could not include an ID image in the guest PDF: $error');
    }
    return null;
  }

  static String _value(String value) =>
      value.trim().isEmpty ? 'Not recorded' : value.trim();

  static String _date(DateTime date) =>
      '${date.day.toString().padLeft(2, '0')}/'
      '${date.month.toString().padLeft(2, '0')}/${date.year}';

  static String _time(DateTime date) =>
      '${date.hour.toString().padLeft(2, '0')}:'
      '${date.minute.toString().padLeft(2, '0')}';
}
