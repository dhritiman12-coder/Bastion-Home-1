import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppSettingsService extends ChangeNotifier {
  static final AppSettingsService _instance = AppSettingsService._internal();
  factory AppSettingsService() => _instance;
  AppSettingsService._internal();

  static const _fontChoices = {'Modern', 'Classic', 'System'};
  static const _currencySymbols = {
    'INR': '₹',
    'USD': r'$',
    'EUR': '€',
    'GBP': '£',
  };
  static const _dateFormats = {
    'dd-MMM-yyyy',
    'dd/MM/yyyy',
    'MM/dd/yyyy',
    'yyyy-MM-dd',
  };
  static const _measurementSystems = {'Metric', 'Imperial'};
  static const _temperatureUnits = {'Celsius', 'Fahrenheit'};
  static const _stockUnits = {
    'pcs',
    'sets',
    'kg',
    'litres',
    'bottles',
    'packs',
  };

  ThemeMode themeMode = ThemeMode.system;
  double textScale = 1.0;
  String fontFamily = 'Modern';
  String headingFontFamily = 'Classic';
  String currencyCode = 'INR';
  String currencySymbol = '₹';
  bool indianNumberGrouping = true;
  String dateFormat = 'dd-MMM-yyyy';
  String measurementSystem = 'Metric';
  String temperatureUnit = 'Celsius';
  String defaultCheckinTime = '12:00';
  String defaultCheckoutTime = '11:00';
  bool biometricUnlock = false;
  bool lockOnBackground = true;
  bool bookingReminders = true;
  bool expenseReminders = true;
  bool lowStockAlerts = true;
  bool weeklyBackupReminder = true;
  String defaultStockUnit = 'pcs';

  Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    themeMode = ThemeMode.values.firstWhere(
      (mode) => mode.name == prefs.getString('setting_theme_mode'),
      orElse: () => ThemeMode.system,
    );
    textScale = _safeTextScale(prefs.getDouble('setting_text_scale'));
    fontFamily = _choice(
      prefs.getString('setting_font_family'),
      _fontChoices,
      'Modern',
    );
    headingFontFamily = _choice(
      prefs.getString('setting_heading_font_family'),
      _fontChoices,
      'Classic',
    );
    currencyCode = _choice(
      prefs.getString('setting_currency_code'),
      _currencySymbols.keys.toSet(),
      'INR',
    );
    currencySymbol = _currencySymbols[currencyCode]!;
    indianNumberGrouping =
        prefs.getBool('setting_indian_grouping') ?? currencyCode == 'INR';
    dateFormat = _choice(
      prefs.getString('setting_date_format'),
      _dateFormats,
      'dd-MMM-yyyy',
    );
    measurementSystem = _choice(
      prefs.getString('setting_measurement_system'),
      _measurementSystems,
      'Metric',
    );
    temperatureUnit = _choice(
      prefs.getString('setting_temperature_unit'),
      _temperatureUnits,
      'Celsius',
    );
    defaultCheckinTime = _safeTime(
      prefs.getString('setting_checkin_time'),
      '12:00',
    );
    defaultCheckoutTime = _safeTime(
      prefs.getString('setting_checkout_time'),
      '11:00',
    );
    biometricUnlock = prefs.getBool('setting_biometric_unlock') ?? false;
    lockOnBackground = prefs.getBool('setting_lock_background') ?? true;
    bookingReminders = prefs.getBool('setting_booking_reminders') ?? true;
    expenseReminders = prefs.getBool('setting_expense_reminders') ?? true;
    lowStockAlerts = prefs.getBool('setting_low_stock_alerts') ?? true;
    weeklyBackupReminder = prefs.getBool('setting_backup_reminder') ?? true;
    defaultStockUnit = _choice(
      prefs.getString('setting_stock_unit'),
      _stockUnits,
      'pcs',
    );
    notifyListeners();
  }

  Future<void> update({
    ThemeMode? themeMode,
    double? textScale,
    String? fontFamily,
    String? headingFontFamily,
    String? currencyCode,
    String? currencySymbol,
    bool? indianNumberGrouping,
    String? dateFormat,
    String? measurementSystem,
    String? temperatureUnit,
    String? defaultCheckinTime,
    String? defaultCheckoutTime,
    bool? biometricUnlock,
    bool? lockOnBackground,
    bool? bookingReminders,
    bool? expenseReminders,
    bool? lowStockAlerts,
    bool? weeklyBackupReminder,
    String? defaultStockUnit,
  }) async {
    this.themeMode = themeMode ?? this.themeMode;
    this.textScale = textScale == null
        ? this.textScale
        : _safeTextScale(textScale, fallback: this.textScale);
    this.fontFamily = _choice(fontFamily, _fontChoices, this.fontFamily);
    this.headingFontFamily = _choice(
      headingFontFamily,
      _fontChoices,
      this.headingFontFamily,
    );
    this.currencyCode = _choice(
      currencyCode,
      _currencySymbols.keys.toSet(),
      this.currencyCode,
    );
    this.currencySymbol = _currencySymbols[this.currencyCode]!;
    this.indianNumberGrouping =
        indianNumberGrouping ?? this.indianNumberGrouping;
    this.dateFormat = _choice(dateFormat, _dateFormats, this.dateFormat);
    this.measurementSystem = _choice(
      measurementSystem,
      _measurementSystems,
      this.measurementSystem,
    );
    this.temperatureUnit = _choice(
      temperatureUnit,
      _temperatureUnits,
      this.temperatureUnit,
    );
    this.defaultCheckinTime = _safeTime(
      defaultCheckinTime,
      this.defaultCheckinTime,
    );
    this.defaultCheckoutTime = _safeTime(
      defaultCheckoutTime,
      this.defaultCheckoutTime,
    );
    this.biometricUnlock = biometricUnlock ?? this.biometricUnlock;
    this.lockOnBackground = lockOnBackground ?? this.lockOnBackground;
    this.bookingReminders = bookingReminders ?? this.bookingReminders;
    this.expenseReminders = expenseReminders ?? this.expenseReminders;
    this.lowStockAlerts = lowStockAlerts ?? this.lowStockAlerts;
    this.weeklyBackupReminder =
        weeklyBackupReminder ?? this.weeklyBackupReminder;
    this.defaultStockUnit = _choice(
      defaultStockUnit,
      _stockUnits,
      this.defaultStockUnit,
    );

    final prefs = await SharedPreferences.getInstance();
    await Future.wait([
      prefs.setString('setting_theme_mode', this.themeMode.name),
      prefs.setDouble('setting_text_scale', this.textScale),
      prefs.setString('setting_font_family', this.fontFamily),
      prefs.setString('setting_heading_font_family', this.headingFontFamily),
      prefs.setString('setting_currency_code', this.currencyCode),
      prefs.setString('setting_currency_symbol', this.currencySymbol),
      prefs.setBool('setting_indian_grouping', this.indianNumberGrouping),
      prefs.setString('setting_date_format', this.dateFormat),
      prefs.setString('setting_measurement_system', this.measurementSystem),
      prefs.setString('setting_temperature_unit', this.temperatureUnit),
      prefs.setString('setting_checkin_time', this.defaultCheckinTime),
      prefs.setString('setting_checkout_time', this.defaultCheckoutTime),
      prefs.setBool('setting_biometric_unlock', this.biometricUnlock),
      prefs.setBool('setting_lock_background', this.lockOnBackground),
      prefs.setBool('setting_booking_reminders', this.bookingReminders),
      prefs.setBool('setting_expense_reminders', this.expenseReminders),
      prefs.setBool('setting_low_stock_alerts', this.lowStockAlerts),
      prefs.setBool('setting_backup_reminder', this.weeklyBackupReminder),
      prefs.setString('setting_stock_unit', this.defaultStockUnit),
    ]);
    notifyListeners();
  }

  Map<String, dynamic> toBackupMap() => {
    'themeMode': themeMode.name,
    'textScale': textScale,
    'fontFamily': fontFamily,
    'headingFontFamily': headingFontFamily,
    'currencyCode': currencyCode,
    'currencySymbol': currencySymbol,
    'indianNumberGrouping': indianNumberGrouping,
    'dateFormat': dateFormat,
    'measurementSystem': measurementSystem,
    'temperatureUnit': temperatureUnit,
    'defaultCheckinTime': defaultCheckinTime,
    'defaultCheckoutTime': defaultCheckoutTime,
    'biometricUnlock': biometricUnlock,
    'lockOnBackground': lockOnBackground,
    'bookingReminders': bookingReminders,
    'expenseReminders': expenseReminders,
    'lowStockAlerts': lowStockAlerts,
    'weeklyBackupReminder': weeklyBackupReminder,
    'defaultStockUnit': defaultStockUnit,
  };

  Future<void> restoreFromBackup(Map<String, dynamic> map) async {
    await update(
      themeMode: ThemeMode.values.firstWhere(
        (mode) => mode.name == map['themeMode'],
        orElse: () => themeMode,
      ),
      textScale: map['textScale'] is num
          ? (map['textScale'] as num).toDouble()
          : null,
      fontFamily: map['fontFamily'] is String
          ? map['fontFamily'] as String
          : null,
      headingFontFamily: map['headingFontFamily'] is String
          ? map['headingFontFamily'] as String
          : null,
      currencyCode: map['currencyCode'] is String
          ? map['currencyCode'] as String
          : null,
      indianNumberGrouping: map['indianNumberGrouping'] is bool
          ? map['indianNumberGrouping'] as bool
          : null,
      dateFormat: map['dateFormat'] is String
          ? map['dateFormat'] as String
          : null,
      measurementSystem: map['measurementSystem'] is String
          ? map['measurementSystem'] as String
          : null,
      temperatureUnit: map['temperatureUnit'] is String
          ? map['temperatureUnit'] as String
          : null,
      defaultCheckinTime: map['defaultCheckinTime'] is String
          ? map['defaultCheckinTime'] as String
          : null,
      defaultCheckoutTime: map['defaultCheckoutTime'] is String
          ? map['defaultCheckoutTime'] as String
          : null,
      biometricUnlock: map['biometricUnlock'] is bool
          ? map['biometricUnlock'] as bool
          : null,
      lockOnBackground: map['lockOnBackground'] is bool
          ? map['lockOnBackground'] as bool
          : null,
      bookingReminders: map['bookingReminders'] is bool
          ? map['bookingReminders'] as bool
          : null,
      expenseReminders: map['expenseReminders'] is bool
          ? map['expenseReminders'] as bool
          : null,
      lowStockAlerts: map['lowStockAlerts'] is bool
          ? map['lowStockAlerts'] as bool
          : null,
      weeklyBackupReminder: map['weeklyBackupReminder'] is bool
          ? map['weeklyBackupReminder'] as bool
          : null,
      defaultStockUnit: map['defaultStockUnit'] is String
          ? map['defaultStockUnit'] as String
          : null,
    );
  }

  static String _choice(String? value, Set<String> allowed, String fallback) =>
      value != null && allowed.contains(value) ? value : fallback;

  static double _safeTextScale(double? value, {double fallback = 1.0}) {
    if (value == null || !value.isFinite) return fallback;
    return value.clamp(0.9, 1.35).toDouble();
  }

  static String _safeTime(String? value, String fallback) {
    if (value == null || !RegExp(r'^\d{2}:\d{2}$').hasMatch(value)) {
      return fallback;
    }
    final parts = value.split(':');
    final hour = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);
    if (hour == null || minute == null || hour > 23 || minute > 59) {
      return fallback;
    }
    return value;
  }
}
