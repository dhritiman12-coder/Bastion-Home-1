class WorkforceCredentialPolicy {
  static String normalizeUsername(String value) => value.trim().toLowerCase();

  static bool isPrimaryOwnerAlias(String value) =>
      normalizeUsername(value) == 'admin';

  static bool isValidUsername(String value) =>
      RegExp(r'^[a-z0-9._-]{3,40}$').hasMatch(normalizeUsername(value));

  static String signInIdentifier(String value) {
    final normalized = value.trim().toLowerCase();
    return normalized.contains('@')
        ? normalized
        : '$normalized@staff.bastionhome.app';
  }

  static String? passwordError(String value) {
    if (value.length < 10 || value.length > 72) {
      return 'Use 10 to 72 characters';
    }
    if (!RegExp(r'[a-z]').hasMatch(value) ||
        !RegExp(r'[A-Z]').hasMatch(value) ||
        !RegExp(r'[0-9]').hasMatch(value)) {
      return 'Include uppercase, lowercase, and a number';
    }
    return null;
  }
}
