import 'dart:math';

import 'package:intl/intl.dart';

import '../services/app_settings_service.dart';

class CurrencyFormatter {
  /// Format as Indian numbering system: ₹1,25,000
  static String format(double amount, {bool showSign = false}) {
    final isNegative = amount < 0;
    final settings = AppSettingsService();
    final formatted = settings.indianNumberGrouping
        ? _formatIndianFull(amount.abs().round())
        : NumberFormat('#,##0', 'en_US').format(amount.abs().round());

    final sign = isNegative ? '−' : (showSign && amount > 0 ? '+' : '');
    return '$sign${settings.currencySymbol}$formatted';
  }

  static String formatCompact(double amount) {
    final settings = AppSettingsService();
    final symbol = settings.currencySymbol;
    if (settings.indianNumberGrouping && amount >= 10000000) {
      return '$symbol${(amount / 10000000).toStringAsFixed(1)}Cr';
    } else if (settings.indianNumberGrouping && amount >= 100000) {
      return '$symbol${(amount / 100000).toStringAsFixed(1)}L';
    } else if (!settings.indianNumberGrouping && amount >= 1000000000) {
      return '$symbol${(amount / 1000000000).toStringAsFixed(1)}B';
    } else if (!settings.indianNumberGrouping && amount >= 1000000) {
      return '$symbol${(amount / 1000000).toStringAsFixed(1)}M';
    } else if (amount >= 1000) {
      return '$symbol${(amount / 1000).toStringAsFixed(1)}K';
    }
    return '$symbol${amount.round()}';
  }

  static String _formatIndianFull(int amount) {
    if (amount < 1000) return amount.toString();
    final s = amount.toString();
    if (s.length <= 3) return s;

    // Indian grouping: last 3, then groups of 2
    final last3 = s.substring(s.length - 3);
    final rest = s.substring(0, s.length - 3);
    final groups = <String>[];
    for (int i = rest.length; i > 0; i -= 2) {
      groups.insert(0, rest.substring(max(0, i - 2), i));
    }
    return '${groups.join(',')},$last3';
  }
}

class DateFormatter {
  static String format(DateTime date) {
    return DateFormat(AppSettingsService().dateFormat).format(date);
  }

  static String monthYear(DateTime date) {
    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
    return '${months[date.month - 1]} ${date.year}';
  }

  static String shortMonthYear(DateTime date) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return '${months[date.month - 1]} ${date.year}';
  }
}
