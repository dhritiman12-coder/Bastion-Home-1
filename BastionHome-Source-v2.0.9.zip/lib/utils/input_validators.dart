class InputValidators {
  static const double maxMoney = 1000000000;

  static String? money(
    String? value, {
    bool required = false,
    bool allowZero = true,
  }) {
    final text = value?.trim() ?? '';
    if (text.isEmpty) return required ? 'Required' : null;

    final amount = double.tryParse(text);
    if (amount == null || !amount.isFinite) return 'Enter a valid amount';
    if (amount < 0 || (!allowZero && amount == 0)) {
      return allowZero ? 'Amount cannot be negative' : 'Amount must be above 0';
    }
    if (amount > maxMoney) return 'Amount is too large';
    return null;
  }
}
