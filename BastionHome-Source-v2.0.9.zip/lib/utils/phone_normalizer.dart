class PhoneNormalizer {
  const PhoneNormalizer._();

  static String digitsOnly(String value) =>
      value.replaceAll(RegExp(r'[^0-9]'), '');

  /// Produces a stable lookup key. Ten-digit numbers use India's +91 code,
  /// while explicitly international numbers keep their supplied country code.
  static String canonical(String value) {
    final trimmed = value.trim();
    var digits = digitsOnly(trimmed);
    if (digits.startsWith('00')) digits = digits.substring(2);
    if (digits.length == 11 && digits.startsWith('0')) {
      digits = digits.substring(1);
    }
    if (digits.length == 10) return '91$digits';
    return digits;
  }
}
