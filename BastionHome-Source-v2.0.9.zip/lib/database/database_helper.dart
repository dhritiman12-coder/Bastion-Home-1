import 'dart:convert';
import 'dart:math';

import 'package:sqflite_sqlcipher/sqflite.dart';
import 'package:path/path.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/foundation.dart' show visibleForTesting;

import '../services/database_key_service.dart';
import '../services/data_change_service.dart';
import '../services/sync_payload_validator.dart';
import '../services/id_retention_policy.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  static Database? _database;
  static const int _databaseVersion = 9;

  static const List<String> _exportTables = [
    'bookings',
    'payments',
    'daily_expenses',
    'monthly_expenses',
    'yearly_expenses',
    'id_records',
    'inventory',
  ];

  static const List<String> syncTables = [..._exportTables, 'seasonal_rates'];
  static const List<String> _backupTables = [
    ...syncTables,
    'trash_entries',
    'purged_records',
  ];

  static const Map<String, String> _primaryKeys = {
    'bookings': 'id',
    'payments': 'id',
    'daily_expenses': 'id',
    'monthly_expenses': 'id',
    'yearly_expenses': 'id',
    'id_records': 'id',
    'inventory': 'id',
    'seasonal_rates': 'id',
  };

  Future<Database> get database async {
    _database ??= await _initDatabase();
    return _database!;
  }

  @visibleForTesting
  Future<void> initializeForTesting(Database testDatabase) async {
    await _database?.close();
    _database = testDatabase;
    await _onConfigure(testDatabase);
    await _onCreate(testDatabase, _databaseVersion);
  }

  @visibleForTesting
  Future<void> closeForTesting() async {
    await _database?.close();
    _database = null;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final legacyPath = join(dbPath, 'bastion_home.db');
    final securePath = join(dbPath, 'bastion_home_secure.db');
    final password = await DatabaseKeyService().getOrCreateKey();

    if (!await databaseExists(securePath) && await databaseExists(legacyPath)) {
      await _migrateLegacyDatabase(legacyPath, securePath, password);
    }

    return openDatabase(
      securePath,
      password: password,
      version: _databaseVersion,
      onConfigure: _onConfigure,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _onConfigure(Database db) async {
    await db.execute('PRAGMA foreign_keys = ON');
  }

  Future<void> _migrateLegacyDatabase(
    String legacyPath,
    String securePath,
    String password,
  ) async {
    Database? legacyDb;
    Database? secureDb;
    try {
      legacyDb = await openDatabase(legacyPath, readOnly: true);
      final snapshot = <String, List<Map<String, dynamic>>>{};
      for (final table in _exportTables) {
        try {
          snapshot[table] = await legacyDb.query(table);
        } catch (_) {
          snapshot[table] = const [];
        }
      }

      secureDb = await openDatabase(
        securePath,
        password: password,
        version: _databaseVersion,
        onConfigure: _onConfigure,
        onCreate: _onCreate,
        onUpgrade: _onUpgrade,
      );
      await _replaceAllRows(secureDb, snapshot);
      await legacyDb.close();
      legacyDb = null;
      await secureDb.close();
      secureDb = null;
      await deleteDatabase(legacyPath);
    } catch (_) {
      await secureDb?.close();
      secureDb = null;
      if (await databaseExists(securePath)) {
        await deleteDatabase(securePath);
      }
      rethrow;
    } finally {
      await legacyDb?.close();
      await secureDb?.close();
    }
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE bookings (
        id TEXT PRIMARY KEY,
        guest TEXT NOT NULL,
        phone TEXT DEFAULT '',
        address TEXT DEFAULT '',
        otherOccupants TEXT NOT NULL DEFAULT '',
        guests INTEGER DEFAULT 1,
        room TEXT NOT NULL,
        checkin TEXT NOT NULL,
        checkout TEXT NOT NULL,
        checkinTime TEXT DEFAULT '12:00',
        checkoutTime TEXT DEFAULT '11:00',
        tariff REAL DEFAULT 0,
        extra REAL DEFAULT 0,
        discount REAL DEFAULT 0,
        status TEXT DEFAULT 'Booked',
        idTaken TEXT DEFAULT 'No',
        idType TEXT DEFAULT '',
        idNumber TEXT DEFAULT '',
        idFrontPath TEXT DEFAULT '',
        idBackPath TEXT DEFAULT '',
        idFrontCapturedAt TEXT NOT NULL DEFAULT '',
        idBackCapturedAt TEXT NOT NULL DEFAULT '',
        paymentMode TEXT DEFAULT 'Cash',
        serialNumber TEXT DEFAULT '',
        createdBy TEXT DEFAULT '',
        bookingSource TEXT NOT NULL DEFAULT 'Offline',
        notes TEXT DEFAULT '',
        syncId TEXT,
        syncUpdatedAt TEXT NOT NULL DEFAULT '',
        isExample INTEGER NOT NULL DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT NOT NULL,
        bookingId TEXT NOT NULL,
        amount REAL NOT NULL,
        mode TEXT DEFAULT 'Cash',
        type TEXT DEFAULT 'Advance',
        by TEXT DEFAULT '',
        notes TEXT DEFAULT '',
        syncId TEXT,
        syncUpdatedAt TEXT NOT NULL DEFAULT '',
        isExample INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (bookingId) REFERENCES bookings(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE daily_expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT NOT NULL,
        head TEXT NOT NULL,
        spentOn TEXT DEFAULT '',
        amount REAL DEFAULT 0,
        vendor TEXT DEFAULT '',
        mode TEXT DEFAULT 'Cash',
        by TEXT DEFAULT '',
        notes TEXT DEFAULT '',
        syncId TEXT,
        syncUpdatedAt TEXT NOT NULL DEFAULT '',
        isExample INTEGER NOT NULL DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE monthly_expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        head TEXT NOT NULL,
        desc TEXT DEFAULT '',
        payee TEXT DEFAULT '',
        amount REAL DEFAULT 0,
        dueDay INTEGER DEFAULT 1,
        autopay TEXT DEFAULT 'No',
        notes TEXT DEFAULT '',
        syncId TEXT,
        syncUpdatedAt TEXT NOT NULL DEFAULT '',
        isExample INTEGER NOT NULL DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE yearly_expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        head TEXT NOT NULL,
        desc TEXT DEFAULT '',
        authority TEXT DEFAULT '',
        amount REAL DEFAULT 0,
        dueMonth TEXT DEFAULT 'Jan',
        renewal TEXT DEFAULT '',
        reminder TEXT DEFAULT 'No',
        notes TEXT DEFAULT '',
        syncId TEXT,
        syncUpdatedAt TEXT NOT NULL DEFAULT '',
        isExample INTEGER NOT NULL DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE id_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT NOT NULL,
        bookingId TEXT NOT NULL,
        idType TEXT NOT NULL,
        idNumber TEXT DEFAULT '',
        copyType TEXT DEFAULT 'Physical',
        fileName TEXT DEFAULT '',
        capturedAt TEXT NOT NULL DEFAULT '',
        storage TEXT DEFAULT '',
        verified TEXT DEFAULT 'No',
        notes TEXT DEFAULT '',
        syncId TEXT,
        syncUpdatedAt TEXT NOT NULL DEFAULT '',
        isExample INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (bookingId) REFERENCES bookings(id) ON DELETE CASCADE
      )
    ''');

    await _createOperationalTables(db);

    await _createIndexes(db);

    await _seedData(db);
    await _initializeFreshSyncMetadata(db);
  }

  Future<void> _createIndexes(Database db) async {
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_bookings_dates ON bookings(checkin, checkout)',
    );
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_bookings_room_dates ON bookings(room, checkin, checkout)',
    );
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_payments_booking ON payments(bookingId)',
    );
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_ids_booking ON id_records(bookingId)',
    );
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_inventory_room ON inventory(room, category)',
    );
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_users_username ON app_users(username)',
    );
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_trash_expiry ON trash_entries(expiresAt)',
    );
    for (final table in syncTables) {
      final exists =
          Sqflite.firstIntValue(
            await db.rawQuery(
              "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=?",
              [table],
            ),
          ) ==
          1;
      if (exists) {
        await db.execute(
          'CREATE UNIQUE INDEX IF NOT EXISTS idx_${table}_sync_id ON $table(syncId)',
        );
      }
    }
  }

  Future<void> _createOperationalTables(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS inventory (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        room TEXT NOT NULL,
        category TEXT NOT NULL,
        itemName TEXT NOT NULL,
        currentStock INTEGER DEFAULT 0,
        minStock INTEGER DEFAULT 1,
        reorderQty INTEGER DEFAULT 5,
        unit TEXT DEFAULT 'pcs',
        notes TEXT DEFAULT '',
        updatedAt TEXT NOT NULL,
        syncId TEXT,
        syncUpdatedAt TEXT NOT NULL DEFAULT '',
        isExample INTEGER NOT NULL DEFAULT 0
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS trash_entries (
        syncId TEXT PRIMARY KEY,
        entityType TEXT NOT NULL,
        originalKey TEXT NOT NULL,
        payload TEXT NOT NULL,
        deletedAt TEXT NOT NULL,
        deletedBy TEXT NOT NULL,
        expiresAt TEXT NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS purged_records (
        syncId TEXT PRIMARY KEY,
        purgedAt TEXT NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS app_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL COLLATE NOCASE UNIQUE,
        displayName TEXT NOT NULL,
        role TEXT NOT NULL,
        pinHash TEXT NOT NULL,
        pinSalt TEXT NOT NULL,
        permissions TEXT NOT NULL DEFAULT '[]',
        active INTEGER NOT NULL DEFAULT 1,
        createdAt TEXT NOT NULL,
        lastLoginAt TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS seasonal_rates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        room TEXT NOT NULL DEFAULT 'All Rooms',
        startDate TEXT NOT NULL,
        endDate TEXT NOT NULL,
        ratePerNight REAL NOT NULL DEFAULT 0,
        rateType TEXT NOT NULL DEFAULT 'Custom',
        notes TEXT DEFAULT '',
        isActive INTEGER NOT NULL DEFAULT 1,
        syncId TEXT,
        syncUpdatedAt TEXT NOT NULL DEFAULT '',
        isExample INTEGER NOT NULL DEFAULT 0
      )
    ''');
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 5) {
      await _createOperationalTables(db);
    }
    if (oldVersion < 2) {
      // Add new booking columns for enhanced booking module
      final cols = await db.rawQuery("PRAGMA table_info(bookings)");
      final existing = cols.map((c) => c['name'] as String).toSet();
      if (!existing.contains('address')) {
        await db.execute(
          "ALTER TABLE bookings ADD COLUMN address TEXT DEFAULT ''",
        );
      }
      if (!existing.contains('checkinTime')) {
        await db.execute(
          "ALTER TABLE bookings ADD COLUMN checkinTime TEXT DEFAULT '12:00'",
        );
      }
      if (!existing.contains('checkoutTime')) {
        await db.execute(
          "ALTER TABLE bookings ADD COLUMN checkoutTime TEXT DEFAULT '11:00'",
        );
      }
      if (!existing.contains('idType')) {
        await db.execute(
          "ALTER TABLE bookings ADD COLUMN idType TEXT DEFAULT ''",
        );
      }
      if (!existing.contains('idNumber')) {
        await db.execute(
          "ALTER TABLE bookings ADD COLUMN idNumber TEXT DEFAULT ''",
        );
      }
      if (!existing.contains('idFrontPath')) {
        await db.execute(
          "ALTER TABLE bookings ADD COLUMN idFrontPath TEXT DEFAULT ''",
        );
      }
      if (!existing.contains('idBackPath')) {
        await db.execute(
          "ALTER TABLE bookings ADD COLUMN idBackPath TEXT DEFAULT ''",
        );
      }
      if (!existing.contains('paymentMode')) {
        await db.execute(
          "ALTER TABLE bookings ADD COLUMN paymentMode TEXT DEFAULT 'Cash'",
        );
      }
      if (!existing.contains('serialNumber')) {
        await db.execute(
          "ALTER TABLE bookings ADD COLUMN serialNumber TEXT DEFAULT ''",
        );
      }
    }
    if (oldVersion < 3) {
      await _createIndexes(db);
    }
    if (oldVersion < 4) {
      const monthNames = {
        'January': 'Jan',
        'February': 'Feb',
        'March': 'Mar',
        'April': 'Apr',
        'June': 'Jun',
        'July': 'Jul',
        'August': 'Aug',
        'September': 'Sep',
        'October': 'Oct',
        'November': 'Nov',
        'December': 'Dec',
      };
      for (final month in monthNames.entries) {
        await db.update(
          'yearly_expenses',
          {'dueMonth': month.value},
          where: 'dueMonth = ?',
          whereArgs: [month.key],
        );
      }
    }
    if (oldVersion < 5) {
      final cols = await db.rawQuery("PRAGMA table_info(bookings)");
      final existing = cols.map((c) => c['name'] as String).toSet();
      if (!existing.contains('createdBy')) {
        await db.execute(
          "ALTER TABLE bookings ADD COLUMN createdBy TEXT DEFAULT ''",
        );
      }
      await _createIndexes(db);
    }
    if (oldVersion < 6) {
      await _createOperationalTables(db);
      await _upgradeSyncSchema(db);
      await _createIndexes(db);
    }
    if (oldVersion < 7) {
      final cols = await db.rawQuery("PRAGMA table_info(bookings)");
      final existing = cols.map((c) => c['name'] as String).toSet();
      if (!existing.contains('bookingSource')) {
        await db.execute(
          "ALTER TABLE bookings ADD COLUMN bookingSource TEXT NOT NULL DEFAULT 'Offline'",
        );
      }
    }
    if (oldVersion < 8) {
      final cols = await db.rawQuery("PRAGMA table_info(bookings)");
      final existing = cols.map((c) => c['name'] as String).toSet();
      if (!existing.contains('otherOccupants')) {
        await db.execute(
          "ALTER TABLE bookings ADD COLUMN otherOccupants TEXT NOT NULL DEFAULT ''",
        );
      }
    }
    if (oldVersion < 9) {
      final bookingCols = await db.rawQuery("PRAGMA table_info(bookings)");
      final bookingFields = bookingCols.map((c) => c['name'] as String).toSet();
      if (!bookingFields.contains('idFrontCapturedAt')) {
        await db.execute(
          "ALTER TABLE bookings ADD COLUMN idFrontCapturedAt TEXT NOT NULL DEFAULT ''",
        );
      }
      if (!bookingFields.contains('idBackCapturedAt')) {
        await db.execute(
          "ALTER TABLE bookings ADD COLUMN idBackCapturedAt TEXT NOT NULL DEFAULT ''",
        );
      }
      await db.execute('''
        UPDATE bookings
        SET idFrontCapturedAt = CASE
          WHEN syncUpdatedAt != '' THEN syncUpdatedAt
          ELSE checkin || 'T00:00:00.000Z'
        END
        WHERE idFrontPath != '' AND idFrontCapturedAt = ''
      ''');
      await db.execute('''
        UPDATE bookings
        SET idBackCapturedAt = CASE
          WHEN syncUpdatedAt != '' THEN syncUpdatedAt
          ELSE checkin || 'T00:00:00.000Z'
        END
        WHERE idBackPath != '' AND idBackCapturedAt = ''
      ''');

      final idCols = await db.rawQuery("PRAGMA table_info(id_records)");
      final idFields = idCols.map((c) => c['name'] as String).toSet();
      if (!idFields.contains('capturedAt')) {
        await db.execute(
          "ALTER TABLE id_records ADD COLUMN capturedAt TEXT NOT NULL DEFAULT ''",
        );
      }
      await db.execute('''
        UPDATE id_records
        SET capturedAt = CASE
          WHEN syncUpdatedAt != '' THEN syncUpdatedAt
          ELSE date || 'T00:00:00.000Z'
        END
        WHERE fileName != '' AND capturedAt = ''
      ''');
    }
  }

  Future<void> _seedData(Database db) async {
    // Seed bookings
    await db.insert('bookings', {
      'id': 'BH-001',
      'guest': 'Rahul Sharma',
      'phone': '9876543210',
      'guests': 2,
      'room': 'Room 2',
      'checkin': '2026-07-01',
      'checkout': '2026-07-04',
      'tariff': 2500.0,
      'extra': 500.0,
      'discount': 0.0,
      'status': 'Checked-out',
      'idTaken': 'Yes',
      'notes': 'Early check-in requested',
    });
    await db.insert('bookings', {
      'id': 'BH-002',
      'guest': 'Priya Mehta',
      'phone': '9123456780',
      'guests': 1,
      'room': 'Room 4',
      'checkin': '2026-07-05',
      'checkout': '2026-07-08',
      'tariff': 2200.0,
      'extra': 0.0,
      'discount': 200.0,
      'status': 'Checked-in',
      'idTaken': 'Yes',
      'notes': 'Vegetarian meals',
    });

    // Seed payments
    await db.insert('payments', {
      'date': '2026-07-01',
      'bookingId': 'BH-001',
      'amount': 3000.0,
      'mode': 'UPI',
      'type': 'Advance',
      'by': 'Rahul Sharma',
      'notes': 'GPay transfer',
    });
    await db.insert('payments', {
      'date': '2026-07-04',
      'bookingId': 'BH-001',
      'amount': 5000.0,
      'mode': 'Cash',
      'type': 'Balance',
      'by': 'Rahul Sharma',
      'notes': 'Checkout settlement',
    });
    await db.insert('payments', {
      'date': '2026-07-05',
      'bookingId': 'BH-002',
      'amount': 2000.0,
      'mode': 'UPI',
      'type': 'Advance',
      'by': 'Priya Mehta',
      'notes': 'PhonePe',
    });

    // Seed daily expenses
    await db.insert('daily_expenses', {
      'date': '2026-07-02',
      'head': 'Groceries / Provisions',
      'spentOn': 'Vegetables and fruits',
      'amount': 850.0,
      'vendor': 'Local market',
      'mode': 'Cash',
      'by': 'Raju (staff)',
      'notes': '',
    });
    await db.insert('daily_expenses', {
      'date': '2026-07-03',
      'head': 'Cleaning Supplies',
      'spentOn': 'Cleaning materials',
      'amount': 450.0,
      'vendor': 'Sharma Store',
      'mode': 'Cash',
      'by': 'Raju (staff)',
      'notes': '',
    });

    // Seed ID records
    await db.insert('id_records', {
      'date': '2026-07-01',
      'bookingId': 'BH-001',
      'idType': 'Aadhaar Card',
      'idNumber': 'XXXX-XXXX-3210',
      'copyType': 'Scanned',
      'fileName': 'rahul_aadhaar.jpg',
      'storage': 'Phone Gallery',
      'verified': 'Yes',
      'notes': '',
    });
    await db.insert('id_records', {
      'date': '2026-07-05',
      'bookingId': 'BH-002',
      'idType': 'PAN Card',
      'idNumber': 'XXXXX-1234',
      'copyType': 'Physical',
      'fileName': '',
      'storage': 'Front Desk File',
      'verified': 'No',
      'notes': 'Physical copy kept at desk',
    });

    // Seed monthly recurring expenses
    final monthlyHeads = [
      'Electricity',
      'Water Charges',
      'Internet / WiFi',
      'DTH / Cable TV',
      'LPG / Cooking Gas',
      'Staff Salary',
      'Housekeeping Wages',
      'Cook / Kitchen Wages',
      'Security Guard',
      'Laundry / Dry Cleaning',
      'Garbage / Waste Collection',
      'OTA / Booking Commission',
      'Software / App Subscription',
      'Professional / Accounting Fees',
      'Rent / Lease',
      'Pest Control',
    ];
    for (int i = 0; i < monthlyHeads.length; i++) {
      await db.insert('monthly_expenses', {
        'head': monthlyHeads[i],
        'desc': '',
        'payee': '',
        'amount': 0.0,
        'dueDay': 1,
        'autopay': 'No',
        'notes': '',
      });
    }

    // Seed yearly recurring expenses
    final yearlyHeads = [
      'Trade License',
      'FSSAI License',
      'Fire Safety / NOC',
      'Property Tax / Holding Tax',
      'Insurance Premium',
      'AC Service / Repair',
      'Website / Domain / Hosting',
      'Painting',
      'GST / Tax Payment',
      'Professional / Accounting Fees',
      'Pest Control',
      'Deep Cleaning',
      'Linen & Towels',
    ];
    for (int i = 0; i < yearlyHeads.length; i++) {
      await db.insert('yearly_expenses', {
        'head': yearlyHeads[i],
        'desc': '',
        'authority': '',
        'amount': 0.0,
        'dueMonth': 'Jan',
        'renewal': '',
        'reminder': 'No',
        'notes': '',
      });
    }

    // Mark seeded
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('db_seeded', true);
  }

  Future<void> _initializeFreshSyncMetadata(Database db) async {
    for (final table in _exportTables.where((name) => name != 'inventory')) {
      await _assignMissingSyncIds(db, table);
      await db.update(table, {'isExample': 1});
    }
  }

  Future<void> _upgradeSyncSchema(Database db) async {
    for (final table in syncTables) {
      final exists =
          Sqflite.firstIntValue(
            await db.rawQuery(
              "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=?",
              [table],
            ),
          ) ==
          1;
      if (!exists) continue;
      final columns = await db.rawQuery('PRAGMA table_info($table)');
      final names = columns.map((column) => column['name'] as String).toSet();
      if (!names.contains('syncId')) {
        await db.execute('ALTER TABLE $table ADD COLUMN syncId TEXT');
      }
      if (!names.contains('syncUpdatedAt')) {
        await db.execute(
          "ALTER TABLE $table ADD COLUMN syncUpdatedAt TEXT NOT NULL DEFAULT ''",
        );
      }
      if (!names.contains('isExample')) {
        await db.execute(
          'ALTER TABLE $table ADD COLUMN isExample INTEGER NOT NULL DEFAULT 0',
        );
      }
      await _assignMissingSyncIds(db, table);
      await db.execute(
        'CREATE UNIQUE INDEX IF NOT EXISTS idx_${table}_sync_id ON $table(syncId)',
      );
    }

    // Protect only the demonstration records shipped with earlier releases.
    await db.update(
      'bookings',
      {'isExample': 1},
      where:
          "id IN ('BH-001', 'BH-002') AND guest IN ('Rahul Sharma', 'Priya Mehta')",
    );
    await db.update(
      'payments',
      {'isExample': 1},
      where:
          "bookingId IN ('BH-001', 'BH-002') AND date BETWEEN '2026-07-01' AND '2026-07-05'",
    );
    await db.update(
      'daily_expenses',
      {'isExample': 1},
      where:
          "date IN ('2026-07-02', '2026-07-03') AND vendor IN ('Local market', 'Sharma Store')",
    );
    await db.update(
      'id_records',
      {'isExample': 1},
      where:
          "bookingId IN ('BH-001', 'BH-002') AND date BETWEEN '2026-07-01' AND '2026-07-05'",
    );
    await db.update('monthly_expenses', {
      'isExample': 1,
    }, where: "amount = 0 AND payee = '' AND desc = ''");
    await db.update('yearly_expenses', {
      'isExample': 1,
    }, where: "amount = 0 AND authority = '' AND desc = ''");
    await db.update(
      'inventory',
      {'isExample': 1},
      where:
          "room IN ('Room 1','Room 2','Room 3','Room 4','Room 5') AND "
          "itemName IN ('Air Freshener','Bath Towels','Bed Sheets',"
          "'Biscuit Packets','Blankets','Coffee Sachets','Conditioner Sachets',"
          "'Dustbin Bags','Floor Cleaner','Hand Towels','Mineral Water Bottles',"
          "'Mosquito Repellent','Pillow Covers','Shampoo Sachets','Soap Bars',"
          "'Sugar Sachets','Tea Bags','Toilet Cleaner','Toilet Paper Rolls',"
          "'Toothbrush Kits')",
    );
  }

  Future<void> _assignMissingSyncIds(Database db, String table) async {
    final key = _primaryKeys[table]!;
    final rows = await db.query(
      table,
      columns: [key],
      where: "syncId IS NULL OR syncId = ''",
    );
    final now = DateTime.now().toUtc().toIso8601String();
    for (final row in rows) {
      await db.update(
        table,
        {'syncId': _newSyncId(), 'syncUpdatedAt': now},
        where: '$key = ?',
        whereArgs: [row[key]],
      );
    }
  }

  String _newSyncId() {
    final bytes = List<int>.generate(16, (_) => Random.secure().nextInt(256));
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    final hex = bytes
        .map((byte) => byte.toRadixString(16).padLeft(2, '0'))
        .join();
    return '${hex.substring(0, 8)}-${hex.substring(8, 12)}-'
        '${hex.substring(12, 16)}-${hex.substring(16, 20)}-${hex.substring(20)}';
  }

  // ── Generic helpers ────────────────────────────────────────────────────────

  Future<List<Map<String, dynamic>>> query(
    String table, {
    String? where,
    List<dynamic>? whereArgs,
    String? orderBy,
  }) async {
    final db = await database;
    return db.query(
      table,
      where: where,
      whereArgs: whereArgs,
      orderBy: orderBy,
    );
  }

  Future<int> insert(String table, Map<String, dynamic> values) async {
    final db = await database;
    final storedValues = Map<String, dynamic>.from(values);
    if (syncTables.contains(table)) {
      final now = DateTime.now().toUtc().toIso8601String();
      storedValues.putIfAbsent('syncId', _newSyncId);
      storedValues['syncUpdatedAt'] = now;
      storedValues.putIfAbsent('isExample', () => 0);
    }
    final result = await db.insert(
      table,
      storedValues,
      conflictAlgorithm: ConflictAlgorithm.abort,
    );
    DataChangeService().markChanged();
    return result;
  }

  Future<String> nextAvailableBookingSerial(DateTime date) async {
    final db = await database;
    return _nextAvailableBookingSerial(db, _serialMonthKey(date));
  }

  Future<String> insertBookingWithNextSerial(
    Map<String, dynamic> values,
    DateTime date,
  ) async {
    final db = await database;
    late String serial;
    await db.transaction((txn) async {
      serial = await _nextAvailableBookingSerial(txn, _serialMonthKey(date));
      final storedValues = Map<String, dynamic>.from(values)
        ..['serialNumber'] = serial
        ..putIfAbsent('syncId', _newSyncId)
        ..['syncUpdatedAt'] = DateTime.now().toUtc().toIso8601String()
        ..putIfAbsent('isExample', () => 0);
      await txn.insert(
        'bookings',
        storedValues,
        conflictAlgorithm: ConflictAlgorithm.abort,
      );
    });
    DataChangeService().markChanged();
    return serial;
  }

  Future<String> _nextAvailableBookingSerial(
    DatabaseExecutor executor,
    String monthKey,
  ) async {
    final rows = await executor.query(
      'bookings',
      columns: ['serialNumber'],
      where: "serialNumber LIKE ? AND serialNumber != ''",
      whereArgs: ['%/$monthKey'],
    );
    final used = <int>{};
    for (final row in rows) {
      final parsed = _parseBookingSerial(row['serialNumber']?.toString());
      if (parsed != null && parsed.$2 == monthKey) used.add(parsed.$1);
    }
    var next = 1;
    while (used.contains(next)) {
      next++;
    }
    return '$next/$monthKey';
  }

  String _serialMonthKey(DateTime date) {
    final month = date.month.toString().padLeft(2, '0');
    return '$month-${date.year}';
  }

  (int, String)? _parseBookingSerial(String? value) {
    final match = RegExp(
      r'^(\d+)/(0[1-9]|1[0-2])-(\d{4})$',
    ).firstMatch(value?.trim() ?? '');
    if (match == null) return null;
    final number = int.tryParse(match.group(1)!);
    if (number == null || number < 1) return null;
    return (number, '${match.group(2)}-${match.group(3)}');
  }

  Future<void> _ensureUniqueBookingSerial(
    DatabaseExecutor executor,
    Map<String, dynamic> row,
  ) async {
    final parsed = _parseBookingSerial(row['serialNumber']?.toString());
    final collision = parsed == null
        ? const <Map<String, dynamic>>[]
        : await executor.query(
            'bookings',
            columns: ['id'],
            where: 'serialNumber = ?',
            whereArgs: [row['serialNumber']],
            limit: 1,
          );
    if (parsed == null || collision.isNotEmpty) {
      final monthKey = parsed?.$2 ?? _serialMonthKey(DateTime.now());
      row['serialNumber'] = await _nextAvailableBookingSerial(
        executor,
        monthKey,
      );
    }
  }

  Future<int> update(
    String table,
    Map<String, dynamic> values, {
    required String where,
    required List<dynamic> whereArgs,
  }) async {
    final db = await database;
    final storedValues = Map<String, dynamic>.from(values);
    if (syncTables.contains(table)) {
      storedValues['syncUpdatedAt'] = DateTime.now().toUtc().toIso8601String();
      storedValues.remove('syncId');
      storedValues.remove('isExample');
    }
    final result = await db.update(
      table,
      storedValues,
      where: where,
      whereArgs: whereArgs,
    );
    if (result > 0) DataChangeService().markChanged();
    return result;
  }

  Future<int> deleteAppUser(int id) async {
    final db = await database;
    return db.delete('app_users', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> delete(
    String table, {
    required String where,
    required List<dynamic> whereArgs,
  }) async {
    throw UnsupportedError(
      'Permanent deletion is disabled. Move records to Trash instead.',
    );
  }

  Future<List<Map<String, dynamic>>> rawQuery(
    String sql, [
    List<dynamic>? args,
  ]) async {
    final db = await database;
    return db.rawQuery(sql, args);
  }

  Future<void> moveToTrash({
    required String table,
    required String keyColumn,
    required Object keyValue,
    required String deletedBy,
    DateTime? deletedAt,
    bool allowExample = false,
  }) async {
    if (!syncTables.contains(table)) {
      throw ArgumentError('Trash is not supported for $table');
    }
    final db = await database;
    await db.transaction((txn) async {
      if (table == 'bookings') {
        final bookingRows = await txn.query(
          table,
          where: '$keyColumn = ?',
          whereArgs: [keyValue],
          limit: 1,
        );
        if (bookingRows.isEmpty) return;
        final bookingId = bookingRows.first['id'];
        for (final childTable in ['payments', 'id_records']) {
          final children = await txn.query(
            childTable,
            where: 'bookingId = ?',
            whereArgs: [bookingId],
          );
          for (final child in children) {
            await _moveRowToTrash(
              txn,
              childTable,
              child,
              deletedBy,
              deletedAt: deletedAt,
              allowExample: allowExample,
            );
          }
        }
      }
      final rows = await txn.query(
        table,
        where: '$keyColumn = ?',
        whereArgs: [keyValue],
        limit: 1,
      );
      if (rows.isEmpty) return;
      await _moveRowToTrash(
        txn,
        table,
        rows.first,
        deletedBy,
        deletedAt: deletedAt,
        allowExample: allowExample,
      );
    });
    DataChangeService().markChanged();
  }

  Future<void> _moveRowToTrash(
    Transaction txn,
    String table,
    Map<String, dynamic> row,
    String deletedBy, {
    DateTime? deletedAt,
    bool allowExample = false,
  }) async {
    if ((row['isExample'] as int? ?? 0) == 1 && !allowExample) {
      throw StateError('Example records are protected and cannot be deleted.');
    }
    final keyColumn = _primaryKeys[table]!;
    final syncId = row['syncId'] as String?;
    if (syncId == null || syncId.isEmpty) {
      throw StateError('This record is not ready for synchronization.');
    }
    final removedAt = (deletedAt ?? DateTime.now()).toUtc();
    final expiresAt = IdRetentionPolicy.trashExpiry(
      table: table,
      row: row,
      deletedAt: removedAt,
    );
    await txn.insert('trash_entries', {
      'syncId': syncId,
      'entityType': table,
      'originalKey': row[keyColumn].toString(),
      'payload': jsonEncode(row),
      'deletedAt': removedAt.toIso8601String(),
      'deletedBy': deletedBy,
      'expiresAt': expiresAt.toIso8601String(),
    }, conflictAlgorithm: ConflictAlgorithm.replace);
    await txn.delete(
      table,
      where: '$keyColumn = ?',
      whereArgs: [row[keyColumn]],
    );
  }

  Future<List<Map<String, dynamic>>> getTrashEntries() async {
    final db = await database;
    return db.query('trash_entries', orderBy: 'deletedAt DESC');
  }

  Future<void> restoreFromTrash(String syncId) async {
    final db = await database;
    await db.transaction((txn) async {
      final entries = await txn.query(
        'trash_entries',
        where: 'syncId = ?',
        whereArgs: [syncId],
        limit: 1,
      );
      if (entries.isEmpty) return;
      final entry = entries.first;
      final expiresAt = DateTime.parse(entry['expiresAt'] as String);
      if (!expiresAt.isAfter(DateTime.now().toUtc())) {
        throw StateError(
          'This item has reached the end of its recovery period.',
        );
      }
      final bookingIds = await _restoreTrashEntry(txn, entry);
      if (entry['entityType'] == 'bookings') {
        final children = await txn.query(
          'trash_entries',
          where: "entityType IN ('payments', 'id_records')",
        );
        for (final child in children) {
          final payload = jsonDecode(child['payload'] as String) as Map;
          if (payload['bookingId']?.toString() == bookingIds.$1) {
            await _restoreTrashEntry(
              txn,
              child,
              restoredBookingId: bookingIds.$2,
            );
          }
        }
      }
    });
    DataChangeService().markChanged();
  }

  Future<(String?, String?)> _restoreTrashEntry(
    Transaction txn,
    Map<String, dynamic> entry, {
    String? restoredBookingId,
  }) async {
    final table = entry['entityType'] as String;
    final row = Map<String, dynamic>.from(
      jsonDecode(entry['payload'] as String) as Map,
    );
    final originalBookingId = table == 'bookings'
        ? row['id']?.toString()
        : row['bookingId']?.toString();
    if (restoredBookingId != null) row['bookingId'] = restoredBookingId;
    row['syncUpdatedAt'] = DateTime.now().toUtc().toIso8601String();
    row['isExample'] = 0;
    if (table == 'bookings') {
      final desiredId = row['id']?.toString() ?? 'BH-RESTORED';
      final collision = await txn.query(
        table,
        columns: ['id'],
        where: 'id = ?',
        whereArgs: [desiredId],
        limit: 1,
      );
      if (collision.isNotEmpty) {
        row['id'] = '$desiredId-R${entry['syncId'].toString().substring(0, 4)}';
      }
      await _ensureUniqueBookingSerial(txn, row);
      await txn.insert(table, row, conflictAlgorithm: ConflictAlgorithm.abort);
    } else {
      try {
        await txn.insert(
          table,
          row,
          conflictAlgorithm: ConflictAlgorithm.abort,
        );
      } on DatabaseException {
        row.remove('id');
        await txn.insert(
          table,
          row,
          conflictAlgorithm: ConflictAlgorithm.abort,
        );
      }
    }
    await txn.delete(
      'trash_entries',
      where: 'syncId = ?',
      whereArgs: [entry['syncId']],
    );
    return (
      originalBookingId,
      table == 'bookings' ? row['id']?.toString() : restoredBookingId,
    );
  }

  Future<List<Map<String, dynamic>>> purgeExpiredTrash() async {
    final db = await database;
    final now = DateTime.now().toUtc().toIso8601String();
    final expired = await db.query(
      'trash_entries',
      where: 'expiresAt <= ?',
      whereArgs: [now],
    );
    if (expired.isEmpty) return const [];
    await db.transaction((txn) async {
      for (final entry in expired) {
        await txn.insert('purged_records', {
          'syncId': entry['syncId'],
          'purgedAt': now,
        }, conflictAlgorithm: ConflictAlgorithm.ignore);
        await txn.delete(
          'trash_entries',
          where: 'syncId = ?',
          whereArgs: [entry['syncId']],
        );
      }
    });
    DataChangeService().markChanged();
    return expired;
  }

  Future<List<Map<String, dynamic>>> getLocalSyncRecords() async {
    final db = await database;
    final records = <Map<String, dynamic>>[];
    for (final table in syncTables) {
      final exists =
          Sqflite.firstIntValue(
            await db.rawQuery(
              "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=?",
              [table],
            ),
          ) ==
          1;
      if (!exists) continue;
      final rows = await db.query(table, where: 'isExample = 0');
      for (final row in rows) {
        records.add({
          'record_id': row['syncId'],
          'entity_type': table,
          'payload': await _cloudPayload(db, table, row),
          'updated_at': row['syncUpdatedAt'],
          'deleted_at': null,
          'deleted_by': null,
        });
      }
    }
    for (final entry in await db.query('trash_entries')) {
      final table = entry['entityType'] as String;
      final payload = Map<String, dynamic>.from(
        jsonDecode(entry['payload'] as String) as Map,
      );
      records.add({
        'record_id': entry['syncId'],
        'entity_type': table,
        'payload': await _cloudPayload(db, table, payload),
        'updated_at': entry['deletedAt'],
        'deleted_at': entry['deletedAt'],
        'deleted_by': entry['deletedBy'],
      });
    }
    return records;
  }

  Future<Map<String, dynamic>> _cloudPayload(
    Database db,
    String table,
    Map<String, dynamic> source,
  ) async {
    final payload = Map<String, dynamic>.from(source)
      ..remove('isExample')
      ..remove('syncUpdatedAt')
      ..remove('syncId');
    if (table != 'bookings') payload.remove('id');
    if (table == 'bookings') {
      payload
        ..remove('idFrontPath')
        ..remove('idBackPath');
    } else if (table == 'id_records') {
      payload
        ..remove('fileName')
        ..remove('storage');
    }
    if (table == 'payments' || table == 'id_records') {
      payload['booking_sync_id'] = await _bookingSyncIdForLocalId(
        db,
        source['bookingId']?.toString() ?? '',
      );
    }
    return payload;
  }

  Future<String?> _bookingSyncIdForLocalId(
    Database db,
    String bookingId,
  ) async {
    final active = await db.query(
      'bookings',
      columns: ['syncId'],
      where: 'id = ?',
      whereArgs: [bookingId],
      limit: 1,
    );
    if (active.isNotEmpty) return active.first['syncId'] as String?;
    final deleted = await db.query(
      'trash_entries',
      columns: ['syncId', 'payload'],
      where: "entityType = 'bookings'",
    );
    for (final entry in deleted) {
      final payload = jsonDecode(entry['payload'] as String) as Map;
      if (payload['id']?.toString() == bookingId) {
        return entry['syncId'] as String?;
      }
    }
    return null;
  }

  Future<List<String>> getPurgedSyncIds() async {
    final db = await database;
    final rows = await db.query('purged_records', columns: ['syncId']);
    return rows.map((row) => row['syncId'] as String).toList();
  }

  Future<List<Map<String, dynamic>>> getLocalPurgedRecords() async {
    final db = await database;
    final rows = await db.query(
      'purged_records',
      columns: ['syncId', 'purgedAt'],
      orderBy: 'purgedAt ASC, syncId ASC',
    );
    return rows
        .map(
          (row) => {'record_id': row['syncId'], 'purged_at': row['purgedAt']},
        )
        .toList();
  }

  Future<bool> applyRemoteSyncRecords(
    List<Map<String, dynamic>> remoteRecords,
  ) async {
    final priority = <String, int>{
      'bookings': 0,
      'daily_expenses': 1,
      'monthly_expenses': 1,
      'yearly_expenses': 1,
      'inventory': 1,
      'seasonal_rates': 1,
      'payments': 2,
      'id_records': 2,
    };
    remoteRecords.sort(
      (a, b) => (priority[a['entity_type']] ?? 9).compareTo(
        priority[b['entity_type']] ?? 9,
      ),
    );
    final db = await database;
    var changed = false;
    await db.transaction((txn) async {
      for (final record in remoteRecords) {
        changed = await _applyRemoteRecord(txn, record) || changed;
      }
    });
    if (changed) DataChangeService().markChanged();
    return changed;
  }

  Future<bool> _applyRemoteRecord(
    Transaction txn,
    Map<String, dynamic> record,
  ) async {
    final table = record['entity_type'] as String?;
    final syncId = record['record_id'] as String?;
    if (table == null ||
        syncId == null ||
        !syncTables.contains(table) ||
        !SyncPayloadValidator.isValidSyncId(syncId)) {
      return false;
    }
    final validatedPayload = SyncPayloadValidator.validate(
      table,
      record['payload'],
    );
    if (validatedPayload == null) return false;
    final wasPurged = await txn.query(
      'purged_records',
      columns: ['syncId'],
      where: 'syncId = ?',
      whereArgs: [syncId],
      limit: 1,
    );
    if (wasPurged.isNotEmpty) return false;

    final updatedAt =
        DateTime.tryParse(record['updated_at']?.toString() ?? '')?.toUtc() ??
        DateTime.fromMillisecondsSinceEpoch(0, isUtc: true);
    final active = await txn.query(
      table,
      where: 'syncId = ?',
      whereArgs: [syncId],
      limit: 1,
    );
    final trash = await txn.query(
      'trash_entries',
      where: 'syncId = ?',
      whereArgs: [syncId],
      limit: 1,
    );
    final deletedAtValue = record['deleted_at']?.toString();
    if (deletedAtValue != null && deletedAtValue.isNotEmpty) {
      final deletedAt = DateTime.parse(deletedAtValue).toUtc();
      var changed = false;
      if (active.isNotEmpty) {
        final localUpdated =
            DateTime.tryParse(
              active.first['syncUpdatedAt']?.toString() ?? '',
            )?.toUtc() ??
            DateTime.fromMillisecondsSinceEpoch(0, isUtc: true);
        if (!localUpdated.isAfter(updatedAt) &&
            (active.first['isExample'] as int? ?? 0) == 0) {
          await _moveRowToTrash(
            txn,
            table,
            active.first,
            record['deleted_by']?.toString() ?? 'Administrator',
            deletedAt: deletedAt,
          );
          changed = true;
        }
      } else if (trash.isEmpty) {
        final payload = Map<String, dynamic>.from(validatedPayload);
        payload['syncId'] = syncId;
        payload['syncUpdatedAt'] = updatedAt.toIso8601String();
        payload['isExample'] = 0;
        await txn.insert('trash_entries', {
          'syncId': syncId,
          'entityType': table,
          'originalKey': payload[_primaryKeys[table]]?.toString() ?? syncId,
          'payload': jsonEncode(payload),
          'deletedAt': deletedAt.toIso8601String(),
          'deletedBy': record['deleted_by']?.toString() ?? 'Administrator',
          'expiresAt': deletedAt.add(const Duration(days: 7)).toIso8601String(),
        });
        changed = true;
      }
      return changed;
    }

    var changed = false;
    if (trash.isNotEmpty) {
      final localDeletedAt = DateTime.parse(
        trash.first['deletedAt'] as String,
      ).toUtc();
      if (!updatedAt.isAfter(localDeletedAt)) return false;
      await txn.delete(
        'trash_entries',
        where: 'syncId = ?',
        whereArgs: [syncId],
      );
      changed = true;
    }
    if (active.isNotEmpty) {
      final localUpdated =
          DateTime.tryParse(
            active.first['syncUpdatedAt']?.toString() ?? '',
          )?.toUtc() ??
          DateTime.fromMillisecondsSinceEpoch(0, isUtc: true);
      if (!updatedAt.isAfter(localUpdated)) return changed;
    }

    final payload = Map<String, dynamic>.from(validatedPayload);
    final bookingSyncId = payload.remove('booking_sync_id')?.toString();
    if (bookingSyncId != null && bookingSyncId.isNotEmpty) {
      final parent = await txn.query(
        'bookings',
        columns: ['id'],
        where: 'syncId = ?',
        whereArgs: [bookingSyncId],
        limit: 1,
      );
      if (parent.isEmpty) return changed;
      payload['bookingId'] = parent.first['id'];
    }
    final columns = await txn.rawQuery('PRAGMA table_info($table)');
    final allowed = columns.map((column) => column['name'] as String).toSet();
    payload.removeWhere((key, value) => !allowed.contains(key));
    payload['syncId'] = syncId;
    payload['syncUpdatedAt'] = updatedAt.toIso8601String();
    payload['isExample'] = 0;

    if (active.isNotEmpty) {
      if (table == 'bookings') {
        payload['idFrontPath'] = active.first['idFrontPath'];
        payload['idBackPath'] = active.first['idBackPath'];
        payload['serialNumber'] = active.first['serialNumber'];
        payload.remove('id');
      } else if (table == 'id_records') {
        payload['fileName'] = active.first['fileName'];
        payload['storage'] = active.first['storage'];
      }
      await txn.update(
        table,
        payload,
        where: 'syncId = ?',
        whereArgs: [syncId],
      );
      return true;
    }

    if (table != 'bookings') payload.remove('id');
    if (table == 'bookings') {
      payload['idFrontPath'] = '';
      payload['idBackPath'] = '';
      final requestedId = payload['id']?.toString() ?? 'BH-CLOUD';
      final collision = await txn.query(
        'bookings',
        columns: ['id'],
        where: 'id = ?',
        whereArgs: [requestedId],
        limit: 1,
      );
      if (collision.isNotEmpty) {
        payload['id'] = '$requestedId-${syncId.substring(0, 4).toUpperCase()}';
      }
      await _ensureUniqueBookingSerial(txn, payload);
    } else if (table == 'id_records') {
      payload['fileName'] = '';
      payload['storage'] = '';
    }
    await txn.insert(
      table,
      payload,
      conflictAlgorithm: ConflictAlgorithm.abort,
    );
    return true;
  }

  Future<bool> applyRemotePurges(List<String> syncIds) async {
    if (syncIds.isEmpty) return false;
    final db = await database;
    final now = DateTime.now().toUtc().toIso8601String();
    var changed = false;
    await db.transaction((txn) async {
      for (final syncId in syncIds) {
        final existingMarker = await txn.query(
          'purged_records',
          columns: ['syncId'],
          where: 'syncId = ?',
          whereArgs: [syncId],
          limit: 1,
        );
        for (final table in syncTables) {
          final deleted = await txn.delete(
            table,
            where: 'syncId = ?',
            whereArgs: [syncId],
          );
          changed = deleted > 0 || changed;
        }
        final deletedTrash = await txn.delete(
          'trash_entries',
          where: 'syncId = ?',
          whereArgs: [syncId],
        );
        changed = deletedTrash > 0 || changed;
        if (existingMarker.isEmpty) {
          await txn.insert('purged_records', {
            'syncId': syncId,
            'purgedAt': now,
          });
          changed = true;
        }
      }
    });
    if (changed) DataChangeService().markChanged();
    return changed;
  }

  // ── Full export for backup ─────────────────────────────────────────────────
  Future<Map<String, dynamic>> exportAll() async {
    final db = await database;
    final backup = <String, dynamic>{
      'version': 4,
      'encryptedAtRest': true,
      'exportedAt': DateTime.now().toIso8601String(),
    };
    for (final table in _backupTables) {
      backup[table] = await db.query(table);
    }
    return backup;
  }

  Future<void> mergeSyncData(Map<String, dynamic> data) async {
    final version = data['version'];
    if (version is! int || version < 1 || version > 4) {
      throw const FormatException('Unsupported cloud data version');
    }
    final db = await database;
    await db.transaction((txn) async {
      for (final table in _exportTables) {
        final incomingRows = data[table];
        if (incomingRows is! List) continue;
        for (final value in incomingRows) {
          final row = Map<String, dynamic>.from(value as Map);
          if (table == 'bookings') {
            final existing = await txn.query(
              'bookings',
              columns: ['idFrontPath', 'idBackPath'],
              where: 'id = ?',
              whereArgs: [row['id']],
              limit: 1,
            );
            if (existing.isNotEmpty) {
              final localFront = existing.first['idFrontPath'] as String? ?? '';
              final localBack = existing.first['idBackPath'] as String? ?? '';
              if (localFront.isNotEmpty) row['idFrontPath'] = localFront;
              if (localBack.isNotEmpty) row['idBackPath'] = localBack;
            } else {
              row['idFrontPath'] = '';
              row['idBackPath'] = '';
            }
          }
          if (table == 'yearly_expenses') {
            row['dueMonth'] = _normalizeDueMonth(row['dueMonth']);
          }
          await txn.insert(
            table,
            row,
            conflictAlgorithm: ConflictAlgorithm.replace,
          );
        }
      }
    });
    await _upgradeSyncSchema(db);
  }

  // ── Full import for restore ────────────────────────────────────────────────
  Future<void> validateBackup(Map<String, dynamic> data) async {
    _parseBackupSnapshot(data);
  }

  Future<void> importAll(Map<String, dynamic> data) async {
    final db = await database;
    final snapshot = _parseBackupSnapshot(data);
    await _replaceAllRows(db, snapshot);
  }

  Map<String, List<Map<String, dynamic>>> _parseBackupSnapshot(
    Map<String, dynamic> data,
  ) {
    final version = data['version'];
    if (version is! int || version < 1 || version > 4) {
      throw const FormatException('Unsupported backup version');
    }
    final requiredTables = version >= 4
        ? _backupTables
        : version >= 3
        ? _exportTables
        : _exportTables.where((table) => table != 'inventory');
    for (final table in requiredTables) {
      if (data[table] is! List) {
        throw FormatException('Backup is missing $table');
      }
    }

    final snapshot = <String, List<Map<String, dynamic>>>{};
    for (final table in _backupTables) {
      final rows = data[table] as List<dynamic>? ?? const [];
      if (rows.length > 100000) {
        throw FormatException('Backup contains too many $table records');
      }
      snapshot[table] = rows.map((row) {
        if (row is! Map) {
          throw FormatException('Backup contains an invalid $table record');
        }
        final parsed = <String, dynamic>{};
        for (final entry in row.entries) {
          final key = entry.key;
          final value = entry.value;
          if (key is! String || key.length > 64) {
            throw FormatException('Backup contains an invalid $table field');
          }
          if (value is num && !value.isFinite) {
            throw FormatException('Backup contains an invalid $table number');
          }
          if (value != null &&
              value is! String &&
              value is! num &&
              value is! bool) {
            throw FormatException('Backup contains nested $table data');
          }
          if (value is String && value.length > 20000) {
            throw FormatException('Backup contains an oversized $table value');
          }
          parsed[key] = value;
        }
        return parsed;
      }).toList();
    }
    return snapshot;
  }

  Future<void> _replaceAllRows(
    Database db,
    Map<String, List<Map<String, dynamic>>> snapshot,
  ) async {
    await db.transaction((txn) async {
      for (final table in [
        'trash_entries',
        'purged_records',
        'payments',
        'id_records',
        'daily_expenses',
        'monthly_expenses',
        'yearly_expenses',
        'inventory',
        'seasonal_rates',
        'bookings',
      ]) {
        await txn.delete(table);
      }

      for (final table in _backupTables) {
        for (final row in snapshot[table] ?? const []) {
          final values = Map<String, dynamic>.from(row);
          if (table == 'yearly_expenses') {
            values['dueMonth'] = _normalizeDueMonth(values['dueMonth']);
          }
          await txn.insert(
            table,
            values,
            conflictAlgorithm: ConflictAlgorithm.abort,
          );
        }
      }
    });
    await _upgradeSyncSchema(db);
  }

  String _normalizeDueMonth(dynamic value) {
    const months = {
      'January': 'Jan',
      'February': 'Feb',
      'March': 'Mar',
      'April': 'Apr',
      'June': 'Jun',
      'July': 'Jul',
      'August': 'Aug',
      'September': 'Sep',
      'October': 'Oct',
      'November': 'Nov',
      'December': 'Dec',
    };
    final month = value?.toString() ?? 'Jan';
    return months[month] ?? month;
  }
}
