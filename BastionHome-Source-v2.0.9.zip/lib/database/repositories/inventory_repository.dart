import 'package:sqflite_sqlcipher/sqflite.dart';
import '../database_helper.dart';
import '../../services/trash_service.dart';

class InventoryItem {
  final int? id;
  final String room;
  final String category;
  final String itemName;
  final int currentStock;
  final int minStock;
  final int reorderQty;
  final String unit;
  final String notes;
  final String updatedAt;

  InventoryItem({
    this.id,
    required this.room,
    required this.category,
    required this.itemName,
    required this.currentStock,
    required this.minStock,
    required this.reorderQty,
    required this.unit,
    this.notes = '',
    required this.updatedAt,
  });

  bool get isLowStock => currentStock <= minStock;
  bool get isOutOfStock => currentStock == 0;

  Map<String, dynamic> toMap() => {
    if (id != null) 'id': id,
    'room': room,
    'category': category,
    'itemName': itemName,
    'currentStock': currentStock,
    'minStock': minStock,
    'reorderQty': reorderQty,
    'unit': unit,
    'notes': notes,
    'updatedAt': updatedAt,
  };

  factory InventoryItem.fromMap(Map<String, dynamic> map) => InventoryItem(
    id: map['id'] as int?,
    room: map['room'] as String,
    category: map['category'] as String,
    itemName: map['itemName'] as String,
    currentStock: map['currentStock'] as int,
    minStock: map['minStock'] as int,
    reorderQty: map['reorderQty'] as int,
    unit: map['unit'] as String,
    notes: map['notes'] as String? ?? '',
    updatedAt: map['updatedAt'] as String,
  );

  InventoryItem copyWith({
    int? id,
    String? room,
    String? category,
    String? itemName,
    int? currentStock,
    int? minStock,
    int? reorderQty,
    String? unit,
    String? notes,
    String? updatedAt,
  }) => InventoryItem(
    id: id ?? this.id,
    room: room ?? this.room,
    category: category ?? this.category,
    itemName: itemName ?? this.itemName,
    currentStock: currentStock ?? this.currentStock,
    minStock: minStock ?? this.minStock,
    reorderQty: reorderQty ?? this.reorderQty,
    unit: unit ?? this.unit,
    notes: notes ?? this.notes,
    updatedAt: updatedAt ?? this.updatedAt,
  );
}

class InventoryRepository {
  final DatabaseHelper _db = DatabaseHelper();

  static const String _table = 'inventory';

  Future<void> ensureTable() async {
    final db = await _db.database;
    await db.execute('''
      CREATE TABLE IF NOT EXISTS $_table (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        room TEXT NOT NULL,
        category TEXT NOT NULL,
        itemName TEXT NOT NULL,
        currentStock INTEGER DEFAULT 0,
        minStock INTEGER DEFAULT 1,
        reorderQty INTEGER DEFAULT 5,
        unit TEXT DEFAULT 'pcs',
        notes TEXT DEFAULT '',
        updatedAt TEXT NOT NULL,
        syncId TEXT,
        syncUpdatedAt TEXT NOT NULL DEFAULT '',
        isExample INTEGER NOT NULL DEFAULT 0
      )
    ''');

    // Seed default items if table is empty
    final count = Sqflite.firstIntValue(
      await db.rawQuery('SELECT COUNT(*) FROM $_table'),
    );
    if (count == 0) {
      await _seedDefaults(db);
    }
  }

  Future<void> _seedDefaults(Database db) async {
    final now = DateTime.now().toIso8601String();
    final rooms = ['Room 1', 'Room 2', 'Room 3', 'Room 4', 'Room 5'];

    final defaultItems = [
      // Linens
      {
        'category': 'Linens',
        'itemName': 'Bed Sheets',
        'minStock': 2,
        'reorderQty': 4,
        'unit': 'sets',
        'currentStock': 4,
      },
      {
        'category': 'Linens',
        'itemName': 'Pillow Covers',
        'minStock': 4,
        'reorderQty': 8,
        'unit': 'pcs',
        'currentStock': 6,
      },
      {
        'category': 'Linens',
        'itemName': 'Bath Towels',
        'minStock': 2,
        'reorderQty': 4,
        'unit': 'pcs',
        'currentStock': 3,
      },
      {
        'category': 'Linens',
        'itemName': 'Hand Towels',
        'minStock': 2,
        'reorderQty': 4,
        'unit': 'pcs',
        'currentStock': 2,
      },
      {
        'category': 'Linens',
        'itemName': 'Blankets',
        'minStock': 1,
        'reorderQty': 2,
        'unit': 'pcs',
        'currentStock': 2,
      },
      // Toiletries
      {
        'category': 'Toiletries',
        'itemName': 'Soap Bars',
        'minStock': 2,
        'reorderQty': 6,
        'unit': 'pcs',
        'currentStock': 4,
      },
      {
        'category': 'Toiletries',
        'itemName': 'Shampoo Sachets',
        'minStock': 3,
        'reorderQty': 10,
        'unit': 'pcs',
        'currentStock': 5,
      },
      {
        'category': 'Toiletries',
        'itemName': 'Toilet Paper Rolls',
        'minStock': 2,
        'reorderQty': 6,
        'unit': 'rolls',
        'currentStock': 3,
      },
      {
        'category': 'Toiletries',
        'itemName': 'Toothbrush Kits',
        'minStock': 2,
        'reorderQty': 5,
        'unit': 'kits',
        'currentStock': 1,
      },
      {
        'category': 'Toiletries',
        'itemName': 'Conditioner Sachets',
        'minStock': 2,
        'reorderQty': 8,
        'unit': 'pcs',
        'currentStock': 3,
      },
      // Supplies
      {
        'category': 'Supplies',
        'itemName': 'Dustbin Bags',
        'minStock': 5,
        'reorderQty': 20,
        'unit': 'pcs',
        'currentStock': 8,
      },
      {
        'category': 'Supplies',
        'itemName': 'Floor Cleaner',
        'minStock': 1,
        'reorderQty': 2,
        'unit': 'bottles',
        'currentStock': 2,
      },
      {
        'category': 'Supplies',
        'itemName': 'Toilet Cleaner',
        'minStock': 1,
        'reorderQty': 2,
        'unit': 'bottles',
        'currentStock': 1,
      },
      {
        'category': 'Supplies',
        'itemName': 'Air Freshener',
        'minStock': 1,
        'reorderQty': 2,
        'unit': 'cans',
        'currentStock': 0,
      },
      {
        'category': 'Supplies',
        'itemName': 'Mosquito Repellent',
        'minStock': 1,
        'reorderQty': 2,
        'unit': 'pcs',
        'currentStock': 2,
      },
      // Pantry
      {
        'category': 'Pantry',
        'itemName': 'Tea Bags',
        'minStock': 5,
        'reorderQty': 20,
        'unit': 'pcs',
        'currentStock': 10,
      },
      {
        'category': 'Pantry',
        'itemName': 'Coffee Sachets',
        'minStock': 5,
        'reorderQty': 20,
        'unit': 'pcs',
        'currentStock': 4,
      },
      {
        'category': 'Pantry',
        'itemName': 'Sugar Sachets',
        'minStock': 10,
        'reorderQty': 30,
        'unit': 'pcs',
        'currentStock': 12,
      },
      {
        'category': 'Pantry',
        'itemName': 'Mineral Water Bottles',
        'minStock': 2,
        'reorderQty': 6,
        'unit': 'bottles',
        'currentStock': 3,
      },
      {
        'category': 'Pantry',
        'itemName': 'Biscuit Packets',
        'minStock': 2,
        'reorderQty': 6,
        'unit': 'pkts',
        'currentStock': 1,
      },
    ];

    final batch = db.batch();
    for (final room in rooms) {
      for (final item in defaultItems) {
        batch.insert(_table, {
          'room': room,
          'category': item['category'],
          'itemName': item['itemName'],
          'currentStock': item['currentStock'],
          'minStock': item['minStock'],
          'reorderQty': item['reorderQty'],
          'unit': item['unit'],
          'notes': '',
          'updatedAt': now,
          'syncId':
              'example-inventory-${room.replaceAll(' ', '-').toLowerCase()}-${item['itemName'].toString().replaceAll(' ', '-').toLowerCase()}',
          'syncUpdatedAt': now,
          'isExample': 1,
        });
      }
    }
    await batch.commit(noResult: true);
  }

  Future<List<InventoryItem>> getByRoom(String room) async {
    await ensureTable();
    final db = await _db.database;
    final maps = await db.query(
      _table,
      where: 'room = ?',
      whereArgs: [room],
      orderBy: 'category ASC, itemName ASC',
    );
    return maps.map(InventoryItem.fromMap).toList();
  }

  Future<List<InventoryItem>> getLowStockItems() async {
    await ensureTable();
    final db = await _db.database;
    final maps = await db.rawQuery(
      'SELECT * FROM $_table WHERE currentStock <= minStock ORDER BY currentStock ASC, room ASC',
    );
    return maps.map(InventoryItem.fromMap).toList();
  }

  Future<List<InventoryItem>> getAllItems() async {
    await ensureTable();
    final db = await _db.database;
    final maps = await db.query(
      _table,
      orderBy: 'room ASC, category ASC, itemName ASC',
    );
    return maps.map(InventoryItem.fromMap).toList();
  }

  Future<int> insert(InventoryItem item) async {
    await ensureTable();
    return _db.insert(_table, item.toMap());
  }

  Future<int> update(InventoryItem item) async {
    await ensureTable();
    return _db.update(
      _table,
      item.toMap(),
      where: 'id = ?',
      whereArgs: [item.id],
    );
  }

  Future<int> delete(int id) async {
    await ensureTable();
    await TrashService().deleteRecord(
      table: _table,
      keyColumn: 'id',
      keyValue: id,
    );
    return 1;
  }

  Future<int> updateStock(int id, int newStock) async {
    await ensureTable();
    return _db.update(
      _table,
      {'currentStock': newStock, 'updatedAt': DateTime.now().toIso8601String()},
      where: 'id = ?',
      whereArgs: [id],
    );
  }
}
