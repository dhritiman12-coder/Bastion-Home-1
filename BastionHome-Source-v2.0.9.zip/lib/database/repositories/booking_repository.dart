import '../database_helper.dart';
import '../../services/trash_service.dart';
import '../../models/booking_model.dart';

class BookingRepository {
  final DatabaseHelper _db = DatabaseHelper();

  Future<List<BookingModel>> getAllBookings() async {
    return _queryWithReceived(orderBy: 'b.checkin DESC');
  }

  Future<BookingModel?> getBookingById(String id) async {
    final rows = await _queryWithReceived(where: 'b.id = ?', whereArgs: [id]);
    if (rows.isEmpty) return null;
    return rows.first;
  }

  Future<List<BookingModel>> _queryWithReceived({
    String? where,
    List<Object?> whereArgs = const [],
    String? orderBy,
  }) async {
    final rows = await _db.rawQuery('''
      SELECT b.*, COALESCE(SUM(p.amount), 0) AS received
      FROM bookings b
      LEFT JOIN payments p ON p.bookingId = b.id
      ${where == null ? '' : 'WHERE $where'}
      GROUP BY b.id
      ${orderBy == null ? '' : 'ORDER BY $orderBy'}
      ''', whereArgs);
    return rows.map(BookingModel.fromMap).toList();
  }

  Future<List<BookingModel>> getBookingsForMonth(int year, int month) async {
    final start = '$year-${month.toString().padLeft(2, '0')}-01';
    final end = DateTime(year, month + 1, 1).toIso8601String().split('T').first;
    return _queryWithReceived(
      where:
          "b.checkin < ? AND b.checkout > ? AND b.status NOT IN ('Cancelled', 'No-show')",
      whereArgs: [end, start],
      orderBy: 'b.checkin DESC',
    );
  }

  Future<List<BookingModel>> getActiveBookingsOnDate(DateTime date) async {
    final dateStr = date.toIso8601String().split('T').first;
    return _queryWithReceived(
      where:
          "b.checkin <= ? AND b.checkout > ? AND b.status NOT IN ('Cancelled', 'No-show')",
      whereArgs: [dateStr, dateStr],
    );
  }

  Future<List<BookingModel>> getBookingsForOccupancy(
    int year,
    int month,
  ) async {
    final monthStart = DateTime(year, month, 1);
    final monthEnd = DateTime(year, month + 1, 1);
    final startStr = monthStart.toIso8601String().split('T').first;
    final endStr = monthEnd.toIso8601String().split('T').first;
    return _queryWithReceived(
      where:
          "b.checkin < ? AND b.checkout > ? AND b.status NOT IN ('Cancelled', 'No-show')",
      whereArgs: [endStr, startStr],
    );
  }

  Future<String> suggestNextId() async {
    final rows = await _db.rawQuery(
      "SELECT id FROM bookings WHERE id LIKE 'BH-%' ORDER BY CAST(SUBSTR(id, 4) AS INTEGER) DESC LIMIT 1",
    );
    if (rows.isEmpty) return 'BH-001';
    final lastId = rows.first['id'] as String;
    final num = int.tryParse(lastId.replaceAll('BH-', '')) ?? 0;
    return 'BH-${(num + 1).toString().padLeft(3, '0')}';
  }

  Future<bool> isIdUnique(String id) async {
    final rows = await _db.query('bookings', where: 'id = ?', whereArgs: [id]);
    return rows.isEmpty;
  }

  Future<bool> hasOverlap(
    String room,
    DateTime checkin,
    DateTime checkout, {
    String? excludeId,
  }) async {
    final checkinStr = checkin.toIso8601String().split('T').first;
    final checkoutStr = checkout.toIso8601String().split('T').first;
    String where =
        "room = ? AND checkin < ? AND checkout > ? AND status NOT IN ('Cancelled', 'No-show')";
    List<dynamic> args = [room, checkoutStr, checkinStr];
    if (excludeId != null) {
      where += ' AND id != ?';
      args.add(excludeId);
    }
    final rows = await _db.query('bookings', where: where, whereArgs: args);
    return rows.isNotEmpty;
  }

  Future<void> insertBooking(BookingModel b) async {
    if (b.idNumber.trim().isEmpty) {
      throw ArgumentError('ID Number is required for a new booking');
    }
    if (await hasOverlap(b.roomLabel, b.checkin, b.checkout)) {
      throw StateError('${b.roomLabel} is already booked for those dates');
    }
    if (b.serialNumber.trim().isEmpty) {
      await _db.insertBookingWithNextSerial(b.toMap(), DateTime.now());
    } else {
      await _db.insert('bookings', b.toMap());
    }
  }

  Future<void> updateBooking(BookingModel b) async {
    if (await hasOverlap(b.roomLabel, b.checkin, b.checkout, excludeId: b.id)) {
      throw StateError('${b.roomLabel} is already booked for those dates');
    }
    await _db.update('bookings', b.toMap(), where: 'id = ?', whereArgs: [b.id]);
  }

  Future<void> deleteBooking(String id) async {
    await TrashService().deleteRecord(
      table: 'bookings',
      keyColumn: 'id',
      keyValue: id,
    );
  }

  Future<double> getDuesOutstanding() async {
    final bookings = await getAllBookings();
    double total = 0;
    for (final b in bookings) {
      if (b.status != BookingStatus.cancelled && b.due > 0) {
        total += b.due;
      }
    }
    return total;
  }
}
