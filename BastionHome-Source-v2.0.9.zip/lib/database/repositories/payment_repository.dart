import '../database_helper.dart';
import '../../services/trash_service.dart';
import '../../models/payment_model.dart';

class PaymentRepository {
  final DatabaseHelper _db = DatabaseHelper();

  Future<List<PaymentModel>> getAllPayments() async {
    final rows = await _db.rawQuery('''
      SELECT p.*, b.guest as guestName
      FROM payments p
      LEFT JOIN bookings b ON p.bookingId = b.id
      ORDER BY p.date DESC, p.id DESC
    ''');
    return rows
        .map(
          (r) => PaymentModel.fromMap({
            ...r,
            'dbId': r['id'],
            'guestName': r['guestName'] ?? '',
          }),
        )
        .toList();
  }

  Future<List<PaymentModel>> getPaymentsForBooking(String bookingId) async {
    final rows = await _db.rawQuery(
      '''
      SELECT p.*, b.guest as guestName
      FROM payments p
      LEFT JOIN bookings b ON p.bookingId = b.id
      WHERE p.bookingId = ?
      ORDER BY p.date ASC
    ''',
      [bookingId],
    );
    return rows
        .map(
          (r) => PaymentModel.fromMap({
            ...r,
            'dbId': r['id'],
            'guestName': r['guestName'] ?? '',
          }),
        )
        .toList();
  }

  Future<List<PaymentModel>> getPaymentsForMonth(int year, int month) async {
    final start = '$year-${month.toString().padLeft(2, '0')}-01';
    final end = DateTime(year, month + 1, 1).toIso8601String().split('T').first;
    final rows = await _db.rawQuery(
      '''
      SELECT p.*, b.guest as guestName
      FROM payments p
      LEFT JOIN bookings b ON p.bookingId = b.id
      WHERE p.date >= ? AND p.date < ?
      ORDER BY p.date DESC
    ''',
      [start, end],
    );
    return rows
        .map(
          (r) => PaymentModel.fromMap({
            ...r,
            'dbId': r['id'],
            'guestName': r['guestName'] ?? '',
          }),
        )
        .toList();
  }

  Future<double> getTotalReceivedForMonth(int year, int month) async {
    final start = '$year-${month.toString().padLeft(2, '0')}-01';
    final end = DateTime(year, month + 1, 1).toIso8601String().split('T').first;
    final rows = await _db.rawQuery(
      'SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE date >= ? AND date < ?',
      [start, end],
    );
    return (rows.first['total'] as num? ?? 0).toDouble();
  }

  Future<void> insertPayment(PaymentModel p) async {
    final map = p.toMap()
      ..remove('dbId')
      ..remove('guestName');
    await _db.insert('payments', map);
  }

  Future<void> updatePayment(PaymentModel p) async {
    final map = p.toMap()
      ..remove('dbId')
      ..remove('guestName');
    await _db.update('payments', map, where: 'id = ?', whereArgs: [p.dbId]);
  }

  Future<void> deletePayment(int id) async {
    await TrashService().deleteRecord(
      table: 'payments',
      keyColumn: 'id',
      keyValue: id,
    );
  }
}
