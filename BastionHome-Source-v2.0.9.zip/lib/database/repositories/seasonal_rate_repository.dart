import '../database_helper.dart';
import '../../services/trash_service.dart';

class SeasonalRate {
  final int? id;
  final String name;
  final String room; // 'All Rooms' or specific room name
  final String startDate; // YYYY-MM-DD
  final String endDate; // YYYY-MM-DD
  final double ratePerNight;
  final String rateType; // 'Standard', 'Peak', 'Off-Peak', 'Custom'
  final String notes;
  final bool isActive;

  const SeasonalRate({
    this.id,
    required this.name,
    required this.room,
    required this.startDate,
    required this.endDate,
    required this.ratePerNight,
    this.rateType = 'Custom',
    this.notes = '',
    this.isActive = true,
  });

  Map<String, dynamic> toMap() => {
    if (id != null) 'id': id,
    'name': name,
    'room': room,
    'startDate': startDate,
    'endDate': endDate,
    'ratePerNight': ratePerNight,
    'rateType': rateType,
    'notes': notes,
    'isActive': isActive ? 1 : 0,
  };

  factory SeasonalRate.fromMap(Map<String, dynamic> m) => SeasonalRate(
    id: m['id'] as int?,
    name: m['name'] as String,
    room: m['room'] as String,
    startDate: m['startDate'] as String,
    endDate: m['endDate'] as String,
    ratePerNight: (m['ratePerNight'] as num).toDouble(),
    rateType: m['rateType'] as String? ?? 'Custom',
    notes: m['notes'] as String? ?? '',
    isActive: (m['isActive'] as int? ?? 1) == 1,
  );

  SeasonalRate copyWith({
    int? id,
    String? name,
    String? room,
    String? startDate,
    String? endDate,
    double? ratePerNight,
    String? rateType,
    String? notes,
    bool? isActive,
  }) => SeasonalRate(
    id: id ?? this.id,
    name: name ?? this.name,
    room: room ?? this.room,
    startDate: startDate ?? this.startDate,
    endDate: endDate ?? this.endDate,
    ratePerNight: ratePerNight ?? this.ratePerNight,
    rateType: rateType ?? this.rateType,
    notes: notes ?? this.notes,
    isActive: isActive ?? this.isActive,
  );
}

class SeasonalRateRepository {
  final DatabaseHelper _db = DatabaseHelper();

  Future<void> ensureTable() async {
    final db = await _db.database;
    await db.execute('''
      CREATE TABLE IF NOT EXISTS seasonal_rates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        room TEXT NOT NULL DEFAULT 'All Rooms',
        startDate TEXT NOT NULL,
        endDate TEXT NOT NULL,
        ratePerNight REAL NOT NULL DEFAULT 0,
        rateType TEXT NOT NULL DEFAULT 'Custom',
        notes TEXT DEFAULT '',
        isActive INTEGER NOT NULL DEFAULT 1,
        syncId TEXT,
        syncUpdatedAt TEXT NOT NULL DEFAULT '',
        isExample INTEGER NOT NULL DEFAULT 0
      )
    ''');
  }

  Future<List<SeasonalRate>> getAll() async {
    await ensureTable();
    final rows = await _db.query('seasonal_rates', orderBy: 'startDate DESC');
    return rows.map(SeasonalRate.fromMap).toList();
  }

  Future<List<SeasonalRate>> getActive() async {
    await ensureTable();
    final rows = await _db.query(
      'seasonal_rates',
      where: 'isActive = 1',
      orderBy: 'startDate ASC',
    );
    return rows.map(SeasonalRate.fromMap).toList();
  }

  Future<int> insert(SeasonalRate rate) async {
    await ensureTable();
    return _db.insert('seasonal_rates', rate.toMap());
  }

  Future<int> update(SeasonalRate rate) async {
    await ensureTable();
    return _db.update(
      'seasonal_rates',
      rate.toMap(),
      where: 'id = ?',
      whereArgs: [rate.id],
    );
  }

  Future<int> delete(int id) async {
    await ensureTable();
    await TrashService().deleteRecord(
      table: 'seasonal_rates',
      keyColumn: 'id',
      keyValue: id,
    );
    return 1;
  }

  Future<int> toggleActive(int id, bool isActive) async {
    await ensureTable();
    return _db.update(
      'seasonal_rates',
      {'isActive': isActive ? 1 : 0},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  /// Returns the best matching rate for a given room and date.
  /// Room-specific rates take priority over 'All Rooms' rates.
  Future<double?> getRateForRoomOnDate(String room, DateTime date) async {
    await ensureTable();
    final dateStr = date.toIso8601String().split('T').first;
    // Room-specific first
    final specific = await _db.rawQuery(
      "SELECT ratePerNight FROM seasonal_rates WHERE isActive=1 AND room=? AND startDate<=? AND endDate>=? ORDER BY startDate DESC LIMIT 1",
      [room, dateStr, dateStr],
    );
    if (specific.isNotEmpty) {
      return (specific.first['ratePerNight'] as num).toDouble();
    }
    // Fall back to All Rooms
    final all = await _db.rawQuery(
      "SELECT ratePerNight FROM seasonal_rates WHERE isActive=1 AND room='All Rooms' AND startDate<=? AND endDate>=? ORDER BY startDate DESC LIMIT 1",
      [dateStr, dateStr],
    );
    if (all.isNotEmpty) {
      return (all.first['ratePerNight'] as num).toDouble();
    }
    return null;
  }
}
