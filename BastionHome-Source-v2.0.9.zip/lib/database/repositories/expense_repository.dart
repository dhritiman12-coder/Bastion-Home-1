import '../../services/notification_service.dart';
import '../database_helper.dart';
import '../../services/trash_service.dart';

class DailyExpense {
  final int? id;
  final DateTime date;
  final String head;
  final String spentOn;
  final double amount;
  final String vendor;
  final String mode;
  final String by;
  final String notes;

  DailyExpense({
    this.id,
    required this.date,
    required this.head,
    this.spentOn = '',
    required this.amount,
    this.vendor = '',
    this.mode = 'Cash',
    this.by = '',
    this.notes = '',
  });

  factory DailyExpense.fromMap(Map<String, dynamic> m) => DailyExpense(
    id: m['id'] as int?,
    date: DateTime.parse(m['date'] as String),
    head: m['head'] as String,
    spentOn: m['spentOn'] as String? ?? '',
    amount: (m['amount'] as num? ?? 0).toDouble(),
    vendor: m['vendor'] as String? ?? '',
    mode: m['mode'] as String? ?? 'Cash',
    by: m['by'] as String? ?? '',
    notes: m['notes'] as String? ?? '',
  );

  Map<String, dynamic> toMap() => {
    if (id != null) 'id': id,
    'date': date.toIso8601String().split('T').first,
    'head': head,
    'spentOn': spentOn,
    'amount': amount,
    'vendor': vendor,
    'mode': mode,
    'by': by,
    'notes': notes,
  };
}

class MonthlyExpense {
  final int? id;
  final String head;
  final String desc;
  final String payee;
  final double amount;
  final int dueDay;
  final String autopay;
  final String notes;

  MonthlyExpense({
    this.id,
    required this.head,
    this.desc = '',
    this.payee = '',
    this.amount = 0,
    this.dueDay = 1,
    this.autopay = 'No',
    this.notes = '',
  });

  factory MonthlyExpense.fromMap(Map<String, dynamic> m) => MonthlyExpense(
    id: m['id'] as int?,
    head: m['head'] as String,
    desc: m['desc'] as String? ?? '',
    payee: m['payee'] as String? ?? '',
    amount: (m['amount'] as num? ?? 0).toDouble(),
    dueDay: m['dueDay'] as int? ?? 1,
    autopay: m['autopay'] as String? ?? 'No',
    notes: m['notes'] as String? ?? '',
  );

  Map<String, dynamic> toMap() => {
    if (id != null) 'id': id,
    'head': head,
    'desc': desc,
    'payee': payee,
    'amount': amount,
    'dueDay': dueDay,
    'autopay': autopay,
    'notes': notes,
  };
}

class YearlyExpense {
  final int? id;
  final String head;
  final String desc;
  final String authority;
  final double amount;
  final String dueMonth;
  final String renewal;
  final String reminder;
  final String notes;

  YearlyExpense({
    this.id,
    required this.head,
    this.desc = '',
    this.authority = '',
    this.amount = 0,
    this.dueMonth = 'Jan',
    this.renewal = '',
    this.reminder = 'No',
    this.notes = '',
  });

  factory YearlyExpense.fromMap(Map<String, dynamic> m) => YearlyExpense(
    id: m['id'] as int?,
    head: m['head'] as String,
    desc: m['desc'] as String? ?? '',
    authority: m['authority'] as String? ?? '',
    amount: (m['amount'] as num? ?? 0).toDouble(),
    dueMonth: m['dueMonth'] as String? ?? 'Jan',
    renewal: m['renewal'] as String? ?? '',
    reminder: m['reminder'] as String? ?? 'No',
    notes: m['notes'] as String? ?? '',
  );

  Map<String, dynamic> toMap() => {
    if (id != null) 'id': id,
    'head': head,
    'desc': desc,
    'authority': authority,
    'amount': amount,
    'dueMonth': dueMonth,
    'renewal': renewal,
    'reminder': reminder,
    'notes': notes,
  };
}

class ExpenseRepository {
  final DatabaseHelper _db = DatabaseHelper();

  // ── Daily Expenses ─────────────────────────────────────────────────────────
  Future<List<DailyExpense>> getAllDailyExpenses() async {
    final rows = await _db.query(
      'daily_expenses',
      orderBy: 'date DESC, id DESC',
    );
    return rows.map(DailyExpense.fromMap).toList();
  }

  Future<List<DailyExpense>> getDailyExpensesForMonth(
    int year,
    int month,
  ) async {
    final start = '$year-${month.toString().padLeft(2, '0')}-01';
    final end = DateTime(year, month + 1, 1).toIso8601String().split('T').first;
    final rows = await _db.query(
      'daily_expenses',
      where: 'date >= ? AND date < ?',
      whereArgs: [start, end],
      orderBy: 'date DESC',
    );
    return rows.map(DailyExpense.fromMap).toList();
  }

  Future<double> getDailyExpensesTotalForMonth(int year, int month) async {
    final start = '$year-${month.toString().padLeft(2, '0')}-01';
    final end = DateTime(year, month + 1, 1).toIso8601String().split('T').first;
    final rows = await _db.rawQuery(
      'SELECT COALESCE(SUM(amount), 0) as total FROM daily_expenses WHERE date >= ? AND date < ?',
      [start, end],
    );
    return (rows.first['total'] as num? ?? 0).toDouble();
  }

  Future<void> insertDailyExpense(DailyExpense e) async {
    final map = e.toMap()..remove('id');
    await _db.insert('daily_expenses', map);
  }

  Future<void> updateDailyExpense(DailyExpense e) async {
    final map = e.toMap();
    await _db.update('daily_expenses', map, where: 'id = ?', whereArgs: [e.id]);
  }

  Future<void> deleteDailyExpense(int id) async {
    await TrashService().deleteRecord(
      table: 'daily_expenses',
      keyColumn: 'id',
      keyValue: id,
    );
  }

  // ── Monthly Expenses ───────────────────────────────────────────────────────
  Future<List<MonthlyExpense>> getAllMonthlyExpenses() async {
    final rows = await _db.query('monthly_expenses', orderBy: 'head ASC');
    return rows.map(MonthlyExpense.fromMap).toList();
  }

  Future<double> getMonthlyExpensesTotal() async {
    final rows = await _db.rawQuery(
      'SELECT COALESCE(SUM(amount), 0) as total FROM monthly_expenses',
    );
    return (rows.first['total'] as num? ?? 0).toDouble();
  }

  Future<void> insertMonthlyExpense(MonthlyExpense e) async {
    final map = e.toMap()..remove('id');
    await _db.insert('monthly_expenses', map);
    await NotificationService().scheduleAllNotifications();
  }

  Future<void> updateMonthlyExpense(MonthlyExpense e) async {
    await _db.update(
      'monthly_expenses',
      e.toMap(),
      where: 'id = ?',
      whereArgs: [e.id],
    );
    await NotificationService().scheduleAllNotifications();
  }

  Future<void> deleteMonthlyExpense(int id) async {
    await TrashService().deleteRecord(
      table: 'monthly_expenses',
      keyColumn: 'id',
      keyValue: id,
    );
    await NotificationService().cancelMonthlyNotification(id);
  }

  // ── Yearly Expenses ────────────────────────────────────────────────────────
  Future<List<YearlyExpense>> getAllYearlyExpenses() async {
    final rows = await _db.query('yearly_expenses', orderBy: 'head ASC');
    return rows.map(YearlyExpense.fromMap).toList();
  }

  Future<double> getYearlyExpensesTotal() async {
    final rows = await _db.rawQuery(
      'SELECT COALESCE(SUM(amount), 0) as total FROM yearly_expenses',
    );
    return (rows.first['total'] as num? ?? 0).toDouble();
  }

  Future<void> insertYearlyExpense(YearlyExpense e) async {
    final map = e.toMap()..remove('id');
    await _db.insert('yearly_expenses', map);
    await NotificationService().scheduleAllNotifications();
  }

  Future<void> updateYearlyExpense(YearlyExpense e) async {
    await _db.update(
      'yearly_expenses',
      e.toMap(),
      where: 'id = ?',
      whereArgs: [e.id],
    );
    await NotificationService().scheduleAllNotifications();
  }

  Future<void> deleteYearlyExpense(int id) async {
    await TrashService().deleteRecord(
      table: 'yearly_expenses',
      keyColumn: 'id',
      keyValue: id,
    );
    await NotificationService().cancelYearlyNotifications(id);
  }
}
