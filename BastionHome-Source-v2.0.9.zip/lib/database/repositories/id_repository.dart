import '../database_helper.dart';
import '../../services/trash_service.dart';

class IdRecord {
  final int? id;
  final DateTime date;
  final String bookingId;
  final String idType;
  final String idNumber;
  final String copyType;
  final String fileName;
  final DateTime? capturedAt;
  final String storage;
  final String verified;
  final String notes;
  // Denormalized
  final String guestName;

  IdRecord({
    this.id,
    required this.date,
    required this.bookingId,
    required this.idType,
    this.idNumber = '',
    this.copyType = 'Physical',
    this.fileName = '',
    this.capturedAt,
    this.storage = '',
    this.verified = 'No',
    this.notes = '',
    this.guestName = '',
  });

  factory IdRecord.fromMap(Map<String, dynamic> m) => IdRecord(
    id: m['id'] as int?,
    date: DateTime.parse(m['date'] as String),
    bookingId: m['bookingId'] as String,
    idType: m['idType'] as String,
    idNumber: m['idNumber'] as String? ?? '',
    copyType: m['copyType'] as String? ?? 'Physical',
    fileName: m['fileName'] as String? ?? '',
    capturedAt: _optionalDateTime(m['capturedAt']),
    storage: m['storage'] as String? ?? '',
    verified: m['verified'] as String? ?? 'No',
    notes: m['notes'] as String? ?? '',
    guestName: m['guestName'] as String? ?? '',
  );

  Map<String, dynamic> toMap() => {
    if (id != null) 'id': id,
    'date': date.toIso8601String().split('T').first,
    'bookingId': bookingId,
    'idType': idType,
    'idNumber': idNumber,
    'copyType': copyType,
    'fileName': fileName,
    'capturedAt': capturedAt?.toUtc().toIso8601String() ?? '',
    'storage': storage,
    'verified': verified,
    'notes': notes,
  };

  static DateTime? _optionalDateTime(Object? value) {
    final text = value?.toString().trim() ?? '';
    return text.isEmpty ? null : DateTime.tryParse(text);
  }
}

class IdRepository {
  final DatabaseHelper _db = DatabaseHelper();

  Future<List<IdRecord>> getAllIdRecords() async {
    final rows = await _db.rawQuery('''
      SELECT ir.*, b.guest as guestName
      FROM id_records ir
      LEFT JOIN bookings b ON ir.bookingId = b.id
      ORDER BY ir.date DESC
    ''');
    return rows
        .map((r) => IdRecord.fromMap({...r, 'guestName': r['guestName'] ?? ''}))
        .toList();
  }

  Future<List<IdRecord>> getIdRecordsForBooking(String bookingId) async {
    final rows = await _db.rawQuery(
      '''
      SELECT ir.*, b.guest as guestName
      FROM id_records ir
      LEFT JOIN bookings b ON ir.bookingId = b.id
      WHERE ir.bookingId = ?
    ''',
      [bookingId],
    );
    return rows
        .map((r) => IdRecord.fromMap({...r, 'guestName': r['guestName'] ?? ''}))
        .toList();
  }

  Future<void> insertIdRecord(IdRecord r) async {
    final map = r.toMap()..remove('id');
    await _db.insert('id_records', map);
  }

  Future<void> updateIdRecord(IdRecord r) async {
    await _db.update(
      'id_records',
      r.toMap(),
      where: 'id = ?',
      whereArgs: [r.id],
    );
  }

  Future<void> deleteIdRecord(int id) async {
    await TrashService().deleteRecord(
      table: 'id_records',
      keyColumn: 'id',
      keyValue: id,
    );
  }
}
