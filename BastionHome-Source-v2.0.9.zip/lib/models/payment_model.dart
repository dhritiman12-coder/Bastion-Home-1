enum PaymentMode { cash, upi, card, bankTransfer, cheque, other }

enum PaymentType { advance, balance, fullPayment, refund }

class PaymentModel {
  final int? dbId;
  final DateTime date;
  final String bookingId;
  final double amount;
  final PaymentMode mode;
  final PaymentType type;
  final String by;
  final String notes;

  // Denormalized for display
  final String guestName;

  PaymentModel({
    this.dbId,
    required this.date,
    required this.bookingId,
    required this.amount,
    required this.mode,
    required this.type,
    required this.by,
    required this.notes,
    this.guestName = '',
  });

  String get modeLabel {
    switch (mode) {
      case PaymentMode.cash:
        return 'Cash';
      case PaymentMode.upi:
        return 'UPI';
      case PaymentMode.card:
        return 'Card';
      case PaymentMode.bankTransfer:
        return 'Bank Transfer';
      case PaymentMode.cheque:
        return 'Cheque';
      case PaymentMode.other:
        return 'Other';
    }
  }

  String get typeLabel {
    switch (type) {
      case PaymentType.advance:
        return 'Advance';
      case PaymentType.balance:
        return 'Balance';
      case PaymentType.fullPayment:
        return 'Full Payment';
      case PaymentType.refund:
        return 'Refund';
    }
  }

  static PaymentMode _modeFromString(String v) {
    switch (v) {
      case 'UPI':
        return PaymentMode.upi;
      case 'Card':
        return PaymentMode.card;
      case 'Bank Transfer':
        return PaymentMode.bankTransfer;
      case 'Cheque':
        return PaymentMode.cheque;
      case 'Other':
        return PaymentMode.other;
      default:
        return PaymentMode.cash;
    }
  }

  static PaymentType _typeFromString(String v) {
    switch (v) {
      case 'Balance':
        return PaymentType.balance;
      case 'Full Payment':
        return PaymentType.fullPayment;
      case 'Refund':
        return PaymentType.refund;
      default:
        return PaymentType.advance;
    }
  }

  static PaymentMode modeFromString(String v) => _modeFromString(v);
  static PaymentType typeFromString(String v) => _typeFromString(v);

  factory PaymentModel.fromMap(Map<String, dynamic> map) {
    return PaymentModel(
      dbId: map['dbId'] as int?,
      date: DateTime.parse(map['date'] as String),
      bookingId: map['bookingId'] as String,
      amount: (map['amount'] as num).toDouble(),
      mode: _modeFromString(map['mode'] as String),
      type: _typeFromString(map['type'] as String),
      by: map['by'] as String? ?? '',
      notes: map['notes'] as String? ?? '',
      guestName: map['guestName'] as String? ?? '',
    );
  }

  Map<String, dynamic> toMap() => {
    if (dbId != null) 'dbId': dbId,
    'date': date.toIso8601String().split('T').first,
    'bookingId': bookingId,
    'amount': amount,
    'mode': modeLabel,
    'type': typeLabel,
    'by': by,
    'notes': notes,
    'guestName': guestName,
  };
}
