enum BookingStatus { booked, checkedIn, checkedOut, cancelled, noShow }

enum PayStatus { paid, partial, unpaid, none }

enum RoomType { room1, room2, room3, room4, room5 }

enum BookingSource { offline, online }

class BookingModel {
  final String id;
  final String guest;
  final String phone;
  final String address;
  final String otherOccupants;
  final int guests;
  final RoomType room;
  final DateTime checkin;
  final DateTime checkout;
  final String checkinTime;
  final String checkoutTime;
  final double tariff;
  final double extra;
  final double discount;
  final BookingStatus status;
  final bool idTaken;
  final String idType;
  final String idNumber;
  final String idFrontPath;
  final String idBackPath;
  final DateTime? idFrontCapturedAt;
  final DateTime? idBackCapturedAt;
  final String paymentMode;
  final String serialNumber;
  final String createdBy;
  final BookingSource bookingSource;
  final String notes;

  // Injected from payment query
  final double received;

  BookingModel({
    required this.id,
    required this.guest,
    required this.phone,
    this.address = '',
    this.otherOccupants = '',
    required this.guests,
    required this.room,
    required this.checkin,
    required this.checkout,
    this.checkinTime = '12:00',
    this.checkoutTime = '11:00',
    required this.tariff,
    required this.extra,
    required this.discount,
    required this.status,
    required this.idTaken,
    this.idType = '',
    this.idNumber = '',
    this.idFrontPath = '',
    this.idBackPath = '',
    this.idFrontCapturedAt,
    this.idBackCapturedAt,
    this.paymentMode = 'Cash',
    this.serialNumber = '',
    this.createdBy = '',
    this.bookingSource = BookingSource.offline,
    required this.notes,
    this.received = 0,
  });

  int get nights {
    final value = checkout.difference(checkin).inDays;
    return value < 0 ? 0 : value;
  }

  double get roomCharges => nights * tariff;
  double get total => roomCharges + extra - discount;
  double get due => total - received;

  List<String> get otherOccupantNames => otherOccupants
      .split(RegExp(r'[\r\n]+'))
      .map((name) => name.trim())
      .where((name) => name.isNotEmpty)
      .toList(growable: false);

  PayStatus get payStatus {
    if (total <= 0) return PayStatus.none;
    if (due <= 0) return PayStatus.paid;
    if (received > 0) return PayStatus.partial;
    return PayStatus.unpaid;
  }

  String get roomLabel {
    switch (room) {
      case RoomType.room1:
        return 'Room 1';
      case RoomType.room2:
        return 'Room 2';
      case RoomType.room3:
        return 'Room 3';
      case RoomType.room4:
        return 'Room 4';
      case RoomType.room5:
        return 'Room 5';
    }
  }

  String get statusLabel {
    switch (status) {
      case BookingStatus.booked:
        return 'Booked';
      case BookingStatus.checkedIn:
        return 'Checked-in';
      case BookingStatus.checkedOut:
        return 'Checked-out';
      case BookingStatus.cancelled:
        return 'Cancelled';
      case BookingStatus.noShow:
        return 'No-show';
    }
  }

  String get bookingSourceLabel =>
      bookingSource == BookingSource.online ? 'Online' : 'Offline';

  static BookingStatus _statusFromString(String v) {
    switch (v) {
      case 'Checked-in':
        return BookingStatus.checkedIn;
      case 'Checked-out':
        return BookingStatus.checkedOut;
      case 'Cancelled':
        return BookingStatus.cancelled;
      case 'No-show':
        return BookingStatus.noShow;
      default:
        return BookingStatus.booked;
    }
  }

  static RoomType _roomFromString(String v) {
    switch (v) {
      case 'Room 2':
        return RoomType.room2;
      case 'Room 3':
        return RoomType.room3;
      case 'Room 4':
        return RoomType.room4;
      case 'Room 5':
        return RoomType.room5;
      default:
        return RoomType.room1;
    }
  }

  static BookingStatus statusFromString(String v) => _statusFromString(v);
  static RoomType roomFromString(String v) => _roomFromString(v);

  static BookingSource sourceFromString(String v) => v.toLowerCase() == 'online'
      ? BookingSource.online
      : BookingSource.offline;

  factory BookingModel.fromMap(Map<String, dynamic> map) {
    return BookingModel(
      id: map['id'] as String,
      guest: map['guest'] as String,
      phone: map['phone'] as String? ?? '',
      address: map['address'] as String? ?? '',
      otherOccupants: map['otherOccupants'] as String? ?? '',
      guests: map['guests'] as int,
      room: _roomFromString(map['room'] as String),
      checkin: DateTime.parse(map['checkin'] as String),
      checkout: DateTime.parse(map['checkout'] as String),
      checkinTime: map['checkinTime'] as String? ?? '12:00',
      checkoutTime: map['checkoutTime'] as String? ?? '11:00',
      tariff: (map['tariff'] as num).toDouble(),
      extra: (map['extra'] as num? ?? 0).toDouble(),
      discount: (map['discount'] as num? ?? 0).toDouble(),
      status: _statusFromString(map['status'] as String),
      idTaken: (map['idTaken'] as String?) == 'Yes',
      idType: map['idType'] as String? ?? '',
      idNumber: map['idNumber'] as String? ?? '',
      idFrontPath: map['idFrontPath'] as String? ?? '',
      idBackPath: map['idBackPath'] as String? ?? '',
      idFrontCapturedAt: _optionalDateTime(map['idFrontCapturedAt']),
      idBackCapturedAt: _optionalDateTime(map['idBackCapturedAt']),
      paymentMode: map['paymentMode'] as String? ?? 'Cash',
      serialNumber: map['serialNumber'] as String? ?? '',
      createdBy: map['createdBy'] as String? ?? '',
      bookingSource: sourceFromString(map['bookingSource'] as String? ?? ''),
      notes: map['notes'] as String? ?? '',
      received: (map['received'] as num? ?? 0).toDouble(),
    );
  }

  Map<String, dynamic> toMap() => {
    'id': id,
    'guest': guest,
    'phone': phone,
    'address': address,
    'otherOccupants': otherOccupantNames.join('\n'),
    'guests': guests,
    'room': roomLabel,
    'checkin': checkin.toIso8601String().split('T').first,
    'checkout': checkout.toIso8601String().split('T').first,
    'checkinTime': checkinTime,
    'checkoutTime': checkoutTime,
    'tariff': tariff,
    'extra': extra,
    'discount': discount,
    'status': statusLabel,
    'idTaken': idTaken ? 'Yes' : 'No',
    'idType': idType,
    'idNumber': idNumber,
    'idFrontPath': idFrontPath,
    'idBackPath': idBackPath,
    'idFrontCapturedAt': idFrontCapturedAt?.toUtc().toIso8601String() ?? '',
    'idBackCapturedAt': idBackCapturedAt?.toUtc().toIso8601String() ?? '',
    'paymentMode': paymentMode,
    'serialNumber': serialNumber,
    'createdBy': createdBy,
    'bookingSource': bookingSourceLabel,
    'notes': notes,
  };

  BookingModel copyWith({
    double? received,
    BookingStatus? status,
    BookingSource? bookingSource,
  }) => BookingModel(
    id: id,
    guest: guest,
    phone: phone,
    address: address,
    otherOccupants: otherOccupants,
    guests: guests,
    room: room,
    checkin: checkin,
    checkout: checkout,
    checkinTime: checkinTime,
    checkoutTime: checkoutTime,
    tariff: tariff,
    extra: extra,
    discount: discount,
    status: status ?? this.status,
    idTaken: idTaken,
    idType: idType,
    idNumber: idNumber,
    idFrontPath: idFrontPath,
    idBackPath: idBackPath,
    idFrontCapturedAt: idFrontCapturedAt,
    idBackCapturedAt: idBackCapturedAt,
    paymentMode: paymentMode,
    serialNumber: serialNumber,
    createdBy: createdBy,
    bookingSource: bookingSource ?? this.bookingSource,
    notes: notes,
    received: received ?? this.received,
  );

  static DateTime? _optionalDateTime(Object? value) {
    final text = value?.toString().trim() ?? '';
    return text.isEmpty ? null : DateTime.tryParse(text);
  }
}
