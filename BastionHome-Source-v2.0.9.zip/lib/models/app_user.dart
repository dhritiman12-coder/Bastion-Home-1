import 'dart:convert';

enum UserRole { primaryAdmin, backupAdmin, administrator, employee }

enum AppPermission {
  createBookings,
  viewOccupancy,
  recordExpenses,
  viewBookings,
  manageBookings,
  manageInventory,
  viewPayments,
  recordPayments,
  manageGuestIds,
  viewAnalytics,
}

const employeeCorePermissions = <AppPermission>{
  AppPermission.createBookings,
  AppPermission.viewOccupancy,
  AppPermission.recordExpenses,
};

extension UserRoleLabel on UserRole {
  String get label {
    switch (this) {
      case UserRole.primaryAdmin:
        return 'Primary administrator';
      case UserRole.backupAdmin:
        return 'Backup administrator';
      case UserRole.administrator:
        return 'Administrator';
      case UserRole.employee:
        return 'Employee';
    }
  }

  bool get isAdmin => this != UserRole.employee;
}

extension AppPermissionLabel on AppPermission {
  String get label {
    switch (this) {
      case AppPermission.createBookings:
        return 'Record new bookings';
      case AppPermission.viewOccupancy:
        return 'View occupancy chart';
      case AppPermission.recordExpenses:
        return 'Record daily expenses';
      case AppPermission.viewBookings:
        return 'View booking records';
      case AppPermission.manageBookings:
        return 'Edit and cancel bookings';
      case AppPermission.manageInventory:
        return 'Manage stock records';
      case AppPermission.viewPayments:
        return 'View payments';
      case AppPermission.recordPayments:
        return 'Record payments';
      case AppPermission.manageGuestIds:
        return 'Manage guest ID records';
      case AppPermission.viewAnalytics:
        return 'View business reports';
    }
  }
}

class AppUser {
  final int? id;
  final String username;
  final String displayName;
  final UserRole role;
  final String pinHash;
  final String pinSalt;
  final Set<AppPermission> permissions;
  final bool active;
  final String createdAt;
  final String? lastLoginAt;

  const AppUser({
    this.id,
    required this.username,
    required this.displayName,
    required this.role,
    required this.pinHash,
    required this.pinSalt,
    required this.permissions,
    this.active = true,
    required this.createdAt,
    this.lastLoginAt,
  });

  bool can(AppPermission permission) =>
      role.isAdmin ||
      (role == UserRole.employee &&
          employeeCorePermissions.contains(permission)) ||
      permissions.contains(permission);

  factory AppUser.fromMap(Map<String, dynamic> map) {
    final roleName = map['role'] as String? ?? UserRole.employee.name;
    final decoded = jsonDecode(map['permissions'] as String? ?? '[]') as List;
    return AppUser(
      id: map['id'] as int?,
      username: map['username'] as String,
      displayName: map['displayName'] as String,
      role: UserRole.values.firstWhere(
        (role) => role.name == roleName,
        orElse: () => UserRole.employee,
      ),
      pinHash: map['pinHash'] as String,
      pinSalt: map['pinSalt'] as String,
      permissions: decoded
          .map((name) => AppPermission.values.where((p) => p.name == name))
          .where((matches) => matches.isNotEmpty)
          .map((matches) => matches.first)
          .toSet(),
      active: (map['active'] as int? ?? 1) == 1,
      createdAt: map['createdAt'] as String,
      lastLoginAt: map['lastLoginAt'] as String?,
    );
  }

  Map<String, dynamic> toMap() => {
    if (id != null) 'id': id,
    'username': username,
    'displayName': displayName,
    'role': role.name,
    'pinHash': pinHash,
    'pinSalt': pinSalt,
    'permissions': jsonEncode(permissions.map((p) => p.name).toList()),
    'active': active ? 1 : 0,
    'createdAt': createdAt,
    'lastLoginAt': lastLoginAt,
  };

  AppUser copyWith({
    int? id,
    String? username,
    String? displayName,
    UserRole? role,
    String? pinHash,
    String? pinSalt,
    Set<AppPermission>? permissions,
    bool? active,
    String? createdAt,
    String? lastLoginAt,
  }) => AppUser(
    id: id ?? this.id,
    username: username ?? this.username,
    displayName: displayName ?? this.displayName,
    role: role ?? this.role,
    pinHash: pinHash ?? this.pinHash,
    pinSalt: pinSalt ?? this.pinSalt,
    permissions: permissions ?? this.permissions,
    active: active ?? this.active,
    createdAt: createdAt ?? this.createdAt,
    lastLoginAt: lastLoginAt ?? this.lastLoginAt,
  );
}
