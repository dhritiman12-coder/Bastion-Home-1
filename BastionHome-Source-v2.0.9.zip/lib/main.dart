import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:sizer/sizer.dart';

import './database/database_helper.dart';
import './routes/app_routes.dart';
import './services/id_vault_service.dart';
import './services/notification_service.dart';
import './services/account_service.dart';
import './services/app_settings_service.dart';
import './services/cloud_sync_service.dart';
import './theme/app_theme.dart';
import './widgets/custom_error_widget.dart';
import './widgets/app_lock_gate.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Android may recreate the activity while the external camera is open.
  // Secure the returned image before the UI starts so the form can reclaim it.
  try {
    await IdVaultService().recoverLostCapture();
  } catch (e) {
    debugPrint('Failed to recover an interrupted ID capture: $e');
  }

  Object? startupError;
  try {
    await _initializeCoreServices();
  } catch (e) {
    startupError = e;
    debugPrint('Failed to initialize local database: $e');
  }

  bool hasShownError = false;

  ErrorWidget.builder = (FlutterErrorDetails details) {
    if (!hasShownError) {
      hasShownError = true;

      Future.delayed(const Duration(seconds: 5), () {
        hasShownError = false;
      });

      return CustomErrorWidget(errorDetails: details);
    }
    return const SizedBox.shrink();
  };

  if (startupError != null) {
    runApp(const BootstrapFailureApp());
    return;
  }

  GoRouter.optionURLReflectsImperativeAPIs = true;
  await _initializeNotifications();
  runApp(const MyApp());
}

Future<void> _initializeCoreServices() async {
  await DatabaseHelper().database;
  await AppSettingsService().initialize();
  await AccountService().initialize();
  await CloudSyncService().initialize();
}

Future<void> _initializeNotifications() async {
  try {
    await NotificationService().initialize();
    await NotificationService().scheduleAllNotifications();
  } catch (e) {
    debugPrint('Failed to initialize local notifications: $e');
  }
}

class BootstrapFailureApp extends StatefulWidget {
  const BootstrapFailureApp({super.key});

  @override
  State<BootstrapFailureApp> createState() => _BootstrapFailureAppState();
}

class _BootstrapFailureAppState extends State<BootstrapFailureApp> {
  bool _retrying = false;
  bool _retryFailed = false;

  Future<void> _retry() async {
    setState(() {
      _retrying = true;
      _retryFailed = false;
    });
    try {
      await _initializeCoreServices();
      GoRouter.optionURLReflectsImperativeAPIs = true;
      await _initializeNotifications();
      runApp(const MyApp());
    } catch (e) {
      debugPrint('Startup retry failed: $e');
      if (mounted) {
        setState(() {
          _retrying = false;
          _retryFailed = true;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: const Color(0xFFF7F4EE),
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.storage_outlined,
                      size: 52,
                      color: Color(0xFF8E2A18),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'Bastion Home could not open its secure data',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF123F34),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      _retryFailed
                          ? 'The retry did not succeed. Restart the phone, check available storage, then try again.'
                          : 'Your records have not been changed. Check available storage and try again.',
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 24),
                    FilledButton.icon(
                      onPressed: _retrying ? null : _retry,
                      icon: _retrying
                          ? const SizedBox.square(
                              dimension: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.refresh),
                      label: Text(_retrying ? 'Retrying' : 'Try again'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsService();
    return AnimatedBuilder(
      animation: settings,
      builder: (context, _) => Sizer(
        builder: (context, orientation, screenType) {
          return MaterialApp.router(
            title: 'Bastion Home Manager',
            theme: AppTheme.lightThemeFor(
              fontChoice: settings.fontFamily,
              headingChoice: settings.headingFontFamily,
            ),
            darkTheme: AppTheme.darkThemeFor(
              fontChoice: settings.fontFamily,
              headingChoice: settings.headingFontFamily,
            ),
            themeMode: settings.themeMode,
            builder: (context, child) {
              final media = MediaQuery.of(context);
              return MediaQuery(
                data: media.copyWith(
                  textScaler: TextScaler.linear(settings.textScale),
                ),
                child: AppLockGate(child: child ?? const SizedBox.shrink()),
              );
            },
            debugShowCheckedModeBanner: false,
            routerConfig: appRouter,
          );
        },
      ),
    );
  }
}
