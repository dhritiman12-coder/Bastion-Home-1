// THEME LOCK: light — source: domain signal (hospitality front-desk, outdoor/indoor clarity)
// Scaffold.backgroundColor = AppTheme.backgroundLight — ALL screens

import 'package:flutter/material.dart';

class AppTheme {
  // ── Brand Colours ──────────────────────────────────────────────────────────
  static const Color deepTeal = Color(0xFF123F34);
  static const Color deepTealDark = Color(0xFF0E332B);
  static const Color brassAccent = Color(0xFF8E2A18);
  static const Color brassLight = Color(0xFFB85B48);

  // ── Semantic Colours ───────────────────────────────────────────────────────
  static const Color successGreen = Color(0xFF3D6B4A);
  static const Color alertRed = Color(0xFFA2432F);
  static const Color warningAmber = Color(0xFFB06B20);

  // ── Light Surfaces ─────────────────────────────────────────────────────────
  static const Color backgroundLight = Color(0xFFF7F4EE);
  static const Color backgroundLightAlt = Color(0xFFFCFAF7);
  static const Color surfaceLight = Color(0xFFFFFFFF);
  static const Color surfaceVariantLight = Color(0xFFF0EEE9);
  static const Color cardLight = Color(0xFFFFFFFF);

  // ── Dark Surfaces ──────────────────────────────────────────────────────────
  static const Color backgroundDark = Color(0xFF121212);
  static const Color surfaceDark = Color(0xFF1E2428);
  static const Color surfaceVariantDark = Color(0xFF2A3338);

  // ── Text ───────────────────────────────────────────────────────────────────
  static const Color textPrimaryLight = Color(0xFF162E28);
  static const Color textSecondaryLight = Color(0xFF52645F);
  static const Color textMutedLight = Color(0xFF7B8A86);
  static const Color textPrimaryDark = Color(0xFFE8EDF0);
  static const Color textSecondaryDark = Color(0xFFAABBBF);

  static ThemeData lightThemeFor({
    required String fontChoice,
    required String headingChoice,
  }) => _withTypography(
    lightTheme,
    fontChoice: fontChoice,
    headingChoice: headingChoice,
  );

  static ThemeData darkThemeFor({
    required String fontChoice,
    required String headingChoice,
  }) => _withTypography(
    darkTheme,
    fontChoice: fontChoice,
    headingChoice: headingChoice,
  );

  static ThemeData _withTypography(
    ThemeData base, {
    required String fontChoice,
    required String headingChoice,
  }) {
    final bodyFamily = _fontFamily(fontChoice);
    final headingFamily = headingChoice == 'Match app'
        ? bodyFamily
        : _fontFamily(headingChoice);
    final bodyTheme = base.textTheme.apply(
      fontFamily: bodyFamily,
      bodyColor: base.colorScheme.onSurface,
      displayColor: base.colorScheme.onSurface,
    );
    TextStyle? heading(TextStyle? style) => style?.copyWith(
      fontFamily: headingFamily,
      fontWeight: FontWeight.w700,
      letterSpacing: 0,
    );
    final textTheme = bodyTheme.copyWith(
      displayLarge: heading(bodyTheme.displayLarge),
      displayMedium: heading(bodyTheme.displayMedium),
      displaySmall: heading(bodyTheme.displaySmall),
      headlineLarge: heading(bodyTheme.headlineLarge),
      headlineMedium: heading(bodyTheme.headlineMedium),
      headlineSmall: heading(bodyTheme.headlineSmall),
      titleLarge: heading(bodyTheme.titleLarge),
      titleMedium: heading(bodyTheme.titleMedium),
      titleSmall: heading(bodyTheme.titleSmall),
    );
    return base.copyWith(
      textTheme: textTheme,
      appBarTheme: base.appBarTheme.copyWith(
        titleTextStyle: heading(
          base.appBarTheme.titleTextStyle,
        )?.copyWith(fontSize: 20),
      ),
    );
  }

  static String? _fontFamily(String choice) {
    switch (choice) {
      case 'Modern':
        return 'BastionInter';
      case 'Classic':
        return 'BastionLora';
      default:
        return null;
    }
  }

  static ThemeData get lightTheme => ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.light(
      primary: deepTeal,
      onPrimary: Colors.white,
      primaryContainer: const Color(0xFFDCEBE4),
      onPrimaryContainer: deepTealDark,
      secondary: brassAccent,
      onSecondary: Colors.white,
      secondaryContainer: const Color(0xFFF4DDD8),
      onSecondaryContainer: const Color(0xFF5D180E),
      surface: surfaceLight,
      onSurface: textPrimaryLight,
      surfaceContainerHighest: surfaceVariantLight,
      onSurfaceVariant: textSecondaryLight,
      error: alertRed,
      onError: Colors.white,
      outline: const Color(0xFFB8C5C0),
      outlineVariant: const Color(0xFFDCE4E0),
    ),
    scaffoldBackgroundColor: backgroundLight,
    textTheme: const TextTheme(
      displayLarge: TextStyle(
        fontSize: 32,
        fontWeight: FontWeight.w700,
        letterSpacing: 0,
      ),
      displayMedium: TextStyle(
        fontSize: 28,
        fontWeight: FontWeight.w700,
        letterSpacing: 0,
      ),
      headlineLarge: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
      headlineMedium: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
      headlineSmall: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
      titleLarge: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
      titleMedium: TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
      titleSmall: TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
      bodyLarge: TextStyle(fontSize: 15, fontWeight: FontWeight.w400),
      bodyMedium: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
      bodySmall: TextStyle(fontSize: 12, fontWeight: FontWeight.w400),
      labelLarge: TextStyle(
        fontSize: 13,
        fontWeight: FontWeight.w600,
        letterSpacing: 0,
      ),
      labelMedium: TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w500,
        letterSpacing: 0,
      ),
      labelSmall: TextStyle(
        fontSize: 11,
        fontWeight: FontWeight.w500,
        letterSpacing: 0,
      ),
    ),
    appBarTheme: AppBarThemeData(
      backgroundColor: backgroundLight,
      foregroundColor: textPrimaryLight,
      elevation: 0,
      scrolledUnderElevation: 1,
      shadowColor: Colors.black.withAlpha(20),
      titleTextStyle: const TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w700,
        color: textPrimaryLight,
        letterSpacing: 0,
      ),
    ),
    cardTheme: CardThemeData(
      color: surfaceLight,
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      shadowColor: Colors.black.withAlpha(15),
      surfaceTintColor: Colors.transparent,
    ),
    inputDecorationTheme: InputDecorationThemeData(
      filled: true,
      fillColor: surfaceVariantLight,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide.none,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: Color(0xFFDCE4E0), width: 1),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: deepTeal, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: alertRed, width: 1),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      labelStyle: const TextStyle(color: textSecondaryLight, fontSize: 14),
      hintStyle: const TextStyle(color: textMutedLight, fontSize: 14),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: surfaceVariantLight,
      selectedColor: deepTeal,
      labelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(50)),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: surfaceLight,
      indicatorColor: const Color(0xFFDCEBE4),
      labelTextStyle: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.selected)) {
          return const TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w600,
            color: deepTeal,
          );
        }
        return const TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w400,
          color: textSecondaryLight,
        );
      }),
      iconTheme: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.selected)) {
          return const IconThemeData(color: deepTeal, size: 22);
        }
        return const IconThemeData(color: Color(0xFF7B8A86), size: 22);
      }),
    ),
    dividerTheme: const DividerThemeData(
      color: Color(0xFFEAE4DC),
      thickness: 1,
      space: 0,
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: deepTeal,
      foregroundColor: Colors.white,
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    ),
  );

  static ThemeData get darkTheme => ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.dark(
      primary: const Color(0xFF78B49D),
      onPrimary: deepTealDark,
      primaryContainer: deepTeal,
      onPrimaryContainer: const Color(0xFFDCEBE4),
      secondary: brassLight,
      onSecondary: const Color(0xFF3A2000),
      secondaryContainer: const Color(0xFF5D180E),
      onSecondaryContainer: const Color(0xFFF4DDD8),
      surface: surfaceDark,
      onSurface: textPrimaryDark,
      surfaceContainerHighest: surfaceVariantDark,
      onSurfaceVariant: textSecondaryDark,
      error: const Color(0xFFCF6679),
      onError: Colors.white,
      outline: const Color(0xFF3E5058),
      outlineVariant: const Color(0xFF2A3338),
    ),
    scaffoldBackgroundColor: backgroundDark,
    textTheme: const TextTheme(
      displayLarge: TextStyle(
        fontSize: 32,
        fontWeight: FontWeight.w700,
        color: textPrimaryDark,
      ),
      headlineLarge: TextStyle(
        fontSize: 24,
        fontWeight: FontWeight.w700,
        color: textPrimaryDark,
      ),
      titleLarge: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w600,
        color: textPrimaryDark,
      ),
      bodyMedium: TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w400,
        color: textPrimaryDark,
      ),
      labelMedium: TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w500,
        color: textSecondaryDark,
      ),
    ),
    appBarTheme: AppBarThemeData(
      backgroundColor: surfaceDark,
      foregroundColor: textPrimaryDark,
      elevation: 0,
      scrolledUnderElevation: 1,
    ),
    cardTheme: CardThemeData(
      color: surfaceDark,
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: surfaceDark,
      indicatorColor: deepTeal.withAlpha(102),
      labelTextStyle: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.selected)) {
          return const TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w600,
            color: Color(0xFF78B49D),
          );
        }
        return TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w400,
          color: textSecondaryDark,
        );
      }),
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: const Color(0xFF78B49D),
      foregroundColor: deepTealDark,
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    ),
  );
}
