import 'package:go_router/go_router.dart';

import '../presentation/bookings_screen/bookings_screen.dart';
import '../presentation/dashboard_screen/dashboard_screen.dart';
import '../presentation/expenses_screen/expenses_screen.dart';
import '../presentation/more_screen/more_screen.dart';
import '../presentation/occupancy_screen/occupancy_screen.dart';
import '../widgets/app_scaffold.dart';

class AppRoutes {
  static const String initial = '/dashboard';
  static const String dashboardScreen = '/dashboard';
  static const String bookingsScreen = '/bookings';
  static const String occupancyScreen = '/occupancy';
  static const String guestIdsScreen = '/guest-ids';
  static const String paymentsScreen = '/payments';
  static const String expensesScreen = '/expenses';
  static const String backupScreen = '/backup';
}

final GoRouter appRouter = GoRouter(
  initialLocation: AppRoutes.initial,
  routes: [
    StatefulShellRoute.indexedStack(
      builder: (context, state, navigationShell) =>
          AppScaffold(navigationShell: navigationShell),
      branches: [
        StatefulShellBranch(
          routes: [
            GoRoute(
              path: AppRoutes.dashboardScreen,
              builder: (context, state) => const DashboardScreen(),
            ),
          ],
        ),
        StatefulShellBranch(
          routes: [
            GoRoute(
              path: AppRoutes.bookingsScreen,
              builder: (context, state) => const BookingsScreen(),
            ),
          ],
        ),
        StatefulShellBranch(
          routes: [
            GoRoute(
              path: AppRoutes.occupancyScreen,
              builder: (context, state) => const OccupancyScreen(),
            ),
          ],
        ),
        StatefulShellBranch(
          routes: [
            GoRoute(
              path: AppRoutes.expensesScreen,
              builder: (context, state) => const ExpensesScreen(),
            ),
          ],
        ),
        StatefulShellBranch(
          routes: [
            GoRoute(
              path: AppRoutes.backupScreen,
              builder: (context, state) => const MoreScreen(),
            ),
          ],
        ),
      ],
    ),
  ],
);
