class AppConstants {
  static const List<String> rooms = [
    'Room 1',
    'Room 2',
    'Room 3',
    'Room 4',
    'Room 5',
  ];

  static const List<String> paymentModes = [
    'Cash',
    'UPI',
    'Card',
    'Bank Transfer',
    'Cheque',
    'Other',
  ];

  static const List<String> paymentTypes = [
    'Advance',
    'Balance',
    'Full Payment',
    'Refund',
  ];

  static const List<String> bookingStatuses = [
    'Booked',
    'Checked-in',
    'Checked-out',
    'Cancelled',
    'No-show',
  ];

  static const List<String> idTypes = [
    'Aadhaar Card',
    'PAN Card',
    'Passport',
    'Driving License',
    'Voter ID',
    'Other Govt ID',
  ];

  static const List<String> copyTypes = ['Physical', 'Scanned', 'Both'];

  static const List<String> months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];

  static const List<String> expenseHeads = [
    'Electricity',
    'Water Charges',
    'LPG / Cooking Gas',
    'Internet / WiFi',
    'DTH / Cable TV',
    'Telephone / Mobile',
    'Staff Salary',
    'Housekeeping Wages',
    'Cook / Kitchen Wages',
    'Security Guard',
    'Staff Food / Welfare',
    'Bonus / Incentive',
    'Groceries / Provisions',
    'Vegetables & Perishables',
    'Dairy / Bread / Eggs',
    'Drinking Water / Cans',
    'Tea / Coffee / Beverages',
    'Toiletries & Guest Amenities',
    'Guest Welcome Kit',
    'Cleaning Supplies',
    'Linen & Towels',
    'Kitchen Consumables',
    'Repairs & Maintenance',
    'AC Service / Repair',
    'Plumbing',
    'Electrical',
    'Carpentry',
    'Furniture / Fixtures',
    'Pest Control',
    'Painting',
    'Garden / Landscaping',
    'Laundry / Dry Cleaning',
    'Garbage / Waste Collection',
    'Water Tanker',
    'OTA / Booking Commission',
    'Payment Gateway Charges',
    'Software / App Subscription',
    'Website / Domain / Hosting',
    'Trade License',
    'FSSAI License',
    'Fire Safety / NOC',
    'Property Tax / Holding Tax',
    'GST / Tax Payment',
    'Professional / Accounting Fees',
    'Legal Fees',
    'Insurance Premium',
    'Bank Charges',
    'Advertising / Promotion',
    'Printing / Signage / Stationery',
    'Transport / Fuel',
    'Vehicle Maintenance',
    'Courier / Postage',
    'Rent / Lease',
    'Guest Refund',
    "Owner's Drawings",
    'Petty Cash',
    'Miscellaneous',
  ];
}
