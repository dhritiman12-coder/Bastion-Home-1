import 'package:flutter/material.dart';

import '../services/account_service.dart';
import '../services/cloud_sync_service.dart';
import 'app_back_button.dart';

class AdminAccessDenied extends StatefulWidget {
  final String resource;

  const AdminAccessDenied({required this.resource, super.key});

  @override
  State<AdminAccessDenied> createState() => _AdminAccessDeniedState();
}

class _AdminAccessDeniedState extends State<AdminAccessDenied> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      CloudSyncService().reportSecurityEvent(
        'settings_access_attempt',
        resource: widget.resource,
        attemptedAction: 'open_admin_screen',
      );
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      leading: const AppBackButton(),
      title: const Text('Administrator Access'),
    ),
    body: Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 440),
          child: Column(
            children: [
              Icon(
                Icons.admin_panel_settings_outlined,
                size: 52,
                color: Theme.of(context).colorScheme.error,
              ),
              const SizedBox(height: 16),
              Text(
                'Administrator approval required',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 10),
              const Text(
                'Employee accounts cannot view or change application settings. This attempt has been added to the administrator security log.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 22),
              FilledButton.icon(
                onPressed: Navigator.of(context).canPop()
                    ? () => Navigator.of(context).pop()
                    : AccountService().logout,
                icon: const Icon(Icons.arrow_back),
                label: const Text('Go Back'),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
