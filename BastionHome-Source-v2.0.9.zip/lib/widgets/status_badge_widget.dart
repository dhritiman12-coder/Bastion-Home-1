import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

enum StatusBadgeType {
  paid,
  partial,
  unpaid,
  neutral,
  booked,
  checkedIn,
  checkedOut,
  cancelled,
  noShow,
  verified,
  unverified,
}

class StatusBadgeWidget extends StatelessWidget {
  final StatusBadgeType type;
  final String? label;

  const StatusBadgeWidget({required this.type, this.label, super.key});

  @override
  Widget build(BuildContext context) {
    final config = _resolveConfig(type);
    final displayLabel = label ?? config.defaultLabel;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: config.bgColor,
        borderRadius: BorderRadius.circular(50),
        border: Border.all(color: config.borderColor, width: 1),
      ),
      child: Text(
        displayLabel,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w600,
          color: config.textColor,
          letterSpacing: 0,
        ),
      ),
    );
  }

  _BadgeConfig _resolveConfig(StatusBadgeType type) {
    switch (type) {
      case StatusBadgeType.paid:
        return _BadgeConfig(
          defaultLabel: 'Paid',
          bgColor: AppTheme.successGreen.withAlpha(31),
          borderColor: AppTheme.successGreen.withAlpha(77),
          textColor: AppTheme.successGreen,
        );
      case StatusBadgeType.partial:
        return _BadgeConfig(
          defaultLabel: 'Partial',
          bgColor: AppTheme.brassAccent.withAlpha(31),
          borderColor: AppTheme.brassAccent.withAlpha(77),
          textColor: AppTheme.brassAccent,
        );
      case StatusBadgeType.unpaid:
        return _BadgeConfig(
          defaultLabel: 'Unpaid',
          bgColor: AppTheme.alertRed.withAlpha(31),
          borderColor: AppTheme.alertRed.withAlpha(77),
          textColor: AppTheme.alertRed,
        );
      case StatusBadgeType.neutral:
        return _BadgeConfig(
          defaultLabel: '—',
          bgColor: const Color(0xFFF0EEE9),
          borderColor: const Color(0xFFDDD8CF),
          textColor: const Color(0xFF7B8A86),
        );
      case StatusBadgeType.booked:
        return _BadgeConfig(
          defaultLabel: 'Booked',
          bgColor: const Color(0xFFE3F0F5),
          borderColor: const Color(0xFFB0D4DF),
          textColor: AppTheme.deepTeal,
        );
      case StatusBadgeType.checkedIn:
        return _BadgeConfig(
          defaultLabel: 'Checked-in',
          bgColor: AppTheme.successGreen.withAlpha(31),
          borderColor: AppTheme.successGreen.withAlpha(77),
          textColor: AppTheme.successGreen,
        );
      case StatusBadgeType.checkedOut:
        return _BadgeConfig(
          defaultLabel: 'Checked-out',
          bgColor: const Color(0xFFF0EEE9),
          borderColor: const Color(0xFFDDD8CF),
          textColor: const Color(0xFF6B7280),
        );
      case StatusBadgeType.cancelled:
        return _BadgeConfig(
          defaultLabel: 'Cancelled',
          bgColor: AppTheme.alertRed.withAlpha(20),
          borderColor: AppTheme.alertRed.withAlpha(51),
          textColor: AppTheme.alertRed,
        );
      case StatusBadgeType.noShow:
        return _BadgeConfig(
          defaultLabel: 'No-show',
          bgColor: const Color(0xFFF5E6CC),
          borderColor: const Color(0xFFE0C080),
          textColor: const Color(0xFF8A5C00),
        );
      case StatusBadgeType.verified:
        return _BadgeConfig(
          defaultLabel: 'Verified',
          bgColor: AppTheme.successGreen.withAlpha(31),
          borderColor: AppTheme.successGreen.withAlpha(77),
          textColor: AppTheme.successGreen,
        );
      case StatusBadgeType.unverified:
        return _BadgeConfig(
          defaultLabel: 'Unverified',
          bgColor: AppTheme.alertRed.withAlpha(31),
          borderColor: AppTheme.alertRed.withAlpha(77),
          textColor: AppTheme.alertRed,
        );
    }
  }
}

class _BadgeConfig {
  final String defaultLabel;
  final Color bgColor;
  final Color borderColor;
  final Color textColor;

  const _BadgeConfig({
    required this.defaultLabel,
    required this.bgColor,
    required this.borderColor,
    required this.textColor,
  });
}
