import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';

import '../presentation/employee_screen/employee_portal_screen.dart';
import '../services/account_service.dart';
import '../services/app_settings_service.dart';
import '../services/cloud_sync_service.dart';
import 'brand_logo.dart';
import 'cloud_enrollment.dart';
import 'credential_text_form_field.dart';

class AppLockGate extends StatefulWidget {
  final Widget child;
  const AppLockGate({required this.child, super.key});

  @override
  State<AppLockGate> createState() => _AppLockGateState();
}

class _AppLockGateState extends State<AppLockGate> with WidgetsBindingObserver {
  final AccountService _accounts = AccountService();
  final CloudSyncService _cloud = CloudSyncService();
  final LocalAuthentication _auth = LocalAuthentication();
  bool _locked = true;
  bool _checkingBiometric = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _tryBiometric());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if ((state == AppLifecycleState.paused ||
            state == AppLifecycleState.detached) &&
        AppSettingsService().lockOnBackground &&
        mounted) {
      setState(() => _locked = true);
    }
    if (state == AppLifecycleState.resumed) _refreshAccessAndUnlock();
  }

  Future<void> _refreshAccessAndUnlock() async {
    if (_cloud.isSignedIn) {
      try {
        await _cloud.refreshMembership();
      } catch (_) {
        // Cached authority keeps offline operation available. A server-side
        // revocation is applied as soon as the service can reconnect.
      }
    }
    await _tryBiometric();
  }

  Future<void> _tryBiometric() async {
    if (!_locked ||
        _checkingBiometric ||
        !_accounts.isInitialized ||
        _accounts.needsSetup ||
        !AppSettingsService().biometricUnlock) {
      return;
    }
    setState(() => _checkingBiometric = true);
    try {
      final supported =
          await _auth.canCheckBiometrics || await _auth.isDeviceSupported();
      if (!supported) return;
      final authenticated = await _auth.authenticate(
        localizedReason: 'Unlock Bastion Home Manager',
        persistAcrossBackgrounding: true,
      );
      if (authenticated && await _accounts.resumeLastUserAfterDeviceAuth()) {
        if (mounted) setState(() => _locked = false);
      }
    } catch (_) {
      // PIN login remains available when device authentication is unavailable.
    } finally {
      if (mounted) setState(() => _checkingBiometric = false);
    }
  }

  void _unlocked() => setState(() => _locked = false);

  void _activatedFromCloud() => setState(() => _locked = false);

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([_accounts, _cloud]),
      builder: (context, _) {
        if (!_accounts.isInitialized) {
          return const Material(
            child: Center(child: CircularProgressIndicator()),
          );
        }
        if (_cloud.isRevoked) {
          return _RevokedAccess(
            onSignOut: () async {
              _accounts.logout();
              await _cloud.signOut();
            },
          );
        }
        if (_accounts.needsSetup ||
            !_cloud.hasCloudAuthority ||
            _cloud.cloudRole == 'unapproved' ||
            !_cloud.hasActiveCloudAuthority ||
            _cloud.mustChangeCloudPassword) {
          return CloudEnrollment(onActivated: _activatedFromCloud);
        }
        if (_locked || _accounts.currentUser == null) {
          return _AccountLogin(
            biometricBusy: _checkingBiometric,
            onBiometric: _tryBiometric,
            onSuccess: _unlocked,
          );
        }
        if (_accounts.isEmployee) {
          return const EmployeePortalScreen();
        }
        return widget.child;
      },
    );
  }
}

class _AccountLogin extends StatefulWidget {
  final bool biometricBusy;
  final VoidCallback onBiometric;
  final VoidCallback onSuccess;
  const _AccountLogin({
    required this.biometricBusy,
    required this.onBiometric,
    required this.onSuccess,
  });

  @override
  State<_AccountLogin> createState() => _AccountLoginState();
}

class _RevokedAccess extends StatelessWidget {
  final Future<void> Function() onSignOut;
  const _RevokedAccess({required this.onSignOut});

  @override
  Widget build(BuildContext context) => Material(
    color: Theme.of(context).scaffoldBackgroundColor,
    child: SafeArea(
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 440),
            child: Column(
              children: [
                const BrandLogo(height: 78),
                const SizedBox(height: 24),
                Icon(
                  Icons.block_outlined,
                  size: 48,
                  color: Theme.of(context).colorScheme.error,
                ),
                const SizedBox(height: 14),
                Text(
                  'Business Access Disabled',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                const SizedBox(height: 10),
                const Text(
                  'The primary owner has disabled this account. Business records and synchronization are locked on this phone.',
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 22),
                FilledButton.icon(
                  onPressed: onSignOut,
                  icon: const Icon(Icons.logout),
                  label: const Text('Sign In With Another Account'),
                ),
              ],
            ),
          ),
        ),
      ),
    ),
  );
}

class _AccountLoginState extends State<_AccountLogin> {
  final _formKey = GlobalKey<FormState>();
  final _username = TextEditingController();
  final _pin = TextEditingController();
  final _pinFocus = FocusNode();
  bool _signingIn = false;

  @override
  void dispose() {
    _username.dispose();
    _pin.dispose();
    _pinFocus.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _signingIn = true);
    final result = await AccountService().signIn(_username.text, _pin.text);
    if (!mounted) return;
    if (result.needsPasswordChange) {
      // The gate swaps to the secure enrollment screen so the temporary
      // password can be replaced before this account is used.
      setState(() => _signingIn = false);
      return;
    }
    if (!result.ok) {
      setState(() => _signingIn = false);
      _pin.clear();
      _pinFocus.requestFocus();
      TextInput.finishAutofillContext(shouldSave: false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result.message ?? 'Could not sign in')),
      );
      return;
    }
    widget.onSuccess();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Theme.of(context).scaffoldBackgroundColor,
      child: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const BrandLogo(height: 86),
                    const SizedBox(height: 28),
                    Text(
                      'Sign In',
                      style: Theme.of(context).textTheme.headlineMedium,
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 22),
                    CredentialTextFormField(
                      fieldKey: const ValueKey('sign_in_username'),
                      clearButtonKey: const ValueKey('sign_in_username_clear'),
                      controller: _username,
                      labelText: 'Username',
                      prefixIcon: Icons.person_outline,
                      textInputAction: TextInputAction.next,
                      validator: (value) =>
                          value == null || value.trim().isEmpty
                          ? 'Enter your username'
                          : null,
                    ),
                    const SizedBox(height: 14),
                    CredentialTextFormField(
                      fieldKey: const ValueKey('sign_in_pin'),
                      clearButtonKey: const ValueKey('sign_in_pin_clear'),
                      controller: _pin,
                      focusNode: _pinFocus,
                      labelText: 'Password or PIN',
                      prefixIcon: Icons.lock_outline,
                      secret: true,
                      keyboardType: TextInputType.visiblePassword,
                      textInputAction: TextInputAction.done,
                      onFieldSubmitted: (_) => _login(),
                      validator: (value) => value == null || value.isEmpty
                          ? 'Enter your password or PIN'
                          : null,
                    ),
                    const SizedBox(height: 20),
                    FilledButton(
                      key: const ValueKey('sign_in_button'),
                      onPressed: _signingIn ? null : _login,
                      style: FilledButton.styleFrom(
                        minimumSize: const Size.fromHeight(52),
                      ),
                      child: _signingIn
                          ? const SizedBox.square(
                              dimension: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Text('Sign In'),
                    ),
                    if (AppSettingsService().biometricUnlock) ...[
                      const SizedBox(height: 8),
                      TextButton.icon(
                        onPressed: widget.biometricBusy
                            ? null
                            : widget.onBiometric,
                        icon: const Icon(Icons.fingerprint),
                        label: const Text('Use Device Unlock'),
                      ),
                    ],
                    const SizedBox(height: 12),
                    Text(
                      'Any approved account can sign in on any phone. Use your username with your cloud password, or with your PIN on a phone you have already used. Signing in with a different account on a new phone needs an internet connection.',
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'The primary owner\'s username is admin. Other accounts use the username given by the owner.',
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
