import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class AppNavigation extends StatelessWidget {
  final StatefulNavigationShell navigationShell;
  final bool rail;

  const AppNavigation({
    required this.navigationShell,
    this.rail = false,
    super.key,
  });

  static const tabs = <({String label, IconData icon, IconData selectedIcon})>[
    (
      label: 'Dashboard',
      icon: Icons.dashboard_outlined,
      selectedIcon: Icons.dashboard_rounded,
    ),
    (
      label: 'Bookings',
      icon: Icons.bed_outlined,
      selectedIcon: Icons.bed_rounded,
    ),
    (
      label: 'Occupancy',
      icon: Icons.grid_view_outlined,
      selectedIcon: Icons.grid_view_rounded,
    ),
    (
      label: 'Expenses',
      icon: Icons.receipt_long_outlined,
      selectedIcon: Icons.receipt_long_rounded,
    ),
    (label: 'More', icon: Icons.more_horiz, selectedIcon: Icons.more),
  ];

  void _select(int index) {
    navigationShell.goBranch(
      index,
      initialLocation: index == navigationShell.currentIndex,
    );
  }

  @override
  Widget build(BuildContext context) {
    if (rail) {
      return NavigationRail(
        selectedIndex: navigationShell.currentIndex,
        onDestinationSelected: _select,
        labelType: NavigationRailLabelType.all,
        leading: const Padding(
          padding: EdgeInsets.only(top: 12, bottom: 16),
          child: Icon(Icons.shield_outlined, size: 30),
        ),
        destinations: [
          for (final tab in tabs)
            NavigationRailDestination(
              icon: Icon(tab.icon),
              selectedIcon: Icon(tab.selectedIcon),
              label: Text(tab.label),
            ),
        ],
      );
    }

    final colors = Theme.of(context).colorScheme;
    return Material(
      color: colors.surface,
      elevation: 3,
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 72,
          child: Row(
            children: List.generate(tabs.length, (index) {
              final selected = navigationShell.currentIndex == index;
              final tab = tabs[index];
              return Expanded(
                child: Semantics(
                  selected: selected,
                  button: true,
                  label: tab.label,
                  child: InkWell(
                    onTap: () => _select(index),
                    borderRadius: BorderRadius.circular(8),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          selected ? tab.selectedIcon : tab.icon,
                          color: selected
                              ? colors.primary
                              : colors.onSurfaceVariant,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          tab.label,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.labelSmall
                              ?.copyWith(
                                color: selected
                                    ? colors.primary
                                    : colors.onSurfaceVariant,
                                fontWeight: selected
                                    ? FontWeight.w700
                                    : FontWeight.w500,
                              ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }
}
