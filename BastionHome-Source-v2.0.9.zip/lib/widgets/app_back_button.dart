import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../routes/app_routes.dart';

class AppBackButton extends StatelessWidget {
  final Color? color;
  final VoidCallback? onPressed;
  final String fallbackLocation;

  const AppBackButton({
    super.key,
    this.color,
    this.onPressed,
    this.fallbackLocation = AppRoutes.initial,
  });

  void _goBack(BuildContext context) {
    if (onPressed != null) {
      onPressed!();
      return;
    }
    final navigator = Navigator.of(context);
    if (navigator.canPop()) {
      navigator.maybePop();
      return;
    }
    context.go(fallbackLocation);
  }

  @override
  Widget build(BuildContext context) => IconButton(
    tooltip: 'Back to previous page',
    onPressed: () => _goBack(context),
    icon: Icon(Icons.arrow_back_rounded, color: color),
  );
}
