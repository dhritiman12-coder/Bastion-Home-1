import 'package:flutter/material.dart';

import '../services/account_service.dart';
import '../services/cloud_sync_service.dart';

Future<bool> confirmMoveToTrash(
  BuildContext context, {
  required String itemName,
}) async {
  if (!AccountService().isAdmin) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Only an administrator can delete records.'),
      ),
    );
    return false;
  }
  final cloud = CloudSyncService();
  if (cloud.isConnected && !cloud.isCloudAdmin) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'This phone has employee cloud access. Delete records from an administrator device.',
        ),
      ),
    );
    return false;
  }
  return await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          icon: const Icon(Icons.delete_outline),
          title: const Text('Move to Trash?'),
          content: Text(
            '$itemName will be removed from the app and kept in Trash for '
            '7 days. An administrator can restore it during that time. '
            'After 7 days it will be permanently removed from every '
            'synchronized device.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancel'),
            ),
            FilledButton.icon(
              onPressed: () => Navigator.pop(dialogContext, true),
              icon: const Icon(Icons.delete_outline),
              label: const Text('Move to Trash'),
            ),
          ],
        ),
      ) ??
      false;
}
