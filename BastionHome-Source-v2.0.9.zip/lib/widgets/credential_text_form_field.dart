import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class CredentialTextFormField extends StatefulWidget {
  final TextEditingController controller;
  final Key? fieldKey;
  final Key? clearButtonKey;
  final String labelText;
  final String? helperText;
  final IconData? prefixIcon;
  final bool secret;
  final bool enabled;
  final bool autofocus;
  final TextInputType? keyboardType;
  final TextInputAction? textInputAction;
  final List<TextInputFormatter>? inputFormatters;
  final FormFieldValidator<String>? validator;
  final ValueChanged<String>? onChanged;
  final ValueChanged<String>? onFieldSubmitted;
  final FocusNode? focusNode;

  const CredentialTextFormField({
    required this.controller,
    required this.labelText,
    this.fieldKey,
    this.clearButtonKey,
    this.helperText,
    this.prefixIcon,
    this.secret = false,
    this.enabled = true,
    this.autofocus = false,
    this.keyboardType,
    this.textInputAction,
    this.inputFormatters,
    this.validator,
    this.onChanged,
    this.onFieldSubmitted,
    this.focusNode,
    super.key,
  });

  @override
  State<CredentialTextFormField> createState() =>
      _CredentialTextFormFieldState();
}

class _CredentialTextFormFieldState extends State<CredentialTextFormField> {
  bool _obscure = true;

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_controllerChanged);
  }

  @override
  void didUpdateWidget(CredentialTextFormField oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != widget.controller) {
      oldWidget.controller.removeListener(_controllerChanged);
      widget.controller.addListener(_controllerChanged);
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_controllerChanged);
    super.dispose();
  }

  void _controllerChanged() {
    if (mounted) setState(() {});
  }

  void _clear() {
    widget.controller.value = TextEditingValue.empty;
    widget.onChanged?.call('');
    widget.focusNode?.requestFocus();
  }

  void _handleChanged(String value) {
    final editingValue = widget.controller.value;
    if (!editingValue.composing.isCollapsed) {
      widget.controller.value = editingValue.copyWith(
        composing: TextRange.empty,
      );
    }
    widget.onChanged?.call(value);
  }

  @override
  Widget build(BuildContext context) {
    final actions = <Widget>[
      if (widget.controller.text.isNotEmpty)
        IconButton(
          key: widget.clearButtonKey,
          tooltip: 'Clear ${widget.labelText.toLowerCase()}',
          onPressed: widget.enabled ? _clear : null,
          icon: const Icon(Icons.clear),
        ),
      if (widget.secret)
        IconButton(
          tooltip: _obscure
              ? 'Show ${widget.labelText}'
              : 'Hide ${widget.labelText}',
          onPressed: widget.enabled
              ? () => setState(() => _obscure = !_obscure)
              : null,
          icon: Icon(
            _obscure
                ? Icons.visibility_outlined
                : Icons.visibility_off_outlined,
          ),
        ),
    ];

    return TextFormField(
      key: widget.fieldKey,
      controller: widget.controller,
      focusNode: widget.focusNode,
      enabled: widget.enabled,
      autofocus: widget.autofocus,
      obscureText: widget.secret && _obscure,
      autocorrect: false,
      enableSuggestions: false,
      enableIMEPersonalizedLearning: false,
      smartDashesType: SmartDashesType.disabled,
      smartQuotesType: SmartQuotesType.disabled,
      keyboardType: widget.keyboardType ?? TextInputType.visiblePassword,
      textInputAction: widget.textInputAction,
      inputFormatters: widget.inputFormatters,
      autofillHints: const <String>[],
      onChanged: _handleChanged,
      onFieldSubmitted: widget.onFieldSubmitted,
      validator: widget.validator,
      decoration: InputDecoration(
        labelText: widget.labelText,
        helperText: widget.helperText,
        prefixIcon: widget.prefixIcon == null ? null : Icon(widget.prefixIcon),
        suffixIcon: actions.isEmpty
            ? null
            : Row(mainAxisSize: MainAxisSize.min, children: actions),
        suffixIconConstraints: const BoxConstraints(minHeight: 48),
      ),
    );
  }
}
