import 'dart:convert';

import 'package:flutter/material.dart';

import '../services/logo_service.dart';

class BrandLogo extends StatelessWidget {
  const BrandLogo({
    super.key,
    this.width,
    this.height,
    this.fit = BoxFit.contain,
    this.alignment = Alignment.center,
  });

  static const assetPath = 'assets/images/bastion_home_official_logo.png';

  final double? width;
  final double? height;
  final BoxFit fit;
  final AlignmentGeometry alignment;

  @override
  Widget build(BuildContext context) {
    final service = LogoService();
    return AnimatedBuilder(
      animation: service,
      builder: (context, _) => FutureBuilder<String?>(
        future: service.getLogoPath(),
        builder: (context, snapshot) {
          final custom = snapshot.data;
          if (custom != null && custom.startsWith('data:')) {
            final separator = custom.indexOf(',');
            if (separator > 0) {
              try {
                return Image.memory(
                  base64Decode(custom.substring(separator + 1)),
                  width: width,
                  height: height,
                  fit: fit,
                  alignment: alignment,
                  filterQuality: FilterQuality.high,
                  semanticLabel: 'Property logo',
                  errorBuilder: (_, __, ___) => _officialLogo(),
                );
              } catch (_) {
                return _officialLogo();
              }
            }
          }
          return _officialLogo();
        },
      ),
    );
  }

  Widget _officialLogo() => Image.asset(
    assetPath,
    width: width,
    height: height,
    fit: fit,
    alignment: alignment,
    filterQuality: FilterQuality.high,
    semanticLabel: 'Bastion Home',
  );
}
