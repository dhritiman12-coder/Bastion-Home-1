import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../services/account_service.dart';
import '../services/cloud_sync_service.dart';
import 'brand_logo.dart';
import 'credential_text_form_field.dart';

class CloudEnrollment extends StatefulWidget {
  final VoidCallback? onActivated;
  const CloudEnrollment({this.onActivated, super.key});

  @override
  State<CloudEnrollment> createState() => _CloudEnrollmentState();
}

class _CloudEnrollmentState extends State<CloudEnrollment> {
  final _sync = CloudSyncService();
  final _url = TextEditingController(
    text: 'https://okvtvqoxymkmralfuonn.supabase.co',
  );
  final _key = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _newCloudPassword = TextEditingController();
  final _confirmCloudPassword = TextEditingController();
  final _displayName = TextEditingController();
  final _propertyName = TextEditingController(text: 'Bastion Home');
  final _username = TextEditingController();
  final _pin = TextEditingController();
  final _confirmPin = TextEditingController();
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _url.text = _sync.projectUrl ?? _url.text;
    _displayName.text = _sync.memberDisplayName ?? '';
  }

  @override
  void dispose() {
    _url.dispose();
    _key.dispose();
    _email.dispose();
    _password.dispose();
    _newCloudPassword.dispose();
    _confirmCloudPassword.dispose();
    _displayName.dispose();
    _propertyName.dispose();
    _username.dispose();
    _pin.dispose();
    _confirmPin.dispose();
    super.dispose();
  }

  Future<void> _run(
    Future<void> Function() action, {
    TextEditingController? clearOnError,
  }) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await action();
    } catch (error) {
      clearOnError?.clear();
      TextInput.finishAutofillContext(shouldSave: false);
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(_cleanError(error))));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _cleanError(Object error) => error
      .toString()
      .replaceFirst('Invalid argument(s): ', '')
      .replaceFirst('Bad state: ', '')
      .replaceFirst('AuthException(message: ', '')
      .replaceFirst(RegExp(r', statusCode:.*$'), '');

  Future<void> _configure() => _run(
    () => _sync.configureProject(url: _url.text, publishableKey: _key.text),
  );

  Future<void> _signIn() => _run(
    () => _sync.signIn(identifier: _email.text, password: _password.text),
    clearOnError: _password,
  );

  Future<void> _createOwnerWorkspace() => _run(() async {
    if (_displayName.text.trim().length < 2) {
      throw ArgumentError('Enter the owner name.');
    }
    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        icon: const Icon(Icons.verified_user_outlined),
        title: const Text('Create the owner workspace?'),
        content: const Text(
          'Use this only for the business owner. This cloud account will become the protected primary administrator and will control all other access.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Create Owner Workspace'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await _sync.createWorkspace(_propertyName.text);
    await _sync.updateMyDisplayName(_displayName.text);
  });

  Future<void> _finishEnrollment() => _run(() async {
    if (_pin.text != _confirmPin.text) {
      throw ArgumentError('The PINs do not match.');
    }
    final role = AccountService.roleForCloudAuthority(_sync.cloudRole);
    final username = switch (role) {
      null => '',
      _ when role.name == 'primaryAdmin' => 'admin',
      _ when role.name == 'backupAdmin' =>
        _sync.sessionUsername ?? 'backup-admin',
      _ => _sync.memberUsername ?? _username.text,
    };
    final displayName = _displayName.text.trim().isEmpty
        ? (_sync.memberDisplayName ?? '')
        : _displayName.text.trim();
    if (displayName != _sync.memberDisplayName) {
      await _sync.updateMyDisplayName(displayName);
    }
    final accounts = AccountService();
    await accounts.createCloudEnrolledAccount(
      username: username,
      displayName: displayName,
      pin: _pin.text,
    );
    final signedIn = await accounts.authenticate(username, _pin.text);
    if (signedIn == null) {
      throw StateError('The device account could not be activated.');
    }
    widget.onActivated?.call();
  });

  Future<void> _changeTemporaryPassword() => _run(() async {
    if (_newCloudPassword.text != _confirmCloudPassword.text) {
      throw ArgumentError('The new passwords do not match.');
    }
    final newPassword = _newCloudPassword.text;
    final onActivated = widget.onActivated;
    await _sync.changeCloudPassword(
      currentPassword: _password.text,
      newPassword: newPassword,
    );
    // Changing the password updates the cloud status, which can replace this
    // screen before the code below runs, so avoid touching the controllers.
    final username = _sync.sessionUsername;
    if (username == null) return;
    // The new password becomes this account's sign-in secret on this phone.
    final result = await AccountService().signIn(username, newPassword);
    if (result.ok) onActivated?.call();
  });

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: _sync,
    builder: (context, _) => Material(
      color: Theme.of(context).scaffoldBackgroundColor,
      child: SafeArea(
        child: AbsorbPointer(
          absorbing: _busy,
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 520),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const BrandLogo(height: 78),
                    const SizedBox(height: 22),
                    Text(
                      'Secure Business Enrollment',
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _headingMessage(),
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    const SizedBox(height: 24),
                    if (!_sync.isConfigured) _projectStep(),
                    if (_sync.isConfigured && !_sync.isSignedIn) _accountStep(),
                    if (_sync.isSignedIn && !_sync.isConnected)
                      _workspaceStep(),
                    if (_sync.isConnected &&
                        !_sync.isRevoked &&
                        _sync.mustChangeCloudPassword)
                      _temporaryPasswordStep(),
                    if (_sync.isConnected &&
                        !_sync.isRevoked &&
                        !_sync.mustChangeCloudPassword)
                      _devicePinStep(),
                    if (_sync.isRevoked) _revokedStep(),
                    if (_busy) ...[
                      const SizedBox(height: 20),
                      const Center(child: CircularProgressIndicator()),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    ),
  );

  String _headingMessage() {
    if (_sync.isRevoked) return 'This account no longer has business access.';
    if (_sync.isConnected) {
      return 'Cloud approval is confirmed. Create a private PIN for this phone.';
    }
    return 'Use any approved administrator or employee username and cloud password.';
  }

  Widget _projectStep() => _section(
    icon: Icons.cloud_outlined,
    title: 'Connect Bastion Home Cloud',
    children: [
      const Text(
        'Use the official project details supplied with this business. Never enter a secret or service-role key.',
      ),
      const SizedBox(height: 14),
      TextField(
        controller: _url,
        autocorrect: false,
        keyboardType: TextInputType.url,
        decoration: const InputDecoration(labelText: 'Project URL'),
      ),
      const SizedBox(height: 12),
      TextField(
        controller: _key,
        autocorrect: false,
        decoration: const InputDecoration(labelText: 'Publishable key'),
      ),
      const SizedBox(height: 16),
      FilledButton.icon(
        onPressed: _configure,
        icon: const Icon(Icons.link),
        label: const Text('Connect Secure Business'),
      ),
    ],
  );

  Widget _accountStep() => _section(
    icon: Icons.account_circle_outlined,
    title: 'Sign In to an Approved Account',
    children: [
      CredentialTextFormField(
        controller: _email,
        labelText: 'Username or owner email',
        keyboardType: TextInputType.emailAddress,
      ),
      const SizedBox(height: 12),
      CredentialTextFormField(
        controller: _password,
        labelText: 'Password',
        secret: true,
        textInputAction: TextInputAction.done,
        onFieldSubmitted: (_) => _signIn(),
      ),
      const SizedBox(height: 16),
      FilledButton.icon(
        onPressed: _signIn,
        icon: const Icon(Icons.login),
        label: const Text('Sign In'),
      ),
      const SizedBox(height: 8),
      const Text(
        'Use admin for the primary owner. Employee accounts are created and approved by the primary owner.',
        textAlign: TextAlign.center,
      ),
    ],
  );

  Widget _workspaceStep() => _section(
    icon: Icons.business_outlined,
    title: 'Owner Approval',
    children: [
      TextField(
        controller: _displayName,
        textCapitalization: TextCapitalization.words,
        decoration: const InputDecoration(labelText: 'Your full name'),
      ),
      const SizedBox(height: 12),
      const Text(
        'No approved membership was found. Employee accounts must be created by the primary owner.',
      ),
      const SizedBox(height: 18),
      TextField(
        controller: _propertyName,
        decoration: const InputDecoration(labelText: 'Business name'),
      ),
      const SizedBox(height: 10),
      OutlinedButton.icon(
        onPressed: _createOwnerWorkspace,
        icon: const Icon(Icons.verified_user_outlined),
        label: const Text('First-Time Owner Setup'),
      ),
      TextButton(
        onPressed: () => _run(_sync.signOut),
        child: const Text('Use a different cloud account'),
      ),
    ],
  );

  Widget _devicePinStep() {
    final role = AccountService.roleForCloudAuthority(_sync.cloudRole);
    final fixedUsername =
        _sync.memberUsername ??
        (role?.name == 'primaryAdmin'
            ? 'admin'
            : role?.name == 'backupAdmin'
            ? 'backup-admin'
            : null);
    return _section(
      icon: Icons.phonelink_lock_outlined,
      title: 'Protect This Phone',
      children: [
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.verified_outlined),
          title: Text(_sync.memberDisplayName ?? _sync.signedInEmail ?? ''),
          subtitle: Text(_roleLabel(_sync.cloudRole)),
        ),
        TextField(
          controller: _displayName,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(labelText: 'Display name'),
        ),
        const SizedBox(height: 12),
        CredentialTextFormField(
          controller: _username,
          labelText: 'App username',
          enabled: fixedUsername == null,
        ),
        if (fixedUsername != null) ...[
          const SizedBox(height: 6),
          Text(
            'Your protected username is $fixedUsername.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ],
        const SizedBox(height: 12),
        CredentialTextFormField(
          controller: _pin,
          labelText: 'Device PIN (6 to 12 digits)',
          secret: true,
          keyboardType: TextInputType.number,
          inputFormatters: [
            FilteringTextInputFormatter.digitsOnly,
            LengthLimitingTextInputFormatter(12),
          ],
        ),
        const SizedBox(height: 12),
        CredentialTextFormField(
          controller: _confirmPin,
          labelText: 'Confirm device PIN',
          secret: true,
          keyboardType: TextInputType.number,
          inputFormatters: [
            FilteringTextInputFormatter.digitsOnly,
            LengthLimitingTextInputFormatter(12),
          ],
        ),
        const SizedBox(height: 18),
        FilledButton.icon(
          onPressed: _finishEnrollment,
          icon: const Icon(Icons.lock_outline),
          label: const Text('Activate This Phone'),
        ),
        TextButton(
          onPressed: () => _run(_sync.signOut),
          child: const Text('Use a different cloud account'),
        ),
      ],
    );
  }

  Widget _temporaryPasswordStep() => _section(
    icon: Icons.password_outlined,
    title: 'Replace Temporary Password',
    children: [
      const Text(
        'Create your private cloud password before activating this phone. Security changes are recorded in the administrator audit log, but passwords are never recorded.',
      ),
      const SizedBox(height: 14),
      CredentialTextFormField(
        controller: _password,
        labelText: 'Temporary password',
        secret: true,
      ),
      const SizedBox(height: 12),
      CredentialTextFormField(
        controller: _newCloudPassword,
        labelText: 'New password',
        helperText: '10+ characters with uppercase, lowercase, and a number',
        secret: true,
      ),
      const SizedBox(height: 12),
      CredentialTextFormField(
        controller: _confirmCloudPassword,
        labelText: 'Confirm new password',
        secret: true,
      ),
      const SizedBox(height: 18),
      FilledButton.icon(
        onPressed: _changeTemporaryPassword,
        icon: const Icon(Icons.lock_reset_outlined),
        label: const Text('Save Private Password'),
      ),
    ],
  );

  Widget _revokedStep() => _section(
    icon: Icons.block_outlined,
    title: 'Access Disabled',
    children: [
      const Text(
        'The business owner has disabled this account. No business records can be opened or synchronized on this phone.',
      ),
      const SizedBox(height: 14),
      OutlinedButton.icon(
        onPressed: () => _run(_sync.signOut),
        icon: const Icon(Icons.logout),
        label: const Text('Sign In With Another Approved Account'),
      ),
    ],
  );

  Widget _section({
    required IconData icon,
    required String title,
    required List<Widget> children,
  }) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      Row(
        children: [
          Icon(icon, size: 22),
          const SizedBox(width: 10),
          Expanded(
            child: Text(title, style: Theme.of(context).textTheme.titleLarge),
          ),
        ],
      ),
      const SizedBox(height: 14),
      ...children,
    ],
  );

  String _roleLabel(String? role) => switch (role) {
    'primary_admin' => 'Protected primary owner',
    'backup_admin' => 'Backup administrator',
    'admin' => 'Administrator',
    'employee' => 'Employee',
    _ => 'Workspace member',
  };
}
