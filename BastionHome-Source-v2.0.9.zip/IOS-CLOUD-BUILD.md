# Build the iOS IPA without owning a Mac

The repository includes `codemagic.yaml`, which runs the iOS release build on a
Codemagic cloud Mac. It produces a signed IPA for TestFlight or App Store
distribution using bundle identifier `in.bastionhome.manager` and iOS 15 as the
minimum supported version.

## Required owner accounts

1. An active Apple Developer Program membership.
2. An App Store Connect API key with App Manager access.
3. A private GitHub, GitLab, or Bitbucket repository containing this source.
4. A Codemagic account connected to that repository.

Apple requires its own certificate and provisioning profile for every IPA that
can be installed on a real iPhone. Codemagic creates or fetches those files on
the cloud Mac; the repository never stores them.

## One-time Apple setup

1. In App Store Connect, open **Users and Access > Integrations > App Store
   Connect API**.
2. Create a key named **Bastion Home Codemagic** with **App Manager** access.
3. Download the `.p8` private key immediately. Apple permits this download only
   once.
4. Record the displayed **Issuer ID** and **Key ID**.
5. In Apple Developer **Certificates, Identifiers & Profiles**, register an
   explicit App ID using `in.bastionhome.manager` if it does not already exist.

## One-time Codemagic setup

1. Add the private source repository to Codemagic as a Flutter application.
2. Open **Environment variables** for the application and create a group named
   `appstore_credentials`.
3. Add these three variables to that group and mark every one as **Secret**:

   - `APP_STORE_CONNECT_ISSUER_ID`: the Issuer ID from Apple.
   - `APP_STORE_CONNECT_KEY_IDENTIFIER`: the Key ID from Apple.
   - `APP_STORE_CONNECT_PRIVATE_KEY`: the complete contents of the downloaded
     `.p8` file, including its BEGIN and END lines.

4. Start the **Bastion Home iOS Release** workflow manually.

The workflow installs dependencies, runs analysis and automated tests, creates
or fetches the App Store distribution certificate and provisioning profile,
and builds the signed IPA. After a successful run, download the `.ipa` from the
build's **Artifacts** section.

## Installation and distribution

An App Store-signed IPA is distributed through TestFlight or the App Store; it
cannot normally be opened directly from the iPhone Downloads folder. Create the
app record in App Store Connect with bundle ID `in.bastionhome.manager`, upload
the IPA, and add the intended users as TestFlight testers.

For direct installation on registered devices instead, change the workflow's
signing type from `IOS_APP_STORE` to `IOS_APP_ADHOC`, register each iPhone's
UDID in Apple Developer, and build again.

Keep the Apple API private key only in Apple/Codemagic secret storage. Never
commit it to this repository or send it in chat.

