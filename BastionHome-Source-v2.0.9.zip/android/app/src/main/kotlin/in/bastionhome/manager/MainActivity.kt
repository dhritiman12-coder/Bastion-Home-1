package `in`.bastionhome.manager

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileInputStream

class MainActivity : FlutterFragmentActivity() {
    companion object {
        private const val DOWNLOAD_CHANNEL = "in.bastionhome.manager/downloads"
        private const val WRITE_DOWNLOAD_REQUEST = 4172
    }

    private var pendingCall: MethodCall? = null
    private var pendingResult: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, DOWNLOAD_CHANNEL)
            .setMethodCallHandler { call, result ->
                if (call.method != "saveFile") {
                    result.notImplemented()
                    return@setMethodCallHandler
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ||
                    ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    ) == PackageManager.PERMISSION_GRANTED
                ) {
                    saveFile(call, result)
                } else {
                    if (pendingResult != null) {
                        result.error("download_busy", "Another download is still in progress", null)
                        return@setMethodCallHandler
                    }
                    pendingCall = call
                    pendingResult = result
                    ActivityCompat.requestPermissions(
                        this,
                        arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                        WRITE_DOWNLOAD_REQUEST,
                    )
                }
            }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != WRITE_DOWNLOAD_REQUEST) return
        val call = pendingCall
        val result = pendingResult
        pendingCall = null
        pendingResult = null
        if (call == null || result == null) return
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            saveFile(call, result)
        } else {
            result.error(
                "download_permission_denied",
                "Storage permission is required to save files in Downloads on Android 8 and 9",
                null,
            )
        }
    }

    private fun saveFile(call: MethodCall, result: MethodChannel.Result) {
        val sourcePath = call.argument<String>("sourcePath")
        val requestedName = call.argument<String>("fileName")
        val mimeType = call.argument<String>("mimeType") ?: "application/octet-stream"
        if (sourcePath.isNullOrBlank() || requestedName.isNullOrBlank()) {
            result.error("invalid_download", "Download file information is missing", null)
            return
        }
        val source = File(sourcePath)
        if (!source.isFile) {
            result.error("missing_download", "The generated download file is missing", null)
            return
        }
        val fileName = File(requestedName).name
        if (fileName.isBlank()) {
            result.error("invalid_download", "The download file name is invalid", null)
            return
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                saveWithMediaStore(source, fileName, mimeType, result)
            } else {
                saveLegacy(source, fileName, mimeType, result)
            }
        } catch (error: Exception) {
            result.error("download_failed", error.message ?: "Could not save the download", null)
        }
    }

    private fun saveWithMediaStore(
        source: File,
        fileName: String,
        mimeType: String,
        result: MethodChannel.Result,
    ) {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Could not create the Downloads file")
        try {
            contentResolver.openOutputStream(uri, "w")?.use { output ->
                FileInputStream(source).use { input -> input.copyTo(output) }
            } ?: throw IllegalStateException("Could not open the Downloads file")
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            result.success("Downloads/$fileName")
        } catch (error: Exception) {
            contentResolver.delete(uri, null, null)
            throw error
        }
    }

    @Suppress("DEPRECATION")
    private fun saveLegacy(
        source: File,
        fileName: String,
        mimeType: String,
        result: MethodChannel.Result,
    ) {
        val downloads = Environment.getExternalStoragePublicDirectory(
            Environment.DIRECTORY_DOWNLOADS,
        )
        if (!downloads.exists() && !downloads.mkdirs()) {
            throw IllegalStateException("Could not open the Downloads folder")
        }
        val destination = uniqueFile(downloads, fileName)
        FileInputStream(source).use { input ->
            destination.outputStream().use { output -> input.copyTo(output) }
        }
        MediaScannerConnection.scanFile(
            this,
            arrayOf(destination.absolutePath),
            arrayOf(mimeType),
            null,
        )
        result.success("Downloads/${destination.name}")
    }

    private fun uniqueFile(directory: File, fileName: String): File {
        val initial = File(directory, fileName)
        if (!initial.exists()) return initial
        val dot = fileName.lastIndexOf('.')
        val stem = if (dot > 0) fileName.substring(0, dot) else fileName
        val extension = if (dot > 0) fileName.substring(dot) else ""
        for (suffix in 2..9999) {
            val candidate = File(directory, "$stem ($suffix)$extension")
            if (!candidate.exists()) return candidate
        }
        throw IllegalStateException("Could not create a unique download name")
    }
}
