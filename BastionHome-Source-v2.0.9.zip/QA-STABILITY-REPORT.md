# Bastion Home Manager v2.0.6 Stability Report

Audit date: 5 October 2026

## Release decision

The audited source passes the available automated, database, security, layout,
and Android release-build gates. No known release-blocking defect remains in the
tested scope. Absolute defect-free operation cannot be guaranteed without the
physical-device and live-cloud tests listed under Remaining verification.

## High-risk defects fixed

- Prevented booking and guest-ID forms from deleting persisted ID images before
  Save, and cleaned up temporary captures when a form is cancelled.
- Recovered Android camera results after activity recreation without leaving the
  form in an invalid state.
- Added disposal guards to asynchronous invoice, expense, guest-ID, branding,
  rate, payment, and occupancy loads to prevent `setState`-after-dispose crashes.
- Prevented stale month/week queries from overwriting newer occupancy or expense
  results after rapid navigation.
- Replaced an endless startup spinner with a safe failure screen and retry path
  when encrypted storage or the local database cannot open.
- Validated booking charges, discounts, payments, refunds, and expenses against
  negative, zero, non-finite, and excessive values as applicable.
- Replaced per-booking payment queries with one aggregate query, removing a major
  large-dataset performance bottleneck.
- Added backup preflight checks, size and nesting limits, safe ID-image names,
  staged encrypted image restoration, and cleanup after failed imports.
- Bounded restored settings, fonts, scales, times, tax values, and embedded logos
  so damaged backups cannot break dropdowns, layouts, or preferences.
- Added PIN lockout after repeated failures, service-level account authorization,
  username validation, and protection against disabling the backup administrator.
- Fixed cloud refund acceptance, malformed Realtime payload handling, dropped
  sync requests, session/workspace races, stable pagination, and offline purge
  propagation that could otherwise resurrect deleted records.
- Stopped the post-sign-in dashboard flicker by suppressing no-op cloud writes,
  ignoring this phone's own Realtime echoes, and keeping dashboard content
  visible while background synchronization refreshes its data.
- Hardened Supabase row-level security so employees cannot read unrelated records
  or turn an unauthorized update into an allowed entity type.
- Removed account enumeration from sign-in. Every administrator and employee now
  signs in by entering their private username and PIN directly.
- Added a back control to Payments and replaced fixed payment-page colors with
  theme-aware high-contrast text, icons, fields, filters, summaries, and cards.
- Applied explicit readable text colors to application typography in both light
  and dark themes, including user-selected font families and scaling.
- Allowed administrators to delete shipped example records after the standard
  confirmation; these records follow the same seven-day Trash and restore rules
  as other business data.
- Added administrator deletion of employee sign-in accounts with confirmation,
  while preventing the action from deleting any administrator account or the
  business records previously entered by that employee.
- Added a Trash action to booking cards so example and regular bookings can be
  deleted and restored consistently with payments, expenses, stock, IDs, and
  seasonal rates.
- Added startup repair for the protected `admin` and `backup-admin` accounts so
  an older or damaged stored role cannot make the backup administrator appear as
  the primary administrator or hide the primary administrator from sign-in.
- Moved monthly booking-serial allocation into the successful database save so
  opening or abandoning a form cannot consume a number. New bookings reuse the
  lowest available number after deletion, and local, Trash-restored, or
  cloud-received bookings are prevented from creating duplicate serials.
- Made guest ID Number mandatory for every new booking in both the visible form
  and the booking repository, preventing alternate save paths from bypassing the
  requirement while leaving older records editable.
- Added automatic, account-specific attribution to new bookings, payments, and
  daily expenses using both employee display name and username. Existing
  attribution is preserved during edits and the attribution fields are read-only.
- Added a per-employee administrator activity view covering guests processed,
  payments recorded, and daily expenses recorded, with attribution matching that
  remains valid for legacy display-name-only records.
- Added an immediate employee-account lock for suspected misuse. Administrators
  can keep the activity history and business records, reset the employee PIN
  without knowing the old PIN, restore access, or delete the employee account.
- Added an explicit Online or Offline / Walk-in source to every booking, with the
  source visible in booking lists, customer details, and invoices.
- Blocked overlapping active bookings for the same room and dates in the form,
  local repository, cloud database trigger, and public website booking function.
  The website path uses a transaction-level room lock so simultaneous website
  and walk-in attempts cannot both reserve the same room.
- Added an administrator-only Website Booking settings screen for enabling the
  channel, restricting the permitted website origin, and rotating or revoking
  the private channel secret.
- Added a public Supabase Edge Function and reusable website client supporting
  availability checks and online booking submission without exposing privileged
  database credentials in a browser.
- Replaced viewport-scaled body text across the application with stable logical
  sizes and made dense booking fields wrap on narrow phones, preventing labels,
  room numbers, controls, and values from overflowing their frames.
- Disabled unused mobile authentication deep-link detection so email/PIN cloud
  sessions do not depend on an unnecessary Android native bridge.
- Added other room occupant names to bookings, backups, Trash restore, live
  synchronization, website submissions, booking details, and calendar details.
- Added a downloadable/shareable guest-stay PDF for each booking. It includes
  property branding, primary guest and occupant names, contact/address, room,
  check-in/check-out dates and times, status/source, masked ID information,
  locally available encrypted ID photos, notes, and processing employee while
  excluding tariffs, charges, payments, discounts, and other monetary data.
- Replaced fresh-device local administrator creation with cloud-authorized
  enrollment. A new phone must now sign in to an approved Supabase identity and
  join the owner's workspace before it can create a local device PIN.
- Made the cloud workspace role authoritative over every local account. A local
  administrator PIN cannot elevate an employee, an unapproved identity, or a
  disabled member into administrator access.
- Protected the primary owner from deactivation or demotion and replaced staff
  self-registration and invitation codes with owner-created, preapproved cloud
  usernames and temporary passwords. Temporary passwords must be changed after
  first sign-in, and passwords themselves are never stored in audit records.
- Added a live Business Access roster where the primary owner can immediately
  disable or restore a member and select each employee permission. Disabled
  memberships are rejected by database row-level security on every device.
- Embedded only the safe Supabase project URL and publishable client key so new
  phones connect to the correct Bastion Home cloud without technical setup. No
  service-role or database secret is included in the app.
- Added an administrator-only Customer Master that groups formatting variants of
  an Indian phone number, searches names, phones, booking IDs, occupant names,
  and monthly serials, and filters booking history by month or year.
- Preserved monthly serial allocation in `N/MM-YYYY` format and verified that
  numbering restarts independently for every month and every calendar year.
- Added immutable capture dates and one-year minimum protection for encrypted ID
  photos. Protected photos cannot be replaced early, and ID-bearing Trash items
  remain recoverable until the later of seven days or the retention anniversary.
- Consolidated guest PDFs, invoices, analytics CSV files, and JSON/CSV backups
  behind one download service. Android writes to the public Downloads folder,
  web uses the browser's configured Downloads folder, and iOS opens Apple's
  Files export sheet because apps cannot silently write to a global iOS folder.
- Added collision-safe and traversal-safe file names. Android 10+ uses scoped
  MediaStore downloads without storage permission; Android 8-9 requests only
  the legacy write permission required for the public Downloads folder.
- Fixed stale or mistyped username, PIN, and password text across every local
  and cloud credential workflow. Credential fields now provide an explicit
  clear control, reject stale keyboard suggestions and autofill restoration,
  and discard an incorrect secret after a failed sign-in.
- Fixed employee booking and expense actions so they use the current Supabase
  permission record instead of stale local permissions, preserve employee
  username attribution, and request an immediate cloud synchronization after a
  successful save.
- Made an active cloud session and workspace membership mandatory for employee
  access. Cached or signed-out employee accounts are returned to secure cloud
  enrollment and cannot continue through local-only authorization.
- Enforced an administrator-only guard on Settings, Branding, and More screens,
  including deep-link or route-level entry attempts by employee accounts.
- Added persisted security events and administrator alerts for denied actions,
  settings-access attempts, repeated PIN failures, and cloud/local role
  mismatches. Events are rate-limited, derive the actor from the signed JWT, and
  are available in the Workforce Security Log across devices.

## Verification completed

- Flutter static analysis: no issues.
- Automated tests: 77 passed.
- SQLite integration coverage includes protected examples, booking-child cascade,
  Trash restore, seven-day purge behavior, stale-cloud resurrection prevention,
  malformed remote row isolation, silent equal-record and repeated-purge sync,
  backup rejection, and refund aggregation.
- Widget checks cover the startup-failure view at 320 x 568 and 135% text plus
  direct username/PIN sign-in by the protected primary administrator account,
  including clearing and replacing mistyped credentials.
- Narrow-screen widget checks cover the enhanced booking form and website
  booking settings at 320 x 568 and 135% text without overflow exceptions.
- Contrast tests verify WCAG 4.5:1 minimum ratios for primary application text
  and the payment summary in both light and dark themes.
- Locked dependency scan: 160 Pub packages checked against OSV; no known advisory
  was returned.
- Android release APK and AAB built with release signing.
- APK package: `in.bastionhome.manager`.
- Version: `2.0.6` (`versionCode 22`).
- Minimum Android: API 26 / Android 8.0.
- APK architectures: arm64-v8a, armeabi-v7a, and x86_64.
- APK signature scheme v2 verified; AAB JAR signature verified.
- Signing certificate SHA-256:
  `6A5DECB106EC5385E911A4AD4BCA3529FF3559A3B8E9FA36BA20CDBF8E4B9EA1`.
- Measured line coverage: 16.37% across all source loaded by the test runner. The
  most safety-critical data and validation paths have direct tests; broad visual
  screen coverage remains limited.

## Remaining verification

- Run camera capture/return, gallery selection, biometric lock, notifications,
  Downloads writes, iOS Files export, low-memory background restoration, and
  upgrade installation on physical Android 8, 10, 13, current Android, and iOS
  devices.
- Build, sign, and test the iOS 15+ target on macOS/Xcode. Windows cannot produce
  or validate an installable IPA.
- Exercise the deployed website endpoint plus two or more real phones under
  administrator and employee accounts, including concurrent booking attempts,
  offline edits, reconnects, and long-running Realtime sessions. Local pgTAP
  execution remains unavailable because this machine has no running
  Docker/Postgres service.
- Schedule a future Gradle 9.1 / Android Gradle Plugin 9 migration. The current
  toolchain builds successfully but Flutter reports that current-version support
  will be removed in a later Flutter release.

## Cloud activation

The hardened authority and owner-managed account schema migrations were activated
and verified in Supabase project `okvtvqoxymkmralfuonn` on 4 October 2026.
Version 2.0.6 contains only safe public connection details. The privileged
`manage-workforce` Edge Function was deployed on 5 October 2026 with legacy JWT
verification disabled and modern signed-user authentication enforced inside the
function. A live anonymous-call test reached the function and was rejected with
HTTP 401. The deployed handler reads the normalized authenticated `userClaims.id`
with a raw JWT `sub` fallback, then verifies that every workforce action comes
from the active primary owner. The employee security-event migration and updated
function were deployed on 5 October 2026; employee-originated alerts derive the
actor from the JWT and do not grant any workforce-management privilege. Never
place a service-role key in the mobile app or website JavaScript.
